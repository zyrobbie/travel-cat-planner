# E4-E v07 independent storage and deployment gates

Authoritative Linux preparation is [linux/README.md](linux/README.md). This is local candidate work, not a deployment receipt. No real server, cloud database, credentials, mail, microphone or ASR has been accessed by this preparation. The observation release, scopes, 15-second timer and cutoff remain unchanged.

## Storage boundary

The v07 real deployment selects only E4_VOICE_STORAGE=tmpfs-private-v1 with payload /run/cat-voice-private/payload and probe /run/cat-voice-private/probe. Raw audio, conversion output and unconfirmed transcription must not enter SQL, disk /tmp, public assets, logs or backups. PostgreSQL retains metadata, quota/reservations, lease state and random payload version/epoch pointers. The historical UNLOGGED payload table is not an acceptable real-audio backend; UNLOGGED still has disk files and may enter backups.

Files are staged and published under valid metadata locks and current session/lease checks. Only the exact current DB pointer is readable. Filesystem and PG are separate transactions: crash orphan cleanup is compensation, not a claim that COMMIT physically erases files. Terminal/cancel/logout/deletion revokes readability first; physical delete results may be complete or pending. A new mount epoch or lost payload invalidates old material, requires rerecording and never triggers ASR replay. Browser drafts and explicitly sent responses remain separate from server temporary material.

## Isolation and cleanup

New Node/ffmpeg/proxy/PG/cleanup processes run in catvoice.slice, proposed MemoryHigh=640MiB, MemoryMax=768MiB, MemorySwapMax=0, CPUQuota=100%. Dedicated 128MiB app and 32MiB proxy tmpfs mounts use noswap, 0700 and explicit UID/GID. A tmpfs path name or parent /run mount is not proof. Linux guards inspect exact mountinfo/statfs, cgroup limits and core limits. Proxy request/response buffering and cache are disabled; all proxy temporary paths are in its own private mount. Proxy mount failure is fatal. App private mount loss degrades voice only; ordinary text can stay online, while the store strictly rejects audio requests.

Prepared/private-open app startup first attempts one bounded cleanup process, with supplier credentials removed. A cleanup failure logs a fixed pending code and continues text service; it never writes a false lastSuccess. A separate minute timer runs the same cleanup, no provider key needed. Up to 100 jobs and 100 orphan files per round, orphan age at least 120s. Reports contain counts, payloadBytes, oldestAgeMs, lastSuccess, never content. Persistent cleanup health including the current store epoch must be valid before new create/upload/transcribe. Three failures, stale over 180s, future over 30s or epoch mismatch closes voice. Normal terminal deletion is immediate best effort; physical cleanup can lag.

## Entry and authentication

The default is closed entry, voice disabled and empty account scope, without mail or ASR keys. No synthetic OTP or local-review server is a production entry. Prepared scope is explicit 1–10 new internal accounts. Opening requires an independent mail configuration, restricted whole-site BasicAuth, exact https://cat-test.zyrobbie.site:8443 origin and separate cookie names. Ports do not isolate cookies. The independent proxy only forwards the new account/deletion names and rejects ambiguous duplicates; old invite/admin/legacy routes are not exposed. TLS renewal reloads only the new proxy after guards and nginx -t, never the existing nginx service.

Long-lived Tencent credentials omit TOKEN entirely. Enabling Tencent remains subject to the separate deployment preflight in TENCENT.md and actual service, quota, postpaid-off, IAM and retention verification. Runtime never reads or renews a daily receipt. No automatic ASR retry, paid fallback, top-up or cloud permissions are added. Vendor retention is independent of local deletion.

## Evidence and rollback

Linux/amd64 dependencies and Next output must be built on an isolated Linux builder from the exact frozen source and lock. Never upload macOS dependencies or build on the live 2GB observation host without a separately approved isolated plan. This local preparation has not produced a Linux binary artifact or run systemd/nginx/mount/cgroup/backup/TLS tests on the actual host.

The read-only host snapshot suggests isolation may be feasible; it does not prove peak memory or old-observation latency remains acceptable. Before real voice, measure concurrent uploads/transcribes, ffmpeg, tmpfs, proxy and dual PG under the slice limit; inspect real logs and backup/restore with unique synthetic markers, including VM memory snapshot/hibernation/core exclusions. Never treat explicit local pg_dump exclusions as proof of all backup mechanisms.

Rollback closes only the new proxy gates and voice, stops new units/timer, and unmounts only their two dedicated tmpfs mounts after processes stop. Preserve new persistent sent responses/ledger and review evidence. Do not modify old current pointers, restore old Supabase, unmount whole /run, change observation intervals/scopes or rewind its clock. Keep real-device, WeChat, vendor, billing, Linux operational and user acceptance separate from local synthetic results.
