# Tencent SentenceRecognition — deployment preflight and sustainable runtime

The user approved Tencent with FREE quota only. Engineering has not read real
credentials, called actual ASR, changed Tencent settings or deployed this code.

For the independent Linux environment, see `linux/README.md`. Its closed base
needs no vendor keys. Proposed user hand-fill locations are
`/etc/cat-voice-test/app/provider.env` and `mail.env` (root:root0600); neither is
created by this local preparation. The proxy and maintenance worker do not load
these supplier files. Do not source an observation-site env or use its accounts.

## Deployment preflight (operator action, not a user-request dependency)

Before deploying/enabling the proposed server configuration, the coordinator
must verify the actual Tencent account: service enabled, remaining free calls,
postpaid OFF, optional data-optimization authorization OFF, and a dedicated
server identity restricted to `asr:SentenceRecognition`. That identity must not
have SetPayMode, ActivateService, CAM or other billing/administration actions.
Actual Tencent postpaid-off state is the spending barrier; app flags, screenshots
or a receipt cannot remotely establish it. Do not create or enable paid resources.

Keep the private verification record and settings/IAM evidence for audit. The
record format remains `tencent-readiness.example.json`; its dummy placeholders
cannot pass validation. A private directory outside application/static source,
mode0700, owned by the runtime UID; receipt/evidence files0600, no symlinks.
The credential fingerprint binds SHA256(SecretId), never SecretKey. Evidence
basenames, hashes and account/permission/policy fields are checked.

Run this read-only command once against the proposed protected deployment env:

```sh
node --import tsx scripts/voice-tencent-preflight.ts
```

Only this command reads E4_VOICE_TENCENT_READINESS_FILE. It checks recent
operator evidence (within24h, unexpired and for the current Shanghai month),
private permissions, evidence hashes and proposed credential/config format.
It reports an evidence hash and predeployment deadline. It does not query
Tencent billing or IAM, call ASR, write a receipt, enable a service, create a
credential or access a database. The operator's live verification is still
required; the command is a record/config preflight, not independent remote proof.
Capture its output with the private deployment evidence.

## Runtime

Runtime uses the normal protected deployment configuration:

- APP_MODE=INTERNAL, E4_VOICE_ENABLED=true, explicit internal UUID account scope
  and independently verified private storage/backup/cleanup configuration.
- E4_VOICE_MODE=tencent-sentence-v1; E4_VOICE_TENCENT_ASR_APPROVED=true;
  E4_VOICE_TENCENT_FREE_ONLY=true. These are explicit operator deployment intent,
  not remote verification of quota, billing, permission or credential validity.
- Server-only SecretId/SecretKey and optional STS token. Never NEXT_PUBLIC/VITE.
  Local credential format is checked; actual authentication is decided by Tencent.

For long-lived SecretId/SecretKey credentials, omit E4_VOICE_TENCENT_TOKEN
entirely, including from environment examples and protected env files. An empty
TOKEN assignment is not the long-lived-key configuration. Only an actual STS
configuration supplies its matching nonempty temporary token.

**The runtime factory never imports the evidence reader, reads a receipt/file,
checks its age/month, or needs a daily signature/renewal.** A missing/expired
record or later calendar date cannot by itself disable an enabled service.
No daily manual task, auto-enablement job or billing mutation has been added.
The operator can keep records in separate audit storage; they need not be mounted
in the running service. The old READINESS_FILE env setting is ignored at runtime.

Explicit disable/mode/credential changes are rechecked at dispatch. A genuine
upstream quota/auth failure closes that credential configuration in this process;
new user calls cannot repeatedly retry it. The operator verifies the actual
service and can recover through a deliberate restart/redeployment or credential
replacement after fixing the issue. Record renewal and approval-flag toggling
do not reopen the failed configuration. This failure latch is not durable across
process restarts and is not a spending guarantee; actual postpaid OFF and narrow
caller permissions remain essential. There are no automatic ASR retries,
quota probes, purchase/top-up links or paid fallback.

The closed set includes FailedOperation.UserHasNoAmount, UserHasNoFreeAmount,
ServiceIsolate, limit/resource errors, HTTP429 and authentication errors. UI keeps
the original draft, closes unusable voice retry and allows cancel/text send.
Existing whitelist/session/letter checks, limits, cleanup and explicit review/
confirm/ordinary-send boundaries remain in place. Audio-job24h TTL is unchanged;
it is separate from this removed daily deployment-record dependency.

## Protocol and privacy

Application entry is configuredVoiceProvider. Fixed HTTPS endpoint,
SentenceRecognition/API2019-06-14/TC3, SourceType1,16k_zh, canonical PCM WAV
Base64. No app job/account/letter identifiers, draft or history are forwarded.
No public audio URL, redirects, automatic retry, data-optimization opt-in,
emotion inference or text rewriting. Upstream request/body deadline12s,
response64KiB. UI discloses Tencent as receiver and possible7-day text retention;
application cleanup does not assert deletion of vendor copies. Applicability
and vendor controls remain the coordinator's live verification responsibility.
[Official API](https://cloud.tencent.com/document/product/1093/35646),
[retention FAQ](https://cloud.tencent.com/document/faq/1093/35802).

Validation uses isolated local HTTP/dual PostgreSQL and intercepted provider
responses. It proves missing/stale records do not affect runtime and the
preflight is separate, without changing the clock or pretending to wait a day.
No fake record is treated as actual Tencent settings/auth/quota evidence.
