# 独立 E4-E Linux 部署文件

本目录是 v07 候选的部署准备，**没有安装、挂载、启用或连接真实服务器**。文件中的账号、路径和端口都是拟部署值；当前不代表它们已创建。实际源文件冻结、Linux 构建、系统服务与存储实测须由主任务逐项复核。本目录不使用旧观察站的环境文件、数据库、Cookie、定时器或 15 秒调度配置。

## 环境与入口

| 项目 | 拟定值 |
|---|---|
| 独立公网入口 | `https://cat-test.zyrobbie.site:8443`，新 nginx master 自行终止 TLS |
| 新应用 | `127.0.0.1:3187`，不监听公网 |
| 新业务 PG | `127.0.0.1:55441/cat_voice_business` |
| 新账本 PG | `127.0.0.1:55442/cat_voice_ledger`，独立 PGDATA/集群 |
| 新 release/current | `/srv/cat-voice-test/releases/<reviewed-version>`、`/srv/cat-voice-test/current` |
| 持久库目录 | `/var/lib/cat-voice-test/business`、`/var/lib/cat-voice-test/ledger` |
| 私有 payload/probe | `/run/cat-voice-private/payload`、`/run/cat-voice-private/probe`，同一 128 MiB 专用 tmpfs |
| 新代理临时目录 | `/run/cat-voice-proxy`，另一 32 MiB 专用 tmpfs |
| 系统用户 | `catvoice-app`、`catvoice-proxy`、`catvoice-pg`，均为拟建独立 OS 用户 |
| Node/PG/媒体工具 | `/opt/cat-voice-runtime/node/bin/node`、`/usr/lib/postgresql/17/bin/`、`/usr/bin/ffmpeg`、`/usr/bin/ffprobe`，安装与版本验证待做 |

`APP_ORIGIN` 必须精确包含 `:8443`，不能带末尾 `/`。账号 Cookie 使用 `cat_voice_test_session`，注销凭据使用 `cat_voice_test_deletion`；原默认名称保留供原站使用，改环境名称须重启新进程。新代理只转发这两个新名称，拒绝同名重复 Cookie，移除外层 BasicAuth 的 Authorization，并固定 Host、X-Forwarded-Host、X-Forwarded-Proto、X-Forwarded-Port。旧邀请、后台、legacy、合成审阅入口及其他未列出的路径均不向新应用代理。

端口并不隔离 Cookie；浏览器仍可能把原站 Cookie 发到新端口。此配置避免它们进入新应用，并不宣称两个同主机进程之间存在浏览器安全边界。新 release 必须由受信任的同一维护方管理；若需防御互不信任的应用，需要另域名和另外的安全审查。

## 三个部署阶段

| 阶段 | 账号范围、清理、语音 | 整站入口 |
|---|---|---|
| `closed`（交付默认） | scope `[]`，cleanup=false，voice=false，OTP disabled；无需邮件/ASR 凭据 | `entry-gate.conf` 返回 503，voice gate 也返回 503 |
| `prepared` | 新库明确建立 1–10 个内部账号，填 UUID scope，cleanup=true；voice=false | 仍返回 503；完成 Linux 合成存储、清理、重启、备份和资源检查 |
| `private-open` | 真实邮件配置完成；明确的 entry reviewed 和 Linux storage accepted 标志；默认仍 voice=false。语音另需审核后设置 Tencent 模式、免费/授权、存储确认和凭据 | 外层 BasicAuth 保护全站/API，拟接收者仅内部测试者；两个 gate 和非敏感 `entry-state.json` 必须一致 |

这些 review/accepted 标志是维护方意图，不是自动验证了 Linux、邮件或腾讯。没有真实邮件凭据时停留 `closed`，不能改用 `synthetic-v1` OTP、公开 `/local-review`、发放公共种子会话或要求用户每次去服务器取验证码。

应用启动时先验证 Linux cgroup、资源上限和存储条件。环境、cgroup、core 限制不合格是硬失败；仅 app 的私有 payload mount 异常允许降级为语音不可用，普通文字继续启动，绝不使用 SQL/磁盘 fallback。app 对此挂载只用 Wants/After，代理自身 mount 失败仍严格停止。`closed + [] + cleanup=false` 不运行账号恢复；其他阶段在 Next 开始监听前，先执行独立的有界 `voice-cleanup.ts` 子进程。子进程仅接收新双 PG 与存储必要配置，不接收邮件、腾讯或调试环境；清理失败仅记录固定 PENDING 并继续文字，不伪造 lastSuccess、不自动 ASR。新候选正常有效任务上限为十个账号、每账号两个，单批最多 100 任务覆盖常规启动恢复；异常遗留由后续 timer 多轮处理，旧 epoch 的文件始终不能凭等待清理继续读回。

## 手填文件与权限

以下位置均是**建议安装位置，当前未创建**。由主任务完成基础配置，实际部署后再告知用户已经创建好的手填入口。systemd 以特权读取 `EnvironmentFile` 后再降低进程 UID，文件无需向 app/proxy 用户开放读取。

| 拟部署文件 | 来源/内容 | 权限 |
|---|---|---|
| `/etc/cat-voice-test/app/base.env` | `base.env.example`；主任务配置新双 PG、独立随机 OTP/账本 secret、Cookie、scope 与阶段 | root:root 0600 |
| `/etc/cat-voice-test/app/mail.env` | `mail.env.example`；用户手填 `RESEND_API_KEY` 与经验证的 `OTP_FROM` | root:root 0600，app unit 可选加载 |
| `/etc/cat-voice-test/app/provider.env` | `provider.env.example`；用户手填专用 `SecretId`、`SecretKey`；真实免费模式/IAM审核后才改授权标志 | root:root 0600，app unit 可选加载 |
| `/etc/cat-voice-test/proxy/{nginx.conf,entry-state.json,entry-gate.conf,voice-gate.conf}` | 本目录默认文件，原子安装；均为非敏感配置 | root:catvoice-proxy 0640，无组/其他写权限 |
| `/etc/cat-voice-test/proxy/htpasswd` | 主任务在真正开放前配置的内部测试者外层认证 | root:catvoice-proxy 0640；guard 只检查元数据，不读取内容 |
| `/etc/cat-voice-test/proxy/{fullchain.pem,privkey.pem}` | 有效 TLS 材料，由受权维护方安全供应；不打入制品，不输出私钥 | 私钥 root:catvoice-proxy 0640；不放宽旧证书路径权限 |
| `/etc/cat-voice-test/pg/` | 本目录 `pg/` 配置；owner/bootstrap 密钥另存私有一次性维护配置，不交 runtime | root:catvoice-pg 0640；PGDATA catvoice-pg 0700 |

长期腾讯密钥配置完全省略 `E4_VOICE_TENCENT_TOKEN`，不能保留空赋值。只有实际 STS 配置才提供匹配的非空 token。本轮不读取 CSV、真实凭据、key ID、旧站 env 或上述任何拟部署秘密文件。

`base.env` 复用已有 `E4_SCHEDULED_RUN=true` 的小池设置，每个进程最多 2 个业务库连接和 2 个账本连接；不因此启动调度器，本目录没有安装任何观察/日历调度 unit。应用、cleanup 不持有数据库 owner 密钥；runtime 使用 `cat_letters_app` 和 `cat_letters_ledger` 的最小权限配置。

## Linux 构建与来源

macOS 的 `node_modules`、`.next` 和现有审阅目录都不能当 Linux 运行包。选择另一个 Linux/amd64 构建环境或本机已可用的 Linux 容器，**不在 2GB 观察服务器执行 npm ci/Next 大构建**。当前本机没有已确认可用的 Docker/Linux builder，故本轮不能把本地构建 PASS 写成 Linux 制品已构建。

以最终冻结的 v07 源包、冻结清单和已审查的真实 SHA 创建新目录；下列尖括号是待主任务替换的公开文件/校验值，不是已存在制品：

```sh
python3 deploy/private-voice/linux/prepare-build-context.py \
  --archive '<frozen-v07-source.tar.gz>' \
  --freeze '<source-freeze-v07.json>' \
  --sha256 '<reviewed-source-archive-sha256>' \
  --destination '<new-build-context-directory>'
```

脚本逐文件校验 tar 与清单，拒绝链接、路径穿越、重复/多余/缺失文件、实际 env/CSV/密钥和 macOS 依赖目录；目标已有内容时拒绝覆盖。它不读取工作区 `.env`。准备目录中的 manifest 还会在 Docker 内验证，构建输入检查拒绝准备后追加的未冻结文件。

在独立 builder 使用官方 Node 22.17.1 bookworm-slim 的**已核验 digest**，平台明确 `linux/amd64`：

```sh
docker buildx build --platform linux/amd64 \
  --build-arg NODE_IMAGE='node:22.17.1-bookworm-slim@sha256:<verified-digest>' \
  --file '<new-build-context-directory>/deploy/private-voice/linux/Dockerfile.build' \
  --output 'type=local,dest=<new-artifact-directory>' \
  '<new-build-context-directory>'
```

Dockerfile 拒绝未固定 digest、错误平台；从 lock 安装 Linux 依赖，执行内容检查和完整应用构建，导出运行 tar、`BUILD.json`、源 manifest/源包 SHA。`BUILD.json` 记录源包、源清单、lock、运行包 SHA、平台、Node 与 builder 镜像。主任务须一并保留安装/构建日志，校验目标机器架构/Node，以及新 release 的受限本机健康检查；本地 macOS typecheck 不替代这些步骤。

## 新环境安装顺序

1. 主任务重新确认 8443、3187、55441、55442 和新路径仍可用，记录旧 web/background 指针、配置指纹、15 秒间隔、scope 与 `2026-11-06T18:40:00Z` 截止时间。安装依赖和创建新 OS 用户是后续部署动作，本次未执行。
2. 将已校验 Linux 运行包解到新的 release，root 持有、服务只读。不要覆盖旧 `/srv/cat-letters`，也不要把候选脚本放入观察 unit。确认 Node/PG/媒体工具的实际路径；路径不符时先修订并审查新 unit，不碰旧服务。
3. 为两个新 PGDATA 各自运行 initdb，明确本机 peer + 回环 SCRAM，绝不使用测试脚本 `--auth=trust`。使用本目录 HBA/ident 和各自配置；新库、最小 runtime 角色与 owner 密钥均独立。仅新业务库执行候选迁移，仅新账本执行 ledger migrations 和明确 bootstrap/reconcile，再应用已经审查的 runtime grants 与 v07 voice metadata grants。owner 凭据不保留在服务环境，不能使用 Supabase DSN 或旧 admin key。
4. 源码模板使用安全名称 `private-tmpfs.mount.in` 和 `proxy-tmpfs.mount.in`。把其中 `@APP_UID@/@APP_GID@`、`@PROXY_UID@/@PROXY_GID@` 替换成新系统用户的真实数字，再分别用 `systemd-escape --path --suffix=mount /run/cat-voice-private` 和 `systemd-escape --path --suffix=mount /run/cat-voice-proxy` 生成实际安装 unit 名；不要直接去掉源码文件的 `.in` 当作 unit 名。应用/清理/代理 unit 引用的仍是 systemd 正确转义后的实际名称。两个 mount 都设置容量/inode上限、0700、noswap/nodev/nosuid/noexec；不可只在既有 `/run` 建目录。**未挂载时的底层 mountpoint 必须由 root 持有，且 app/proxy 不可写；不要 chown 底层目录给服务用户，只通过挂载 `Options=uid/gid` 赋予挂载后的权限，防止失挂载时写入磁盘底层目录。** `DirectoryMode=0700` 只保护 systemd 新建目录，已有目录须在未挂载时另行确认 root 所有权/权限。先用 `systemd-analyze verify` 检查新 unit，再验证实际 mountinfo/statfs、UID/GID和权限。[systemd255 mount 命名和目录模式](https://www.freedesktop.org/software/systemd/man/255/systemd.mount.html)。
5. 安装 `catvoice.slice` 和新服务。先启动新双 PG、两个私有挂载；`closed` app 可使用没有 mail/provider 文件的基础环境。独立 nginx 默认返回 503，即使误拿到 URL 也没有合成登录入口。不得把本目录 nginx 配置 include 到旧 nginx，或重启/改参数限制旧 nginx。
6. 在新库创建明确的内部测试账号后，转 `prepared`，填 1–10 个 UUID、开启 cleanup，先手动启动新 cleanup service 验证成功，再启用一分钟 timer；重启新 app 会先做一次恢复。保留真实 Linux 合成存储、竞态、容量、清理故障、崩溃/挂载丢失、备份恢复和资源证据。没有这些证据，不填写 storage accepted。
7. 用户手填邮件与专用 ASR，主任务完成真实权限/免费/后付费/供应商边界核验和一次部署证据预检。随后才可单独审查 `private-open`、外层认证与 voice gate；需要同时更新 base 阶段、非敏感 proxy state 与相应 gate。先检查 staged 配置再原子替换，`systemctl reload cat-voice-proxy` 会先执行 guard 和独立 `nginx -t`，仅成功后 HUP 本实例。不要调用 `systemctl reload nginx`。公开端口大陆/微信可达性和真实手机需单独实测。

新证书续期时由维护方安全更新**新实例自己的** TLS 材料，再只执行上述新实例 reload；reload 失败保留旧运行配置，修复或恢复新实例配置文件。本轮没有配置证书复制任务、读取旧私钥或改变旧续期 hook。

## 清理、容量与回退

cleanup unit 与 app 同一 UID、同一私有挂载、同一个 `catvoice.slice`，但不加载 mail/provider 文件。cleanup 允许剩余 block/inode 为 0，以便回收已占满的挂载；挂载身份、tmpfs/noswap、容量/inode上限、所有权、cgroup 与 core 检查仍保留，app 满容量仍关闭语音、代理仍严格失败。每轮最多 100 个任务和 100 个孤儿文件，孤儿至少等待 120 秒；正常终态立即尝试物理删除。API 的 `cleanup:complete/pending` 区分实际删除结果，不能仅因终态已经提交就声称物理擦除。日志仅记录数量、`payloadBytes`、`oldestAgeMs`、`lastSuccess` 等元数据或固定错误码。

连续三次失败，或持久 lastSuccess 超过 180 秒/向未来偏离超过 30 秒，或 cleanup_epoch 不匹配当前挂载 epoch，服务拒绝新录音、上传 claim 与转写。定时器停摆或清理错误不关闭普通文本 API；应由主任务观察 timer 状态和无内容健康元数据。挂载恢复后也必须先有新 epoch 的成功清理，旧的新鲜时间戳不能开门。恢复清理后由成功轮次更新健康。服务器临时文件的 24 小时逻辑失效与物理清理滞后必须分别报告，不承诺严格 24 小时物理擦除或内存取证级擦除。

`catvoice.slice` 以 MemoryHigh=640 MiB、MemoryMax=768 MiB、MemorySwapMax=0、CPUQuota=100%、TasksMax=128 保护旧业务。各服务另外设内存与 core 限制；媒体子进程在 app 控制组内。两个专用 tmpfs 都禁止 swap；代理关请求/响应 buffering，临时路径也在它自己的 tmpfs，无正文/Cookie/Authorization 日志。挂载 noswap 不能代替进程 no-swap，反过来也一样。[Linux tmpfs](https://www.kernel.org/doc/html/latest/filesystems/tmpfs.html)、[systemd 255 资源控制](https://www.freedesktop.org/software/systemd/man/255/systemd.resource-control.html)、[nginx proxy buffering](https://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_buffering)。

主任务只读预检在 2026-10-25 10:22:49 UTC 记录内核 6.8、systemd 255/cgroup2、MemAvailable 约 1.305 GiB、磁盘可用约 29.76 GiB；这些是一个时间点的余量，既有 `/run` 未带 noswap。可继续准备隔离环境，**不能据此承诺 2GB 足以运行峰值负载**。须在新 slice 上测两个同时上传/转写、代理/ffmpeg/双 PG 与 tmpfs 总峰值、CPU争用、OOM及旧观察延迟。资源不足或观察受影响时关闭新环境，不用全机 swap、扩旧业务限制或在观察机硬撑构建。

回退时先恢复新 proxy 的 closed/voice disabled gates 与 state 并只 reload 新实例；关闭新语音开关，停止新 cleanup timer、新 app/proxy，按需要停新双 PG并保留持久业务/账本目录。仅在新服务已停止后卸载这两个新专用 tmpfs；它们的临时材料会消失。不要卸载整个 `/run`，不要清空持久库、恢复旧 Supabase、改旧站 current 或回拨观察时钟。无法可靠关闭入口时，直接停新 proxy，原站保持原状。

备份/恢复验证仅针对新库：确认录音和未确认转写从未进入 SQL、磁盘临时目录、日志或 core，再用唯一合成 payload 标记核对真实逻辑备份与新建恢复库。文件备份排除两处私有 tmpfs；VM 快照还需核对是否含内存、休眠或崩溃转储。本轮没有运行真实备份/恢复，也没有修改整机已有备份策略。PG 配置禁止常规 SQL/参数日志并仅允许回环 SCRAM；配置正确仍需真实进程/日志验证。[PG17 日志](https://www.postgresql.org/docs/17/runtime-config-logging.html)、[PG17 HBA](https://www.postgresql.org/docs/17/auth-pg-hba-conf.html)。

## 验证边界

本地 cookie/部署单测和 build-context 负例验证只说明对应实现的本机行为。Linux `systemd-analyze verify`、nginx 二进制 `-t`/实际 TLS、真实 mount/cgroup/no-swap、实际内存/观察影响、备份/恢复、邮件/ASR/费用/IAM、手机/微信和8443大陆可达性均须分别给证据；没有执行的项目保留 NOT_TESTED。不能把文件模板、旧 117 项或 v06 的 25 项当本目录已经部署通过。
