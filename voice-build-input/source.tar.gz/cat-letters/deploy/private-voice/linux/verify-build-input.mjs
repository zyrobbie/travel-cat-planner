// Docker build-time only. Verify exact source input before any Next build runs.
import { readFileSync, readdirSync, lstatSync } from "node:fs";
import { createHash } from "node:crypto";
import { join } from "node:path";

try {
  const text = readFileSync("SOURCE-MANIFEST.sha256", "utf8");
  const rows = text.trimEnd().split("\n").map(row => {
    const match = row.match(/^([a-f0-9]{64})  (.+)$/);
    if (!match) throw Error();
    return [match[2], match[1]];
  });
  const expected = new Map(rows);
  if (expected.size !== rows.length || expected.size < 1 || expected.size > 2000) throw Error();
  const generated = new Set(["SOURCE-MANIFEST.sha256", "SOURCE-ARCHIVE.sha256", ".dockerignore"]);
  const seen = new Set();
  const walk = (path = ".", prefix = "") => {
    for (const name of readdirSync(path)) {
      if (!prefix && name === "node_modules") continue;
      const relative = prefix + name, absolute = join(path, name), stat = lstatSync(absolute);
      if (stat.isDirectory()) { walk(absolute, relative + "/"); continue; }
      if (!stat.isFile() || stat.isSymbolicLink()) throw Error();
      if (generated.has(relative)) continue;
      if (!expected.has(relative) || createHash("sha256").update(readFileSync(absolute)).digest("hex") !== expected.get(relative)) throw Error();
      seen.add(relative);
    }
  };
  walk();
  if (seen.size !== expected.size || !/^[a-f0-9]{64}\n$/.test(readFileSync("SOURCE-ARCHIVE.sha256", "utf8")) ||
      !readFileSync(".dockerignore").equals(readFileSync("deploy/private-voice/linux/.dockerignore"))) throw Error();
  console.log(JSON.stringify({ exactFrozenSource: true, files: seen.size, platform: process.platform, arch: process.arch }));
} catch {
  console.error("LINUX_BUILD_INPUT_REJECTED");
  process.exitCode = 1;
}
