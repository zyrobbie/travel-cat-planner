#!/usr/bin/env python3
"""Prepare an exact frozen-source build context; never read a workspace .env."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile


def prepare(archive: Path, freeze: Path, destination: Path, expected_archive_sha256: str):
    if not re.fullmatch(r"[a-f0-9]{64}", expected_archive_sha256):
        raise ValueError("INVALID_ARCHIVE_SHA256")
    digest = hashlib.sha256()
    with archive.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    archive_hash = digest.hexdigest()
    if archive_hash != expected_archive_sha256:
        raise ValueError("ARCHIVE_SHA256_MISMATCH")
    document = json.loads(freeze.read_text())
    expected = document["filesSha256"]
    if not isinstance(expected, dict) or not 1 <= len(expected) <= 2000:
        raise ValueError("INVALID_SOURCE_MANIFEST")
    if destination.exists():
        raise ValueError("DESTINATION_EXISTS")
    files = {}
    size = 0
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle.getmembers():
            if member.isdir():
                continue
            path = PurePosixPath(member.name)
            if not member.isfile() or not member.name.startswith("cat-letters/"):
                raise ValueError("UNSAFE_ARCHIVE_MEMBER")
            relative = str(path.relative_to("cat-letters"))
            if path.is_absolute() or ".." in path.parts or relative in files or relative not in expected or \
               any(char in relative for char in ("\\", "\n", "\r", "\0")):
                raise ValueError("UNEXPECTED_SOURCE_MEMBER")
            parts = PurePosixPath(relative).parts
            if any(part in {"node_modules", ".next", ".git", ".local"} for part in parts) or \
               any(part.startswith(".env") and part != ".env.example" for part in parts) or \
               relative.lower().endswith((".csv", ".pem", ".key", ".p12", ".pfx")):
                raise ValueError("PRIVATE_OR_PLATFORM_MEMBER")
            size += member.size
            if member.size > 64 * 1024 * 1024 or size > 512 * 1024 * 1024:
                raise ValueError("SOURCE_ARCHIVE_TOO_LARGE")
            with bundle.extractfile(member) as source:
                content = source.read()
            if hashlib.sha256(content).hexdigest() != expected[relative]:
                raise ValueError("SOURCE_CHECKSUM_MISMATCH")
            files[relative] = (content, member.mode & 0o755)
    if set(files) != set(expected):
        raise ValueError("SOURCE_FILES_MISSING")
    required = ("deploy/private-voice/linux/Dockerfile.build", "deploy/private-voice/linux/.dockerignore")
    if any(path not in files for path in required):
        raise ValueError("LINUX_BUILD_SOURCE_MISSING")
    # All checks precede extraction. No symlinks, inherited filesystem state or
    # unlisted files can enter the new directory.
    destination.mkdir(mode=0o700, parents=False)
    for relative, (content, mode) in files.items():
        output = destination / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(content)
        output.chmod(mode)
    manifest = "".join(f"{expected[p]}  {p}\n" for p in sorted(expected))
    (destination / "SOURCE-MANIFEST.sha256").write_text(manifest)
    (destination / "SOURCE-ARCHIVE.sha256").write_text(archive_hash + "\n")
    (destination / ".dockerignore").write_bytes(files["deploy/private-voice/linux/.dockerignore"][0])
    print(json.dumps({"result": "PASS", "sourceFiles": len(files), "archiveSha256": archive_hash,
                      "manifestSha256": hashlib.sha256(manifest.encode()).hexdigest(),
                      "linuxBuildExecuted": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    try:
        prepare(args.archive, args.freeze, args.destination, args.sha256)
    except Exception:
        # Only public checksums/counts on success. No source data or secret input.
        raise SystemExit("LINUX_BUILD_CONTEXT_REJECTED")
