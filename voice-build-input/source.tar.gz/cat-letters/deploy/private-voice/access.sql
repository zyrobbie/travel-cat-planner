-- Apply with the migration owner after the existing reviewed runtime profile.
-- Does not alter the old business/ledger grants or observation configuration.
BEGIN;
DO $$ DECLARE viewer text; t text; cols text; BEGIN
 FOREACH viewer IN ARRAY ARRAY['anon','authenticated','service_role'] LOOP
  IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
   FOREACH t IN ARRAY ARRAY['private_voice_jobs','private_voice_payload','private_voice_budget'] LOOP
    EXECUTE format('REVOKE ALL ON TABLE public.%I FROM %I',t,viewer);
    SELECT string_agg(quote_ident(attname),',') INTO cols FROM pg_attribute WHERE attrelid=to_regclass('public.'||t) AND attnum>0 AND NOT attisdropped;
    EXECUTE format('REVOKE ALL (%s) ON TABLE public.%I FROM %I',cols,t,viewer);
   END LOOP;
  END IF;
 END LOOP;
END $$;
REVOKE ALL ON private_voice_jobs,private_voice_payload,private_voice_budget FROM PUBLIC,cat_letters_app;
GRANT SELECT,INSERT,DELETE ON private_voice_jobs TO cat_letters_app;
GRANT UPDATE(status,duration_ms,lease_token,lease_until,attempts,last_error,payload_epoch,audio_version,audio_bytes,text_version,text_bytes,reserved_bytes) ON private_voice_jobs TO cat_letters_app;
GRANT SELECT ON private_voice_budget TO cat_letters_app;
REVOKE UPDATE(singleton) ON private_voice_budget FROM cat_letters_app;
GRANT UPDATE(last_cleanup_at,cleanup_epoch,cleanup_failures,last_cleanup_error) ON private_voice_budget TO cat_letters_app;
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['private_voice_jobs'] LOOP
  EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY',t);
  EXECUTE format('DROP POLICY IF EXISTS private_voice_runtime ON %I',t);
  EXECUTE format('CREATE POLICY private_voice_runtime ON %I TO cat_letters_app USING(true) WITH CHECK(true)',t);
 END LOOP;
END $$;
ALTER TABLE private_voice_budget ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS private_voice_budget_read ON private_voice_budget;
DROP POLICY IF EXISTS private_voice_budget_lock ON private_voice_budget;
CREATE POLICY private_voice_budget_read ON private_voice_budget FOR SELECT TO cat_letters_app USING(true);
CREATE POLICY private_voice_budget_lock ON private_voice_budget FOR UPDATE TO cat_letters_app USING(true) WITH CHECK(true);
DROP POLICY IF EXISTS private_voice_runtime ON private_voice_payload;
REVOKE ALL ON FUNCTION purge_terminal_voice_payload(),revoke_session_voice(),revoke_account_voice() FROM PUBLIC,cat_letters_app;
REVOKE ALL ON FUNCTION clear_private_voice_pointers() FROM PUBLIC,cat_letters_app;
COMMIT;
