#!/bin/sh
set -eu
umask 077
# All manual and timer invocations must use the same persistent lock inode.
# Do not remove run.lock while a process may still hold it.
exec /usr/bin/flock --nonblock --conflict-exit-code 75 /var/lib/cat-letters-background/run.lock \
  /usr/bin/env E4_CONTINUOUS_LOCK_HELD=true DOTENV_CONFIG_PATH=/dev/null \
  /usr/local/bin/node --import tsx /srv/cat-letters/background-current/scripts/continuous-entry.mjs
