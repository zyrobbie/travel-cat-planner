# 持续后台任务：Linux 安装、停止与恢复

工程候选仅交统筹部署；这里的命令不是本机已执行记录。目标是既有 Ubuntu 24.04 主机 robbie-sg-01，现地址 **43.133.32.52**，严格复用已核实的主机密钥。没有新付费组件、开放新端口或引入第三套数据库。

## 固定发布与账号配置

1. 将本增量包应用到本轮记录的精确 Linux 源码基线，逐文件核对 `source-freeze.json` 和 `artifact-check.json`。保留完整304文件基础目录；增量包不是完整应用。停止旧后台 timer/service 后，准备新的只读后台发布目录。不要在运行中的冻结目录覆盖文件。
2. Ubuntu 使用既有 Node 22 和独立 `cat-letters` 用户，依 `package-lock.json` 在新目录安装 Linux 依赖；不复制 Mac node_modules。确认 `/usr/local/bin/node`、`/usr/bin/flock` 可用。无需为后台开放HTTP入口或更改DNS。
3. 后台使用单独软链 `/srv/cat-letters/background-current` 指向本次后台源码发布目录；**无需切换网页的 `/srv/cat-letters/current`**。前台继续运行已验收的发布，原七项任务开关保持关闭。后台与前台都保留现有独立账本和取消事件支持；本轮无数据库迁移。
4. 复用 `/etc/cat-letters/runtime.env` 中既有两个受限 session/direct 连接、账本密钥、CA和内部模式。运行账号必须实际是 cat_letters_app / cat_letters_ledger，无superuser、BYPASSRLS、DDL、表所有权或账本重写权；预检不执行GRANT或修复恢复闸门。不引入管理员URL、个人邮箱或任务token。
5. 单独创建 `/etc/cat-letters/background.env`，root:root 0600，以 `background.env.example` 为模板。由统筹私下把授权账号的**现有UUID**填入相应JSON数组，区分delivery/deletion/export/cleanup；每项1–10个、合计最多10个不同UUID。默认全部false。E4_CONTINUOUS_UNTIL必须显式设置，最晚为2026-11-06T10:00:00Z（北京时间11月6日18:00），程序拒绝更晚截止。不得用邮箱域名、请求参数、查询账号全集或通配符生成名单；同邮箱新注册UUID不会继承授权。本轮实际名单由统筹私下配置为2个已存在内测账号及验证窗口内正例fixture，对照fixture不进名单，验证后撤出正例。最大范围不是实际全量开放。
6. 应用独立环境文件不需要加入登录/发信密钥；后台不会主动请求验证码或发送邮件。既有runtime.env内容不写入终端、产物或报告。`systemctl show ... -p Environment`会泄露配置，禁止用它采证。

## 安装与分步启用（统筹执行）

按当前服务名检查两套路径、用户、环境文件与权限后，安装候选的两个unit。运行状态与任务日志可采证，但不打印配置内容。

```sh
sudo install -o root -g root -m 0644 deploy/continuous-scheduler/cat-letters-background.service /etc/systemd/system/
sudo install -o root -g root -m 0644 deploy/continuous-scheduler/cat-letters-background.timer /etc/systemd/system/
sudo systemd-analyze verify /etc/systemd/system/cat-letters-background.service /etc/systemd/system/cat-letters-background.timer
sudo systemctl daemon-reload
# 此时background.env主开关及四个任务开关均false，应仅输出DISABLED且不连库。
sudo systemctl start cat-letters-background.service
sudo systemctl show cat-letters-background.service -p Result -p ExecMainStatus
sudo journalctl -u cat-letters-background.service -n 10 --no-pager
```

统筹配置名单、仅开启要验证的kind及主开关后，以同一个service做一次受控执行；确认结果和范围，再 `sudo systemctl enable --now cat-letters-background.timer`。不要直接运行TS文件、绕过wrapper或再装cron。正常日志只有任务类别、状态、耗时，没有账号/job/token或原始异常；flock重复启动退出75，unit将其视为正常跳过，不抢工作。

发布门槛：Linux真实unit校验；两个受限角色预检；错误/空名单拒绝；两个进程确实不能同时进入；一次执行中停止与启动后接续；scope之外的**明确合成对照UUID**无变化。不能做全账号摘要。先按正常领养关页自然等待首信，不改时间、不调用前台结算；分别记录领养成功、计划到期、持久投递和首次用户看到。5–10分钟是现有计划窗口，超出10分钟的实际送达如实记录，不能用提前改日历通过验收。

投递、隐私、清理为独立受限runner；隐私中的导出与注销另有独立开关/UUID列表，不能因开启导出就顺带删除。注销只消费用户已确认且有签名DELETE_REQUESTED的PENDING，不发起注销，FAILED保留原人工恢复规则，最多3次自动尝试；exhausted、选择、失败及重入均核验原账号/请求。

导出和清理分开启用。导出只构建用户已请求的任务，不主动导出全部账号。32MiB单份/既有共享字节预算、24小时过期和用户明确重试FAILED规则不变。云端冷连接/传输仍须在明确合成账号验证接近32MiB的实际任务时限；没有证据前保持EXPORT=false，不能把本地耗时外推为云端保证。清理只对名单UUID的导出与私有块工作，不扫全局限流桶或其他账号。

## 时间、并发与故障可见性

- Type=oneshot配合OnUnitInactiveSec=5s：每轮结束后再等5秒，不能把它描述成精确每5秒一次。整轮25秒预算从continuous-entry.mjs加载任何应用模块前计时，所有种类共享同一截止，不重置。35秒启动超时，5秒停止宽限；systemd最终杀死整个control-group。
- 同一unit不重叠，所有手动入口还共用 `/var/lib/cat-letters-background/run.lock` 的flock。**运行中不得删除或替换这个锁文件**。状态目录由systemd创建，归服务用户、0700；游标为0600、fsync后原子rename。重启从下个槽位轮转，配置摘要改变则重头开始。
- 每轮最多5个槽位，不足7秒不再领取。未知提交显示UNKNOWN_CHECK_DURABLE_STATE/ATTENTION、非零退出；租约和持久状态决定下轮工作，不能因超时猜测失败或强制清租约。一次失败不会把其他账号从轮转中永久饿住。
- 状态持久化以数据库为准，日志为诊断线索。定期看timer是否active、上次Result/ExecMainStatus及下一次触发。timer在运行不代表业务成功；ATTENTION、FAILED、RETRY或连续无进度须调查。使用现有日志工具，不添加收费监控或未经授权的消息通知。

## 固定截止和root停用timer

同时安装提供的cat-letters-background-expiry.service/timer，root拥有、0644，先systemd-analyze verify四份unit，再daemon-reload，并在启用应用timer前先enable --now expiry.timer。其OnCalendar固定为2026-11-06 10:00:00 UTC，Persistent=true，届时实际disable/stop应用timer并stop service。该候选只有一个协调timer，三类runner在内部轮转，共用同一锁。不要额外再建三个会争锁、绕游标的应用timer。

程序截止后返回EXPIRED且不加载DB；root timer负责停止进程调度以避免长期空轮询。必须独立核对expiry.timer的NextElapse及root unit权限，不能用源码检查代替Linux运行证据。不得直接重放真实截止的root service测试停用，而应由统筹用明确的临时验证unit验证停止动作，再恢复固定日历配置。

## 立即停用

```sh
sudo systemctl disable --now cat-letters-background.timer
sudo systemctl stop cat-letters-background.service
sudo systemctl is-active cat-letters-background.timer cat-letters-background.service
```

确认进程退出后，将私有background.env主开关和四个任务开关设false。仅把主开关置false不会停止已经载入配置的进程，因此须执行上述stop。保留游标、锁文件和两库记录；不删任务、不清租约、不回滚账本。前台网页与其服务继续工作。

## 安全恢复

1. 修复非敏感配置或连接原因。恢复闸门若CLOSED，停止调度并交既有另行授权的恢复流程；普通上线/重启禁止执行全库reconcile。
2. 若游标损坏，停服务后只备份/移走cursor.json，再让程序从槽位0开始；游标只影响轮转公平，不承载删除决定或任务完成事实。锁文件保持原inode。
3. 若要换后台版本，先停timer/service、核对兼容发布，再切后台软链。前台当前发布不受该软链影响；不能退到不认识DELETE_CANCELLED的旧读者。更不能改用无账号范围的旧全局worker补偿。
4. 自然等待已有60秒租约到期，再由相同受控入口接续；旧token不得覆盖新租约，已发布导出不得重新构建成另一份。FAILED保留显式重试规则，不自动重置attempts。
5. 名单、权限、环境及一次service执行均通过后再启动timer，记录停用/恢复时间及原请求状态。Linux真实停止、重启与双进程flock证据由统筹保存，不用macOS本地断言替代。

systemd行为依据：[timer文档](https://www.freedesktop.org/software/systemd/man/255/systemd.timer.html)、[service文档](https://freedesktop.org/software/systemd/man/devel/systemd.service.html)。本轮未使用旧IP、未登录服务器、未读云密钥或个人邮箱，也未发布。

## v2补充：性能、格式和完整范围

本版本替代未含注销、导出55秒的v1。导出读取把12条固定、逐条UUID限定SELECT合并为一个返回原生pg多结果的往返，仍在原账号锁/事务/双库守护下；私有块在原预算锁和发布事务内一次参数化INSERT，最多16块。原日期、bigint、JSON解析、导出version、manifest、hash和表结构不变，旧web读者可直接消费，无需切换web current。角色预检仅查元数据，实际任务仍运行完整签名双库守护。

真正无父任务的私有块由现有FK禁止；无法归属账号的异常数据不全库扫描或删除。能通过父导出明确归属UUID的旧artifact块采用LIMIT100分批清理，当前READY块和有效BUILDING保留；到期状态变更继续使用既有原子清块触发器。不得把清理扩大成全账号桶扫描。

## 完整包与Linux隔离容量复跑

完整源码归档continuous-scheduler-source-full.tar.gz内含完整基线应用源码、102张源WebP、锁文件、全部新runner/unit与两份逐字节核实的公开本地验证授权SQL，不包含node_modules、真实env、浏览器资料、生成构建或个人数据。解压顶层为cat-letters/；322份源文件逐份hash见完整包manifest（以实际交付计数为准），无需依赖/tmp旧目录或先找增量基线。

服务器Node已核实为/usr/local/bin/node v22.23.3。可在新worker目录复用原Linux node_modules，前提是package-lock SHA256等于755b3abfe403cb38c77d96152fe68b6599f6c67dbb7b09a59275ed6dfe0277f0；依赖软链只读共享，后台代码目录单独固定。也可在新目录依锁文件安装Linux依赖。本地Mac依赖不得上传。

**压力容量复跑在Linux自己的两个新本地集群完成，不写真实云库。** 需已安装可用PostgreSQL二进制（记录实际版本），以非root账号cat-letters执行initdb；验证账号须对独立证据目录有写权、对源码与依赖有读权。新本地集群默认共享缓存各128MiB；32MiB导出会产生短时内存/CPU占用，统筹应确认服务器余量并串行执行，避免与自然首信观测争用资源。不要为了复跑给真实云库发GRANT、恢复或填充大数据。

```sh
# 在完整源码目录，PATH加入实际安装的PG bin目录。
# env -i清掉真实应用配置；脚本另外生成两个随机loopback数据库URL，忽略外部云URL。
sudo -u cat-letters env -i \
  PATH=/usr/local/bin:/usr/bin:/bin:/usr/lib/postgresql/17/bin \
  E4_CONTINUOUS_TEST_PATTERN='^C18 ' \
  /usr/local/bin/node scripts/test-continuous-scheduler.mjs /var/lib/cat-letters-background/linux-large-export-evidence
```

若机器安装的是其他PG版本，替换PATH并如实记录版本；不要把不同版本称为PG17验证。脚本内置的两份SQL只对它创建的nonce本地集群应用，不能手工套到真实云库。C18从单一25秒截止开始，包含真实预检、快照读取、构建和分块发布，每次查询额外300ms；验证实际READY、全部块合并SHA、字节和导出version。Mac成功不等于Linux通过，Linux通过也不等于云端冷TLS/网络吞吐通过。

云验证只使用限定合成正例的小数据完整链路：正常关页首信、未读时正常请求导出、timer仅处理名单正例、下载校验、首读改变revision、timer撤销清理旧导出、正常确认注销后等待COMPLETE。范围外固定对照不进名单，验证结束撤出fixture。自然24小时过期未走满就保留未验证；不要用提前改云时间填补。公开证据记范围和时间，不输出邮箱、UUID或私有凭据。
