-- Target: Supabase yttzoemmgcvrrmchqqqp (business only). Apply only after schema migrations and explicit bootstrap/reconcile.
-- No password, LOGIN activation, ownership, BYPASSRLS, public DDL, TRUNCATE, or restore-gate write grant.
-- Runtime authorization remains in the application; policies permit only this server role.
-- Existing unrelated policies cause an explicit failure instead of silently widening access.
BEGIN;
-- Suppress optional creator SET/INHERIT grants; existing polluted memberships still fail below.
SET LOCAL createrole_self_grant = '';
DO $authority$
DECLARE object_name text; operator_oid oid := current_user::regrole::oid;
BEGIN
  IF NOT has_database_privilege(current_user,current_database(),'CONNECT WITH GRANT OPTION')
    OR NOT has_schema_privilege(current_user,'public','CREATE WITH GRANT OPTION')
    OR NOT has_schema_privilege(current_user,'public','USAGE WITH GRANT OPTION')
  THEN RAISE EXCEPTION 'Deployment operator lacks database/schema grant authority'; END IF;
  FOREACH object_name IN ARRAY ARRAY['account_deletions','account_exports','account_rate_limits','account_requests','account_sessions','accounts','admin_requests','audit_events','cat_profiles','cloud_calendar_nodes','cloud_calendars','cloud_content_versions','cloud_jobs','cloud_letter_sources','cloud_letters','cloud_requests','cloud_response_revisions','cloud_responses','cloud_review_requests','cloud_review_sources','cloud_reviews','cloud_state','cloud_trips','content_versions','deletion_preparations','email_challenges','erased_legacy_sources','invites','legacy_binding_cancellations','legacy_binding_requests','legacy_bindings','letters','lifecycle_control','participants','private_export_budget','private_export_chunks','rate_limits','responses','safety_cases','sessions','trips','schema_migrations'] LOOP
    IF NOT EXISTS(SELECT 1 FROM pg_class WHERE oid=to_regclass(format('public.%I',object_name)) AND relowner=operator_oid)
    THEN RAISE EXCEPTION 'Required table must exist and be owned by deployment operator: %',object_name; END IF;
  END LOOP;
  IF NOT EXISTS(SELECT 1 FROM pg_class WHERE oid=to_regclass('public.audit_events_id_seq') AND relowner=operator_oid)
  THEN RAISE EXCEPTION 'Required sequence must be owned by deployment operator: audit_events_id_seq'; END IF;
  FOREACH object_name IN ARRAY ARRAY['cloud_immutable_content','cloud_immutable_letter','purge_invalid_private_export_chunks'] LOOP
    IF NOT EXISTS(SELECT 1 FROM pg_proc WHERE oid=to_regprocedure(format('public.%I()',object_name)) AND proowner=operator_oid)
    THEN RAISE EXCEPTION 'Required function must be owned by deployment operator: %',object_name; END IF;
  END LOOP;
END $authority$;
DO $role$
DECLARE r record;
BEGIN
  IF to_regclass('public.lifecycle_control') IS NULL OR to_regclass('public.ledger_identity') IS NOT NULL THEN RAISE EXCEPTION 'Wrong database: expected business schema only'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cat_letters_app') THEN
    CREATE ROLE cat_letters_app NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
  SELECT * INTO r FROM pg_roles WHERE rolname='cat_letters_app';
  IF r.rolsuper OR r.rolcreatedb OR r.rolcreaterole OR r.rolreplication OR r.rolbypassrls
    OR EXISTS(
      SELECT 1 FROM pg_auth_members m
      WHERE (m.member=r.oid OR m.roleid=r.oid)
        AND NOT (
          current_user='postgres'
          AND EXISTS(SELECT 1 FROM pg_roles WHERE rolname=current_user AND NOT rolsuper AND rolcreaterole)
          AND m.roleid=r.oid
          AND m.member=(SELECT oid FROM pg_roles WHERE rolname='postgres')
          AND m.grantor=10::oid
          AND m.admin_option AND NOT m.inherit_option AND NOT m.set_option
        )
    )
    OR EXISTS(SELECT 1 FROM pg_class WHERE relowner=r.oid)
    OR EXISTS(SELECT 1 FROM pg_namespace WHERE nspowner=r.oid)
    OR EXISTS(SELECT 1 FROM pg_database WHERE datdba=r.oid)
    OR EXISTS(SELECT 1 FROM pg_proc WHERE proowner=r.oid)
  THEN RAISE EXCEPTION 'Runtime role must have no privileged attributes, unsafe memberships, or object ownership'; END IF;
  EXECUTE format('GRANT CONNECT ON DATABASE %I TO cat_letters_app', current_database());
END $role$;
REVOKE CREATE ON SCHEMA public FROM PUBLIC, cat_letters_app;
GRANT USAGE ON SCHEMA public TO cat_letters_app;
ALTER ROLE cat_letters_app SET search_path = pg_catalog, public;
DO $access$
DECLARE spec record; viewer text; columns_sql text; policy_name text; operation text;
BEGIN
 FOR spec IN SELECT * FROM (VALUES
    ('account_deletions','SI','status,phase,attempts,last_error,completed_at,receipt_closed',''),
    ('account_exports','SID','status,lease_token,lease_until,attempts,last_error,expires_at,captured_revision,cat_id,artifact_hash,artifact_bytes,artifact_name',''),
    ('account_rate_limits','SID','attempts,window_at',''),
    ('account_requests','SID','',''),
    ('account_sessions','SID','revoked_at',''),
    ('accounts','SI','email_normalized,status,deleted_at',''),
    ('admin_requests','SID','',''),
    ('audit_events','SID','',''),
    ('cat_profiles','SID','','id'),
    ('cloud_calendar_nodes','SID','result_outcome,result_reason,written_at,effective_at,letter_id',''),
    ('cloud_calendars','SID','processed_count,last_effective_at',''),
    ('cloud_content_versions','SI','','content_id'),
    ('cloud_jobs','SID','status,lease_token,lease_until,last_error,next_run_at,attempts',''),
    ('cloud_letter_sources','SID','',''),
    ('cloud_letters','SID','read_at,skipped_at',''),
    ('cloud_requests','SID','',''),
    ('cloud_response_revisions','SID','text',''),
    ('cloud_responses','SID','current_revision,status,deleted_at',''),
    ('cloud_review_requests','SID','',''),
    ('cloud_review_sources','SID','',''),
    ('cloud_reviews','SID','status,reason',''),
    ('cloud_state','SID','revision',''),
    ('cloud_trips','SID','status,ended_at',''),
    ('content_versions','S','',''),
    ('deletion_preparations','SID','receipt_hash',''),
    ('email_challenges','SID','revoked_at,delivery_status,failures,consumed_at,subject_account_id',''),
    ('erased_legacy_sources','SI','',''),
    ('invites','SID','used_at',''),
    ('legacy_binding_cancellations','SID','',''),
    ('legacy_binding_requests','SID','',''),
    ('legacy_bindings','SID','',''),
    ('letters','SID','read_at,skipped_at',''),
    ('lifecycle_control','S','ledger_id,ledger_sequence,ledger_hash,status,reconciled_at',''),
    ('participants','SID','cat_name,status,safety_state',''),
    ('private_export_budget','S','','singleton'),
    ('private_export_chunks','SID','','export_id'),
    ('rate_limits','SID','attempts,window_at',''),
    ('responses','SID','',''),
    ('safety_cases','SID','',''),
    ('sessions','SID','',''),
    ('trips','SID','ended_at',''),
    ('schema_migrations','','','')
 ) AS permissions(table_name, ops, update_columns, lock_column)
 LOOP
  IF to_regclass(format('public.%I', spec.table_name)) IS NULL THEN
    RAISE EXCEPTION 'Required table missing: %', spec.table_name;
  END IF;
  SELECT string_agg(quote_ident(attname),',') INTO columns_sql
    FROM pg_attribute WHERE attrelid=to_regclass(format('public.%I',spec.table_name))
    AND attnum>0 AND NOT attisdropped;
  FOR viewer IN SELECT unnest(ARRAY['PUBLIC','anon','authenticated','service_role','cat_letters_app'])
  LOOP
   IF viewer='PUBLIC' OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
    EXECUTE format('REVOKE ALL ON TABLE public.%I FROM %s',spec.table_name,
      CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
    EXECUTE format('REVOKE ALL (%s) ON TABLE public.%I FROM %s',columns_sql,spec.table_name,
      CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   END IF;
  END LOOP;
  IF EXISTS(SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename=spec.table_name
    AND policyname NOT IN ('e4_runtime_select','e4_runtime_insert','e4_runtime_update','e4_runtime_delete'))
  THEN RAISE EXCEPTION 'Unexpected policy on %, inspect before changing access',spec.table_name; END IF;
  FOREACH policy_name IN ARRAY ARRAY['e4_runtime_select','e4_runtime_insert','e4_runtime_update','e4_runtime_delete'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',policy_name,spec.table_name);
  END LOOP;
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',spec.table_name);
  FOR operation IN SELECT unnest(ARRAY['SELECT','INSERT','DELETE']) LOOP
    IF position(left(operation,1) IN spec.ops)>0 THEN
      EXECUTE format('GRANT %s ON TABLE public.%I TO cat_letters_app',operation,spec.table_name);
      EXECUTE format('CREATE POLICY %I ON public.%I FOR %s TO cat_letters_app %s',
        'e4_runtime_'||lower(operation),spec.table_name,operation,
        CASE WHEN operation='INSERT' THEN 'WITH CHECK (true)' ELSE 'USING (true)' END);
    END IF;
  END LOOP;
  IF spec.update_columns<>'' THEN
    EXECUTE format('GRANT UPDATE (%s) ON TABLE public.%I TO cat_letters_app',spec.update_columns,spec.table_name);
    EXECUTE format('CREATE POLICY e4_runtime_update ON public.%I FOR UPDATE TO cat_letters_app USING (true) WITH CHECK (true)',spec.table_name);
  ELSIF spec.lock_column<>'' THEN
    -- SELECT FOR UPDATE/SHARE uses UPDATE USING, but does not evaluate WITH CHECK.
    -- Actual UPDATE is rejected, even when attempting to keep the same value.
    EXECUTE format('GRANT UPDATE (%I) ON TABLE public.%I TO cat_letters_app',spec.lock_column,spec.table_name);
    EXECUTE format('CREATE POLICY e4_runtime_update ON public.%I FOR UPDATE TO cat_letters_app USING (true) WITH CHECK (false)',spec.table_name);
  END IF;
 END LOOP;
END $access$;
REVOKE ALL ON SEQUENCE public.audit_events_id_seq FROM PUBLIC, cat_letters_app;
GRANT USAGE ON SEQUENCE public.audit_events_id_seq TO cat_letters_app;
DO $defaults$
DECLARE viewer text; fn text;
BEGIN
 FOR viewer IN SELECT unnest(ARRAY['PUBLIC','anon','authenticated','service_role']) LOOP
  IF viewer='PUBLIC' OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
   -- These defaults affect the operator role executing this file. Future DDL must use that role.
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   -- A schema-level revoke cannot remove PostgreSQL's global default PUBLIC EXECUTE.
   EXECUTE format('ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   EXECUTE format('REVOKE ALL ON SEQUENCE public.audit_events_id_seq FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   FOREACH fn IN ARRAY ARRAY['cloud_immutable_content','cloud_immutable_letter','purge_invalid_private_export_chunks'] LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION public.%I() FROM %s',fn,CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   END LOOP;
  END IF;
 END LOOP;
END $defaults$;
REVOKE ALL ON FUNCTION public.cloud_immutable_content() FROM cat_letters_app;
REVOKE ALL ON FUNCTION public.cloud_immutable_letter() FROM cat_letters_app;
REVOKE ALL ON FUNCTION public.purge_invalid_private_export_chunks() FROM cat_letters_app;
COMMIT;
