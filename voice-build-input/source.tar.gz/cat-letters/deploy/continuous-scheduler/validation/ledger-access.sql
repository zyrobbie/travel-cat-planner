-- Target: Supabase zcwwvwgkpcjfreetehqe (independent ledger only). Apply only after schema migrations and explicit bootstrap/reconcile.
-- No password, LOGIN activation, ownership, BYPASSRLS, public DDL, TRUNCATE, or restore-gate write grant.
-- Runtime authorization remains in the application; policies permit only this server role.
-- Existing unrelated policies cause an explicit failure instead of silently widening access.
BEGIN;
-- Suppress optional creator SET/INHERIT grants; existing polluted memberships still fail below.
SET LOCAL createrole_self_grant = '';
DO $authority$
DECLARE object_name text; operator_oid oid := current_user::regrole::oid;
BEGIN
  IF NOT has_database_privilege(current_user,current_database(),'CONNECT WITH GRANT OPTION')
    OR NOT has_schema_privilege(current_user,'public','CREATE WITH GRANT OPTION')
    OR NOT has_schema_privilege(current_user,'public','USAGE WITH GRANT OPTION')
  THEN RAISE EXCEPTION 'Deployment operator lacks database/schema grant authority'; END IF;
  FOREACH object_name IN ARRAY ARRAY['ledger_identity','ledger_head','ledger_events','restore_gate','restore_operations'] LOOP
    IF NOT EXISTS(SELECT 1 FROM pg_class WHERE oid=to_regclass(format('public.%I',object_name)) AND relowner=operator_oid)
    THEN RAISE EXCEPTION 'Required table must exist and be owned by deployment operator: %',object_name; END IF;
  END LOOP;


END $authority$;
DO $role$
DECLARE r record;
BEGIN
  IF to_regclass('public.ledger_identity') IS NULL OR to_regclass('public.lifecycle_control') IS NOT NULL THEN RAISE EXCEPTION 'Wrong database: expected independent ledger schema only'; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cat_letters_ledger') THEN
    CREATE ROLE cat_letters_ledger NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
  SELECT * INTO r FROM pg_roles WHERE rolname='cat_letters_ledger';
  IF r.rolsuper OR r.rolcreatedb OR r.rolcreaterole OR r.rolreplication OR r.rolbypassrls
    OR EXISTS(
      SELECT 1 FROM pg_auth_members m
      WHERE (m.member=r.oid OR m.roleid=r.oid)
        AND NOT (
          current_user='postgres'
          AND EXISTS(SELECT 1 FROM pg_roles WHERE rolname=current_user AND NOT rolsuper AND rolcreaterole)
          AND m.roleid=r.oid
          AND m.member=(SELECT oid FROM pg_roles WHERE rolname='postgres')
          AND m.grantor=10::oid
          AND m.admin_option AND NOT m.inherit_option AND NOT m.set_option
        )
    )
    OR EXISTS(SELECT 1 FROM pg_class WHERE relowner=r.oid)
    OR EXISTS(SELECT 1 FROM pg_namespace WHERE nspowner=r.oid)
    OR EXISTS(SELECT 1 FROM pg_database WHERE datdba=r.oid)
    OR EXISTS(SELECT 1 FROM pg_proc WHERE proowner=r.oid)
  THEN RAISE EXCEPTION 'Runtime role must have no privileged attributes, unsafe memberships, or object ownership'; END IF;
  EXECUTE format('GRANT CONNECT ON DATABASE %I TO cat_letters_ledger', current_database());
END $role$;
REVOKE CREATE ON SCHEMA public FROM PUBLIC, cat_letters_ledger;
GRANT USAGE ON SCHEMA public TO cat_letters_ledger;
ALTER ROLE cat_letters_ledger SET search_path = pg_catalog, public;
DO $access$
DECLARE spec record; viewer text; columns_sql text; policy_name text; operation text;
BEGIN
 FOR spec IN SELECT * FROM (VALUES
    ('ledger_identity','S','',''),
    ('ledger_head','S','sequence,hash',''),
    ('ledger_events','SI','',''),
    ('restore_gate','S','',''),
    ('restore_operations','S','','')
 ) AS permissions(table_name, ops, update_columns, lock_column)
 LOOP
  IF to_regclass(format('public.%I', spec.table_name)) IS NULL THEN
    RAISE EXCEPTION 'Required table missing: %', spec.table_name;
  END IF;
  SELECT string_agg(quote_ident(attname),',') INTO columns_sql
    FROM pg_attribute WHERE attrelid=to_regclass(format('public.%I',spec.table_name))
    AND attnum>0 AND NOT attisdropped;
  FOR viewer IN SELECT unnest(ARRAY['PUBLIC','anon','authenticated','service_role','cat_letters_ledger'])
  LOOP
   IF viewer='PUBLIC' OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
    EXECUTE format('REVOKE ALL ON TABLE public.%I FROM %s',spec.table_name,
      CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
    EXECUTE format('REVOKE ALL (%s) ON TABLE public.%I FROM %s',columns_sql,spec.table_name,
      CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   END IF;
  END LOOP;
  IF EXISTS(SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename=spec.table_name
    AND policyname NOT IN ('e4_runtime_select','e4_runtime_insert','e4_runtime_update','e4_runtime_delete'))
  THEN RAISE EXCEPTION 'Unexpected policy on %, inspect before changing access',spec.table_name; END IF;
  FOREACH policy_name IN ARRAY ARRAY['e4_runtime_select','e4_runtime_insert','e4_runtime_update','e4_runtime_delete'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',policy_name,spec.table_name);
  END LOOP;
  EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',spec.table_name);
  FOR operation IN SELECT unnest(ARRAY['SELECT','INSERT','DELETE']) LOOP
    IF position(left(operation,1) IN spec.ops)>0 THEN
      EXECUTE format('GRANT %s ON TABLE public.%I TO cat_letters_ledger',operation,spec.table_name);
      EXECUTE format('CREATE POLICY %I ON public.%I FOR %s TO cat_letters_ledger %s',
        'e4_runtime_'||lower(operation),spec.table_name,operation,
        CASE WHEN operation='INSERT' THEN 'WITH CHECK (true)' ELSE 'USING (true)' END);
    END IF;
  END LOOP;
  IF spec.update_columns<>'' THEN
    EXECUTE format('GRANT UPDATE (%s) ON TABLE public.%I TO cat_letters_ledger',spec.update_columns,spec.table_name);
    EXECUTE format('CREATE POLICY e4_runtime_update ON public.%I FOR UPDATE TO cat_letters_ledger USING (true) WITH CHECK (true)',spec.table_name);
  ELSIF spec.lock_column<>'' THEN
    -- SELECT FOR UPDATE/SHARE uses UPDATE USING, but does not evaluate WITH CHECK.
    -- Actual UPDATE is rejected, even when attempting to keep the same value.
    EXECUTE format('GRANT UPDATE (%I) ON TABLE public.%I TO cat_letters_ledger',spec.lock_column,spec.table_name);
    EXECUTE format('CREATE POLICY e4_runtime_update ON public.%I FOR UPDATE TO cat_letters_ledger USING (true) WITH CHECK (false)',spec.table_name);
  END IF;
 END LOOP;
END $access$;

DO $defaults$
DECLARE viewer text; fn text;
BEGIN
 FOR viewer IN SELECT unnest(ARRAY['PUBLIC','anon','authenticated','service_role']) LOOP
  IF viewer='PUBLIC' OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
   -- These defaults affect the operator role executing this file. Future DDL must use that role.
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   -- A schema-level revoke cannot remove PostgreSQL's global default PUBLIC EXECUTE.
   EXECUTE format('ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
   EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM %s', CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);


  END IF;
 END LOOP;
END $defaults$;

COMMIT;
