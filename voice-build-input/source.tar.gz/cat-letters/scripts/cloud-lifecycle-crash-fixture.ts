/** Loaded only by the disposable loopback test harness. */
import assert from "node:assert/strict";
import pg from "pg";
for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
  const u = new URL(process.env[key]!);
  assert.equal(u.hostname, "127.0.0.1");
  assert.equal(u.pathname, "/catletters_cloud_lifecycle_validation_test");
}
assert.ok(process.env.E4_VALIDATION_LOCAL_NONCE);
const mode = process.argv[2];
assert.ok(["claim", "publish"].includes(mode));
const original = pg.Client.prototype.query;
let commits = 0;
pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
  const sql = typeof args[0] === "string" ? args[0] : args[0].text;
  const result = (original as Function).apply(this, args);
  if (sql === "COMMIT") {
    commits++;
    if (
      (mode === "claim" && commits === 1) ||
      (mode === "publish" && commits === 3)
    )
      return result.then(async (value: unknown) => {
        process.send?.({ phase: "COMMITTED_REPLY_HELD" });
        await new Promise(() => {});
        return value;
      });
  }
  return result;
} as typeof original;
const { runValidationExport } =
  await import("../src/server/cloud-lifecycle-validation-worker");
await runValidationExport();
throw Error("Crash fixture completed unexpectedly");
