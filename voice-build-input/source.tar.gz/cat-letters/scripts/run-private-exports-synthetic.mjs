// Own disposable loopback PostgreSQL cluster only; never touches a configured user DB.
import { mkdtemp, mkdir, writeFile, chmod } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { randomBytes } from "node:crypto";
import pg from "pg";
const bin =
  process.env.PRIVATE_EXPORT_PG_BIN || "/opt/homebrew/opt/postgresql@17/bin";
const root = await mkdtemp(join("/private/tmp", "cat-exp-"));
const data = join(root, "pg"),
  ledger = join(root, "ledger");
await mkdir(ledger, { mode: 0o700 });
await chmod(root, 0o700);
const port = await new Promise((yes, no) => {
  const s = createServer();
  s.once("error", no);
  s.listen(0, "127.0.0.1", () => {
    const p = s.address().port;
    s.close(() => yes(p));
  });
});
const env = {
  ...process.env,
  DATABASE_URL: `postgresql://synthetic@127.0.0.1:${port}/catletters_e4d_private_exports_synthetic`,
  APP_MODE: "INTERNAL",
  SAFETY_ADAPTER: "synthetic-v1",
  APP_ORIGIN: "http://127.0.0.1:31999",
  COOKIE_SECURE: "false",
  E4_LIFECYCLE_DIR: ledger,
  E4_LEDGER_SECRET: randomBytes(32).toString("hex"),
  E4_LIFECYCLE_BOOTSTRAP: "true",
  E4_EXPORT_STORAGE: "postgres",
  OTP_ADAPTER: "synthetic-v1",
  OTP_HASH_SECRET: randomBytes(32).toString("hex"),
};
let started = false;
async function run(command, args, extra = {}) {
  const child = spawn(command, args, {
    env: { ...env, ...extra },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let output = "";
  child.stdout.on("data", (x) => {
    output += x;
    process.stdout.write(x);
  });
  child.stderr.on("data", (x) => {
    output += x;
    process.stderr.write(x);
  });
  const code = await new Promise((yes, no) => {
    child.once("error", no);
    child.once("exit", yes);
  });
  if (code !== 0) throw Error(`Synthetic command failed (${code}): ${command}`);
  return output;
}
try {
  await run(join(bin, "initdb"), [
    "-D",
    data,
    "-A",
    "trust",
    "-U",
    "synthetic",
    "--no-locale",
    "-E",
    "UTF8",
  ]);
  await run(join(bin, "pg_ctl"), [
    "-D",
    data,
    "-l",
    join(root, "postgres.log"),
    "-o",
    `-h 127.0.0.1 -p ${port} -k ${root}`,
    "-w",
    "start",
  ]);
  started = true;
  const admin = new pg.Client({
    connectionString: `postgresql://synthetic@127.0.0.1:${port}/postgres`,
  });
  await admin.connect();
  try {
    await admin.query(
      "CREATE DATABASE catletters_e4d_private_exports_synthetic",
    );
    await admin.query("CREATE ROLE anon;CREATE ROLE authenticated");
    console.log(
      "Synthetic cluster identity:",
      (
        await admin.query(
          "SELECT system_identifier::text AS id FROM pg_control_system()",
        )
      ).rows[0].id,
    );
  } finally {
    await admin.end();
  }
  await run(process.execPath, ["--import", "tsx", "scripts/migrate.ts"]);
  await run(process.execPath, [
    "--import",
    "tsx",
    "scripts/lifecycle.ts",
    "reconcile",
  ]);
  await run(
    process.execPath,
    ["--import", "tsx", "scripts/test-private-exports.ts"],
    { E4_LIFECYCLE_BOOTSTRAP: "false" },
  );
} finally {
  if (started)
    await run(join(bin, "pg_ctl"), ["-D", data, "-m", "fast", "-w", "stop"]);
  console.log(
    started
      ? "Owned synthetic cluster stopped; private temporary files remain under:"
      : "Synthetic cluster did not start; private temporary files remain under:",
    root,
  );
}
