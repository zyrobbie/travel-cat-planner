/** Child-process crash fixture. Only disposable loopback databases are accepted. */
import assert from "node:assert/strict";
import pg from "pg";
for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
  const url = new URL(process.env[key]!);
  assert.equal(url.hostname, "127.0.0.1");
  assert.equal(url.pathname, "/catletters_automatic_delivery_test");
}
assert.equal(process.env.E4_SCHEDULED_RUN, "true");
const mode = process.argv[2];
assert.ok(
  [
    "settling",
    "committed",
    "claim-committed",
    "commit-request-lost",
    "claim-commit-request-lost",
  ].includes(mode),
);
const accountId = process.env.E4_AUTO_DELIVERY_ACCOUNT_ID!;
const { claimCloudJob, runClaimedCloudJob } =
  await import("../src/server/cloud-worker");
const { pool } = await import("../src/server/db");
const originalQuery = pg.Client.prototype.query;
let claimPhase = true;
pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
  const sql = typeof args[0] === "string" ? args[0] : args[0].text;
  if (
    sql === "COMMIT" &&
    ((mode === "commit-request-lost" && !claimPhase) ||
      (mode === "claim-commit-request-lost" && claimPhase))
  ) {
    // Deterministic transport-boundary fault: the driver was asked to COMMIT,
    // but its request is lost before PostgreSQL receives it. The caller sees
    // no acknowledgement. Killing the socket must roll back the real DB tx.
    process.send?.({ phase: "COMMIT_REQUEST_LOST" });
    return new Promise(() => {});
  }
  const result = (originalQuery as Function).apply(this, args);
  if (mode === "settling" && /INSERT INTO cloud_letters\(/.test(sql))
    process.send?.({ phase: "SETTLING" });
  if (
    ((mode === "committed" && !claimPhase) ||
      (mode === "claim-committed" && claimPhase)) &&
    sql === "COMMIT" &&
    result?.then
  )
    return result.then(async (value: unknown) => {
      // The DB commit is durable but invocation completion is withheld. Parent
      // kills this process before application acknowledgement/lease cleanup.
      process.send?.({
        phase: claimPhase
          ? "CLAIM_COMMITTED_REPLY_HELD"
          : "COMMITTED_REPLY_HELD",
      });
      await new Promise(() => {});
      return value;
    });
  return result;
} as typeof originalQuery;
try {
  const scope = { accountId, allowBudgetRecovery: true as const };
  const claim = await claimCloudJob(Date.now() + 25_000, scope);
  assert.ok(claim);
  claimPhase = false;
  process.send?.({ phase: "CLAIMED", claim });
  await runClaimedCloudJob(claim, Date.now() + 25_000, scope);
  throw Error("Synthetic child unexpectedly finished before kill");
} finally {
  await pool.end();
}
