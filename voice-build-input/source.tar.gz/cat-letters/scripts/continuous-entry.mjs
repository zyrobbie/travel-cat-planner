// Capture the one invocation deadline before loading any application modules.
const startedAt=Date.now();
try {
  const {continuousMain}=await import('./continuous-worker.ts');
  await continuousMain(startedAt);
} catch {
  console.error(JSON.stringify({event:'continuous_tick',status:'ENTRY_NOT_COMPLETED',elapsedMs:Date.now()-startedAt}));
  process.exitCode=1;
}
