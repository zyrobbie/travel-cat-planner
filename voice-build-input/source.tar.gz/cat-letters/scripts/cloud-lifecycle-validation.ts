/** Coordinator-operated synthetic validation. No migrations, DDL, restore,
 * global workers, real-email adapter, or public endpoint is registered here. */
import assert from "node:assert/strict";
import { randomUUID, createHash } from "node:crypto";
import {
  mkdir,
  lstat,
  readFile,
  writeFile,
  rename,
  unlink,
} from "node:fs/promises";
import { dirname, isAbsolute, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import {
  validationScope,
  validationOrigin,
  validationControlId,
  validationEmail,
} from "../src/server/cloud-lifecycle-validation-scope";
import { HttpError } from "../src/server/errors";

type State = {
  accountId: string;
  controlId: string;
  origin: string;
  keys: Record<string, string>;
  raw?: string;
  controlRaw?: string;
  receipt?: string;
  requestId?: string;
  exportId?: string;
  catId?: string;
  seeded?: boolean;
  exportChecked?: boolean;
  revoked?: boolean;
  deleted?: boolean;
  replacement?: { accountId: string; rawToken: string };
  finished?: boolean;
  controlBefore?: string;
  proofs?: Record<string, any>;
};
const digest = (v: unknown) =>
  createHash("sha256")
    .update(typeof v === "string" ? v : JSON.stringify(v))
    .digest("hex");
const actions = [
  "preflight",
  "seed",
  "export",
  "revoke",
  "delete",
  "query",
  "new-account",
  "finish",
  "run",
] as const;

export async function privateState() {
  const scope = validationScope(),
    controlId = validationControlId(),
    origin = validationOrigin();
  const file = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE ?? "";
  assert.ok(file && isAbsolute(file), "Private state path required");
  await mkdir(dirname(file), { recursive: true, mode: 0o700 });
  const parent = await lstat(dirname(file));
  assert.ok(
    parent.isDirectory() &&
      !parent.isSymbolicLink() &&
      (parent.mode & 0o077) === 0,
    "State parent must be private",
  );
  let state: State;
  try {
    const st = await lstat(file);
    assert.ok(st.isFile() && !st.isSymbolicLink() && (st.mode & 0o077) === 0);
    state = JSON.parse(await readFile(file, "utf8"));
    assert.equal(state.accountId, scope.accountId);
    assert.equal(state.controlId, controlId);
    assert.equal(state.origin, origin);
  } catch (e: any) {
    if (e.code !== "ENOENT") throw e;
    state = {
      accountId: scope.accountId,
      controlId,
      origin,
      keys: Object.fromEntries(
        ["adopt", "export", "export-again", "response-delete", "deletion"].map(
          (k) => [k, randomUUID()],
        ),
      ),
    };
    await writeFile(file, JSON.stringify(state), { mode: 0o600, flag: "wx" });
  }
  async function save() {
    const temp = file + "." + randomUUID() + ".tmp";
    try {
      await writeFile(temp, JSON.stringify(state), { mode: 0o600, flag: "wx" });
      await rename(temp, file);
    } finally {
      await unlink(temp).catch(() => {});
    }
  }
  return { state, save };
}

/** Uses normal, same-origin HTTP and captures only the deletion capability. */
export function validationHttp(
  state: State,
  control = false,
  replacement = false,
) {
  const accountId = control
    ? state.controlId
    : replacement
      ? state.replacement?.accountId
      : state.accountId;
  const raw = control
    ? state.controlRaw
    : replacement
      ? state.replacement?.rawToken
      : state.raw;
  const fetcher: typeof fetch = async (input, init) => {
    validationScope();
    const path = String(input);
    assert.ok(path.startsWith("/api/e4/") && !path.startsWith("//"));
    const headers = new Headers(init?.headers);
    headers.set("Accept", "application/json");
    headers.set("Origin", state.origin);
    if (accountId) headers.set("X-Catletters-Account", accountId);
    const cookies = [];
    if (raw) cookies.push(`cat_account_session=${raw}`);
    if (!control && state.receipt)
      cookies.push(`cat_deletion_receipt=${state.receipt}`);
    if (cookies.length) headers.set("Cookie", cookies.join("; "));
    const r = await fetch(state.origin + path, {
      ...init,
      headers,
      redirect: "error",
      signal: init?.signal ?? AbortSignal.timeout(65_000),
    });
    assert.match(r.headers.get("cache-control") ?? "", /no-store/);
    if (!control)
      for (const cookie of r.headers.getSetCookie()) {
        const m = cookie.match(/^cat_deletion_receipt=([^;]+)/);
        if (m) state.receipt = decodeURIComponent(m[1]);
      }
    return r;
  };
  const json = async (path: string, body?: unknown, expected = 200) => {
    const r = await fetcher(
      path,
      body === undefined
        ? {}
        : {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          },
    );
    assert.equal(r.status, expected, "Unexpected validation HTTP status");
    return r.json();
  };
  return { fetcher, json };
}

async function syntheticLogin(email: string) {
  assert.match(email, /^e4-lifecycle-[a-f0-9-]{36}@example\.invalid$/);
  const { SyntheticMailbox } = await import("../src/server/otp-delivery");
  const { requestCode, verifyCode } =
    await import("../src/server/account-auth");
  const box = new SyntheticMailbox();
  const asked = await requestCode(email, box);
  const code = box.messages.get(asked.challengeId)!.code;
  const result = await verifyCode(asked.challengeId, email, code);
  box.messages.clear();
  return result;
}

async function controlFingerprint(id: string) {
  const { transaction } = await import("../src/server/db");
  return transaction(async (db) => {
    const rows = [];
    for (const table of [
      "accounts",
      "account_sessions",
      "cat_profiles",
      "cloud_letters",
      "cloud_responses",
      "cloud_trips",
      "account_exports",
      "account_deletions",
    ]) {
      const result = await db.query(
        `SELECT * FROM ${table} WHERE ${table === "accounts" ? "id" : "account_id"}=$1`,
        [id],
      );
      rows.push(result.rows.map((r) => JSON.stringify(r)).sort());
    }
    return digest(rows);
  });
}

async function seed(state: State, save: () => Promise<void>) {
  const scope = validationScope();
  const { transaction } = await import("../src/server/db");
  if (state.seeded) return;
  await transaction(async (db) => {
    for (const id of [scope.accountId, state.controlId]) {
      const email = validationEmail(id);
      const old = await db.query(
        "SELECT id,email_normalized,status FROM accounts WHERE id=$1",
        [id],
      );
      if (old.rows[0]) {
        assert.equal(old.rows[0].email_normalized, email);
        assert.equal(old.rows[0].status, "ACTIVE");
      } else
        await db.query(
          "INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",
          [id, email],
        );
    }
  });
  if (!state.raw) {
    const login = await syntheticLogin(scope.email);
    assert.equal(login.accountId, scope.accountId);
    state.raw = login.rawToken;
    await save();
  }
  if (!state.controlRaw) {
    const login = await syntheticLogin(validationEmail(state.controlId));
    assert.equal(login.accountId, state.controlId);
    state.controlRaw = login.rawToken;
    await save();
  }
  const api = validationHttp(state);
  const adopted = await api.json("/api/e4/cat/adopt", {
    key: state.keys.adopt,
    name: "资料验证猫",
    appearanceId: "cat-02",
  });
  state.catId = adopted.cat.id;
  await save();
  await transaction(async (db) => {
    const a = await db.query(
      "SELECT id FROM accounts WHERE id=$1 AND email_normalized=$2 AND status='ACTIVE' FOR UPDATE",
      [scope.accountId, scope.email],
    );
    assert.equal(a.rowCount, 1);
    const cat = await db.query(
      "SELECT id,name FROM cat_profiles WHERE account_id=$1 AND id=$2 FOR UPDATE",
      [scope.accountId, state.catId],
    );
    assert.equal(cat.rows[0]?.name, "资料验证猫");
    if (
      (
        await db.query(
          "SELECT id FROM cloud_letters WHERE account_id=$1 AND id='validation-source'",
          [scope.accountId],
        )
      ).rowCount
    )
      return;
    await db.query(
      "INSERT INTO cloud_trips(id,cat_id,account_id,scene,status,started_at,ended_at,origin) VALUES('validation-trip',$1,$2,'RHINE','COMPLETE',clock_timestamp(),clock_timestamp(),'LEGACY')",
      [state.catId, scope.accountId],
    );
    for (const [id, type, trip] of [
      ["validation-source", "DEMAND", null],
      ["validation-postcard", "POSTCARD", "validation-trip"],
    ])
      await db.query(
        "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,trip_id,read_at,origin) VALUES($1,$2,$3,$4,$5,$6,clock_timestamp(),'LEGACY')",
        [
          id,
          state.catId,
          scope.accountId,
          type,
          {
            title: "合成验证来信",
            body: "本轮资料完整性验证。",
            catName: "资料验证猫",
          },
          trip,
        ],
      );
    await db.query(
      "INSERT INTO cloud_responses(id,cat_id,account_id,letter_id,current_revision,status) VALUES('validation-response',$1,$2,'validation-source',2,'ACTIVE')",
      [state.catId, scope.accountId],
    );
    for (const revision of [1, 2])
      await db.query(
        "INSERT INTO cloud_response_revisions(cat_id,account_id,response_id,revision,text,at) VALUES($1,$2,'validation-response',$3,$4,clock_timestamp())",
        [state.catId, scope.accountId, revision, `合成资料第${revision}版`],
      );
    await db.query(
      "INSERT INTO cloud_letter_sources(cat_id,account_id,letter_id,source_order,response_id,revision,claim,start_offset,end_offset,assessment,attested) VALUES($1,$2,'validation-postcard',0,'validation-response',1,'companionship',0,2,'SUPPORTED',true)",
      [state.catId, scope.accountId],
    );
    await db.query(
      "UPDATE cloud_state SET revision=revision+1 WHERE account_id=$1",
      [scope.accountId],
    );
  });
  state.controlBefore = await controlFingerprint(state.controlId);
  state.seeded = true;
  await save();
}

async function exportCheck(state: State, save: () => Promise<void>) {
  if (state.exportChecked) return state.proofs?.export;
  assert.ok(state.seeded && !state.revoked);
  const api = validationHttp(state);
  const created = await api.json("/api/e4/privacy/exports", {
    key: state.keys.export,
  });
  state.exportId = created.job.id;
  await save();
  const replay = await api.json("/api/e4/privacy/exports", {
    key: state.keys.export,
  });
  assert.equal(replay.job.id, state.exportId);
  const { runValidationExport } =
    await import("../src/server/cloud-lifecycle-validation-worker");
  const status = await api.json(`/api/e4/privacy/exports/${state.exportId}`);
  if (status.job.status !== "READY") {
    if (status.job.status === "FAILED")
      await api.json(`/api/e4/privacy/exports/${state.exportId}/retry`, {});
    const result = await runValidationExport();
    assert.ok(result.status === "READY" || result.status === "IDLE");
  }
  const { fetchAccountExport } =
    await import("../static-app/account-export-download");
  const file = await fetchAccountExport(
    state.accountId,
    state.exportId!,
    AbortSignal.timeout(65_000),
    api.fetcher,
  );
  const bytes = Buffer.from(await file.blob.arrayBuffer()),
    payload = JSON.parse(bytes.toString("utf8"));
  assert.equal(payload.format, "cat-letters-account-export");
  assert.equal(payload.account.id, state.accountId);
  assert.equal(payload.cat.id, state.catId);
  assert.equal(payload.letters.length, 2);
  assert.equal(payload.responses.length, 1);
  assert.equal(payload.responseRevisions.length, 2);
  assert.equal(payload.responseRevisions[1].text, "合成资料第2版");
  assert.equal(payload.letterSources.length, 1);
  assert.equal(payload.trips.length, 1);
  assert.equal(payload.calendar.nodes.length, 13);
  assert.deepEqual(Object.keys(payload.legacyHistory).sort(), [
    "letters",
    "responses",
    "trips",
  ]);
  assert.deepEqual(payload.omitted, [
    "本机草稿",
    "验证码与登录凭证",
    "内部操作记录",
  ]);
  for (const secret of [state.raw, state.controlRaw])
    assert.ok(!bytes.toString("utf8").includes(secret!));
  for (const key of [
    "token_hash",
    "code_hash",
    "receipt_hash",
    "review_authority",
  ])
    assert.ok(!bytes.toString("utf8").includes(key));
  const other = validationHttp(state, true);
  for (const path of [
    `/api/e4/privacy/exports/${state.exportId}`,
    `/api/e4/privacy/exports/${state.exportId}/download-manifest`,
    `/api/e4/privacy/exports/${state.exportId}/chunks/0?version=${"0".repeat(64)}`,
  ])
    await other.json(path, undefined, 404);
  const proof = {
    bytes: bytes.length,
    sha256: digest(bytes.toString("utf8")),
    letters: 2,
    responseRevisions: 2,
    calendarNodes: 13,
    crossAccountDenied: 3,
  };
  state.proofs ??= {};
  state.proofs.export = proof;
  state.exportChecked = true;
  await save();
  return proof;
}

async function revoke(state: State, save: () => Promise<void>) {
  if (state.revoked) return state.proofs?.revoke;
  assert.ok(state.exportChecked && !state.deleted);
  const api = validationHttp(state);
  await api.json("/api/e4/v1/responses/validation-response/delete", {
    key: state.keys["response-delete"],
    expectedRevision: 2,
  });
  const status = await api.json(`/api/e4/privacy/exports/${state.exportId}`);
  assert.equal(status.job.status, "REVOKED");
  await api.json(
    `/api/e4/privacy/exports/${state.exportId}/download-manifest`,
    undefined,
    409,
  );
  const { observeValidationAccount, cleanupValidationExports } =
    await import("../src/server/cloud-lifecycle-validation-worker");
  assert.equal((await observeValidationAccount()).counts.chunks, 0);
  const cleanup = await cleanupValidationExports();
  assert.equal(cleanup.status, "CLEANED");
  const proof = {
    status: "REVOKED",
    chunksAfterRevocation: 0,
    scopedCleanup: cleanup,
    natural24HourExpiryObserved: false,
  };
  state.proofs ??= {};
  state.proofs.revoke = proof;
  state.revoked = true;
  await save();
  return proof;
}

async function removeAccount(state: State, save: () => Promise<void>) {
  assert.ok(state.revoked);
  const api = validationHttp(state);
  if (!state.receipt) {
    const r = await api.json("/api/e4/privacy/deletions/prepare", {
      key: state.keys.deletion,
    });
    state.requestId = r.deletion.requestId;
    await save();
  }
  let r = await api.json("/api/e4/privacy/deletions/status");
  assert.equal(r.deletion.accountId, state.accountId);
  assert.equal(r.deletion.requestId, state.requestId);
  if (r.deletion.status === "PREPARED") {
    await api.json("/api/e4/privacy/deletions/confirm", {
      requestId: state.requestId,
      confirm: true,
    });
    r = await api.json("/api/e4/privacy/deletions/status");
  }
  await api.json("/api/e4/account", undefined, 401);
  if (r.deletion.status !== "COMPLETE")
    r = await api.json("/api/e4/privacy/deletions/retry", {
      requestId: state.requestId,
    });
  assert.equal(r.deletion.status, "COMPLETE");
  const repeated = await api.json("/api/e4/privacy/deletions/retry", {
    requestId: state.requestId,
  });
  assert.equal(repeated.deletion.requestId, state.requestId);
  assert.equal(repeated.deletion.status, "COMPLETE");
  const { observeValidationAccount } =
    await import("../src/server/cloud-lifecycle-validation-worker");
  const observed = await observeValidationAccount();
  assert.equal(observed.status, "DELETED");
  assert.deepEqual(observed.counts, {
    cats: 0,
    letters: 0,
    responses: 0,
    live_sessions: 0,
    chunks: 0,
  });
  assert.equal(await controlFingerprint(state.controlId), state.controlBefore);
  state.deleted = true;
  await save();
  return {
    status: "COMPLETE",
    oldSessionRejected: true,
    purged: observed.counts,
    controlUnchanged: true,
  };
}

async function replacement(state: State, save: () => Promise<void>) {
  assert.ok(state.deleted);
  if (!state.replacement) {
    const login = await syntheticLogin(validationScope().email);
    assert.notEqual(login.accountId, state.accountId);
    state.replacement = {
      accountId: login.accountId,
      rawToken: login.rawToken,
    };
    await save();
  }
  const fresh = validationHttp(state, false, true);
  const account = await fresh.json("/api/e4/account");
  assert.equal(account.id, state.replacement.accountId);
  assert.equal(account.cat, null);
  const receipt = await fresh.json("/api/e4/privacy/deletions/status");
  assert.equal(receipt.deletion.accountId, state.accountId);
  assert.equal(receipt.deletion.status, "COMPLETE");
  await fresh.json("/api/e4/privacy/deletions/retry", {
    requestId: state.requestId,
  });
  assert.equal(
    (await fresh.json("/api/e4/account")).id,
    state.replacement.accountId,
  );
  return {
    freshAccountIsDistinct: true,
    oldCatNotRestored: true,
    oldReceiptDoesNotDeleteNewAccount: true,
  };
}

export async function runValidationFlow(action: string) {
  assert.ok(actions.includes(action as any), "Unsupported validation action");
  validationScope();
  validationOrigin();
  if (action === "query") {
    // A receipt-bound prefix read remains available when a durable deletion
    // intent precedes the business watermark. Preserve this recovery path.
    const { state } = await privateState();
    const result = await validationHttp(state).json(
      "/api/e4/privacy/deletions/status",
    );
    if (result.deletion) {
      assert.equal(result.deletion.accountId, state.accountId);
      if (state.requestId)
        assert.equal(result.deletion.requestId, state.requestId);
    }
    return result;
  }
  const worker =
    await import("../src/server/cloud-lifecycle-validation-worker");
  const preflight = await worker.preflightValidation();
  // Anonymous read-only probes catch an unreachable/protected wrong origin
  // before creating even a synthetic account. No OTP/email request is made.
  for (const [path, status] of [
    ["/api/health", 200],
    ["/api/e4/account", 401],
  ] as const) {
    const r = await fetch(validationOrigin() + path, {
      headers: { Accept: "application/json" },
      redirect: "error",
      cache: "no-store",
      signal: AbortSignal.timeout(65_000),
    });
    assert.equal(r.status, status, "Existing cloud HTTP preflight failed");
    assert.match(r.headers.get("content-type") ?? "", /application\/json/);
    assert.match(r.headers.get("cache-control") ?? "", /no-store/);
    await r.arrayBuffer();
  }
  if (action === "preflight")
    return {
      ...preflight,
      existingHttpHealth: true,
      anonymousAccountDenied: true,
      deploymentRequired: false,
    };
  const { state, save } = await privateState();
  const results: Record<string, unknown> = {};
  if (action === "run" || action === "seed") {
    await seed(state, save);
    results.seed = { ready: true };
  }
  if (action === "run" || action === "export")
    results.export = await exportCheck(state, save);
  if (action === "run" || action === "revoke")
    results.revoke = await revoke(state, save);
  if (action === "run" || action === "delete")
    results.deletion = await removeAccount(state, save);
  if (action === "run" || action === "new-account")
    results.replacement = await replacement(state, save);
  if (action === "run" || action === "finish") {
    assert.ok(state.replacement);
    const api = validationHttp(state, false, true);
    const r = await api.json("/api/e4/privacy/deletions/finish", {
      requestId: state.requestId,
    });
    assert.equal(r.finished, true);
    assert.equal(
      (await api.json("/api/e4/account")).id,
      state.replacement.accountId,
    );
    state.finished = true;
    await save();
    results.finish = { oldReceiptClosed: true, newSessionPreserved: true };
  }
  return {
    status: "PASS_FOR_COMPLETED_STAGES",
    results,
    emailSent: false,
    cloudRestoreExecuted: false,
  };
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  let loaded = false;
  try {
    assert.equal(process.argv.length, 3);
    assert.ok(actions.includes(process.argv[2] as any));
    validationScope();
    validationOrigin();
    process.env.E4_SCHEDULED_RUN = "true";
    loaded = true;
    console.log(JSON.stringify(await runValidationFlow(process.argv[2])));
  } catch (error) {
    console.error(
      JSON.stringify({
        status: !loaded
          ? "REJECTED"
          : process.argv[2] === "preflight"
            ? "BLOCKED_PREFLIGHT"
            : "UNKNOWN_QUERY_SAME_PRIVATE_STATE",
        reason:
          error instanceof HttpError
            ? error.message
            : "validation_not_completed",
        action: actions.includes(process.argv[2] as any)
          ? process.argv[2]
          : "INVALID",
      }),
    );
    process.exitCode = 1;
  } finally {
    if (loaded) {
      const { closeLifecycleProvider } =
        await import("../src/server/lifecycle-provider");
      const { pool } = await import("../src/server/db");
      await closeLifecycleProvider();
      await pool.end();
    }
  }
}
