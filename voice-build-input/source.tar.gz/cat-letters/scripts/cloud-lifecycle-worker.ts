/** Operator-only command, never imported by an HTTP/Netlify entry. */
import {
  validationScope,
  validationDeadline,
} from "../src/server/cloud-lifecycle-validation-scope";
import { HttpError } from "../src/server/errors";
const startedAt = Date.now();
const action = process.argv[2];
let loaded = false;
let workStarted = false;
try {
  if (
    process.argv.length !== 3 ||
    !["preflight", "export", "cleanup", "observe"].includes(action)
  )
    throw Error("INVALID_VALIDATION_ACTION");
  validationScope();
  const deadlineAt = validationDeadline(startedAt);
  process.env.E4_SCHEDULED_RUN = "true";
  const worker =
    await import("../src/server/cloud-lifecycle-validation-worker");
  loaded = true;
  const preflight = await worker.preflightValidation(deadlineAt);
  workStarted = action !== "preflight";
  const result =
    action === "preflight"
      ? preflight
      : await {
          preflight: worker.preflightValidation,
          export: worker.runValidationExport,
          cleanup: worker.cleanupValidationExports,
          observe: worker.observeValidationAccount,
        }[action]!(deadlineAt);
  console.log(
    JSON.stringify({ action, result, elapsedMs: Date.now() - startedAt }),
  );
} catch (error) {
  // Raw DB/HTTP errors may contain connection details. Unknown is queryable.
  console.error(
    JSON.stringify({
      action: ["preflight", "export", "cleanup", "observe"].includes(action)
        ? action
        : "INVALID",
      status: !loaded
        ? "REJECTED"
        : workStarted
          ? "UNKNOWN_CHECK_DURABLE_STATE"
          : "BLOCKED_PREFLIGHT",
      reason:
        error instanceof HttpError ? error.message : "validation_not_completed",
    }),
  );
  process.exitCode = 1;
} finally {
  if (loaded) {
    const { closeLifecycleProvider } =
      await import("../src/server/lifecycle-provider");
    const { pool } = await import("../src/server/db");
    await closeLifecycleProvider();
    await pool.end();
  }
}
