import "dotenv/config";
import { pool } from "../src/server/db";
import { closeLifecycleProvider, independentLedger, lifecycleAdapterMode } from "../src/server/lifecycle-provider";
import { assertInternal } from "../src/server/safety";
import {
  reconcileLifecycle,
  runDeletionWorkerOnce,
} from "../src/server/account-lifecycle";
import {
  closeLifecycleForRestore,
  assertLifecycleReady,
} from "../src/server/lifecycle-ledger";
import {
  runExportWorkerOnce,
  cleanupAccountExports,
} from "../src/server/account-export";
try {
  assertInternal();
  const command = process.argv[2];
  if (command === "bootstrap") {
    if (lifecycleAdapterMode() !== "postgres-v1") throw Error("Bootstrap command requires postgres-v1");
    const operationId = process.argv[3];
    if (!operationId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(operationId))
      throw Error("Bootstrap requires an operator-recorded UUID");
    await independentLedger(pool).bootstrap();
    const closed = await closeLifecycleForRestore(operationId);
    console.log(JSON.stringify({ bootstrapped: true, ...closed }));
  } else if (command === "reconcile")
    console.log(JSON.stringify(await reconcileLifecycle(process.argv[3], Number(process.argv[4]))));
  else if (command === "restore-lock")
    console.log(JSON.stringify(await closeLifecycleForRestore(process.argv[3])));
  else if (command === "check") {
    await assertLifecycleReady();
    console.log(JSON.stringify({ ready: true }));
  } else if (command === "tick") {
    await assertLifecycleReady();
    console.log(
      JSON.stringify({
        deletion: await runDeletionWorkerOnce(),
        export: await runExportWorkerOnce(),
        cleanup: await cleanupAccountExports(),
      }),
    );
  } else
    throw new Error(
      "Usage: tsx scripts/lifecycle.ts bootstrap [UUID]|restore-lock [UUID]|reconcile [UUID epoch]|check|tick",
    );
} catch (error) {
  console.error(
    error instanceof Error ? error.message : "Lifecycle operation failed",
  );
  process.exitCode = 1;
} finally {
  await closeLifecycleProvider();
  await pool.end();
}
