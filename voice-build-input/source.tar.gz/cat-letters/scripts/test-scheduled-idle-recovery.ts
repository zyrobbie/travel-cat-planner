/** Two disposable local PostgreSQL projects only; never a live URL. */
import "dotenv/config";
import assert from "node:assert/strict";
import pg from "pg";

const businessUrl = new URL(process.env.DATABASE_URL!);
const ledgerUrl = new URL(process.env.E4_LEDGER_DATABASE_URL!);
assert.equal(businessUrl.hostname, "localhost");
assert.equal(ledgerUrl.hostname, "localhost");
assert.equal(businessUrl.pathname, "/catletters_e4d_scheduler_business_test");
assert.equal(ledgerUrl.pathname, "/catletters_e4d_scheduler_ledger_test");
assert.equal(businessUrl.searchParams.get("application_name"), "e4d_idle_business");
assert.equal(ledgerUrl.searchParams.get("application_name"), "e4d_idle_ledger");
process.env.E4_SCHEDULED_RUN = "true";

const { pool } = await import("../src/server/db");
const { independentLedger, closeLifecycleProvider } =
  await import("../src/server/lifecycle-provider");
const businessAdminUrl = new URL(businessUrl);
businessAdminUrl.searchParams.set("application_name", "e4d_idle_business_admin");
const ledgerAdminUrl = new URL(ledgerUrl);
ledgerAdminUrl.searchParams.set("application_name", "e4d_idle_ledger_admin");
const businessAdmin = new pg.Pool({ connectionString: businessAdminUrl.href });
const ledgerAdmin = new pg.Pool({ connectionString: ledgerAdminUrl.href });
const warnings: string[] = [];
const priorWarn = console.warn;
console.warn = (...parts: unknown[]) => {
  const line = parts.map(String).join(" ");
  warnings.push(line);
  priorWarn(line);
};
const pause = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
async function idlePid(admin: pg.Pool, name: string) {
  const rows = (await admin.query(
    "SELECT pid FROM pg_stat_activity WHERE datname=current_database() AND application_name=$1 AND state='idle'",
    [name],
  )).rows;
  assert.equal(rows.length, 1);
  return rows[0].pid as number;
}

try {
  const [businessSystem, ledgerSystem] = await Promise.all([
    businessAdmin.query("SELECT system_identifier FROM pg_control_system()"),
    ledgerAdmin.query("SELECT system_identifier FROM pg_control_system()"),
  ]);
  assert.notEqual(businessSystem.rows[0].system_identifier,
    ledgerSystem.rows[0].system_identifier);
  const adapter = independentLedger(pool);
  assert.equal(await adapter.readBusinessTx(async db =>
    (await db.query("SELECT 1 AS value")).rows[0].value, Date.now() + 25_000), 1);
  assert.equal(pool.idleCount, 1);
  const [businessPid, ledgerPid] = await Promise.all([
    idlePid(businessAdmin, "e4d_idle_business"),
    idlePid(ledgerAdmin, "e4d_idle_ledger"),
  ]);
  const terminated = await Promise.all([
    businessAdmin.query("SELECT pg_terminate_backend($1) AS done", [businessPid]),
    ledgerAdmin.query("SELECT pg_terminate_backend($1) AS done", [ledgerPid]),
  ]);
  assert.ok(terminated.every(result => result.rows[0].done === true));
  for (let i = 0; i < 30 && warnings.length < 2; i++) await pause(100);
  assert.deepEqual(warnings.sort(), [
    "Business PostgreSQL idle connection removed.",
    "Ledger PostgreSQL idle connection removed.",
  ]);
  assert.equal(pool.idleCount, 0);
  console.log("PASS both idle backend errors handled with fixed, redacted messages");

  assert.equal(await adapter.readBusinessTx(async db =>
    (await db.query("SELECT 2 AS value")).rows[0].value, Date.now() + 25_000), 2);
  assert.equal(pool.idleCount, 1);
  await Promise.all([
    idlePid(businessAdmin, "e4d_idle_business"),
    idlePid(ledgerAdmin, "e4d_idle_ledger"),
  ]);
  console.log("PASS next invocation reconnects both pools and completes");
} finally {
  console.warn = priorWarn;
  await closeLifecycleProvider();
  await pool.end();
  assert.equal(pool.totalCount, 0);
  for (let i = 0; i < 30; i++) {
    const rows = await Promise.all([
      businessAdmin.query("SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4d_idle_business'"),
      ledgerAdmin.query("SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4d_idle_ledger'"),
    ]);
    if (rows.every(result => result.rows[0].n === 0)) break;
    await pause(100);
  }
  const remaining = await Promise.all([
    businessAdmin.query("SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4d_idle_business'"),
    ledgerAdmin.query("SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4d_idle_ledger'"),
  ]);
  assert.ok(remaining.every(result => result.rows[0].n === 0));
  await Promise.all([businessAdmin.end(), ledgerAdmin.end()]);
  console.log("PASS both scheduler pools close without residual backend connections");
}
