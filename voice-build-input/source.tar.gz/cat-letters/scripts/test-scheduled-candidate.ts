/** Disposable two-database scheduler test; never run against a user database. */
import "dotenv/config";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";

const businessName = "catletters_e4d_scheduler_business_test";
const ledgerName = "catletters_e4d_scheduler_ledger_test";
assert.equal(new URL(process.env.DATABASE_URL!).pathname, `/${businessName}`);
assert.equal(new URL(process.env.E4_LEDGER_DATABASE_URL!).pathname, `/${ledgerName}`);
assert.ok(["localhost", "127.0.0.1"].includes(new URL(process.env.DATABASE_URL!).hostname));
assert.ok(["localhost", "127.0.0.1"].includes(new URL(process.env.E4_LEDGER_DATABASE_URL!).hostname));
process.env.E4_SCHEDULED_RUN = "true";
const { pool, transaction } = await import("../src/server/db");
const { closeLifecycleProvider } = await import("../src/server/lifecycle-provider");
const { cloudTick, privacyTick, privacyCleanupTick } = await import("../src/server/scheduled-candidate");
const { lockCloudCat } = await import("../src/server/cloud-repository");
const { initializeCloudCalendar } = await import("../src/server/cloud-calendar");

try {
  const identity = (await pool.query("SELECT current_database() AS name")).rows[0].name;
  assert.equal(identity, businessName);
  await pool.query("DELETE FROM account_exports");
  await pool.query("DELETE FROM account_rate_limits WHERE key LIKE 'scheduler-old-%'");
  await pool.query(
    "INSERT INTO account_rate_limits(key,window_at) SELECT 'scheduler-old-'||g,clock_timestamp()-interval '2 days' FROM generate_series(1,120) g",
  );
  const first = await privacyCleanupTick();
  const second = await privacyCleanupTick();
  assert.equal(first.outcome.selected, 100);
  assert.equal(second.outcome.selected, 20);
  assert.equal(Number((await pool.query("SELECT count(*) AS n FROM account_rate_limits WHERE key LIKE 'scheduler-old-%'")).rows[0].n), 0);
  console.log(`PASS bounded cleanup 100+20; ${first.elapsedMs}ms, ${second.elapsedMs}ms`);

  const cloudAccounts: string[] = [];
  const seedCloud = async () => {
    const accountId = randomUUID(), participantId = randomUUID(), catId = randomUUID();
    cloudAccounts.push(accountId);
    await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",
      [accountId, `${accountId}@example.test`]);
    await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [participantId]);
    await pool.query("INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-01','合成猫')",
      [catId, accountId, participantId]);
    await transaction(async db => {
      const cat = await lockCloudCat(db, accountId);
      await initializeCloudCalendar(db, cat, Date.now() - 20 * 60_000);
    });
  };
  for (let i = 0; i < 6; i++) await seedCloud();
  const cloudFirst = await cloudTick();
  assert.equal(cloudFirst.attempted, 5);
  assert.ok(cloudFirst.outcomes.every(x => x.status === "SETTLED"));
  const cloudSecond = await cloudTick();
  assert.equal(cloudSecond.attempted, 1);
  const cloudThird = await cloudTick();
  assert.equal(cloudThird.attempted, 0);
  const letters = Number((await pool.query(
    "SELECT count(*) AS n FROM cloud_letters WHERE account_id=ANY($1::uuid[])", [cloudAccounts],
  )).rows[0].n);
  assert.equal(letters, 6);
  console.log(`PASS cloud cap 5, six due jobs settle once; ${cloudFirst.elapsedMs}ms + ${cloudSecond.elapsedMs}ms`);
  await seedCloud();
  await seedCloud();
  const overlap = await Promise.all([cloudTick(), cloudTick()]);
  assert.equal(overlap.reduce((count, tick) => count + tick.attempted, 0), 2);
  assert.equal(Number((await pool.query(
    "SELECT count(*) AS n FROM cloud_letters WHERE account_id=ANY($1::uuid[])", [cloudAccounts],
  )).rows[0].n), 8);
  assert.equal((await cloudTick()).attempted, 0);
  console.log("PASS overlapping cloud invocations retain one delivery per due cat");

  const account = randomUUID();
  const exportId = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",
    [account, `${account}@example.test`]);
  // Exact durable shape left when a timed-out erasure increments attempts but
  // cannot use its expired scope to record the final failure.
  await pool.query("INSERT INTO account_deletions(account_id,request_id,status,attempts) VALUES($1,$2,'PENDING',3)",
    [account, randomUUID()]);
  await pool.query("INSERT INTO account_exports(id,account_id,request_key,status) VALUES($1,$2,$3,'QUEUED')",
    [exportId, account, randomUUID()]);
  // Test-only opt-in proves selection; the actual candidate defaults OFF.
  process.env.E4_SCHEDULED_EXPORTS_ENABLED = "true";
  const small = await privacyTick();
  assert.equal(small.task, "export");
  assert.equal(small.outcome.status, "READY");
  const exhausted = (await pool.query("SELECT status,last_error FROM account_deletions WHERE account_id=$1", [account])).rows[0];
  assert.deepEqual(exhausted, { status: "FAILED", last_error: "AUTO_RETRIES_EXHAUSTED" });
  console.log(`PASS persisted attempts cap prevents timed-out PENDING deletion starving export; ${small.elapsedMs}ms`);

  const expiredId = randomUUID(), revokedId = randomUUID();
  const body = Buffer.from("x"), bodyHash = createHash("sha256").update(body).digest("hex");
  for (const [id, expiry, catId] of [
    [expiredId, "past", null], [revokedId, "future", randomUUID()],
  ] as const) {
    const name = `${id}.${randomUUID()}.json`;
    await pool.query(
      `INSERT INTO account_exports(id,account_id,request_key,status,expires_at,
        cat_id,artifact_name,artifact_hash,artifact_bytes)
        VALUES($1,$2,$3,'READY',clock_timestamp()+$4::interval,$5,$6,$7,1)`,
      [id, account, randomUUID(), expiry === "past" ? "-1 hour" : "1 hour",
        catId, name, bodyHash]);
    await pool.query(
      `INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body)
        VALUES($1,$2,0,1,$3,$4)`, [id, name, bodyHash, body]);
  }
  const cleanup = await privacyCleanupTick();
  assert.equal(cleanup.outcome.expired, 1);
  assert.equal(cleanup.outcome.revoked, 1);
  assert.equal((await pool.query("SELECT status FROM account_exports WHERE id=$1", [exportId])).rows[0].status, "READY");
  assert.equal(Number((await pool.query("SELECT count(*) AS n FROM private_export_chunks WHERE export_id=ANY($1::uuid[])",
    [[expiredId, revokedId]])).rows[0].n), 0);
  console.log("PASS expired and invalid exports lose chunks; valid export remains READY");

  const largeAccount = randomUUID();
  const participant = randomUUID();
  const cat = randomUUID();
  const largeId = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",
    [largeAccount, `${largeAccount}@example.test`]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [participant]);
  await pool.query("INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-01','合成猫')",
    [cat, largeAccount, participant]);
  await pool.query("INSERT INTO cloud_state(cat_id,account_id,revision) VALUES($1,$2,0)",
    [cat, largeAccount]);
  await pool.query(
    `INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot)
      SELECT 'scheduler-letter-'||g,$1,$2,'DEMAND',
        jsonb_build_object('title','合成来信','body',repeat(md5(g::text),90),'catName','合成猫')
      FROM generate_series(1,10000) g`, [cat, largeAccount]);
  await pool.query("INSERT INTO account_exports(id,account_id,request_key,status) VALUES($1,$2,$3,'QUEUED')",
    [largeId, largeAccount, randomUUID()]);
  const started = Date.now();
  const large = await privacyTick();
  const elapsedMs = Date.now() - started;
  const row = (await pool.query("SELECT status,artifact_bytes FROM account_exports WHERE id=$1", [largeId])).rows[0];
  console.log(JSON.stringify({ benchmark: "full-product-export", elapsedMs,
    status: row.status, bytes: Number(row.artifact_bytes ?? 0),
    maximumBytes: 32 * 1024 * 1024 }));
  assert.equal(large.task, "export");
  assert.equal(large.outcome.status, "READY");
  assert.ok(Number(row.artifact_bytes) > 28 * 1024 * 1024);
  assert.ok(Number(row.artifact_bytes) <= 32 * 1024 * 1024);
  assert.ok(elapsedMs < 25_000);
  console.log("PASS near-32MiB collectExport -> JSON -> PostgreSQL publication within local 25s budget");
} finally {
  await closeLifecycleProvider();
  await pool.end();
}
