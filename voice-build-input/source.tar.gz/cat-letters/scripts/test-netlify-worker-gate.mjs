import assert from "node:assert/strict";
import handler, { config } from "../netlify/functions/e4-worker.mts";

const names = ["APP_MODE", "E4_MANUAL_WORKER_ENABLED", "E4_MANUAL_WORKER_TOKEN",
  "E4_SCHEDULED_RUN", "E4_TEST_WORKER_ACCOUNT_ID"];
const before = Object.fromEntries(names.map(name => [name, process.env[name]]));
const secret = "a".repeat(64);
const request = (kind, method = "POST", bearer) =>
  new Request(`https://local.invalid/.netlify/functions/e4-worker?kind=${kind}`, {
    method,
    headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
  });

try {
  assert.deepEqual(config, { method: "POST" });
  delete process.env.E4_SCHEDULED_RUN;
  delete process.env.E4_TEST_WORKER_ACCOUNT_ID;
  process.env.APP_MODE = "INTERNAL";
  process.env.E4_MANUAL_WORKER_ENABLED = "false";
  process.env.E4_MANUAL_WORKER_TOKEN = secret;
  assert.equal((await handler(request("cloud", "GET", secret))).status, 405);
  assert.equal((await handler(request("cloud", "POST", secret))).status, 404);
  process.env.APP_MODE = "PUBLIC";
  process.env.E4_MANUAL_WORKER_ENABLED = "true";
  assert.equal((await handler(request("cloud", "POST", secret))).status, 404);
  process.env.APP_MODE = "INTERNAL";
  process.env.E4_MANUAL_WORKER_TOKEN = "short";
  assert.equal((await handler(request("cloud", "POST", secret))).status, 503);
  process.env.E4_MANUAL_WORKER_TOKEN = secret;
  assert.equal((await handler(request("cloud"))).status, 401);
  assert.equal((await handler(request("cloud", "POST", "b".repeat(64)))).status, 401);
  assert.equal((await handler(request("cloud", "POST", ` ${secret}`))).status, 401);
  assert.equal((await handler(request("invalid", "POST", secret))).status, 400);
  assert.equal((await handler(request("cloud", "POST", secret))).status, 503);
  process.env.E4_TEST_WORKER_ACCOUNT_ID = "not-a-uuid";
  assert.equal((await handler(request("cloud", "POST", secret))).status, 503);
  process.env.E4_TEST_WORKER_ACCOUNT_ID = "11111111-1111-4111-8111-111111111111";
  for (const kind of ["privacy", "cleanup"])
    assert.equal((await handler(request(kind, "POST", secret))).status, 403);
  for (const query of [
    "cloud&accountId=22222222-2222-4222-8222-222222222222",
    "cloud&all=true", "cloud&kind=cloud",
  ]) assert.equal((await handler(request(query, "POST", secret))).status, 400);
  const suppliedBody = new Request("https://local.invalid/.netlify/functions/e4-worker?kind=cloud", {
    method: "POST", headers: { Authorization: `Bearer ${secret}` },
    body: JSON.stringify({ accountId: "22222222-2222-4222-8222-222222222222" }),
  });
  assert.equal((await handler(suppliedBody)).status, 400);
  const noKind = await handler(request("", "POST", secret));
  assert.equal(noKind.status, 400);
  assert.equal(noKind.headers.get("cache-control"), "no-store, private");
  assert.equal(process.env.E4_SCHEDULED_RUN, undefined,
    "denied requests must not load the worker or change pool configuration");
  console.log("PASS manual worker gate: default-off, token, deployment scope, no caller scope/body, cloud-only, no worker import");
} finally {
  for (const name of names) {
    const value = before[name];
    if (value === undefined) delete process.env[name];
    else process.env[name] = value;
  }
}
