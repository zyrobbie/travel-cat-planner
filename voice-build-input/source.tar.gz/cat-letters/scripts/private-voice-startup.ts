import { spawn } from "node:child_process";
import { pathToFileURL } from "node:url";
import { enforcePrivateVoiceLinux } from "./private-voice-linux-guard";
import { validatePrivateVoiceBase } from "../src/server/private-voice-entry-config";

type Environment = Readonly<Record<string, string | undefined>>;

export function privateVoiceStartupAction(env: Environment) {
  const config = validatePrivateVoiceBase(env);
  if (config.entry === "closed" && !config.cleanup && JSON.parse(env.E4_VOICE_ACCOUNT_IDS!).length === 0) return "skip";
  if (!config.cleanup) throw new Error("PRIVATE_VOICE_STARTUP_RECOVERY_REQUIRED");
  return "cleanup";
}

export function privateVoiceStartupEnvironment(env: Environment) {
  const output: NodeJS.ProcessEnv = { PATH: "/usr/bin:/bin", LANG: "C.UTF-8", NODE_ENV: "production", DOTENV_CONFIG_PATH: "/dev/null", TSX_DISABLE_CACHE: "1" };
  for (const key of ["APP_MODE", "SAFETY_ADAPTER", "DATABASE_URL", "E4_LEDGER_DATABASE_URL", "OTP_HASH_SECRET", "E4_LEDGER_SECRET",
    "APP_ORIGIN", "ACCOUNT_COOKIE_NAME", "DELETION_COOKIE_NAME", "COOKIE_SECURE", "NETLIFY", "E4_SCHEDULED_RUN",
    "E4_LIFECYCLE_ADAPTER", "E4_LIFECYCLE_BOOTSTRAP", "E4_LIFECYCLE_RECOVERY", "E4_EXPORT_STORAGE",
    "E4_VOICE_STORAGE", "E4_VOICE_PAYLOAD_DIRECTORY", "E4_VOICE_PROBE_DIRECTORY", "E4_VOICE_CLEANUP_ENABLED", "E4_VOICE_ACCOUNT_IDS"])
    if (env[key] !== undefined) output[key] = env[key]!;
  // Maintenance never receives provider/mail keys or inherits a hidden dotenv/debug path.
  output.E4_VOICE_ENABLED = "false";
  output.E4_VOICE_MODE = "disabled";
  output.OTP_ADAPTER = "disabled";
  output.TMPDIR = "/run/cat-voice-private";
  return output;
}

/** Cleanup failure is a voice-health failure, not permission to stop ordinary text. */
export async function privateVoiceStartupRecovery(run: () => Promise<number | null>) {
  try { return await run() === 0 ? "complete" as const : "pending" as const; }
  catch { return "pending" as const; }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  let action: "skip" | "cleanup" | undefined;
  try {
    enforcePrivateVoiceLinux("app");
    action = privateVoiceStartupAction(process.env);
  } catch {
    console.error("PRIVATE_VOICE_STARTUP_SAFETY_FAILED");
    process.exitCode = 1;
  }
  if (action === "cleanup") {
      const result = await privateVoiceStartupRecovery(() => new Promise<number | null>((resolve, reject) => {
        const child = spawn(process.execPath, ["--max-old-space-size=64", "--import", "tsx", "scripts/voice-cleanup.ts"], {
          env: privateVoiceStartupEnvironment(process.env), stdio: ["ignore", "inherit", "inherit"],
          timeout: 40_000, killSignal: "SIGTERM",
        });
        child.once("error", reject);
        child.once("exit", resolve);
      }));
      if (result === "complete") console.log("PRIVATE_VOICE_STARTUP_RECOVERY_COMPLETE");
      else console.error("PRIVATE_VOICE_STARTUP_RECOVERY_PENDING");
  } else if (action === "skip") console.log("PRIVATE_VOICE_CLOSED_BASE_NO_RECOVERY_REQUIRED");
}
