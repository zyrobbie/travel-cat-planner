/** Synthetic only: two disposable local PostgreSQL clusters, never a live URL. */
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { Pool } from "pg";
import { IndependentLedger } from "../src/server/independent-ledger";
import type { Ledger, LedgerPayload } from "../src/server/lifecycle-ledger";

const socket = process.env.E4_INDEPENDENT_TEST_SOCKET ?? "/private/tmp";
assert.ok(socket.startsWith("/"), "Synthetic tests require a local Unix socket directory");
const business = new Pool({ host: socket, port: 55971,
  database: "catletters_e4d_business_synthetic", application_name: "e4d_business_test", max: 3 });
const ledger = new Pool({ host: socket, port: 55972,
  database: "catletters_e4d_ledger_synthetic", application_name: "e4d_ledger_test", max: 3 });
const businessAdmin = new Pool({ host: socket, port: 55971,
  database: "catletters_e4d_business_synthetic", application_name: "e4d_business_admin" });
const ledgerAdmin = new Pool({ host: socket, port: 55972,
  database: "catletters_e4d_ledger_synthetic", application_name: "e4d_ledger_admin" });
const secret = "synthetic-e4d-ledger-secret-only-0123456789";
const adapter = new IndependentLedger(business, ledger, secret);
const pass = (name: string) => process.stdout.write(`PASS ${name}\n`);
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function control(current: Ledger, status: "READY" | "CLOSED", epoch?: number) {
  await business.query(
    "UPDATE lifecycle_control SET ledger_id=$1,ledger_sequence=$2,ledger_hash=$3,status=$4,restore_epoch=COALESCE($5,restore_epoch) WHERE singleton=true",
    [current.id, current.sequence, current.hash, status, epoch ?? null],
  );
}

async function main() {
  const [a, b] = await Promise.all([
    business.query("SELECT system_identifier FROM pg_control_system()"),
    ledger.query("SELECT system_identifier FROM pg_control_system()"),
  ]);
  assert.notEqual(a.rows[0].system_identifier, b.rows[0].system_identifier);
  assert.equal((await business.query("SELECT current_database() AS name")).rows[0].name,
    "catletters_e4d_business_synthetic");
  assert.equal((await ledger.query("SELECT current_database() AS name")).rows[0].name,
    "catletters_e4d_ledger_synthetic");
  pass("two physically independent named synthetic PostgreSQL databases");

  const bigintBatch: unknown = await ledger.query(
    "SELECT 9007199254740993::bigint AS sequence; SELECT 9007199254740995::bigint AS epoch",
  );
  assert.ok(Array.isArray(bigintBatch));
  assert.equal(bigintBatch.length, 2);
  assert.equal(bigintBatch[0].rows[0].sequence, "9007199254740993");
  assert.equal(bigintBatch[1].rows[0].epoch, "9007199254740995");
  pass("simple-query batches preserve native bigint strings beyond JS safe integer range");

  const userTables = [
    "participants", "invites", "sessions", "trips", "letters", "responses",
    "safety_cases", "audit_events", "rate_limits", "admin_requests",
    "accounts", "email_challenges", "account_sessions", "cat_profiles",
    "account_requests", "legacy_bindings", "account_deletions", "account_rate_limits",
    "cloud_state", "cloud_trips", "cloud_letters", "cloud_responses",
    "cloud_response_revisions", "cloud_reviews", "cloud_letter_sources",
    "cloud_review_sources", "cloud_requests", "cloud_calendars",
    "cloud_calendar_nodes", "cloud_jobs", "cloud_review_requests",
    "legacy_binding_requests", "legacy_binding_cancellations",
    "deletion_preparations", "erased_legacy_sources", "account_exports",
  ];
  await business.query(`DROP TABLE IF EXISTS synthetic_business_marks,lifecycle_control,${userTables.join(",")}`);
  await ledger.query("DROP TABLE IF EXISTS ledger_events,restore_operations,restore_gate,ledger_head,ledger_identity");
  await business.query(`CREATE TABLE lifecycle_control (
    singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),
    status text NOT NULL DEFAULT 'CLOSED' CHECK(status IN ('CLOSED','READY')),
    ledger_id uuid, ledger_sequence bigint NOT NULL DEFAULT 0,
    ledger_hash text NOT NULL DEFAULT '', reconciled_at timestamptz
  ); INSERT INTO lifecycle_control(singleton) VALUES(true);
  CREATE TABLE synthetic_business_marks(id integer PRIMARY KEY, value text NOT NULL);
  INSERT INTO synthetic_business_marks(id,value) VALUES(1,'before');`);
  for (const table of userTables)
    await business.query(`CREATE TABLE ${table}(id uuid PRIMARY KEY)`);
  await business.query(readFileSync(new URL("../db/migrations/010_lifecycle_restore_epoch.sql", import.meta.url), "utf8"));
  await ledger.query(readFileSync(new URL("../db/ledger-migrations/001_independent_lifecycle.sql", import.meta.url), "utf8"));
  process.env.E4_LIFECYCLE_BOOTSTRAP = "true";
  const initial = await adapter.bootstrap();
  delete process.env.E4_LIFECYCLE_BOOTSTRAP;
  assert.equal(initial.sequence, 0);
  const bootstrapOperation = randomUUID();
  const bootGate = await adapter.closeRestoreGate(bootstrapOperation);
  await control(initial, "READY", bootGate.epoch);
  await adapter.openRestoreGate(bootstrapOperation, bootGate.epoch);
  assert.equal(await adapter.readBusinessTx(async db =>
    (await db.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value), "before");
  pass("closed bootstrap and explicit first opening");

  const response: LedgerPayload = { kind: "RESPONSE_DELETED", requestId: randomUUID(),
    accountId: randomUUID(), catId: randomUUID(), responseId: randomUUID(),
    throughRevision: 1, payloadHash: "a".repeat(64), stateRevision: 1, exportIds: [] };
  const afterFirst = await adapter.withExclusive(async op => {
    const next = await op.append(response);
    await op.businessTx(async db => {
      await db.query("UPDATE lifecycle_control SET ledger_sequence=$1,ledger_hash=$2 WHERE singleton=true",
        [next.sequence, next.hash]);
    }, "reconcile");
    return next;
  });
  assert.equal(afterFirst.sequence, 1);
  const duplicate = await adapter.withExclusive(op => op.append(response));
  assert.equal(duplicate.sequence, 1);
  await assert.rejects(adapter.withExclusive(op => op.append({ ...response, payloadHash: "b".repeat(64) })),
    /幂等键/);
  let forgottenSettled = false;
  await adapter.withExclusive(async op => {
    void op.append(response).then(() => { forgottenSettled = true; });
  });
  assert.equal(forgottenSettled, true);
  await assert.rejects(adapter.withExclusive(async op => {
    void op.append({ ...response, payloadHash: "b".repeat(64) });
  }), /幂等键/);
  pass("ledger first, business watermark, duplicate idempotence, conflict refusal");

  const jobs = Array.from({ length: 2 }, () => {
    const event: LedgerPayload = { kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID() };
    return adapter.withExclusive(async op => {
      const next = await op.append(event);
      await op.businessTx(async db => {
        await db.query("UPDATE lifecycle_control SET ledger_sequence=$1,ledger_hash=$2 WHERE singleton=true",
          [next.sequence, next.hash]);
      }, "reconcile");
      return next.sequence;
    });
  });
  assert.deepEqual((await Promise.all(jobs)).sort(), [2, 3]);
  pass("concurrent appends serialize without a fork");

  const recoveryAppendOperation = randomUUID();
  const recoveryAppendGate = await adapter.closeRestoreGate(recoveryAppendOperation);
  await assert.rejects(adapter.withExclusive(op => op.append({
    kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
  })), /恢复|闸门已关闭/);
  process.env.E4_LIFECYCLE_RECOVERY = "true";
  const recoveryAppend = await adapter.withRecovery(recoveryAppendOperation, recoveryAppendGate.epoch,
    async op => {
      const next = await op.append({
        kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
      });
      await op.businessTx(async db => {
        await db.query("UPDATE lifecycle_control SET ledger_sequence=$1,ledger_hash=$2,restore_epoch=$3,status='READY' WHERE singleton=true",
          [next.sequence, next.hash, recoveryAppendGate.epoch]);
      }, "reconcile");
      return next;
    });
  delete process.env.E4_LIFECYCLE_RECOVERY;
  assert.equal(recoveryAppend.sequence, 4);
  await adapter.openRestoreGate(recoveryAppendOperation, recoveryAppendGate.epoch);
  pass("closed-gate append requires matching recovery operation and exact replay");

  const ahead = await adapter.withExclusive(op => op.append({
    kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
  }));
  await assert.rejects(adapter.readBusinessTx(async () => true), /水位|恢复/);
  await assert.rejects(adapter.withExclusive(op => op.append({
    kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
  })), /水位|恢复/);
  const aheadOperation = randomUUID();
  const aheadGate = await adapter.closeRestoreGate(aheadOperation);
  process.env.E4_LIFECYCLE_RECOVERY = "true";
  await adapter.withRecovery(aheadOperation, aheadGate.epoch, op => op.businessTx(async db => {
    await db.query("UPDATE lifecycle_control SET ledger_sequence=$1,ledger_hash=$2,restore_epoch=$3,status='READY' WHERE singleton=true",
      [ahead.sequence, ahead.hash, aheadGate.epoch]);
  }, "reconcile"));
  delete process.env.E4_LIFECYCLE_RECOVERY;
  await adapter.openRestoreGate(aheadOperation, aheadGate.epoch);
  assert.equal(await adapter.readBusinessTx(async () => true), true);
  pass("ledger committed before business interruption; explicit replay restores guard");

  let appendReached!: () => void;
  let appendProceed!: () => void;
  const appendReachedPromise = new Promise<void>(resolve => { appendReached = resolve; });
  const appendPause = new Promise<void>(resolve => { appendProceed = resolve; });
  const lateAppend = adapter.withExclusive(async op => {
    appendReached();
    await appendPause;
    return op.append({ kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID() });
  });
  await appendReachedPromise;
  const appendKilled = await ledgerAdmin.query(`SELECT pg_terminate_backend(a.pid) AS killed
    FROM pg_stat_activity a JOIN pg_locks l ON l.pid=a.pid
    WHERE a.application_name='e4d_ledger_test' AND l.locktype='advisory'
      AND l.mode='ExclusiveLock' AND l.objid=82101008`);
  assert.equal(appendKilled.rows.filter(r => r.killed).length, 1);
  await wait(100);
  appendProceed();
  await assert.rejects(lateAppend);
  assert.equal(await adapter.readBusinessTx(async (_db, current) => current.sequence), ahead.sequence);
  pass("lost ledger lock rejects a delayed append without advancing head");

  let entered!: () => void;
  let release!: () => void;
  const enteredPromise = new Promise<void>(resolve => { entered = resolve; });
  const hold = new Promise<void>(resolve => { release = resolve; });
  const active = adapter.readBusinessTx(async db => {
    await db.query("UPDATE synthetic_business_marks SET value='committed' WHERE id=1");
    entered();
    await hold;
  });
  await enteredPromise;
  const restoreA = randomUUID();
  const closing = adapter.closeRestoreGate(restoreA);
  assert.equal(await Promise.race([closing.then(() => "closed"), wait(150).then(() => "pending")]), "pending");
  release();
  await active;
  const closed = await closing;
  assert.equal(closed.epoch, aheadGate.epoch + 1);
  assert.equal((await adapter.closeRestoreGate(restoreA)).epoch, closed.epoch);
  assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
    "committed");
  pass("gate close waits for an in-flight business commit");

  // A backup made just before close may have an identical event watermark.
  await control(ahead, "READY", closed.epoch - 1);
  await assert.rejects(adapter.readBusinessTx(async () => true), /恢复/);
  await assert.rejects(adapter.openRestoreGate(restoreA, closed.epoch), /恢复对账/);
  await control({ ...ahead, sequence: ahead.sequence - 1, hash: ahead.events.at(-2)!.hash },
    "READY", closed.epoch - 1);
  await assert.rejects(adapter.readBusinessTx(async () => true), /恢复/);
  await assert.rejects(adapter.openRestoreGate(restoreA, closed.epoch), /恢复对账/);
  pass("same-watermark and older-watermark backup remain locked");

  let staleOperation: { append(payload: LedgerPayload): Promise<Ledger> } | undefined;
  await adapter.withExclusive(async op => { staleOperation = op; });
  assert.ok(staleOperation);
  await assert.rejects(staleOperation.append({
    kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
  }), /已结束/);
  await assert.rejects(adapter.withExclusive(op => op.append({
    kind: "DELETE_COMPLETE", requestId: randomUUID(), accountId: randomUUID(),
  })), /恢复|闸门已关闭/);
  pass("late retained operation and new append cannot write through a closed gate");

  process.env.E4_LIFECYCLE_RECOVERY = "true";
  await adapter.withRecovery(restoreA, closed.epoch, op => op.businessTx(async db => {
    await db.query("UPDATE lifecycle_control SET ledger_sequence=$1,ledger_hash=$2,restore_epoch=$3,status='READY' WHERE singleton=true",
      [ahead.sequence, ahead.hash, closed.epoch]);
  }, "reconcile"));
  delete process.env.E4_LIFECYCLE_RECOVERY;
  const restoreB = randomUUID();
  const secondClose = await adapter.closeRestoreGate(restoreB);
  assert.equal(secondClose.epoch, closed.epoch + 1);
  await assert.rejects(adapter.closeRestoreGate(restoreA), /已使用/);
  await assert.rejects(adapter.openRestoreGate(restoreA, closed.epoch), /身份或代次/);
  process.env.E4_LIFECYCLE_RECOVERY = "true";
  await assert.rejects(adapter.withRecovery(restoreA, closed.epoch, async () => true), /身份或代次/);
  delete process.env.E4_LIFECYCLE_RECOVERY;
  await assert.rejects(adapter.openRestoreGate(restoreB, secondClose.epoch), /恢复对账/);
  pass("new recovery while closed advances epoch; late prior opener is rejected");
  process.env.E4_LIFECYCLE_RECOVERY = "true";
  await adapter.withRecovery(restoreB, secondClose.epoch, op => op.businessTx(async db => {
    await db.query("UPDATE lifecycle_control SET restore_epoch=$1,status='READY' WHERE singleton=true",
      [secondClose.epoch]);
  }, "reconcile"));
  delete process.env.E4_LIFECYCLE_RECOVERY;
  await adapter.openRestoreGate(restoreB, secondClose.epoch);
  assert.equal(await adapter.readBusinessTx(async () => true), true);
  pass("explicit replay of exact watermark and epoch reopens gate");

  let reached!: () => void;
  let proceed!: () => void;
  const reachedPromise = new Promise<void>(resolve => { reached = resolve; });
  const pause = new Promise<void>(resolve => { proceed = resolve; });
  const disconnect = adapter.readBusinessTx(async db => {
    await db.query("UPDATE synthetic_business_marks SET value='must-rollback' WHERE id=1");
    reached();
    await pause;
  });
  await reachedPromise;
  const killed = await ledgerAdmin.query(`SELECT pg_terminate_backend(a.pid) AS killed
    FROM pg_stat_activity a JOIN pg_locks l ON l.pid=a.pid
    WHERE a.application_name='e4d_ledger_test' AND l.locktype='advisory'
      AND l.mode='ShareLock' AND l.objid=82101008`);
  assert.equal(killed.rows.filter(r => r.killed).length, 1);
  await wait(100);
  proceed();
  await assert.rejects(disconnect);
  assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
    "committed");
  pass("ledger connection loss rolls back in-flight business transaction");

  let businessReached!: () => void;
  let businessProceed!: () => void;
  const businessReachedPromise = new Promise<void>(resolve => { businessReached = resolve; });
  const businessPause = new Promise<void>(resolve => { businessProceed = resolve; });
  const businessDisconnect = adapter.readBusinessTx(async db => {
    await db.query("UPDATE synthetic_business_marks SET value='business-must-rollback' WHERE id=1");
    businessReached();
    await businessPause;
  });
  await businessReachedPromise;
  const businessKilled = await businessAdmin.query(`SELECT pg_terminate_backend(a.pid) AS killed
    FROM pg_stat_activity a JOIN pg_locks l ON l.pid=a.pid
    WHERE a.application_name='e4d_business_test' AND l.locktype='advisory'
      AND l.mode='ShareLock' AND l.objid=82101008`);
  assert.equal(businessKilled.rows.filter(r => r.killed).length, 1);
  await wait(100);
  businessProceed();
  await assert.rejects(businessDisconnect);
  assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
    "committed");
  pass("business connection loss rolls back in-flight transaction");

  const businessBlocker = await businessAdmin.connect();
  try {
    await businessBlocker.query("SELECT pg_advisory_lock($1)", [82101008]);
    const started = Date.now();
    await assert.rejects(adapter.readBusinessTx(async () => true, Date.now() + 8000),
      /调度时间已用尽/);
    assert.ok(Date.now() - started < 2500);
  } finally {
    await businessBlocker.query("SELECT pg_advisory_unlock($1)", [82101008]);
    businessBlocker.release();
  }
  assert.equal(await adapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  pass("scheduled business lock wait is bounded and next warm call succeeds");

  const ledgerBlocker = await ledgerAdmin.connect();
  try {
    await ledgerBlocker.query("SELECT pg_advisory_lock($1)", [82101008]);
    const started = Date.now();
    await assert.rejects(adapter.readBusinessTx(async () => true, Date.now() + 8000),
      /调度时间已用尽/);
    assert.ok(Date.now() - started < 2500);
  } finally {
    await ledgerBlocker.query("SELECT pg_advisory_unlock($1)", [82101008]);
    ledgerBlocker.release();
  }
  assert.equal(await adapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  pass("scheduled ledger lock wait releases the business lock");

  const tightBusiness = new Pool({ host: socket, port: 55971,
    database: "catletters_e4d_business_synthetic", max: 1, connectionTimeoutMillis: 3000 });
  const tightLedger = new Pool({ host: socket, port: 55972,
    database: "catletters_e4d_ledger_synthetic", max: 1, connectionTimeoutMillis: 3000 });
  try {
    const tightAdapter = new IndependentLedger(tightBusiness, tightLedger, secret);
    const held = await tightBusiness.connect();
    try {
      const started = Date.now();
      await assert.rejects(tightAdapter.readBusinessTx(async () => true, Date.now() + 8000));
      assert.ok(Date.now() - started >= 2900 && Date.now() - started < 4000);
    } finally { held.release(); }
    assert.equal(await tightAdapter.readBusinessTx(async () => true, Date.now() + 8000), true);
    const heldBusiness = await tightBusiness.connect();
    const heldLedger = await tightLedger.connect();
    try {
      const started = Date.now();
      const blocked = tightAdapter.readBusinessTx(async () => true, Date.now() + 8200);
      await wait(2500);
      heldBusiness.release();
      await assert.rejects(blocked, /调度时间已用尽/);
      assert.ok(Date.now() - started < 3500);
    } finally { heldLedger.release(); }
    assert.equal(await tightAdapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  } finally { await Promise.all([tightBusiness.end(), tightLedger.end()]); }
  pass("scheduled pool wait caps at 3s; late business acquisition skips full ledger wait");

  const slowStarted = Date.now();
  await assert.rejects(adapter.readBusinessTx(async db => {
    await db.query("SELECT pg_sleep(10)");
  }, Date.now() + 8000));
  assert.ok(Date.now() - slowStarted < 7000);
  assert.equal(await adapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  pass("scheduled single SQL timeout leaves no held session lock");

  await businessAdmin.query(`CREATE FUNCTION synthetic_deferred_commit_delay() RETURNS trigger
    LANGUAGE plpgsql AS $$ BEGIN PERFORM pg_sleep(3); RETURN NULL; END $$;
    CREATE CONSTRAINT TRIGGER synthetic_commit_delay AFTER UPDATE ON synthetic_business_marks
    DEFERRABLE INITIALLY DEFERRED FOR EACH ROW
    EXECUTE FUNCTION synthetic_deferred_commit_delay()`);
  try {
    const started = Date.now();
    const deferredResult = await adapter.readBusinessTx(async db => {
      await db.query("UPDATE synthetic_business_marks SET value='deferred-late' WHERE id=1");
    }, Date.now() + 8000).then(() => "committed", e => String(e));
    console.log("Deferred COMMIT probe", Date.now() - started, deferredResult);
    assert.notEqual(deferredResult, "committed");
    assert.ok(Date.now() - started < 4000);
    assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
      "committed");
    await wait(1200);
    assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
      "committed");
  } finally {
    await businessAdmin.query("DROP TRIGGER synthetic_commit_delay ON synthetic_business_marks");
    await businessAdmin.query("DROP FUNCTION synthetic_deferred_commit_delay()");
  }
  assert.equal(await adapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  pass("deferred COMMIT trigger exceeds 2s server limit; no late state or held lock");

  const deadlineStarted = Date.now();
  await assert.rejects(adapter.readBusinessTx(async db => {
    await db.query("UPDATE synthetic_business_marks SET value='late' WHERE id=1");
    await wait(7600);
  }, Date.now() + 7300));
  assert.ok(Date.now() - deadlineStarted < 8500);
  assert.equal((await business.query("SELECT value FROM synthetic_business_marks WHERE id=1")).rows[0].value,
    "committed");
  assert.equal(await adapter.readBusinessTx(async () => true, Date.now() + 8000), true);
  for (const [admin, app] of [[businessAdmin, "e4d_business_test"], [ledgerAdmin, "e4d_ledger_test"]] as const) {
    const locks = await admin.query(
      `SELECT count(*)::int AS n FROM pg_locks l JOIN pg_stat_activity a ON a.pid=l.pid
        WHERE l.locktype='advisory' AND l.objid=82101008 AND a.application_name=$1`, [app]);
    assert.equal(locks.rows[0].n, 0);
  }
  pass("whole-call deadline destroys active sessions and rolls back uncommitted writes");

  const wrongKey = new IndependentLedger(business, ledger, "wrong-synthetic-e4d-ledger-secret-0123456789");
  await assert.rejects(wrongKey.readBusinessTx(async () => true), /密钥不匹配/);
  const original = (await ledgerAdmin.query("SELECT event_json FROM ledger_events WHERE sequence=1")).rows[0].event_json;
  await ledgerAdmin.query("UPDATE ledger_events SET event_json='broken-json' WHERE sequence=1");
  await assert.rejects(adapter.readBusinessTx(async () => true), /事件格式无效/);
  await ledgerAdmin.query("UPDATE ledger_events SET event_json=$1 WHERE sequence=1", [original]);
  pass("wrong secret and corrupt event fail closed");

  const broken = await ledgerAdmin.query("DELETE FROM restore_gate WHERE singleton=true");
  assert.equal(broken.rowCount, 1);
  await assert.rejects(adapter.readBusinessTx(async () => true), /不完整/);
  pass("missing independent gate fails closed");
}

try { await main(); }
finally { await Promise.all([business.end(), ledger.end(), businessAdmin.end(), ledgerAdmin.end()]); }
