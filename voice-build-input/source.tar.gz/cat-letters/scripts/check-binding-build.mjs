import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";

// Public configuration only. This inspects the artifact, not local env files.
const [surface, directory, expected] = process.argv.slice(2);
assert.ok(["pages", "account"].includes(surface), "Choose pages or account");
assert.ok(directory && expected, "Supply build directory and expected public URL/origin");
const url = new URL(expected);
assert.equal(url.protocol, "https:");
assert.ok(!url.username && !url.password && !url.search && !url.hash);
if (surface === "pages") assert.equal(url.pathname, "/account-app/");
else assert.equal(expected, url.origin, "Source trust uses an exact origin without a path");

const assets = join(directory, "assets");
const files = (await readdir(assets)).filter(name => name.endsWith(".js"));
assert.ok(files.length > 0, "No JavaScript build artifact found");
const escaped = expected.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
// Exact literal boundaries prevent a design-reference URL on the same origin
// from incorrectly passing the trusted-source check.
const literal = new RegExp("[`'\"]" + escaped + "[`'\"]");
const matched = [];
for (const name of files)
  if (literal.test(await readFile(join(assets, name), "utf8"))) matched.push(name);
assert.ok(matched.length > 0, `${surface} artifact is missing the exact binding configuration`);
console.log(`PASS ${surface} binding config in ${matched.join(", ")}: ${expected}`);
