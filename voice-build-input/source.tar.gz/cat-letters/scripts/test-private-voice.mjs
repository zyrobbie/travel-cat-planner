// Creates two new loopback clusters. Never accepts a DB URL or restore target.
import { spawn } from "node:child_process";
import {
  mkdtemp,
  realpath,
  readFile,
  mkdir,
  writeFile,
  rm,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createServer } from "node:net";
import { randomUUID, createHash } from "node:crypto";
import pg from "pg";
const evidence = resolve(process.argv[2] ?? "outputs/private-voice");
const cookieOnly = process.env.E4_VOICE_COOKIE_TEST_ONLY === "true";
const pattern = process.env.E4_VOICE_TEST_PATTERN;
const profilePaths = [
  process.env.E4_VALIDATION_BUSINESS_PROFILE ??
    "deploy/continuous-scheduler/validation/business-access.sql",
  process.env.E4_VALIDATION_LEDGER_PROFILE ??
    "deploy/continuous-scheduler/validation/ledger-access.sql",
];
const profileHashes = [
  "335f34f38de6c1952048dbbd7025c9921a6f52de836ebbb810cafc423b22421b",
  "b74a947b47a4a26dcd723fa9cd265d281707614675834697b9b84092019708c4",
];
const profiles = await Promise.all(
  profilePaths.map(async (p, i) => {
    if (!p) throw Error("Set both existing runtime profile SQL paths");
    const b = await readFile(p);
    if (createHash("sha256").update(b).digest("hex") !== profileHashes[i])
      throw Error("Runtime profile hash differs from reviewed cloud grants");
    return b.toString();
  }),
);
await mkdir(evidence, { recursive: true });
const root = await realpath(
  await mkdtemp(join(tmpdir(), "cat-private-voice-")),
);
const baseEnv = {
  PATH: process.env.PATH,
  LANG: "C.UTF-8",
  TMPDIR: tmpdir(),
  DOTENV_CONFIG_PATH: "/dev/null",
};
const clusters = [],
  ports = [];
let log =
    "Two new disposable PostgreSQL clusters; cloudExecuted=false; emailSent=false\n",
  passed = false;
const append = (s) => {
  log += s;
  process.stdout.write(s);
};
let activeChild;
for (const signal of ["SIGTERM", "SIGINT"])
  process.once(signal, () => activeChild?.kill("SIGTERM"));
const run = (command, args, env = baseEnv) =>
  new Promise((done, reject) => {
    const p = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    activeChild = p;
    let output = "";
    p.stdout.on("data", (d) => {
      output += d;
      append(d.toString());
    });
    p.stderr.on("data", (d) => append(d.toString()));
    p.once("error", reject);
    p.once("exit", (code) =>
      code === 0 ? done(output) : reject(Error(`${command} exited ${code}`)),
    );
  });
const freePort = () =>
  new Promise((done, reject) => {
    const s = createServer();
    s.once("error", reject);
    s.listen(0, "127.0.0.1", () => {
      const p = s.address().port;
      s.close(() => done(p));
    });
  });
const dbName = "catletters_cloud_lifecycle_validation_test";
const owner = "cat_lifecycle_owner";
const sourceFiles = [
  "src/server/voice-service.ts",
  "src/server/voice-config.ts",
  "src/server/voice-provider.ts",
  "src/server/tencent-sentence-provider.ts",
  "src/server/tencent-voice-readiness.ts",
  "tests/e4/tencent-sentence-provider.test.ts",
  "tests/e4/fixtures/tencent-signature-vector.json",
  "src/server/voice-probe.ts",
  "src/shared/voice.ts",
  "db/migrations/012_private_voice.sql",
  "src/app/api/e4/voice/[...path]/route.ts",
  "static-app/VoiceComposer.tsx",
  "static-app/voice-draft.ts",
  "static-app/voice.css",
  "static-app/account-settings.css",
  "static-app/App.tsx",
  "static-app/app-client.ts",
  "static-app/account-client.ts",
  "scripts/voice-cleanup.ts",
  "scripts/voice-tencent-preflight.ts",
  "scripts/test-private-voice.mjs",
  "tests/e4/private-voice.test.ts",
  "tests/e4/voice-http.ts",
  "tests/e4/voice-browser.ts",
  "deploy/private-voice/access.sql",
  "src/shared/response-text.ts",
  "src/server/voice-directory.ts",
  "package.json",
  "package-lock.json",
  "next.config.ts",
  "db/migrations/013_response_graphemes.sql",
  "src/server/cloud-responses.ts",
  "src/shared/legacy-transfer.ts",
  "src/app/api/e4/v1/[...path]/route.ts",
  "static-app/ResponseManager.tsx",
  "static-app/model.ts",
  "static-app/store.ts",
  "scripts/voice-review.ts",
  "deploy/private-voice/OPERATIONS.md",
  "deploy/private-voice/voice.env.example",
  "deploy/private-voice/TENCENT.md",
  "deploy/private-voice/tencent-readiness.example.json",
  "src/server/account-cookie-config.ts",
  "src/server/private-voice-entry-config.ts",
  "src/server/account-auth.ts",
  "src/server/account-lifecycle.ts",
  "src/server/voice-payload-store.ts",
  "db/migrations/014_voice_private_files.sql",
  "scripts/private-voice-linux-guard.ts",
  "tests/e4/private-cookie-entry.test.ts",
  "tests/e4/voice-payload-store.test.ts",
];
const sourceSha256 = Object.fromEntries(
  await Promise.all(
    sourceFiles.map(async (p) => [
      p,
      createHash("sha256")
        .update(await readFile(p))
        .digest("hex"),
    ]),
  ),
);
try {
  const urls = [];
  for (const kind of ["business", "ledger"]) {
    const data = join(root, kind),
      port = await freePort();
    ports.push(port);
    await run("initdb", [
      "-D",
      data,
      "-U",
      owner,
      "--auth=trust",
      "--no-locale",
      "--encoding=UTF8",
    ]);
    await run("pg_ctl", [
      "-D",
      data,
      "-l",
      join(root, `${kind}.log`),
      "-o",
      `-h 127.0.0.1 -p ${port} -k ${root}`,
      "-w",
      "start",
    ]);
    clusters.push(data);
    await run("createdb", [
      "-h",
      "127.0.0.1",
      "-p",
      String(port),
      "-U",
      owner,
      dbName,
    ]);
    urls.push(`postgresql://${owner}@127.0.0.1:${port}/${dbName}`);
  }
  const nonce = randomUUID();
  const env = {
    ...baseEnv,
    DATABASE_URL: urls[0],
    E4_LEDGER_DATABASE_URL: urls[1],
    APP_MODE: "INTERNAL",
    SAFETY_ADAPTER: "synthetic-v1",
    OTP_ADAPTER: "synthetic-v1",
    APP_ORIGIN: "http://127.0.0.1:3100",
    COOKIE_SECURE: "true",
    NETLIFY: "false",
    E4_SCHEDULED_RUN: "true",
    E4_CONTINUOUS_UNTIL: "2026-11-06T10:00:00Z",
    OTP_HASH_SECRET: "local-cloud-lifecycle-synthetic-only-otp-0123456789",
    E4_LEDGER_SECRET: "local-cloud-lifecycle-synthetic-only-ledger-0123456789",
    E4_LIFECYCLE_ADAPTER: "postgres-v1",
    E4_LIFECYCLE_BOOTSTRAP: "false",
    E4_LIFECYCLE_RECOVERY: "false",
    E4_EXPORT_STORAGE: "postgres",
    E4_CLOUD_LIFECYCLE_VALIDATION_ENABLED: "true",
    E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID: randomUUID(),
    E4_CLOUD_LIFECYCLE_VALIDATION_CONTROL_ID: randomUUID(),
    E4_CLOUD_LIFECYCLE_VALIDATION_UNTIL: new Date(
      Date.now() + 55 * 60_000,
    ).toISOString(),
    E4_CLOUD_LIFECYCLE_VALIDATION_STATE: join(root, "private", "state.json"),
    E4_VALIDATION_EVIDENCE: evidence,
    E4_VALIDATION_LOCAL_OWNER_BUSINESS: urls[0],
    E4_VALIDATION_LOCAL_OWNER_LEDGER: urls[1],
    E4_VALIDATION_LOCAL_NONCE: nonce,
    E4_VALIDATION_LOCAL_DIRECTORY: root,
  };
  const roleConnection = new pg.Pool({ connectionString: urls[0] });
  try {
    await roleConnection.query(
      "CREATE ROLE cat_letters_app NOINHERIT NOSUPERUSER NOBYPASSRLS",
    );
  } finally {
    await roleConnection.end();
  }
  env.E4_VOICE_REVIEW_PORT = process.env.E4_VOICE_REVIEW_PORT ?? "0";
  env.E4_LOCAL_ACCOUNT_CLIENT_DIRECTORY = resolve(
    process.env.E4_LOCAL_ACCOUNT_CLIENT_DIRECTORY ?? "public/account-app",
  );
  env.E4_VOICE_REVIEW_TENCENT_OFFLINE =
    process.env.E4_VOICE_REVIEW_TENCENT_OFFLINE ?? "false";
  env.E4_VOICE_ENABLED = "true";
  env.E4_VOICE_MODE = "synthetic-v1";
  env.E4_VOICE_BACKUP_POLICY = "exclude-ephemeral-v1";
  env.E4_VOICE_FFPROBE =
    process.env.E4_LOCAL_FFPROBE ?? "/opt/homebrew/bin/ffprobe";
  env.E4_VOICE_FFMPEG =
    process.env.E4_LOCAL_FFMPEG ?? "/opt/homebrew/bin/ffmpeg";
  env.E4_VOICE_STORAGE = "synthetic-files-v1";
  env.E4_VOICE_TEST_PAYLOAD_ROOT = join(root, "voice-private");
  env.E4_VOICE_PAYLOAD_DIRECTORY = join(root, "voice-private", "payload");
  env.E4_VOICE_PROBE_DIRECTORY = join(root, "voice-private", "probe");
  await mkdir(env.E4_VOICE_TEST_PAYLOAD_ROOT, { recursive: true, mode: 0o700 });
  await run(process.execPath, ["--import", "tsx", "scripts/migrate.ts"], env);
  const business = new pg.Pool({ connectionString: urls[0] }),
    ledger = new pg.Pool({ connectionString: urls[1] });
  try {
    await ledger.query(
      await readFile(
        "db/ledger-migrations/001_independent_lifecycle.sql",
        "utf8",
      ),
    );
    await ledger.query(
      await readFile(
        "db/ledger-migrations/002_deletion_cancellation.sql",
        "utf8",
      ),
    );
    for (const db of [business, ledger]) {
      await db.query(
        "CREATE TABLE local_validation_cluster_nonce(value uuid PRIMARY KEY)",
      );
      await db.query("INSERT INTO local_validation_cluster_nonce VALUES($1)", [
        nonce,
      ]);
    }
  } finally {
    await business.end();
    await ledger.end();
  }
  const op = randomUUID();
  const boot = await run(
    process.execPath,
    ["--import", "tsx", "scripts/lifecycle.ts", "bootstrap", op],
    { ...env, E4_LIFECYCLE_BOOTSTRAP: "true" },
  );
  const { epoch } = JSON.parse(boot.trim().split("\n").at(-1));
  await run(
    process.execPath,
    ["--import", "tsx", "scripts/lifecycle.ts", "reconcile", op, String(epoch)],
    { ...env, E4_LIFECYCLE_RECOVERY: "true" },
  );
  for (let i = 0; i < 2; i++) {
    const p = new pg.Pool({ connectionString: urls[i] });
    try {
      await p.query(profiles[i]);
      await p.query(
        `ALTER ROLE ${i === 0 ? "cat_letters_app" : "cat_letters_ledger"} LOGIN`,
      );
    } finally {
      await p.end();
    }
  }
  const voiceAccess = new pg.Pool({ connectionString: urls[0] });
  try {
    await voiceAccess.query(
      await readFile("deploy/private-voice/access.sql", "utf8"),
    );
  } finally {
    await voiceAccess.end();
  }
  await run(
    process.execPath,
    process.env.E4_VOICE_REVIEW === "true"
      ? ["--import", "tsx", "scripts/voice-review.ts"]
      : [
          "--import",
          "tsx",
          "--test",
          ...(pattern ? ["--test-name-pattern", pattern] : []),
          cookieOnly ? "tests/e4/private-cookie-entry.test.ts" : "tests/e4/private-voice.test.ts",
        ],
    {
      ...env,
      DATABASE_URL: urls[0].replace(owner, "cat_letters_app"),
      E4_LEDGER_DATABASE_URL: urls[1].replace(owner, "cat_letters_ledger"),
    },
  );
  if (!cookieOnly && process.env.E4_VOICE_REVIEW !== "true")
    await run(
      process.execPath,
      [
        "--import",
        "tsx",
        "--test",
        "tests/e4/tencent-sentence-provider.test.ts",
      ],
      env,
    );
  if (!cookieOnly && (!pattern || process.env.E4_VOICE_INCLUDE_REGRESSION === "true") && process.env.E4_VOICE_REVIEW !== "true") {
    const regressionEnv = {
      ...env,
      DATABASE_URL: urls[0].replace(owner, "cat_letters_app"),
      E4_LEDGER_DATABASE_URL: urls[1].replace(owner, "cat_letters_ledger"),
    };
    await run(
      process.execPath,
      [
        "--import",
        "tsx",
        "--test",
        "tests/domain.test.ts",
        "tests/independent-ledger-snapshot.test.ts",
        "tests/otp-delivery.test.ts",
        "tests/integration.test.ts",
        "tests/e4/account-client.test.ts",
      ],
      regressionEnv,
    );
    await run(
      process.execPath,
      ["--import", "tsx", "--test", "tests/e4-lifecycle-directory.test.ts"],
      { ...baseEnv, APP_MODE: "INTERNAL", E4_LIFECYCLE_ADAPTER: "file-v1" },
    );
    await run(
      process.execPath,
      [
        "--import",
        "tsx",
        "--test",
        "tests/e4/cloud-lifecycle-validation.test.ts",
      ],
      regressionEnv,
    );
  }
  passed = true;
} catch (e) {
  append(`FAIL ${e.message}\n`);
  process.exitCode = 1;
} finally {
  for (const data of clusters.reverse())
    await run("pg_ctl", ["-D", data, "-m", "fast", "-w", "stop"]);
  await rm(root, { recursive: true, force: true });
  await writeFile(join(evidence, "test.log"), log);
  await writeFile(
    join(evidence, "result.json"),
    JSON.stringify(
      {
        result: passed ? "PASS" : "FAIL",
        testPattern: process.env.E4_VOICE_TEST_PATTERN ?? null,
        suite: cookieOnly ? "private-cookie-entry" : "private-voice",
        ordinaryRegressionIncluded: !cookieOnly && (!pattern || process.env.E4_VOICE_INCLUDE_REGRESSION === "true"),
        payloadStorage: "synthetic-files-v1; explicit temporary filesystem, not Linux tmpfs evidence",
        provider: "synthetic-v1",
        realAsrTested: false,
        twoNewLocalClusters: true,
        runtimeRoles: ["cat_letters_app", "cat_letters_ledger"],
        runtimeProfileSha256: profileHashes,
        sourceSha256,
        cloudExecuted: false,
        emailSent: false,
        deployed: false,
        restoreOnlyFreshLoopbackClusters: true,
      },
      null,
      2,
    ) + "\n",
  );
}
