import { lstatSync, readFileSync, statfsSync } from "node:fs";
import { createHash } from "node:crypto";
import { posix } from "node:path";
import { pathToFileURL } from "node:url";
import { validatePrivateVoiceBase, type PrivateVoiceEntryStage } from "../src/server/private-voice-entry-config";

const bad = () => { throw new Error("PRIVATE_VOICE_LINUX_GUARD_FAILED"); };
const mounts = {
  app: { path: "/run/cat-voice-private", maximum: 128 * 1024 * 1024 },
  proxy: { path: "/run/cat-voice-proxy", maximum: 32 * 1024 * 1024 },
} as const;
export type PrivateVoiceRole = "app" | "proxy" | "business" | "ledger" | "cleanup";
const roleMemory = { app: 384, proxy: 64, business: 128, ledger: 128, cleanup: 128 } as const;

/** Exact mount identity; a tmpfs parent or an ordinary directory is insufficient. */
export function validatePrivateMount(info: string, target: string, maximum: number) {
  const matches = info.split("\n").filter(line => line.split(" ")[4] === target);
  if (matches.length !== 1) return bad();
  const [left, right] = matches[0].split(" - ");
  if (!right) return bad();
  if (left.split(" ")[3] !== "/") return bad();
  const [type, , superOptions] = right.split(" ");
  const flags = new Set([...left.split(" ")[5].split(","), ...superOptions.split(",")]);
  if (type !== "tmpfs" || !["rw", "noswap", "nodev", "nosuid", "noexec"].every(f => flags.has(f)))
    return bad();
  const size = [...flags].find(f => f.startsWith("size="))?.slice(5);
  // mountinfo reports k in the supported Linux deployment. Fail on unknown units.
  if (!size || !/^\d+k?$/.test(size)) return bad();
  const bytes = Number(size.replace(/k$/, "")) * (size.endsWith("k") ? 1024 : 1);
  if (!(bytes > 0 && bytes <= maximum)) return bad();
}

export function privateVoiceCgroupPath(info: string) {
  const rows = info.trim().split("\n");
  if (rows.length !== 1 || !rows[0].startsWith("0::")) return bad();
  const group = rows[0].slice(3);
  if (posix.normalize(group) !== group || !group.startsWith("/catvoice.slice/") ||
      !/^\/catvoice\.slice\/cat-voice-(?:app|proxy|business|ledger|cleanup)\.service$/.test(group))
    return bad();
  return `/sys/fs/cgroup${group}`;
}

export function validatePrivateMemory(value: string, maximum: number) {
  if (!/^[1-9]\d*$/.test(value.trim()) || Number(value.trim()) > maximum) return bad();
}

export function validateClosedProxyGate(text: string) {
  if (text.split("\n").map(line => line.replace(/#.*/, "")).join(" ").trim() !== "return 503;") return bad();
}

export function validatePrivateProxyStage(raw: string, entryGate: string, voiceGate: string) {
  if (Buffer.byteLength(raw) > 4096) return bad();
  let state: { entry: PrivateVoiceEntryStage; voice: "enabled" | "disabled" };
  try { state = JSON.parse(raw); } catch { return bad(); }
  if (!state || Object.keys(state).sort().join(",") !== "entry,voice" ||
      !["closed", "prepared", "private-open"].includes(state.entry) ||
      !["enabled", "disabled"].includes(state.voice) ||
      (state.entry !== "private-open" && state.voice !== "disabled")) return bad();
  if (state.entry === "private-open") {
    if (entryGate.trim() !== "# PRIVATE_E4_OPEN") return bad();
  } else validateClosedProxyGate(entryGate);
  if (state.voice === "enabled") {
    if (voiceGate.split("\n").map(line => line.replace(/#.*/, "")).join(" ").trim() !== "proxy_pass http://catvoice_app;") return bad();
  } else validateClosedProxyGate(voiceGate);
  return state;
}

/** Only the app can keep its ordinary text routes when private storage disappears. */
export function privateVoiceMountAvailability(role: PrivateVoiceRole, verify: () => void) {
  try { verify(); return "available" as const; }
  catch (error) {
    if (role !== "app") throw error;
    return "unavailable" as const;
  }
}

/** Reclamation must remain runnable when the otherwise valid private mount is full. */
export function validatePrivateVoiceFreeCapacity(role: PrivateVoiceRole, freeBlocks: number, freeInodes: number) {
  if (role !== "cleanup" && (freeBlocks <= 0 || freeInodes <= 0)) bad();
}

export function enforcePrivateVoiceLinux(role: PrivateVoiceRole) {
  if (process.platform !== "linux" || !Object.hasOwn(roleMemory, role))
    return bad();
  const cgroup = privateVoiceCgroupPath(readFileSync("/proc/self/cgroup", "utf8"));
  if (!cgroup.endsWith(`/cat-voice-${role}.service`) ||
      readFileSync(`${cgroup}/memory.swap.max`, "utf8").trim() !== "0" ||
      readFileSync("/sys/fs/cgroup/catvoice.slice/memory.max", "utf8").trim() !== String(768 * 1024 * 1024) ||
      readFileSync("/sys/fs/cgroup/catvoice.slice/memory.high", "utf8").trim() !== String(640 * 1024 * 1024) ||
      readFileSync("/sys/fs/cgroup/catvoice.slice/memory.swap.max", "utf8").trim() !== "0" ||
      !/^Max core file size\s+0\s+0\s+bytes[ \t]*$/m.test(readFileSync("/proc/self/limits", "utf8")))
    return bad();
  validatePrivateMemory(readFileSync(`${cgroup}/memory.max`, "utf8"), roleMemory[role] * 1024 * 1024);
  let stage: { entry: string; voice: string } = { entry: "closed", voice: "disabled" };
  if (role === "app" || role === "cleanup") stage = validatePrivateVoiceBase(process.env, role === "cleanup");
  let storage: "available" | "unavailable" | "not-applicable" = "not-applicable";
  if (role === "app" || role === "proxy" || role === "cleanup") {
    const mount = mounts[role === "cleanup" ? "app" : role];
    storage = privateVoiceMountAvailability(role, () => {
      validatePrivateMount(readFileSync("/proc/self/mountinfo", "utf8"), mount.path, mount.maximum);
      const stat = lstatSync(mount.path), fs = statfsSync(mount.path);
      if (!stat.isDirectory() || stat.isSymbolicLink() || stat.uid !== process.geteuid?.() ||
          stat.gid !== process.getegid?.() || (stat.mode & 0o777) !== 0o700 || fs.type !== 0x01021994 ||
          fs.bsize * fs.blocks > mount.maximum || fs.files > 4096) bad();
      validatePrivateVoiceFreeCapacity(role, fs.bavail, fs.ffree);
    });
    if (storage === "unavailable") stage = { ...stage, voice: "disabled" };
  }
  if (role === "proxy") {
    const gate = "/etc/cat-voice-test/proxy/entry-gate.conf";
    const voiceGate = "/etc/cat-voice-test/proxy/voice-gate.conf";
    const state = "/etc/cat-voice-test/proxy/entry-state.json";
    const config = "/etc/cat-voice-test/proxy/nginx.conf";
    for (const path of [gate, voiceGate, state, config]) {
      const stat = lstatSync(path);
      if (!stat.isFile() || stat.isSymbolicLink() || stat.uid !== 0 || (stat.mode & 0o022) !== 0) return bad();
    }
    stage = validatePrivateProxyStage(readFileSync(state, "utf8"), readFileSync(gate, "utf8"), readFileSync(voiceGate, "utf8"));
    if (stage.entry === "private-open") {
      const auth = lstatSync("/etc/cat-voice-test/proxy/htpasswd");
      if (!auth.isFile() || auth.isSymbolicLink() || auth.uid !== 0 || auth.gid !== process.getegid?.() ||
          (auth.mode & 0o027) !== 0 || auth.size < 1 || auth.size > 16384) return bad();
    }
    const hash = (file: string) => createHash("sha256").update(readFileSync(file)).digest("hex");
    if (hash(config) !== hash("deploy/private-voice/linux/nginx.conf")) return bad();
  }
  return { result: "PASS", role, ...stage, storage } as const;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    console.log(JSON.stringify(enforcePrivateVoiceLinux(process.argv[2] as PrivateVoiceRole)));
  } catch {
    // Do not emit Error objects, configuration, credential values or response content.
    console.error("PRIVATE_VOICE_LINUX_GUARD_FAILED");
    process.exitCode = 1;
  }
}
