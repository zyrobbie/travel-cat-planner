/** Manual isolated invocation only; this file registers no Netlify schedule. */
import "dotenv/config";

const selected = process.argv[2];
if (!["cloud", "privacy", "cleanup"].includes(selected))
  throw new Error("Usage: tsx scripts/run-scheduled-candidate.ts cloud|privacy|cleanup");
process.env.E4_SCHEDULED_RUN = "true";
const { cloudTick, privacyTick, privacyCleanupTick } =
  await import("../src/server/scheduled-candidate");
try {
  const outcome = selected === "cloud" ? await cloudTick()
    : selected === "privacy" ? await privacyTick() : await privacyCleanupTick();
  console.log(JSON.stringify(outcome));
} finally {
  const { closeLifecycleProvider } = await import("../src/server/lifecycle-provider");
  const { pool } = await import("../src/server/db");
  await closeLifecycleProvider();
  await pool.end();
}
