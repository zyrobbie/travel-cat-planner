import { z } from "zod";
import { cleanupPrivateVoice } from "../src/server/voice-service";
import { pool } from "../src/server/db";
import { closeLifecycleProvider } from "../src/server/lifecycle-provider";
try {
  if (
    process.env.APP_MODE !== "INTERNAL" ||
    process.env.E4_VOICE_CLEANUP_ENABLED !== "true"
  )
    throw Error("VOICE_CLEANUP_DISABLED");
  const ids = z
    .array(z.uuid())
    .min(1)
    .max(10)
    .parse(JSON.parse(process.env.E4_VOICE_ACCOUNT_IDS ?? "null"));
  const result = await cleanupPrivateVoice(ids);
  console.log(JSON.stringify(result));
} catch {
  console.error("VOICE_CLEANUP_FAILED");
  process.exitCode = 1;
} finally {
  await pool.end();
  await closeLifecycleProvider();
}
