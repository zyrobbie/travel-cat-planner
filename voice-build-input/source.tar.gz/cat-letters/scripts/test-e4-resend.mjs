// Fresh, disposable PostgreSQL cluster only. Never loads an existing .env or DB.
import { spawn } from "node:child_process";
import { mkdir, mkdtemp, writeFile, rm, realpath } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createServer } from "node:net";
import { randomBytes } from "node:crypto";

const evidence = resolve("outputs/E4-2026-10-12/netlify-preflight/resend-transactions");
await mkdir(evidence, { recursive: true });
const privateRoot = await realpath(await mkdtemp(join(tmpdir(), "cat-resend-db-")));
const dbDir = join(privateRoot, "pg");
const baseEnv = { PATH: process.env.PATH, LANG: "C.UTF-8" };
let log = "E4-D Resend integration: fresh disposable local PostgreSQL cluster; all mail transport mocked\n";
let server;
let dbStarted = false;
let passed = false;
const append = (value) => { log += value; process.stdout.write(value); };
const freePort = () => new Promise((done, reject) => {
  const socket = createServer();
  socket.on("error", reject);
  socket.listen(0, "127.0.0.1", () => { const port = socket.address().port; socket.close(() => done(port)); });
});
const run = (command, args, env = baseEnv) => new Promise((done, reject) => {
  const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
  child.stdout.on("data", data => append(data.toString()));
  child.stderr.on("data", data => append(data.toString()));
  child.once("error", reject);
  child.once("exit", code => code === 0 ? done() : reject(Error(`${command} failed with code ${code}`)));
});
async function stopServer() {
  if (!server || server.exitCode !== null) return;
  const active = server;
  await new Promise(done => {
    const timer = setTimeout(() => { active.kill("SIGKILL"); done(); }, 5_000);
    active.once("exit", () => { clearTimeout(timer); done(); });
    active.kill("SIGTERM");
  });
}
function startServer(env, port) {
  server = spawn(process.execPath, ["node_modules/next/dist/bin/next", "dev", "--webpack", "--hostname", "127.0.0.1", "--port", String(port)], { env, stdio: ["ignore", "pipe", "pipe"] });
  server.stdout.on("data", data => append(data.toString()));
  server.stderr.on("data", data => append(data.toString()));
}
async function reachable(url, options = {}) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (server.exitCode !== null) throw Error("Isolated Next server exited");
    try { return await fetch(url, { ...options, signal: AbortSignal.timeout(10_000) }); } catch {}
    await new Promise(done => setTimeout(done, 250));
  }
  throw Error("Isolated HTTP readiness timeout");
}
let port, dbPort;
try {
  dbPort = await freePort();
  port = await freePort();
  await run("initdb", ["-D", dbDir, "-U", "cat_resend_test", "--auth=trust", "--no-locale", "--encoding=UTF8"]);
  await run("pg_ctl", ["-D", dbDir, "-l", join(privateRoot, "postgres.log"), "-o", `-h 127.0.0.1 -p ${dbPort} -k ${privateRoot}`, "-w", "start"]);
  dbStarted = true;
  await run("createdb", ["-h", "127.0.0.1", "-p", String(dbPort), "-U", "cat_resend_test", "catletters_e4_resend_test"]);
  const env = {
    ...baseEnv,
    DATABASE_URL: `postgresql://cat_resend_test@127.0.0.1:${dbPort}/catletters_e4_resend_test`,
    APP_MODE: "INTERNAL", SAFETY_ADAPTER: "synthetic-v1", OTP_ADAPTER: "resend-v1",
    OTP_HASH_SECRET: randomBytes(32).toString("hex"),
    E4_LEDGER_SECRET: randomBytes(32).toString("hex"),
    E4_LIFECYCLE_DIR: join(privateRoot, "privacy"), E4_LIFECYCLE_BOOTSTRAP: "true",
    APP_ORIGIN: `http://127.0.0.1:${port}`, E4_TEST_ORIGIN: `http://127.0.0.1:${port}`, COOKIE_SECURE: "true",
    RESEND_API_KEY: "re_local_harness_never_used_over_network", OTP_FROM: "有猫来信 <login@auth.example.test>",
  };
  await run(process.execPath, ["--import", "tsx", "scripts/migrate.ts"], env);
  await run(process.execPath, ["--import", "tsx", "scripts/lifecycle.ts", "reconcile"], env);
  // Existing boundaries, using injected SyntheticMailbox and the same new DB.
  await run(process.execPath, ["--import", "tsx", "--test", "--test-name-pattern", "^A0[12]:", "tests/e4/account.test.ts"], env);
  startServer(env, port);
  const ready = await reachable(`${env.APP_ORIGIN}/api/health`);
  if (!ready.ok) throw Error("Health endpoint failed");
  await run(process.execPath, ["--import", "tsx", "--test", "tests/e4/resend-transaction.test.ts"], env);
  await stopServer();
  startServer({ ...env, APP_MODE: "PUBLIC" }, port);
  const refused = await reachable(`${env.APP_ORIGIN}/api/e4/auth/request-code`, {
    method: "POST", headers: { Origin: env.APP_ORIGIN, "Content-Type": "application/json" },
    body: JSON.stringify({ email: "synthetic-public-guard@example.test" }),
  });
  if (refused.status !== 503 || (await refused.json()).error !== "服务暂不可用，请稍后再试。")
    throw Error("PUBLIC HTTP request-code did not fail closed");
  append("R05: PUBLIC request-code HTTP 503 PASS; no sender invoked\n");
  passed = true;
} catch (error) {
  append(`FAIL: ${error.message}\n`);
  process.exitCode = 1;
} finally {
  await stopServer();
  if (dbStarted) await run("pg_ctl", ["-D", dbDir, "-m", "fast", "-w", "stop"]);
  await rm(privateRoot, { recursive: true, force: true });
  append(`Result: ${passed ? "PASS" : "FAIL"}; disposable cluster removed; actualEmailSent=false\n`);
  await writeFile(join(evidence, "test.log"), log);
  await writeFile(join(evidence, "result.json"), JSON.stringify({
    result: passed ? "PASS" : "FAIL", timestamp: new Date().toISOString(), dbPort, httpPort: port,
    database: "catletters_e4_resend_test", freshDisposableCluster: true, realPostgres: true, realHttp: true,
    mockedResend: true, actualEmailSent: false, publicEnabled: false, realDevice: false,
  }, null, 2) + "\n");
}
