import { randomBytes, randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { pool, transaction } from "../src/server/db";
import { digest } from "../src/server/auth";
import { closeLifecycleProvider } from "../src/server/lifecycle-provider";
import { lockCloudCat } from "../src/server/cloud-repository";
import { initializeCloudCalendar } from "../src/server/cloud-calendar";
import { voiceHttp } from "../tests/e4/voice-http";
import pg from "pg";
import { cleanupPrivateVoice } from "../src/server/voice-service";
for (const value of [
  process.env.DATABASE_URL,
  process.env.E4_LEDGER_DATABASE_URL,
  process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS,
])
  if (!value || new URL(value).hostname !== "127.0.0.1")
    throw Error("LOCAL_REVIEW_ONLY");
const proofOwner = new pg.Pool({
  connectionString: process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS,
});
try {
  const proof = (
    await proofOwner.query("SELECT value FROM local_validation_cluster_nonce")
  ).rows[0]?.value;
  if (proof !== process.env.E4_VALIDATION_LOCAL_NONCE)
    throw Error("LOCAL_NONCE_MISMATCH");
} finally {
  await proofOwner.end();
}
const account = randomUUID(),
  cat = randomUUID(),
  participant = randomUUID(),
  raw = randomBytes(32).toString("hex"),
  letter = `voice-review-${randomUUID()}`;
await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
  account,
  `${account}@voice-review.example.test`,
]);
await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [
  participant,
]);
await pool.query(
  "INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-02','小狸')",
  [cat, account, participant],
);
await pool.query(
  "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '4 hours')",
  [digest(raw), account],
);
await transaction(async (db) =>
  initializeCloudCalendar(db, await lockCloudCat(db, account), Date.now()),
);
await pool.query(
  "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,read_at) VALUES($1,$2,$3,'DEMAND',$4,now())",
  [
    letter,
    cat,
    account,
    {
      title: "窗边的小事",
      body: "今天的风轻轻吹过窗边。我想听听，你此刻有什么想说的话？",
      catName: "小狸",
    },
  ],
);
process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([account]);
await cleanupPrivateVoice([account]);
let cleanupWork: Promise<unknown> | undefined;
const cleanupTimer = setInterval(() => {
  if (!cleanupWork) cleanupWork = cleanupPrivateVoice([account])
    .catch(() => console.error("LOCAL_REVIEW_CLEANUP_FAILED"))
    .finally(() => { cleanupWork = undefined; });
}, 60_000);
const tencentOffline = process.env.E4_VOICE_REVIEW_TENCENT_OFFLINE === "true";
// Review can NEVER dispatch to a real remote service, even with a bad env file.
globalThis.fetch = (async (input) => {
  if (tencentOffline && String(input) === "https://asr.tencentcloudapi.com/")
    return Response.json({
      Response: {
        Result: "这是离线腾讯模式预览，请检查并改成你想说的话。",
        RequestId: "local-offline-only",
      },
    });
  throw Error("LOCAL_REVIEW_EXTERNAL_NETWORK_BLOCKED");
}) as typeof fetch;
process.env.E4_VOICE_MODE = tencentOffline
  ? "tencent-sentence-v1"
  : "synthetic-v1";
if (tencentOffline) {
  const id = "AKIDOfflineReviewOnly0000000000";
  Object.assign(process.env, {
    E4_VOICE_TENCENT_ASR_APPROVED: "true",
    E4_VOICE_TENCENT_FREE_ONLY: "true",
    E4_VOICE_TENCENT_SECRET_ID: id,
    E4_VOICE_TENCENT_SECRET_KEY: "OfflineReviewSecretNotReal00000000",
  });
  delete process.env.E4_VOICE_TENCENT_TOKEN;
  delete process.env.E4_VOICE_TENCENT_READINESS_FILE;
}
const bridge = await voiceHttp(raw, {
  syntheticMic: true,
  port: Number(process.env.E4_VOICE_REVIEW_PORT ?? 0),
});
const information = {
  url: bridge.url + "/local-review",
  entry: "点击来信盒→窗边的小事→给它回信；原草稿可先打字，再点用语音写几句。",
  accountId: account,
  synthetic: true,
  providerMode: process.env.E4_VOICE_MODE,
  providerTransport: tencentOffline
    ? "OFFLINE_RESPONSE_INTERCEPTOR"
    : "SYNTHETIC_FIXED_TEXT",
  liveBillingAndOptimizationVerified: false,
  externalNetwork: "BLOCKED_IN_REVIEW_PROCESS",
  nativeMicrophone: false,
  realAsr: false,
  cloudExecuted: false,
  stopRunnerPid: process.ppid,
  expiresInHours: 4,
};
await writeFile(
  join(process.env.E4_VALIDATION_EVIDENCE!, "review.json"),
  JSON.stringify(information, null, 2),
);
console.log(JSON.stringify(information));
await new Promise<void>((resolve) => {
  const timer = setTimeout(resolve, 4 * 60 * 60 * 1000);
  const stop = () => {
    clearTimeout(timer);
    resolve();
  };
  process.once("SIGTERM", stop);
  process.once("SIGINT", stop);
});
await bridge.close();
clearInterval(cleanupTimer);
await cleanupWork;
await pool.end();
await closeLifecycleProvider();
