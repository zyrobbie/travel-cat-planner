// Disposable loopback PostgreSQL only. Does not load credentials or send mail.
import { spawn } from "node:child_process";
import {
  mkdtemp,
  readFile,
  realpath,
  rm,
  mkdir,
  writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createServer } from "node:net";
import { randomUUID } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import pg from "pg";

const evidence = resolve(process.argv[2] ?? "outputs/reading-latency");
await mkdir(evidence, { recursive: true });
const root = await realpath(
  await mkdtemp(join(tmpdir(), "cat-reading-latency-")),
);
const baseEnv = {
  PATH: process.env.PATH,
  LANG: "C.UTF-8",
  DOTENV_CONFIG_PATH: "/dev/null",
};
const clusters = [];
const browser = process.argv.includes("--browser");
let server;
let log = "Disposable two-cluster reading regression; actualEmailSent=false\n";
const append = (data) => {
  log += data;
  process.stdout.write(data);
};
const run = (command, args, env = baseEnv) =>
  new Promise((done, reject) => {
    const child = spawn(command, args, {
      env,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let stdout = "";
    child.stdout.on("data", (data) => {
      stdout += data;
      append(data.toString());
    });
    child.stderr.on("data", (data) => append(data.toString()));
    child.once("error", reject);
    child.once("exit", (code) =>
      code === 0 ? done(stdout) : reject(Error(`${command} exited ${code}`)),
    );
  });
const freePort = () =>
  new Promise((done, reject) => {
    const server = createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const port = server.address().port;
      server.close(() => done(port));
    });
  });
let passed = false;
try {
  const urls = [];
  for (const kind of ["business", "ledger"]) {
    const data = join(root, kind),
      port = await freePort();
    await run("initdb", [
      "-D",
      data,
      "-U",
      "cat_reading_test",
      "--auth=trust",
      "--no-locale",
      "--encoding=UTF8",
    ]);
    await run("pg_ctl", [
      "-D",
      data,
      "-l",
      join(root, `${kind}.log`),
      "-o",
      `-h 127.0.0.1 -p ${port} -k ${root}`,
      "-w",
      "start",
    ]);
    clusters.push(data);
    await run("createdb", [
      "-h",
      "127.0.0.1",
      "-p",
      String(port),
      "-U",
      "cat_reading_test",
      "catletters_reading_latency_test",
    ]);
    urls.push(
      `postgresql://cat_reading_test@127.0.0.1:${port}/catletters_reading_latency_test`,
    );
  }
  const port = await freePort();
  const env = {
    ...baseEnv,
    DATABASE_URL: urls[0],
    E4_LEDGER_DATABASE_URL: urls[1],
    APP_MODE: "INTERNAL",
    SAFETY_ADAPTER: "synthetic-v1",
    OTP_ADAPTER: "synthetic-v1",
    APP_ORIGIN: `http://127.0.0.1:${port}`,
    COOKIE_SECURE: browser ? "false" : "true",
    NETLIFY: "false",
    READING_PHASE: process.argv[3] ?? "optimized",
    OTP_HASH_SECRET: "local-reading-latency-synthetic-only-secret-0123456789",
    E4_LEDGER_SECRET: "local-reading-latency-synthetic-only-ledger-0123456789",
    E4_LIFECYCLE_ADAPTER: "postgres-v1",
    E4_LIFECYCLE_BOOTSTRAP: "false",
    E4_LIFECYCLE_RECOVERY: "false",
    E4_EXPORT_STORAGE: "postgres",
    E4_SYNTHETIC_MAILBOX_DIR: join(root, "inbox"),
    E4_READING_EVIDENCE: evidence,
  };
  await run(process.execPath, ["--import", "tsx", "scripts/migrate.ts"], env);
  const ledger = new pg.Pool({ connectionString: urls[1] });
  try {
    await ledger.query(
      await readFile(
        "db/ledger-migrations/001_independent_lifecycle.sql",
        "utf8",
      ),
    );
  } finally {
    await ledger.end();
  }
  const operation = randomUUID();
  const bootstrap = await run(
    process.execPath,
    ["--import", "tsx", "scripts/lifecycle.ts", "bootstrap", operation],
    { ...env, E4_LIFECYCLE_BOOTSTRAP: "true" },
  );
  const { epoch } = JSON.parse(bootstrap.trim().split("\n").at(-1));
  await run(
    process.execPath,
    [
      "--import",
      "tsx",
      "scripts/lifecycle.ts",
      "reconcile",
      operation,
      String(epoch),
    ],
    { ...env, E4_LIFECYCLE_RECOVERY: "true" },
  );
  if (browser) {
    await run(
      process.execPath,
      [
        "node_modules/vite/bin/vite.js",
        "build",
        "--config",
        "static-app/account-app/vite.config.ts",
      ],
      env,
    );
    server = spawn(
      process.execPath,
      [
        "node_modules/next/dist/bin/next",
        "dev",
        "--webpack",
        "--hostname",
        "127.0.0.1",
        "--port",
        String(port),
      ],
      { env, stdio: ["ignore", "pipe", "pipe"] },
    );
    server.stdout.on("data", (data) => append(data.toString()));
    server.stderr.on("data", (data) => append(data.toString()));
    let ready = false;
    for (let attempt = 0; attempt < 120; attempt++) {
      try {
        const response = await fetch(`${env.APP_ORIGIN}/api/e4/v1/view`);
        if (response.status === 401) {
          ready = true;
          break;
        }
      } catch {
        /* loopback server still starting */
      }
      await delay(250);
    }
    if (!ready) throw Error("Synthetic local HTTP server did not become ready");
    env.E4_READING_HTTP_ORIGIN = env.APP_ORIGIN;
  }
  await run(
    process.execPath,
    ["--import", "tsx", "--test", "tests/e4/reading-latency.test.ts"],
    env,
  );
  passed = true;
} catch (error) {
  append(`FAIL ${error.message}\n`);
  process.exitCode = 1;
} finally {
  if (server && server.exitCode === null) {
    server.kill("SIGTERM");
    await Promise.race([
      new Promise((done) => server.once("exit", done)),
      delay(3000),
    ]);
    if (server.exitCode === null) server.kill("SIGKILL");
  }
  for (const data of clusters.reverse())
    await run("pg_ctl", ["-D", data, "-m", "fast", "-w", "stop"]);
  await rm(root, { recursive: true, force: true });
  await writeFile(join(evidence, "test.log"), log);
  await writeFile(
    join(evidence, "result.json"),
    JSON.stringify(
      {
        result: passed ? "PASS" : "FAIL",
        realPostgres: true,
        independentLocalClusters: true,
        actualEmailSent: false,
        cloudExecuted: false,
        browserExecuted: browser,
      },
      null,
      2,
    ) + "\n",
  );
}
