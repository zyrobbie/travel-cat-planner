import assert from "node:assert/strict";
import { randomUUID, randomBytes } from "node:crypto";
import { NextRequest } from "next/server";
import { pool, transaction } from "../src/server/db";
import { digest } from "../src/server/auth";
import { deleteResponseWithLedger } from "../src/server/response-erasure";
import { adoptCat } from "../src/server/account-service";
import {
  prepareAccountDeletion,
  confirmAccountDeletion,
  runDeletionWorkerOnce,
} from "../src/server/account-lifecycle";
import {
  requestAccountExport,
  runExportWorkerOnce,
  accountExportStatus,
  accountExportManifest,
  accountExportChunk,
  cleanupAccountExports,
  claimAccountExport,
  runClaimedAccountExport,
} from "../src/server/account-export";
import {
  postgresExportStorage,
  fileExportStorage,
  configuredExportStorage,
  buildExportManifest,
  exportSha,
} from "../src/server/export-storage";
import { GET } from "../src/app/api/e4/privacy/[...path]/route";
import { fetchAccountExport } from "../static-app/account-export-download";
import {
  EXPORT_MAX_BYTES,
  EXPORT_CHUNK_BYTES,
} from "../src/shared/export-download";

const passed: string[] = [];
const step = async (name: string, fn: () => Promise<void>) => {
  await fn();
  passed.push(name);
  console.log(`PASS ${name}`);
};
const count = async (id?: string) =>
  Number(
    (
      await pool.query(
        `SELECT count(*) AS n FROM private_export_chunks${id ? " WHERE export_id=$1" : ""}`,
        id ? [id] : [],
      )
    ).rows[0].n,
  );
async function owner() {
  const id = randomUUID(),
    raw = randomBytes(32).toString("hex");
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    id,
    `${id}@example.test`,
  ]);
  await pool.query(
    "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,clock_timestamp()+interval '1 day')",
    [digest(raw), id],
  );
  return { id, raw };
}
async function prepared(a: Awaited<ReturnType<typeof owner>>) {
  const { job } = await requestAccountExport(a.id, randomUUID());
  const result = await runExportWorkerOnce();
  assert.equal(result.status, "READY");
  return job.id;
}
async function large(a: Awaited<ReturnType<typeof owner>>, size: number) {
  const { job } = await requestAccountExport(a.id, randomUUID());
  const name = `${job.id}.${randomUUID()}.json`;
  const bytes = Buffer.from(`"${"a".repeat(size - 2)}"`);
  const version = (
    await pool.query(
      "SELECT c.id,s.revision FROM cat_profiles c JOIN cloud_state s ON c.id=s.cat_id WHERE c.account_id=$1",
      [a.id],
    )
  ).rows[0];
  await transaction(async (db) => {
    await postgresExportStorage.write(name, bytes, db);
    await db.query(
      "UPDATE account_exports SET status='READY',artifact_name=$2,artifact_hash=$3,artifact_bytes=$4,expires_at=clock_timestamp()+interval '1 day',cat_id=$5,captured_revision=$6 WHERE id=$1",
      [
        job.id,
        name,
        exportSha(bytes),
        bytes.length,
        version?.id ?? null,
        version?.revision ?? null,
      ],
    );
  });
  return { id: job.id, name, bytes };
}
function route(
  a?: Awaited<ReturnType<typeof owner>>,
  before?: (path: string) => Promise<void>,
): typeof fetch {
  return async (input, init) => {
    const path = String(input);
    await before?.(path);
    const headers = new Headers(init?.headers);
    if (a) headers.set("cookie", `cat_account_session=${a.raw}`);
    const req = new NextRequest(new URL(path, "http://127.0.0.1:31999"), {
      ...init,
      headers,
      signal: init?.signal ?? undefined,
    });
    return GET(req);
  };
}
async function removeTestExports() {
  await pool.query("DELETE FROM account_exports");
  assert.equal(await count(), 0);
}
try {
  const u = new URL(process.env.DATABASE_URL!);
  assert.ok(["localhost", "127.0.0.1"].includes(u.hostname));
  assert.equal(
    (await pool.query("SELECT current_database() AS n")).rows[0].n,
    "catletters_e4d_private_exports_synthetic",
  );
  assert.equal(process.env.E4_EXPORT_STORAGE, "postgres");
  await step(
    "P01 migrated private tables deny client roles and default to a 64MiB payload pool",
    async () => {
      const rows = (
        await pool.query(
          "SELECT relname,relrowsecurity FROM pg_class WHERE relname IN ('private_export_budget','private_export_chunks')",
        )
      ).rows;
      assert.equal(rows.length, 2);
      assert.ok(rows.every((r) => r.relrowsecurity));
      assert.equal(
        Number(
          (
            await pool.query(
              "SELECT payload_budget_bytes FROM private_export_budget",
            )
          ).rows[0].payload_budget_bytes,
        ),
        64 * 1024 * 1024,
      );
      for (const role of ["anon", "authenticated"])
        for (const table of [
          "private_export_budget",
          "private_export_chunks",
        ]) {
          for (const privilege of ["SELECT", "INSERT", "UPDATE", "DELETE"]) {
            assert.equal(
              (
                await pool.query(
                  "SELECT has_table_privilege($1,$2,$3) AS allowed",
                  [role, table, privilege],
                )
              ).rows[0].allowed,
              false,
            );
          }
        }
    },
  );
  await step(
    "P02 actual export worker, protected Next handler and client assemble one verified JSON",
    async () => {
      const a = await owner(),
        id = await prepared(a);
      assert.equal(await count(id), 1);
      const result = await fetchAccountExport(
        a.id,
        id,
        new AbortController().signal,
        route(a),
      );
      assert.equal(JSON.parse(await result.blob.text()).account.id, a.id);
      assert.equal(result.filename, `cat-letters-${id}.json`);
      const direct = await route(a)(`/api/e4/privacy/exports/${id}/download`);
      assert.equal(direct.status, 409);
      const manifest = await route(a)(
        `/api/e4/privacy/exports/${id}/download-manifest`,
      );
      assert.match(manifest.headers.get("cache-control")!, /no-store/);
      assert.equal(
        /https?:|token|blob/i.test(JSON.stringify(await manifest.json())),
        false,
      );
    },
  );
  await step(
    "P03 anonymous, foreign account and stale account context cannot read manifest/chunks",
    async () => {
      const a = await owner(),
        b = await owner(),
        id = await prepared(a),
        m = await accountExportManifest(a.id, id, a.raw);
      for (const path of [
        `download-manifest`,
        `chunks/0?version=${m.downloadVersion}`,
      ]) {
        const url = `/api/e4/privacy/exports/${id}/${path}`;
        assert.equal((await route()(url)).status, 401);
        assert.equal((await route(b)(url)).status, 404);
        assert.equal(
          (await route(a)(url, { headers: { "X-Catletters-Account": b.id } }))
            .status,
          401,
        );
      }
    },
  );
  await step(
    "P04 multi-chunk transfer reauthenticates, aborts after logout and saves no partial blob",
    async () => {
      const a = await owner(),
        x = await large(a, EXPORT_CHUNK_BYTES + 64);
      let chunks = 0;
      await assert.rejects(
        fetchAccountExport(
          a.id,
          x.id,
          new AbortController().signal,
          route(a, async (path) => {
            if (path.includes("/chunks/") && ++chunks === 2)
              await pool.query(
                "UPDATE account_sessions SET revoked_at=clock_timestamp() WHERE token_hash=$1",
                [digest(a.raw)],
              );
          }),
        ),
        (e: any) => e.status === 401,
      );
      assert.equal(chunks, 2);
    },
  );
  await step(
    "P05 last manifest check rejects expiry/revocation after the last chunk",
    async () => {
      const a = await owner(),
        id = await prepared(a);
      let manifests = 0;
      await assert.rejects(
        fetchAccountExport(
          a.id,
          id,
          new AbortController().signal,
          route(a, async (path) => {
            if (path.endsWith("download-manifest") && ++manifests === 2)
              await pool.query(
                "UPDATE account_exports SET expires_at=clock_timestamp()-interval '1 second' WHERE id=$1",
                [id],
              );
          }),
        ),
        (e: any) => e.status === 410,
      );
      assert.equal(manifests, 2);
    },
  );
  await step(
    "P06 revision and pinned artifact changes reject downloads without poisoning a valid job",
    async () => {
      const a = await owner();
      await adoptCat(a.id, {
        name: "合成猫",
        appearanceId: "cat-02",
        key: randomUUID(),
      });
      const id = await prepared(a),
        m = await accountExportManifest(a.id, id, a.raw);
      await assert.rejects(
        accountExportChunk(a.id, id, a.raw, 0, "0".repeat(64)),
        (e: any) => e.status === 409,
      );
      await assert.rejects(
        accountExportChunk(a.id, id, a.raw, 15, m.downloadVersion),
        (e: any) => e.status === 400,
      );
      assert.equal((await accountExportStatus(a.id, id)).job.status, "READY");
      await pool.query(
        "UPDATE cloud_state SET revision=revision+1 WHERE account_id=$1",
        [a.id],
      );
      await assert.rejects(
        accountExportChunk(a.id, id, a.raw, 0, m.downloadVersion),
        (e: any) => e.status === 409,
      );
    },
  );
  await step(
    "P07 corrupt private bytes fail SHA-256 and mark the export explicitly retryable",
    async () => {
      const a = await owner(),
        id = await prepared(a),
        m = await accountExportManifest(a.id, id, a.raw);
      await pool.query(
        "UPDATE private_export_chunks SET body=set_byte(body,0,CASE WHEN get_byte(body,0)=1 THEN 2 ELSE 1 END) WHERE export_id=$1",
        [id],
      );
      await assert.rejects(
        accountExportChunk(a.id, id, a.raw, 0, m.downloadVersion),
        (e: any) => e.status === 503,
      );
      assert.equal((await accountExportStatus(a.id, id)).job.status, "FAILED");
    },
  );
  await step(
    "P08 capacity is serialized: two concurrent 32MiB contenders cannot overrun a 64MiB pool",
    async () => {
      await removeTestExports();
      const keep = await owner(),
        a = await owner(),
        b = await owner();
      const old = await large(keep, EXPORT_MAX_BYTES);
      const results = await Promise.allSettled([
        large(a, EXPORT_MAX_BYTES),
        large(b, EXPORT_MAX_BYTES),
      ]);
      assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
      const rejected = results.find(
        (r) => r.status === "rejected",
      ) as PromiseRejectedResult;
      assert.equal(rejected.reason.status, 507);
      assert.equal(
        Number(
          (
            await pool.query(
              "SELECT sum(chunk_bytes)::bigint AS n FROM private_export_chunks",
            )
          ).rows[0].n,
        ),
        64 * 1024 * 1024,
      );
      assert.equal(await count(old.id), 16);
      const got = await fetchAccountExport(
        keep.id,
        old.id,
        new AbortController().signal,
        route(keep),
      );
      assert.equal(got.blob.size, EXPORT_MAX_BYTES);
      assert.equal(
        exportSha(Buffer.from(await got.blob.arrayBuffer())),
        exportSha(old.bytes),
      );
    },
  );
  await step(
    "P09 oversize and publication SQL failure roll back all candidate chunks",
    async () => {
      await removeTestExports();
      const a = await owner(),
        { job } = await requestAccountExport(a.id, randomUUID());
      await assert.rejects(
        transaction((db) =>
          postgresExportStorage.write(
            `${job.id}.${randomUUID()}.json`,
            Buffer.alloc(EXPORT_MAX_BYTES + 1),
            db,
          ),
        ),
      );
      assert.equal(await count(), 0);
      await pool.query(
        "CREATE FUNCTION fail_private_export_publish() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.status='READY' THEN RAISE EXCEPTION 'synthetic publication failure'; END IF; RETURN NEW; END $$",
      );
      await pool.query(
        "CREATE TRIGGER fail_private_export_publish BEFORE UPDATE ON account_exports FOR EACH ROW EXECUTE FUNCTION fail_private_export_publish()",
      );
      try {
        await assert.rejects(runExportWorkerOnce());
      } finally {
        await pool.query(
          "DROP TRIGGER fail_private_export_publish ON account_exports",
        );
        await pool.query("DROP FUNCTION fail_private_export_publish()");
      }
      assert.equal(await count(), 0);
      assert.equal(
        (await accountExportStatus(a.id, job.id)).job.status,
        "FAILED",
      );
    },
  );
  await step(
    "P10 expired claimant cannot publish a stale file or chunks",
    async () => {
      const a = await owner(),
        { job } = await requestAccountExport(a.id, randomUUID()),
        claim = await claimAccountExport();
      assert.equal(claim!.id, job.id);
      await pool.query(
        "UPDATE account_exports SET lease_until=clock_timestamp()-interval '1 second' WHERE id=$1",
        [job.id],
      );
      assert.equal((await runClaimedAccountExport(claim!)).status, "STALE");
      assert.equal(await count(job.id), 0);
      await pool.query(
        "UPDATE account_exports SET status='FAILED',lease_token=NULL,lease_until=NULL WHERE id=$1",
        [job.id],
      );
    },
  );
  await step(
    "P11 expiry cleanup deletes private chunks and preserves another active export",
    async () => {
      const a = await owner(),
        b = await owner(),
        x = await prepared(a),
        y = await prepared(b);
      await pool.query(
        "UPDATE account_exports SET expires_at=clock_timestamp()-interval '1 second' WHERE id=$1",
        [x],
      );
      await cleanupAccountExports();
      assert.equal(await count(x), 0);
      assert.equal(await count(y), 1);
      assert.equal((await accountExportStatus(b.id, y)).job.status, "READY");
    },
  );
  await step(
    "P12 actual account deletion revokes new requests and physically removes private chunks",
    async () => {
      const a = await owner(),
        id = await prepared(a),
        m = await accountExportManifest(a.id, id, a.raw);
      const p = await prepareAccountDeletion(a.id, randomUUID());
      await confirmAccountDeletion(a.id, p.deletion.requestId, p.receipt);
      assert.equal(
        await count(id),
        0,
        "confirmation and chunk revocation commit together",
      );
      assert.equal(
        (
          await route(a)(
            `/api/e4/privacy/exports/${id}/chunks/0?version=${m.downloadVersion}`,
          )
        ).status,
        401,
      );
      assert.equal((await runDeletionWorkerOnce()).status, "COMPLETE");
      assert.equal(await count(id), 0);
    },
  );
  await step(
    "P13 local private-file mode remains compatible and unknown adapters fail closed",
    async () => {
      const name = `${randomUUID()}.${randomUUID()}.json`,
        bytes = Buffer.from('{"synthetic":true}');
      await fileExportStorage.write(name, bytes);
      const m = await fileExportStorage.manifest(name);
      assert.deepEqual(await fileExportStorage.chunk(name, 0, m), bytes);
      await fileExportStorage.removeJob(name.slice(0, 36));
      await assert.rejects(fileExportStorage.manifest(name));
      const saved = process.env.E4_EXPORT_STORAGE;
      process.env.E4_EXPORT_STORAGE = "unknown";
      assert.throws(configuredExportStorage);
      const oldNetlify = process.env.NETLIFY;
      process.env.NETLIFY = "true";
      process.env.E4_EXPORT_STORAGE = "file";
      assert.throws(configuredExportStorage);
      delete process.env.E4_EXPORT_STORAGE;
      assert.throws(configuredExportStorage);
      process.env.E4_EXPORT_STORAGE = "postgres";
      assert.equal(configuredExportStorage().kind, "postgres");
      if (oldNetlify === undefined) delete process.env.NETLIFY;
      else process.env.NETLIFY = oldNetlify;
      process.env.E4_EXPORT_STORAGE = saved;
    },
  );
  await step(
    "P14 browser transfer rejects tampering, truncation, excess bytes and cancelled sessions",
    async () => {
      const name = `${randomUUID()}.${randomUUID()}.json`,
        bytes = Buffer.from('{"synthetic":true}'),
        m = buildExportManifest(name, bytes);
      for (const bad of [
        Buffer.from("x".repeat(bytes.length)),
        bytes.subarray(0, -1),
        Buffer.alloc(bytes.length + 1),
      ]) {
        const fake: typeof fetch = async (input) =>
          String(input).endsWith("download-manifest")
            ? Response.json(m)
            : new Response(bad);
        await assert.rejects(
          fetchAccountExport(
            randomUUID(),
            name.slice(0, 36),
            new AbortController().signal,
            fake,
          ),
        );
      }
      const c = new AbortController();
      c.abort();
      await assert.rejects(
        fetchAccountExport(randomUUID(), name.slice(0, 36), c.signal),
      );
    },
  );
  await step(
    "P15 actual response deletion removes old chunks and new exports cannot recover deleted text",
    async () => {
      const a = await owner();
      await adoptCat(a.id, {
        name: "合成猫",
        appearanceId: "cat-03",
        key: randomUUID(),
      });
      const cat = (
        await pool.query("SELECT id FROM cat_profiles WHERE account_id=$1", [
          a.id,
        ])
      ).rows[0].id;
      const letter = randomUUID(),
        response = randomUUID(),
        marker = `synthetic-private-${randomUUID()}`;
      await transaction(async (db) => {
        await db.query(
          "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,read_at) VALUES($1,$2,$3,'DEMAND',$4,clock_timestamp())",
          [
            letter,
            cat,
            a.id,
            { title: "合成来信", body: "合成正文", catName: "合成猫" },
          ],
        );
        await db.query(
          "INSERT INTO cloud_responses(id,cat_id,account_id,letter_id,current_revision,status) VALUES($1,$2,$3,$4,1,'ACTIVE')",
          [response, cat, a.id, letter],
        );
        await db.query(
          "INSERT INTO cloud_response_revisions(cat_id,account_id,response_id,revision,text,at) VALUES($1,$2,$3,1,$4,clock_timestamp())",
          [cat, a.id, response, marker],
        );
      });
      const id = await prepared(a);
      assert.equal(await count(id), 1);
      await deleteResponseWithLedger(
        a.id,
        response,
        { key: randomUUID(), expectedRevision: 1 },
        digest("synthetic-delete"),
      );
      assert.equal(await count(id), 0);
      assert.equal((await accountExportStatus(a.id, id)).job.status, "REVOKED");
      const fresh = await prepared(a);
      const file = await fetchAccountExport(
        a.id,
        fresh,
        new AbortController().signal,
        route(a),
      );
      assert.equal((await file.blob.text()).includes(marker), false);
    },
  );
  await step(
    "P16 revocation and private chunk erasure share one transaction and roll back together",
    async () => {
      const a = await owner(),
        id = await prepared(a);
      for (const state of ["REVOKED", "EXPIRED", "FAILED", "QUEUED"]) {
        await assert.rejects(
          transaction(async (db) => {
            await db.query("UPDATE account_exports SET status=$2 WHERE id=$1", [
              id,
              state,
            ]);
            const result = await db.query(
              "SELECT count(*) AS n FROM private_export_chunks WHERE export_id=$1",
              [id],
            );
            assert.equal(Number(result.rows[0].n), 0);
            throw Error("synthetic rollback");
          }),
          /synthetic rollback/,
        );
        assert.equal(await count(id), 1);
        assert.equal((await accountExportStatus(a.id, id)).job.status, "READY");
      }
    },
  );
  console.log(
    JSON.stringify({
      result: "PASS",
      checks: passed.length,
      scope:
        "synthetic isolated PostgreSQL + actual Next route handlers in process + browser download function; no deployed cloud or browser UI acceptance",
    }),
  );
} finally {
  await pool.end();
}
