import { verifyTencentDeploymentEvidence } from "../src/server/tencent-voice-readiness";

// Read-only deployment preflight. Does not enable/configure a service, call ASR,
// query billing, create credentials, write a receipt or connect to any database.
try {
  if (process.argv.length !== 2) throw Error("UNEXPECTED_ARGUMENTS");
  const result = verifyTencentDeploymentEvidence();
  process.stdout.write(
    JSON.stringify({
      status: "PASS",
      purpose: "DEPLOYMENT_EVIDENCE_CHECK_ONLY",
      receiptSha256: result.receiptSha256,
      checkedAt: new Date().toISOString(),
      evidenceValidForDeploymentUntil: result.expiresAt,
      runtimeDependsOnReceipt: false,
      remoteBillingOrPermissionsVerifiedByThisCommand: false,
      asrCalled: false,
    }) + "\n",
  );
} catch {
  process.stderr.write(
    "Tencent deployment evidence preflight failed; no service was enabled or called.\n",
  );
  process.exitCode = 1;
}
