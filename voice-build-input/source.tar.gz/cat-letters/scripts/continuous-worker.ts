// systemd/flock entry only. Do not import dotenv or DB until fixed config passes.
import { continuousPlan, continuousStatus, CONTINUOUS_BUDGET_MS } from "../src/server/continuous-scope";
import { cursorDirectory } from "../src/server/continuous-state";
import { runContinuousCycle } from "../src/server/continuous-runner";
export async function continuousMain(startedAt:number) {
let loaded=false;
try {
  if(process.argv.length!==2)throw Error("INVALID_CONTINUOUS_ARGUMENTS");
  const plan=continuousPlan();
  if(!plan)console.log(JSON.stringify({event:"continuous_tick",status:continuousStatus(),elapsedMs:Date.now()-startedAt}));
  else {
    if(process.env.E4_CONTINUOUS_LOCK_HELD!=="true")throw Error("OS_FLOCK_REQUIRED");
    const dir=await cursorDirectory();
    process.env.E4_SCHEDULED_RUN="true";
    process.env.DOTENV_CONFIG_PATH="/dev/null";
    const deadlineAt=Math.min(startedAt+CONTINUOUS_BUDGET_MS,plan.untilAt);
    loaded=true;
    const worker=await import("../src/server/continuous-worker");
    await worker.preflightContinuous(deadlineAt);
    const result=await runContinuousCycle(plan,dir,deadlineAt,worker.runContinuousSlot);
    console.log(JSON.stringify({event:"continuous_tick",...result,elapsedMs:Date.now()-startedAt}));
    if(result.failed||result.status==="BUDGET_EXHAUSTED")process.exitCode=1;
  }
} catch {
  console.error(JSON.stringify({event:"continuous_tick",status:loaded?"UNKNOWN_CHECK_DURABLE_STATE":"REJECTED_CONFIGURATION",elapsedMs:Date.now()-startedAt}));
  process.exitCode=1;
} finally {
  if(loaded) {
    try {
      const {closeLifecycleProvider}=await import("../src/server/lifecycle-provider");
      const {pool}=await import("../src/server/db");
      await closeLifecycleProvider();await pool.end();
    } catch {
      console.error(JSON.stringify({event:"continuous_tick",status:"CONNECTION_CLOSE_INCOMPLETE"}));
      process.exitCode=1;
    }
  }
}
}
