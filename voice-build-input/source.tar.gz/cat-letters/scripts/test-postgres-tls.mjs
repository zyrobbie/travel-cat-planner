import assert from "node:assert/strict";
import { rootCertificates } from "node:tls";
import pg from "pg";
import { postgresTlsConfig } from "../src/server/postgres-tls.ts";

const before = { ca: process.env.E4_PG_CA_PEM, netlify: process.env.NETLIFY };
const local = "postgresql://user:password@127.0.0.1:5432/catletters?application_name=local_test";
const remote = "postgresql://user:password@aws-0-example.pooler.supabase.com:5432/postgres";
try {
  delete process.env.NETLIFY;
  delete process.env.E4_PG_CA_PEM;
  assert.deepEqual(postgresTlsConfig(undefined), {});
  assert.deepEqual(postgresTlsConfig(local), {});
  assert.throws(() => postgresTlsConfig(remote), /CA certificate is not configured/);
  for (const [key, value] of Object.entries({
    host: "remote.example", ssl: "0", sslmode: "require",
    sslrootcert: "/tmp/ca.crt", sslcert: "/tmp/client.crt",
    sslkey: "/tmp/client.key", sslnegotiation: "direct",
  })) {
    assert.throws(() => postgresTlsConfig(`${remote}?${key}=${encodeURIComponent(value)}`),
      /override/, `${key} must not override verified TLS`);
  }
  assert.throws(() => postgresTlsConfig(`${local}&host=remote.example`), /override/);
  process.env.E4_PG_CA_PEM = "not a certificate";
  assert.throws(() => postgresTlsConfig(remote), /CA certificate is invalid/);

  process.env.E4_PG_CA_PEM = rootCertificates[0];
  const configured = postgresTlsConfig(remote);
  assert.equal(configured.ssl.rejectUnauthorized, true);
  assert.match(configured.ssl.ca, /BEGIN CERTIFICATE/);
  const client = new pg.Client({ connectionString: remote, ...configured });
  assert.equal(client.connectionParameters.ssl.rejectUnauthorized, true);
  assert.equal(client.connectionParameters.ssl.ca, configured.ssl.ca);
  assert.equal(client.connectionParameters.host, "aws-0-example.pooler.supabase.com");
  process.env.NETLIFY = "true";
  assert.equal(postgresTlsConfig(local).ssl.rejectUnauthorized, true);
  console.log("PASS PostgreSQL TLS: local fixture, mandatory CA, conflicting URL rejection, verified pg pool config");
} finally {
  if (before.ca === undefined) delete process.env.E4_PG_CA_PEM;
  else process.env.E4_PG_CA_PEM = before.ca;
  if (before.netlify === undefined) delete process.env.NETLIFY;
  else process.env.NETLIFY = before.netlify;
}
