/** Schedule registration is deliberately disabled in this candidate.
 * No request field chooses an account, job, worker kind, clock or budget. */
type ScheduledContext = {
  deploy?: { context?: string; published?: boolean };
};
const INVOCATION_MS = 25_000;
const MIN_START_MS = 7_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

function report(
  status: string,
  startedAt: number,
  httpStatus = 200,
  extra: { reason?: string; attempted?: number; statuses?: string[] } = {},
) {
  const data = {
    event: "e4_auto_delivery",
    status,
    ...extra,
    elapsedMs: Date.now() - startedAt,
  };
  // Fixed statuses/counts only: no credentials, account IDs, email or content.
  console.info(JSON.stringify(data));
  return Response.json(data, {
    status: httpStatus,
    headers: { "Cache-Control": "no-store, private", Pragma: "no-cache" },
  });
}
async function validInvocation(request: Request) {
  if (new URL(request.url).search !== "" || !request.body) return false;
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 1024) {
        await reader.cancel();
        return false;
      }
      chunks.push(value);
    }
    const data: unknown = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!data || typeof data !== "object" || Array.isArray(data)) return false;
    const event = data as Record<string, unknown>;
    // next_run is the documented platform event shape, not authorization and
    // never a business clock or authorization. Registration remains disabled below.
    return (
      Object.keys(event).length === 1 &&
      typeof event.next_run === "string" &&
      Number.isFinite(Date.parse(event.next_run))
    );
  } catch {
    return false;
  } finally {
    reader.releaseLock();
  }
}

export default async function handler(
  request: Request,
  context: ScheduledContext = {},
) {
  const startedAt = Date.now();
  let invocationDeadlineAt = startedAt + INVOCATION_MS;
  if (
    process.env.APP_MODE !== "INTERNAL" ||
    process.env.E4_AUTO_DELIVERY_ENABLED !== "true"
  )
    return report("DISABLED", startedAt);
  // Trusted Netlify Context, never request headers. Old/unpublished and preview
  // deploys must not operate even when invoked with Run now.
  if (
    context.deploy?.context !== "production" ||
    context.deploy.published !== true
  )
    return report("REJECTED", startedAt, 403, {
      reason: "unpublished_context",
    });
  const accountId = process.env.E4_AUTO_DELIVERY_ACCOUNT_ID?.toLowerCase();
  const until = process.env.E4_AUTO_DELIVERY_UNTIL;
  if (
    !accountId ||
    !UUID.test(accountId) ||
    !until ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(until) ||
    !Number.isFinite(Date.parse(until))
  )
    return report("BLOCKED", startedAt, 503, {
      reason: "scope_or_window_not_configured",
    });
  if (Date.parse(until) <= startedAt) return report("EXPIRED", startedAt);
  invocationDeadlineAt = Math.min(invocationDeadlineAt, Date.parse(until));
  if (!(await validInvocation(request)))
    return report("REJECTED", startedAt, 400, { reason: "invalid_invocation" });
  if (Date.now() >= invocationDeadlineAt - MIN_START_MS)
    return report("DEFERRED", startedAt, 200, { reason: "invocation_budget" });
  // This independent function has its own pool instances. Configure their small
  // scheduled limits before importing any module that constructs them.
  process.env.E4_SCHEDULED_RUN = "true";
  try {
    const { cloudTick } = await import("../../src/server/scheduled-candidate");
    if (Date.now() >= invocationDeadlineAt - MIN_START_MS)
      return report("DEFERRED", startedAt, 200, {
        reason: "invocation_budget",
      });
    const result = await cloudTick(
      { accountId, allowBudgetRecovery: true },
      { invocationDeadlineAt, maxJobs: 1 },
    );
    return report(result.outcomes[0]?.status ?? "IDLE", startedAt, 200, {
      attempted: result.attempted,
      statuses: result.outcomes.map((outcome) => outcome.status),
    });
  } catch {
    report("UNKNOWN", startedAt, 503, { reason: "check_durable_state" });
    // Failed invocation remains visible. The next scheduled call uses the
    // persisted lease/retry state; do not assume the previous COMMIT failed.
    throw new Error("E4_AUTO_DELIVERY_UNKNOWN_CHECK_DURABLE_STATE");
  }
}

export const config = {};
