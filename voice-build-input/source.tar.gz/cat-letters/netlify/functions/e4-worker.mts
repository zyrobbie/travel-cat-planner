import { timingSafeEqual } from "node:crypto";

type WorkerKind = "cloud" | "privacy" | "cleanup";

const response = (body: object, status: number) =>
  Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store, private", Pragma: "no-cache" },
  });

function authorized(header: string | null, configured: string) {
  if (!header?.startsWith("Bearer ")) return false;
  const supplied = header.slice(7);
  if (!/^[a-f0-9]{64}$/.test(supplied)) return false;
  return timingSafeEqual(Buffer.from(supplied, "hex"), Buffer.from(configured, "hex"));
}

function workerKind(url: string): WorkerKind | null {
  const parsed = new URL(url);
  const kind = parsed.searchParams.get("kind");
  return kind === "cloud" || kind === "privacy" || kind === "cleanup"
    ? kind
    : null;
}

/** Explicitly invoked only. No config.schedule or Netlify cron is registered. */
export default async function handler(request: Request): Promise<Response> {
  if (request.method !== "POST") return response({ error: "method_not_allowed" }, 405);
  if (
    process.env.APP_MODE !== "INTERNAL" ||
    process.env.E4_MANUAL_WORKER_ENABLED !== "true"
  ) return response({ error: "not_found" }, 404);

  const secret = process.env.E4_MANUAL_WORKER_TOKEN;
  if (!secret || !/^[a-f0-9]{64}$/.test(secret))
    return response({ error: "worker_not_configured" }, 503);
  if (!authorized(request.headers.get("authorization"), secret))
    return response({ error: "unauthorized" }, 401);

  const kind = workerKind(request.url);
  if (!kind) return response({ error: "invalid_worker_kind" }, 400);
  // This release exposes only a deployment-locked cloud fixture, not the
  // unscoped privacy/cleanup paths used by local operator tooling.
  if (kind !== "cloud") return response({ error: "worker_kind_disabled" }, 403);
  const params = new URL(request.url).searchParams;
  if (params.getAll("kind").length !== 1 ||
      [...params.keys()].some(key => key !== "kind") || request.body !== null)
    return response({ error: "invalid_worker_request" }, 400);
  const accountId = process.env.E4_TEST_WORKER_ACCOUNT_ID?.toLowerCase();
  if (!accountId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(accountId))
    return response({ error: "worker_scope_not_configured" }, 503);

  // This function has its own runtime. The flag must be set before importing
  // the worker modules so both PostgreSQL pools receive the bounded settings.
  process.env.E4_SCHEDULED_RUN = "true";
  try {
    const { cloudTick } =
      await import("../../src/server/scheduled-candidate");
    const result = await cloudTick({ accountId });
    return response({ kind, attempted: result.attempted,
      statuses: result.outcomes.map(x => x.status), elapsedMs: result.elapsedMs }, 200);
  } catch {
    // A disconnected caller cannot infer whether an in-flight COMMIT landed.
    // The operator must inspect durable business and ledger state before retry.
    return response({ kind, status: "UNKNOWN", error: "check_durable_state" }, 503);
  }
}

export const config = { method: "POST" as const };
