-- Independent ledger only; ordinary runtime still has no DDL rights.
-- Cancellation must survive a business-database rollback just like confirmation.
ALTER TABLE ledger_events DROP CONSTRAINT ledger_events_kind_check;
ALTER TABLE ledger_events ADD CONSTRAINT ledger_events_kind_check
  CHECK (kind IN ('DELETE_REQUESTED','DELETE_COMPLETE','RESPONSE_DELETED','DELETE_CANCELLED'));
