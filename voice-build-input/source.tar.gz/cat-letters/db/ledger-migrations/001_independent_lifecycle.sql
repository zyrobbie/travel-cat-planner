-- Apply only to the physically separate lifecycle PostgreSQL project.
-- Ordinary application roles must not have DDL or direct UPDATE/DELETE rights here.
CREATE TABLE ledger_identity (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  id uuid NOT NULL,
  key_hash text NOT NULL CHECK (key_hash ~ '^[a-f0-9]{64}$')
);
CREATE TABLE ledger_head (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  sequence bigint NOT NULL DEFAULT 0 CHECK (sequence >= 0),
  hash text NOT NULL DEFAULT ''
);
CREATE TABLE ledger_events (
  sequence bigint PRIMARY KEY CHECK (sequence > 0),
  kind text NOT NULL CHECK (kind IN ('DELETE_REQUESTED','DELETE_COMPLETE','RESPONSE_DELETED')),
  request_id uuid NOT NULL,
  account_id uuid NOT NULL,
  previous_hash text NOT NULL,
  hash text NOT NULL CHECK (hash ~ '^[a-f0-9]{64}$'),
  event_json text NOT NULL,
  UNIQUE (kind, request_id, account_id)
);
CREATE TABLE restore_gate (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  status text NOT NULL CHECK (status IN ('READY','CLOSED')),
  epoch bigint NOT NULL DEFAULT 0 CHECK (epoch >= 0),
  operation_id uuid,
  closed_at timestamptz
);
CREATE TABLE restore_operations (
  operation_id uuid PRIMARY KEY,
  epoch bigint NOT NULL UNIQUE CHECK (epoch > 0),
  started_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
