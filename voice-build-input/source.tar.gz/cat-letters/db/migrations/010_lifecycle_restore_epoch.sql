-- The independent ledger gate advances this epoch before any physical restore.
-- A restored business backup cannot reopen the gate with an older epoch,
-- including when it happens to contain the same ledger sequence and hash.
ALTER TABLE lifecycle_control
  ADD COLUMN restore_epoch bigint NOT NULL DEFAULT 0 CHECK (restore_epoch >= 0);
