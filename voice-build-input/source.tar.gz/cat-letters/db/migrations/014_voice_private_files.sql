-- Only metadata is persistent. Never copy former SQL payload into a new backend.
TRUNCATE public.private_voice_payload;
ALTER TABLE public.private_voice_payload ADD CONSTRAINT private_voice_payload_disabled CHECK(false);
ALTER TABLE public.private_voice_jobs
 ADD COLUMN payload_epoch uuid,
 ADD COLUMN audio_version uuid,
 ADD COLUMN audio_bytes bigint NOT NULL DEFAULT 0 CHECK(audio_bytes BETWEEN 0 AND 10485760),
 ADD COLUMN text_version uuid,
 ADD COLUMN text_bytes integer NOT NULL DEFAULT 0 CHECK(text_bytes BETWEEN 0 AND 128000),
 ADD COLUMN reserved_bytes bigint NOT NULL DEFAULT 0 CHECK(reserved_bytes BETWEEN 0 AND 33554432),
 ADD CONSTRAINT private_voice_audio_pointer CHECK((audio_version IS NULL)=(audio_bytes=0)),
 ADD CONSTRAINT private_voice_text_pointer CHECK((text_version IS NULL)=(text_bytes=0));
ALTER TABLE public.private_voice_budget
 ADD COLUMN last_cleanup_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 ADD COLUMN cleanup_epoch uuid,
 ADD COLUMN cleanup_failures integer NOT NULL DEFAULT 0 CHECK(cleanup_failures BETWEEN 0 AND 1000000),
 ADD COLUMN last_cleanup_error text;

UPDATE public.private_voice_jobs SET status='FAILED',last_error='AUDIO_LOST',lease_token=NULL,lease_until=NULL
 WHERE status IN ('UPLOADING','UPLOADED','TRANSCRIBING','READY');

CREATE FUNCTION public.clear_private_voice_pointers() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
 IF NEW.status NOT IN ('UPLOADING','TRANSCRIBING') THEN NEW.reserved_bytes=0; END IF;
 IF NEW.status IN ('CONFIRMED','CANCELLED','EXPIRED') OR NEW.last_error='AUDIO_LOST' THEN
  NEW.payload_epoch=NULL; NEW.audio_version=NULL; NEW.audio_bytes=0;
  NEW.text_version=NULL; NEW.text_bytes=0; NEW.reserved_bytes=0;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER private_voice_clear_pointers BEFORE UPDATE ON public.private_voice_jobs
 FOR EACH ROW EXECUTE FUNCTION public.clear_private_voice_pointers();
REVOKE ALL ON FUNCTION public.clear_private_voice_pointers() FROM PUBLIC;

DO $$ DECLARE viewer text; BEGIN
 FOR viewer IN SELECT unnest(ARRAY['PUBLIC','anon','authenticated','service_role','cat_letters_app']) LOOP
  IF viewer='PUBLIC' OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname=viewer) THEN
   EXECUTE format('REVOKE ALL ON public.private_voice_payload FROM %s',
    CASE WHEN viewer='PUBLIC' THEN 'PUBLIC' ELSE quote_ident(viewer) END);
  END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='cat_letters_app') THEN
  REVOKE UPDATE(singleton) ON public.private_voice_budget FROM cat_letters_app;
  GRANT UPDATE(payload_epoch,audio_version,audio_bytes,text_version,text_bytes,reserved_bytes)
   ON public.private_voice_jobs TO cat_letters_app;
  GRANT UPDATE(last_cleanup_at,cleanup_epoch,cleanup_failures,last_cleanup_error) ON public.private_voice_budget TO cat_letters_app;
  DROP POLICY IF EXISTS private_voice_budget_lock ON public.private_voice_budget;
  CREATE POLICY private_voice_budget_lock ON public.private_voice_budget FOR UPDATE TO cat_letters_app USING(true) WITH CHECK(true);
 END IF;
END $$;
