-- Align the application to the approved 2000 visible-grapheme contract.
-- JS Intl.Segmenter enforces graphemes; SQL independently bounds storage.
-- Existing rows remain valid; old migrations and source offsets are unchanged.
ALTER TABLE cloud_response_revisions DROP CONSTRAINT cloud_response_revisions_text_check;
ALTER TABLE cloud_response_revisions ADD CONSTRAINT cloud_response_revisions_text_check
 CHECK(text IS NULL OR (char_length(text) BETWEEN 1 AND 64000 AND octet_length(text)<=128000));
