-- Server-only temporary privacy exports. Never expose through Data API policies.
CREATE TABLE private_export_budget (
  singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),
  payload_budget_bytes bigint NOT NULL DEFAULT 67108864
    CHECK(payload_budget_bytes BETWEEN 33554432 AND 268435456)
);
INSERT INTO private_export_budget(singleton) VALUES(true);
CREATE TABLE private_export_chunks (
  export_id uuid NOT NULL REFERENCES account_exports(id) ON DELETE CASCADE,
  artifact_name text NOT NULL CHECK(artifact_name ~ '^[a-f0-9-]{36}\.[a-f0-9-]{36}\.json$'),
  chunk_index smallint NOT NULL CHECK(chunk_index BETWEEN 0 AND 15),
  chunk_bytes integer NOT NULL CHECK(chunk_bytes BETWEEN 1 AND 2097152),
  chunk_hash text NOT NULL CHECK(chunk_hash ~ '^[a-f0-9]{64}$'),
  body bytea NOT NULL,
  CHECK(left(artifact_name,36)=export_id::text),
  CHECK(octet_length(body)=chunk_bytes),
  PRIMARY KEY(export_id,artifact_name,chunk_index)
);
ALTER TABLE private_export_budget ENABLE ROW LEVEL SECURITY;
ALTER TABLE private_export_chunks ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private_export_budget,private_export_chunks FROM PUBLIC;
DO $$ BEGIN
  IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
    REVOKE ALL ON private_export_budget,private_export_chunks FROM anon;
  END IF;
  IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
    REVOKE ALL ON private_export_budget,private_export_chunks FROM authenticated;
  END IF;
END $$;

-- Every status-based revocation removes its bytes in that same SQL transaction.
-- Rollback restores both status and bytes; deletion also cascades through the FK.
CREATE FUNCTION purge_invalid_private_export_chunks() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status NOT IN ('READY','BUILDING') THEN
    DELETE FROM private_export_chunks WHERE export_id=NEW.id;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER private_export_status_cleanup AFTER UPDATE OF status ON account_exports
FOR EACH ROW EXECUTE FUNCTION purge_invalid_private_export_chunks();
