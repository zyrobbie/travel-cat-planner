-- New E4-E migration; never rewrite old migrations. Apply only after review.
-- Ephemeral payload MUST be excluded from logical backups. UNLOGGED alone
-- does not exclude pg_dump data; it may be lost after crash, which fails safe.
CREATE TABLE private_voice_jobs (
 id uuid PRIMARY KEY, account_id uuid NOT NULL REFERENCES accounts(id),
 session_hash text NOT NULL REFERENCES account_sessions(token_hash) ON DELETE CASCADE,
 cat_id uuid NOT NULL, letter_id text NOT NULL, request_key uuid NOT NULL,
 audio_hash text NOT NULL CHECK(audio_hash ~ '^[a-f0-9]{64}$'),
 expected_bytes integer NOT NULL CHECK(expected_bytes BETWEEN 1 AND 10485760),
 mime_type text NOT NULL CHECK(mime_type IN ('audio/webm','audio/ogg','audio/mp4','audio/wav')),
 status text NOT NULL DEFAULT 'CREATED' CHECK(status IN ('CREATED','UPLOADING','UPLOADED','TRANSCRIBING','READY','FAILED','CONFIRMED','CANCELLED','EXPIRED')),
 provider_mode text NOT NULL, duration_ms integer CHECK(duration_ms BETWEEN 1 AND 60000),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 expires_at timestamptz NOT NULL DEFAULT (clock_timestamp()+interval '24 hours'),
 lease_token uuid, lease_until timestamptz, attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 3),
 last_error text,
 UNIQUE(account_id,session_hash,request_key),
 FOREIGN KEY(account_id,cat_id,letter_id) REFERENCES cloud_letters(account_id,cat_id,id) ON DELETE CASCADE,
 CHECK((status IN ('UPLOADING','TRANSCRIBING'))=(lease_token IS NOT NULL AND lease_until IS NOT NULL))
);
CREATE INDEX private_voice_owner ON private_voice_jobs(account_id,session_hash,created_at);
CREATE INDEX private_voice_expiry ON private_voice_jobs(expires_at,id);
CREATE UNLOGGED TABLE private_voice_payload (
 job_id uuid PRIMARY KEY REFERENCES private_voice_jobs(id) ON DELETE CASCADE,
 audio bytea NOT NULL CHECK(octet_length(audio) BETWEEN 1 AND 10485760),
 transcript text CHECK(transcript IS NULL OR (char_length(transcript) BETWEEN 1 AND 64000 AND octet_length(transcript)<=128000))
);
CREATE TABLE private_voice_budget (
 singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),
 max_bytes bigint NOT NULL DEFAULT 67108864 CHECK(max_bytes BETWEEN 10485760 AND 268435456)
);
INSERT INTO private_voice_budget(singleton) VALUES(true);
CREATE FUNCTION purge_terminal_voice_payload() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
 IF NEW.status IN ('CONFIRMED','CANCELLED','EXPIRED') THEN DELETE FROM public.private_voice_payload WHERE job_id=NEW.id; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER private_voice_terminal AFTER UPDATE OF status ON private_voice_jobs
 FOR EACH ROW EXECUTE FUNCTION purge_terminal_voice_payload();
CREATE FUNCTION revoke_session_voice() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
 IF NEW.revoked_at IS NOT NULL THEN
  UPDATE public.private_voice_jobs SET status='CANCELLED',lease_token=NULL,lease_until=NULL,last_error='SESSION_ENDED'
   WHERE session_hash=NEW.token_hash AND status NOT IN ('CONFIRMED','CANCELLED','EXPIRED');
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER private_voice_logout AFTER UPDATE OF revoked_at ON account_sessions
 FOR EACH ROW EXECUTE FUNCTION revoke_session_voice();
CREATE FUNCTION revoke_account_voice() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,pg_temp AS $$
BEGIN
 IF NEW.status<>'ACTIVE' THEN
  UPDATE public.private_voice_jobs SET status='CANCELLED',lease_token=NULL,lease_until=NULL,last_error='ACCOUNT_ENDED'
   WHERE account_id=NEW.id AND status NOT IN ('CONFIRMED','CANCELLED','EXPIRED');
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER private_voice_account AFTER UPDATE OF status ON accounts
 FOR EACH ROW EXECUTE FUNCTION revoke_account_voice();
REVOKE ALL ON FUNCTION purge_terminal_voice_payload(),revoke_session_voice(),revoke_account_voice() FROM PUBLIC;
ALTER TABLE private_voice_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE private_voice_payload ENABLE ROW LEVEL SECURITY;
ALTER TABLE private_voice_budget ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private_voice_jobs,private_voice_payload,private_voice_budget FROM PUBLIC;
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='cat_letters_app') THEN
  GRANT SELECT,INSERT,DELETE ON private_voice_jobs,private_voice_payload TO cat_letters_app;
  GRANT UPDATE(status,duration_ms,lease_token,lease_until,attempts,last_error) ON private_voice_jobs TO cat_letters_app;
  GRANT UPDATE(transcript) ON private_voice_payload TO cat_letters_app;
  CREATE POLICY private_voice_runtime ON private_voice_jobs TO cat_letters_app USING(true) WITH CHECK(true);
  CREATE POLICY private_voice_runtime ON private_voice_payload TO cat_letters_app USING(true) WITH CHECK(true);
  GRANT SELECT,UPDATE(singleton) ON private_voice_budget TO cat_letters_app;
  CREATE POLICY private_voice_budget_read ON private_voice_budget FOR SELECT TO cat_letters_app USING(true);
  CREATE POLICY private_voice_budget_lock ON private_voice_budget FOR UPDATE TO cat_letters_app USING(true) WITH CHECK(false);
 END IF;
END $$;
