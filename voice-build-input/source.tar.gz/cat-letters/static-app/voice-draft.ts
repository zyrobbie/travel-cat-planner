/** Local UI data only. Never sent to the voice provider or account API. */
export class VoiceDraftConflict extends Error {
  constructor(public readonly latestText: string) {
    super("另一页面已保存了不同版本，原稿和校对文字均已保留，请重新核对。");
    this.name = "VoiceDraftConflict";
  }
}
