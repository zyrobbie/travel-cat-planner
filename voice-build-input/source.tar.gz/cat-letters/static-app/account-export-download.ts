import { AccountError } from "./account-client";
import { validateExportManifest } from "../src/shared/export-download";

async function readBounded(response: Response, limit: number) {
  const declared = response.headers.get("content-length");
  if (
    declared !== null &&
    (!/^\d+$/.test(declared) || Number(declared) > limit)
  ) {
    await response.body?.cancel();
    throw new AccountError("导出数据长度异常，请重新准备。", 503);
  }
  const reader = response.body?.getReader();
  if (!reader) throw new AccountError("导出内容未收到，请重试。", 503);
  const result = new Uint8Array(limit);
  let offset = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) return result.slice(0, offset);
      if (offset + value.length > limit) {
        await reader.cancel();
        throw new AccountError("导出数据长度异常，请重新准备。", 503);
      }
      result.set(value, offset);
      offset += value.length;
    }
  } finally {
    reader.releaseLock();
  }
}
const sha = async (bytes: Uint8Array) =>
  [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", new Uint8Array(bytes).buffer),
    ),
  ]
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");

/** One user action, same-origin authorized fragments, one verified JSON download. */
export async function fetchAccountExport(
  accountId: string,
  exportId: string,
  signal: AbortSignal,
  fetcher: typeof fetch = fetch,
) {
  const base = `/api/e4/privacy/exports/${encodeURIComponent(exportId)}`;
  async function get(path: string) {
    signal.throwIfAborted();
    let response: Response;
    try {
      response = await fetcher(`${base}/${path}`, {
        credentials: "same-origin",
        cache: "no-store",
        redirect: "error",
        signal,
        headers: { "X-Catletters-Account": accountId },
      });
    } catch (error) {
      if (signal.aborted) throw error;
      throw new AccountError("下载中断，未保存不完整文件。请重试。", 0);
    }
    if (!response.ok) {
      const bytes = await readBounded(response, 16384);
      let message = "文件暂不可下载，请刷新资料状态。";
      try {
        const failure = JSON.parse(new TextDecoder().decode(bytes));
        if (typeof failure.error === "string") message = failure.error;
      } catch {}
      throw new AccountError(message, response.status);
    }
    return response;
  }
  async function getManifest() {
    const response = await get("download-manifest");
    return validateExportManifest(
      JSON.parse(
        new TextDecoder("utf-8", { fatal: true }).decode(
          await readBounded(response, 16384),
        ),
      ),
    );
  }
  const manifest = await getManifest();
  const bytes = new Uint8Array(manifest.bytes);
  let offset = 0;
  for (const part of manifest.chunks) {
    const response = await get(
      `chunks/${part.index}?version=${manifest.downloadVersion}`,
    );
    const chunk = await readBounded(response, part.bytes);
    signal.throwIfAborted();
    if (chunk.length !== part.bytes || (await sha(chunk)) !== part.sha256)
      throw new AccountError(
        "导出文件校验失败，未保存不完整文件。请重新下载。",
        503,
      );
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  if (offset !== manifest.bytes || (await sha(bytes)) !== manifest.sha256)
    throw new AccountError("导出文件校验失败，请重新下载。", 503);
  // Re-check after transfer so a revocation/version change mid-download cannot produce a saved file.
  const current = await getManifest();
  signal.throwIfAborted();
  if (
    current.downloadVersion !== manifest.downloadVersion ||
    current.sha256 !== manifest.sha256 ||
    current.bytes !== manifest.bytes
  )
    throw new AccountError("记录已经改变，请重新导出当前内容。", 409);
  return {
    blob: new Blob([bytes], { type: "application/json;charset=utf-8" }),
    filename: manifest.filename,
  };
}
