import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type RefObject,
} from "react";
import type {
  VoiceApi,
  VoiceCapabilities,
  VoiceJob,
} from "../src/shared/voice";
import {
  VOICE_MAX_BYTES,
  VOICE_MAX_MS,
  VOICE_MIMES,
} from "../src/shared/voice";
import "./voice.css";
import { VoiceDraftConflict } from "./voice-draft";
import {
  countResponseText,
  validResponseText,
} from "../src/shared/response-text";

type Props = {
  api: VoiceApi;
  letterId: string;
  draft: string;
  draftInput: RefObject<HTMLTextAreaElement | null>;
  disabled: boolean;
  initialReview: string;
  onReviewDraft: (text: string) => void;
  onApply: (
    text: string,
    expectedDraft: string,
    stillCurrent: () => boolean,
  ) => Promise<void>;
  onReloadDraft: (stillCurrent: () => boolean) => Promise<void>;
  onActivity: (value: boolean) => void;
};
type Phase =
  | "idle"
  | "asking"
  | "recording"
  | "stopped"
  | "uploading"
  | "transcribing"
  | "review"
  | "failed"
  | "cleanup";
const formats = [
  "audio/webm;codecs=opus",
  "audio/ogg;codecs=opus",
  "audio/mp4",
  "audio/webm",
  "audio/ogg",
];
const unavailableCaps: VoiceCapabilities = {
  available: false, mode: "disabled", maxMs: VOICE_MAX_MS,
  maxBytes: VOICE_MAX_BYTES, mimes: VOICE_MIMES,
};
const expiredJob = (j: VoiceJob) => j.error === "AUDIO_LOST" ||
  j.error === "EXPIRED" || ["EXPIRED", "CANCELLED", "CONFIRMED"].includes(j.status);
export default function VoiceComposer({
  api,
  letterId,
  draft,
  draftInput,
  disabled,
  initialReview,
  onReviewDraft,
  onApply,
  onReloadDraft,
  onActivity,
}: Props) {
  const [caps, setCaps] = useState<VoiceCapabilities | null>(
      initialReview
        ? {
            available: false,
            mode: "disabled",
            maxMs: VOICE_MAX_MS,
            maxBytes: VOICE_MAX_BYTES,
            mimes: VOICE_MIMES,
          }
        : null,
    ),
    [phase, setPhase] = useState<Phase>(initialReview ? "review" : "idle"),
    [text, setText] = useState(initialReview),
    [notice, setNotice] = useState(""),
    [seconds, setSeconds] = useState(0),
    [applied, setApplied] = useState(false);
  const [conflict, setConflict] = useState<{ latest: string } | null>(null);
  const epoch = useRef(0),
    mounted = useRef(true),
    recorder = useRef<MediaRecorder | null>(null),
    stream = useRef<MediaStream | null>(null),
    timer = useRef<ReturnType<typeof setInterval> | null>(null),
    jobId = useRef<string | null>(null),
    take = useRef<Blob | null>(null),
    stopping = useRef(false),
    working = useRef(false),
    appliedRef = useRef(false),
    createInput = useRef<{
      key: string;
      hash: string;
      bytes: number;
      mime: string;
    } | null>(null),
    creation = useRef<Promise<VoiceJob> | null>(null);
  const endMessage = useRef("");
  const [saving, setSaving] = useState(false);
  const [cleanupRetry, setCleanupRetry] = useState(true);
  const panel = useRef<HTMLElement>(null),
    reviewInput = useRef<HTMLTextAreaElement>(null),
    focusOwned = useRef(false),
    previousPhase = useRef<Phase | null>(null);
  type DraftSelection = {
    start: number;
    end: number;
    direction: "forward" | "backward" | "none";
  };
  const draftSelection = useRef<DraftSelection | null>(null),
    returnFocus = useRef<{
      epoch: number;
      selection: DraftSelection | null;
    } | null>(null);
  function rememberDraftSelection() {
    const input = draftInput.current;
    if (input)
      draftSelection.current = {
        start: input.selectionStart,
        end: input.selectionEnd,
        direction: input.selectionDirection,
      };
  }
  useEffect(() => {
    const focus = (event: FocusEvent) => {
      // Removing a focused control may expose body as the active element.
      // An explicit outside pointer/focus already releases ownership below.
      if (
        event.target === document.body ||
        event.target === document.documentElement
      )
        return;
      focusOwned.current = !!panel.current?.contains(event.target as Node);
    };
    const pointer = (event: PointerEvent) => {
      if (!panel.current?.contains(event.target as Node))
        focusOwned.current = false;
      else if (
        event.target instanceof Element &&
        event.target.closest("button")
      )
        focusOwned.current = true;
    };
    document.addEventListener("focusin", focus);
    document.addEventListener("pointerdown", pointer, true);
    return () => {
      document.removeEventListener("focusin", focus);
      document.removeEventListener("pointerdown", pointer, true);
    };
  }, []);
  // Resolve handoffs after DOM changes, never from a delayed timer. An input
  // outside this panel owns its focus, and an old component never focuses it.
  useLayoutEffect(() => {
    const region = panel.current;
    if (!mounted.current || !region?.isConnected) return;
    const before = previousPhase.current;
    previousPhase.current = phase;
    const active = document.activeElement;
    const owned = focusOwned.current || !!(active && region.contains(active));
    const request = returnFocus.current;
    if (request) {
      returnFocus.current = null;
      const input = draftInput.current;
      if (
        request.epoch === epoch.current &&
        owned &&
        input?.isConnected &&
        active !== input
      ) {
        input.focus();
        if (request.selection)
          input.setSelectionRange(
            request.selection.start,
            request.selection.end,
            request.selection.direction,
          );
      }
      return;
    }
    if (before === phase) return;
    const restoredReview =
      before === null && phase === "review" && active === document.body;
    if (!owned && !restoredReview) return;
    if (phase === "review") reviewInput.current?.focus();
    else if (phase === "idle") {
      const input = draftInput.current;
      if (before !== null && input?.isConnected && active !== input) {
        input.focus();
        if (draftSelection.current)
          input.setSelectionRange(
            draftSelection.current.start,
            draftSelection.current.end,
            draftSelection.current.direction,
          );
      }
    } else {
      const advance = ["recording", "stopped", "failed"].includes(phase)
        ? region.querySelector<HTMLButtonElement>(
            "button.e4-voice-primary:not(:disabled)",
          )
        : null;
      (advance ?? region).focus();
    }
  }, [phase, saving, applied, notice, caps, draftInput]);
  useEffect(() => {
    onActivity((!["idle", "cleanup"].includes(phase) && !(phase === "failed" && !caps?.available)) || saving);
    return () => onActivity(false);
  }, [phase, saving, onActivity, caps?.available]);
  const alive = (n: number) => mounted.current && n === epoch.current;
  function release() {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    stopping.current = true;
    if (recorder.current?.state === "recording") recorder.current.stop();
    recorder.current = null;
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
  }
  async function resolveJob() {
    if (jobId.current) return jobId.current;
    const i = createInput.current;
    if (!i) return null;
    let j: VoiceJob;
    try {
      j = await (creation.current ??
        api.create(letterId, i.key, i.hash, i.bytes, i.mime));
    } catch {
      creation.current = null;
      j = await api.create(letterId, i.key, i.hash, i.bytes, i.mime);
    }
    jobId.current = j.id;
    return j.id;
  }
  useEffect(() => {
    mounted.current = true;
    let current = true;
    const supported =
      window.isSecureContext &&
      !!navigator.mediaDevices?.getUserMedia &&
      typeof MediaRecorder !== "undefined" &&
      typeof MediaRecorder.isTypeSupported === "function" &&
      formats.some((m) => MediaRecorder.isTypeSupported(m));
    if (supported)
      api
        .capabilities()
        .then((c) => {
          if (current) { setCaps(c); if (!c.available) setNotice(c.reason === "disabled" ? "语音尚未启用，可以直接打字。" : "语音暂不可用，可以直接打字。"); }
        })
        .catch(() => { if (current) { setCaps(unavailableCaps); setNotice("语音暂不可用，可以直接打字。"); } });
    else {
      setCaps(unavailableCaps);
      setNotice("当前浏览器暂不支持录音，可以直接打字。");
    }
    return () => {
      current = false;
      mounted.current = false;
      epoch.current++;
      release();
      void resolveJob()
        .then((id) =>
          id ? api.finish(id, appliedRef.current ? "confirm" : "cancel") : null,
        )
        .catch(() => {});
    };
  }, [api, letterId]);
  useEffect(() => {
    const interrupted = () => {
      if (!stopping.current && recorder.current) {
        endMessage.current =
          "录音已中断。可检查已录下的部分后转文字，也可以重新录音。";
        stopping.current = true;
        if (recorder.current.state === "recording") recorder.current.stop();
      }
    };
    const visibility = () => {
      if (document.hidden) interrupted();
    };
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("pagehide", interrupted);
    return () => {
      document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("pagehide", interrupted);
    };
  });
  async function cancel(
    message = "已取消这段录音，原文字草稿保留。",
    focusDraft = true,
  ) {
    rememberDraftSelection();
    const n = ++epoch.current;
    if (focusDraft)
      returnFocus.current = { epoch: n, selection: draftSelection.current };
    release();
    working.current = false;
    setSaving(false);
    setCleanupRetry(true);
    setPhase("cleanup");
    setNotice("正在清理临时录音…");
    try {
      const id = await resolveJob();
      const result = id ? await api.finish(id, appliedRef.current ? "confirm" : "cancel") : null;
      if (!alive(n)) return;
      if (result?.cleanup === "pending") {
        setNotice("本次语音已停止；服务端临时材料的清理尚未确认。可以继续打字。");
        return;
      }
      jobId.current = null;
      createInput.current = null;
      creation.current = null;
      take.current = null;
      setText("");
      onReviewDraft("");
      setConflict(null);
      setPhase("idle");
      setNotice(
        appliedRef.current ? "文字已填入本机草稿，尚未发送。" : message,
      );
      appliedRef.current = false;
      setApplied(false);
    } catch (error) {
      if (alive(n)) {
        setPhase("cleanup");
        setCleanupRetry([0, 503, 504].includes((error as { status?: number }).status ?? 0));
        setNotice(
          appliedRef.current
            ? "文字已填入草稿，服务端临时材料的清理尚未确认。可以继续打字。"
            : "本次语音已停止；服务端临时材料的清理尚未确认。可以继续打字。",
        );
      }
    }
  }
  async function acceptJob(n: number, j: VoiceJob) {
    if (!alive(n)) return;
    if (expiredJob(j)) {
      jobId.current = null; take.current = null;
      createInput.current = null; creation.current = null;
      setPhase(text.trim() ? "review" : "failed");
      setNotice(text.trim()
        ? "临时录音已失效，下面的校对文字仍在。检查后可以填入草稿。"
        : "这段临时录音已失效，无法继续转写。可以重新录音或直接打字。");
      return;
    }
    if (j.status === "READY" && j.text) {
      setText(j.text);
      onReviewDraft(j.text);
      setPhase("review");
      setNotice(
        "请检查转写文字，尤其是否定词。确认填入后，还需要点击“送出去”。",
      );
      return;
    }
    if (j.status === "TRANSCRIBING") {
      setPhase("transcribing");
      setNotice("转写仍在处理中，可以稍后查看结果，也可以取消并继续打字。");
      return;
    }
    throw Error("没有得到可用文字，请重试或继续打字。");
  }
  function refreshAvailability(n: number) {
    if (alive(n)) setCaps(c => ({ ...(c ?? unavailableCaps), available: false }));
    void api
      .capabilities()
      .then((c) => {
        if (alive(n)) setCaps(c);
      })
      .catch(() => { if (alive(n)) setCaps(c => ({ ...(c ?? unavailableCaps), available: false })); });
  }
  async function processTake(n: number, blob: Blob, mime: string) {
    if (!alive(n) || working.current) return;
    working.current = true;
    setNotice("");
    try {
      setPhase("uploading");
      if (!createInput.current) {
        const hash = [
          ...new Uint8Array(
            await crypto.subtle.digest("SHA-256", await blob.arrayBuffer()),
          ),
        ]
          .map((x) => x.toString(16).padStart(2, "0"))
          .join("");
        if (!alive(n)) return;
        createInput.current = {
          key: crypto.randomUUID(),
          hash,
          bytes: blob.size,
          mime,
        };
      }
      const i = createInput.current;
      if (!jobId.current) {
        creation.current = api.create(letterId, i.key, i.hash, i.bytes, i.mime);
        const j = await creation.current;
        jobId.current = j.id;
        creation.current = null;
      }
      if (!alive(n)) return;
      const status = await api.status(jobId.current!);
      if (!alive(n)) return;
      if (expiredJob(status)) { await acceptJob(n, status); return; }
      if (["CREATED", "FAILED", "UPLOADING"].includes(status.status)) {
        await api.upload(jobId.current!, blob);
        if (!alive(n)) return;
      }
      setPhase("transcribing");
      await acceptJob(n, await api.transcribe(jobId.current!));
    } catch (e) {
      if (alive(n)) {
        setPhase("failed");
        setNotice(
          (e as Error).message || "录音处理失败，你可以重试或继续打字。",
        );
        if ((e as { status?: number }).status === 503)
          setCaps(c => ({ ...(c ?? unavailableCaps), available: false }));
        else refreshAvailability(n);
      }
    } finally {
      if (alive(n)) working.current = false;
    }
  }
  async function start() {
    if (disabled || working.current || !caps?.available) return;
    rememberDraftSelection();
    const n = ++epoch.current;
    working.current = true;
    setPhase("asking");
    setNotice("");
    setSeconds(0);
    stopping.current = false;
    endMessage.current = "";
    try {
      let expired = false,
        permissionTimer: ReturnType<typeof setTimeout> | undefined;
      const permission = navigator.mediaDevices.getUserMedia({ audio: true });
      void permission
        .then((s) => {
          if (expired || !alive(n)) s.getTracks().forEach((t) => t.stop());
        })
        .catch(() => {});
      let source: MediaStream;
      try {
        source = await Promise.race([
          permission,
          new Promise<never>((_, reject) => {
            permissionTimer = setTimeout(() => {
              expired = true;
              reject(Error("MICROPHONE_TIMEOUT"));
            }, 20000);
          }),
        ]);
      } finally {
        clearTimeout(permissionTimer);
      }
      if (!alive(n)) {
        source.getTracks().forEach((t) => t.stop());
        return;
      }
      stream.current = source;
      const mime = formats.find((m) => MediaRecorder.isTypeSupported(m));
      if (!mime) throw Error("此浏览器暂不支持录音，你可以继续打字。");
      const media = new MediaRecorder(source, { mimeType: mime });
      recorder.current = media;
      const chunks: Blob[] = [];
      let size = 0,
        tooLarge = false;
      media.ondataavailable = (e) => {
        if (alive(n) && e.data.size) {
          size += e.data.size;
          if (size > caps.maxBytes) {
            tooLarge = true;
            void cancel("录音超过10MB，请缩短后再试，也可以继续打字。");
          } else chunks.push(e.data);
        }
      };
      media.onerror = () => {
        if (alive(n))
          void cancel("录音中断了，原文字草稿保留。可以重新录音或继续打字。");
      };
      source.getTracks().forEach(
        (t) =>
          (t.onended = () => {
            if (alive(n) && !stopping.current) {
              endMessage.current =
                "麦克风已中断。可以检查已录下的部分后转文字，或重新录音。";
              stopping.current = true;
              if (media.state === "recording") media.stop();
            }
          }),
      );
      media.onstop = () => {
        if (!alive(n) || tooLarge) return;
        release();
        working.current = false;
        const blob = new Blob(chunks, { type: media.mimeType });
        if (!blob.size) {
          setPhase("idle");
          setNotice("没有录到可用声音，可以重新录音或继续打字。");
          return;
        }
        take.current = blob;
        if (endMessage.current) {
          setPhase("stopped");
          setNotice(endMessage.current);
        } else void processTake(n, blob, media.mimeType.split(";")[0]);
      };
      const began = performance.now();
      media.start(1000);
      setPhase("recording");
      working.current = false;
      timer.current = setInterval(() => {
        if (!alive(n) || media.state !== "recording") return;
        const ms = performance.now() - began;
        setSeconds(Math.floor(ms / 1000));
        if (ms >= Math.min(caps.maxMs - 500, 59500)) {
          endMessage.current =
            "已到本段录音时限。可以转成文字，也可以重新录音。";
          stopping.current = true;
          media.stop();
        }
      }, 100);
    } catch (e) {
      if (!alive(n)) return;
      release();
      working.current = false;
      setPhase("idle");
      setNotice(
        (e as Error).name === "NotAllowedError"
          ? "没有获得麦克风权限，你仍可以直接打字。"
          : "录音暂不可用，原文字草稿保留，可以继续打字。",
      );
    }
  }
  async function apply() {
    if (working.current) return;
    rememberDraftSelection();
    const n = epoch.current;
    working.current = true;
    setSaving(true);
    setPhase("cleanup");
    setNotice(appliedRef.current ? "正在清理临时录音…" : "正在填入本机草稿…");
    try {
      if (!appliedRef.current) {
        await onApply(text.trim(), draft, () => alive(n));
        if (!alive(n)) return;
        appliedRef.current = true;
        setApplied(true);
        returnFocus.current = { epoch: n, selection: draftSelection.current };
      }
      setSaving(false);
      onActivity(false);
      setNotice("文字已填入本机草稿，临时录音正在清理；尚未发送。");
      if (!alive(n)) return;
      const id = jobId.current;
      // Restored local review has no audio job; its original job was cancelled
      // on leave. Explicit draft confirmation remains possible without ASR.
      const result = id ? await api.finish(id, "confirm") : null;
      if (!alive(n)) return;
      if (result?.cleanup === "pending") {
        setCleanupRetry(true);
        setNotice("文字已填入草稿，服务端临时材料的清理尚未确认。可以继续打字。");
        return;
      }
      jobId.current = null;
      take.current = null;
      createInput.current = null;
      creation.current = null;
      setText("");
      onReviewDraft("");
      setPhase("idle");
      setNotice("文字已填入本机草稿，尚未发送。");
      appliedRef.current = false;
      setApplied(false);
    } catch (e) {
      if (alive(n)) {
        if (e instanceof VoiceDraftConflict)
          setConflict({ latest: e.latestText });
        setPhase(appliedRef.current ? "cleanup" : "review");
        setCleanupRetry([0, 503, 504].includes((e as { status?: number }).status ?? 0));
        setNotice(
          appliedRef.current
            ? "文字已填入草稿，服务端临时材料的清理尚未确认。可以继续打字。"
            : `草稿未填入：${(e as Error).message}`,
        );
      }
    } finally {
      if (alive(n)) {
        working.current = false;
        setSaving(false);
      }
    }
  }
  function abortApply() {
    rememberDraftSelection();
    epoch.current++;
    returnFocus.current = {
      epoch: epoch.current,
      selection: draftSelection.current,
    };
    working.current = false;
    setSaving(false);
    setPhase("review");
    setNotice("已取消本次填入，原稿与校对文字均保留，尚未发送。");
  }
  async function reloadConflict() {
    if (working.current) return;
    const n = epoch.current;
    working.current = true;
    setSaving(true);
    try {
      await onReloadDraft(() => alive(n));
      if (!alive(n)) return;
      setConflict(null);
      setNotice("已载入最新草稿，校对文字仍保留。请重新检查后再确认追加。");
    } catch (e) {
      if (alive(n)) setNotice((e as Error).message);
    } finally {
      if (alive(n)) {
        working.current = false;
        setSaving(false);
      }
    }
  }
  function continueTyping() {
    rememberDraftSelection();
    const n = ++epoch.current;
    returnFocus.current = { epoch: n, selection: draftSelection.current };
    release(); working.current = false;
    jobId.current = null; take.current = null;
    createInput.current = null; creation.current = null;
    setText(""); onReviewDraft(""); setConflict(null); setSaving(false);
    setPhase("idle");
    setNotice(appliedRef.current ? "文字已填入本机草稿，尚未发送；服务端临时材料的清理尚未确认。" : "本次语音已停止；服务端临时材料的清理尚未确认。可以继续打字。");
    appliedRef.current = false; setApplied(false);
  }
  if (!caps) return null;
  const merged = draft.trim() ? `${draft}\n${text.trim()}` : text.trim(),
    combined = countResponseText(merged);
  const statusMessage =
    notice ||
    (
      {
        asking: "等待麦克风权限…",
        uploading: "正在上传临时录音…",
        transcribing: "正在转成文字…",
      } as Partial<Record<Phase, string>>
    )[phase] ||
    "";
  return (
    <section
      ref={panel}
      tabIndex={-1}
      className="e4-voice"
      aria-label="语音输入"
    >
      {(caps.available || phase !== "idle") && caps.privacyNotice && (
        <p className="e4-voice-help">{caps.privacyNotice}</p>
      )}
      {(caps.available || phase !== "idle") && caps.mode === "synthetic-v1" && (
        <p className="e4-voice-demo">
          录音与校对演示：使用合成转写，不识别音频。
        </p>
      )}
      {phase === "idle" && caps.available && (
        <button type="button" disabled={disabled} onClick={() => void start()}>
          用语音写几句
        </button>
      )}
      {phase === "recording" && (
        <>
          <p>录音中 · {seconds} / 60 秒</p>
          <button
            className="e4-voice-primary"
            type="button"
            onClick={() => {
              stopping.current = true;
              recorder.current?.stop();
            }}
          >
            停止并转成文字
          </button>
        </>
      )}
      {phase === "stopped" && take.current && (
        <button
          className="e4-voice-primary"
          type="button"
          onClick={() =>
            void processTake(
              epoch.current,
              take.current!,
              take.current!.type.split(";")[0],
            )
          }
        >
          转成文字
        </button>
      )}
      {phase === "transcribing" && (
        <>
          {!working.current && (
            <button
              type="button"
              onClick={() => {
                const n = epoch.current;
                working.current = true;
                void api
                  .status(jobId.current!)
                  .then((j) => acceptJob(n, j))
                  .catch((e) => {
                    if (alive(n)) {
                      setPhase("failed");
                      setNotice(e.message);
                      if ((e as { status?: number }).status === 503) setCaps(c => ({ ...(c ?? unavailableCaps), available: false }));
                      else refreshAvailability(n);
                    }
                  })
                  .finally(() => {
                    working.current = false;
                  });
              }}
            >
              查看转写结果
            </button>
          )}
        </>
      )}
      {phase === "review" && (
        <>
          <label htmlFor={`voice-review-${letterId}`}>检查并修改转写文字</label>
          <textarea
            ref={reviewInput}
            id={`voice-review-${letterId}`}
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              onReviewDraft(e.target.value);
            }}
          />
          <p>
            {countResponseText(text)} 字 · 填入后共 {combined} / 2000 字
          </p>
          <p className="e4-voice-help">
            校对文字只在本次页面内暂存，返回来信盒再进入可继续。刷新、关闭页面或退出账号后不会保留；需要保留时，请先填入草稿。
          </p>
          {draft.trim() && <p>原草稿会保留，确认后将追加这段文字。</p>}
          <button
            className="e4-voice-primary"
            type="button"
            disabled={
              disabled ||
              saving ||
              !!conflict ||
              !text.trim() ||
              !validResponseText(merged)
            }
            onClick={() => void apply()}
          >
            {draft.trim() ? "追加到原草稿" : "确认并填入草稿"}
          </button>
          {conflict && (
            <div role="alert">
              <p>另一页面已更新草稿，本次没有覆盖。原稿与校对文字均保留。</p>
              <label htmlFor={`voice-conflict-${letterId}`}>
                检测到的另一页面草稿
              </label>
              <textarea
                id={`voice-conflict-${letterId}`}
                readOnly
                value={conflict.latest}
              />
              <button
                type="button"
                disabled={saving}
                onClick={() => void reloadConflict()}
              >
                载入最新草稿，继续校对
              </button>
            </div>
          )}
          {!validResponseText(merged) && text.trim() && (
            <p role="alert">
              追加后超过2000字或组合符号过多，请先缩短。原稿和校对文字均保留。
            </p>
          )}
        </>
      )}
      {phase === "failed" && take.current && (
        <button
          className="e4-voice-primary"
          type="button"
          disabled={disabled || !caps.available}
          onClick={() =>
            void processTake(
              epoch.current,
              take.current!,
              take.current!.type.split(";")[0],
            )
          }
        >
          重试处理这段录音
        </button>
      )}
      {["stopped", "review", "failed"].includes(phase) && (
        <button
          type="button"
          disabled={disabled || !caps.available}
          onClick={() =>
            void cancel(undefined, false).then(() => {
              if (!createInput.current && !jobId.current) void start();
            })
          }
        >
          重新录音
        </button>
      )}
      {phase === "cleanup" && cleanupRetry && (
        <button
          type="button"
          disabled={working.current}
          onClick={() => void (applied ? apply() : cancel())}
        >
          重试清理临时录音
        </button>
      )}
      {phase === "cleanup" && !saving && (
        <button type="button" className="e4-voice-secondary" onClick={continueTyping}>继续打字</button>
      )}
      {phase === "cleanup" && saving && !applied && (
        <button
          className="e4-voice-secondary"
          type="button"
          onClick={abortApply}
        >
          取消本次填入
        </button>
      )}
      {!["idle", "cleanup"].includes(phase) && (
        <button
          className="e4-voice-secondary"
          type="button"
          onClick={() => void cancel()}
        >
          取消这段录音
        </button>
      )}
      {(caps.available || phase !== "idle") && <p className="e4-voice-help">
        最长60秒。转写后请先检查文字，填入草稿不会自动发送。服务端临时录音和待取回文字最多可取回24小时，也可能提前失效；确认或取消后安排清理，异常时可能延后。
      </p>}
      <p role="status" aria-live="polite" aria-atomic="true">
        {statusMessage}
      </p>
    </section>
  );
}
