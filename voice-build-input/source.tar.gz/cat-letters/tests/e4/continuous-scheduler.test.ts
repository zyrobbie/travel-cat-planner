import test,{before,after} from "node:test";
import assert from "node:assert/strict";
import {randomUUID,createHash} from "node:crypto";
import {spawn} from "node:child_process";
import {mkdir,readFile,writeFile,chmod,symlink,unlink} from "node:fs/promises";
import {join} from "node:path";
import {setTimeout as delay} from "node:timers/promises";
import pg from "pg";
import {pool,transaction} from "../../src/server/db";
import {closeLifecycleProvider} from "../../src/server/lifecycle-provider";
import {lockCloudCat} from "../../src/server/cloud-repository";
import {initializeCloudCalendar} from "../../src/server/cloud-calendar";
import {continuousPlan,assertContinuousScope,type ContinuousScope} from "../../src/server/continuous-scope";
import {preflightContinuous,runContinuousSlot,claimContinuousExport,cleanupContinuousExports} from "../../src/server/continuous-worker";
import {claimCloudJob,runClaimedCloudJob,type CloudJobClaim,CLOUD_BUDGET_PENDING} from "../../src/server/cloud-worker";
import {requestAccountExport,runClaimedAccountExport} from "../../src/server/account-export";
import {runContinuousCycle} from "../../src/server/continuous-runner";
import {cursorDirectory,readCursor} from "../../src/server/continuous-state";

const evidence:object[]=[];
const admin=new pg.Pool({connectionString:process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS});
const ledger=new pg.Pool({connectionString:process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER});
const root=process.env.E4_VALIDATION_LOCAL_DIRECTORY!;
const dir=join(root,"scheduler-state");
let a:string,b:string,c:string,d:string,outside:string,replacement:string,outsideBefore:string;
const deadline=()=>Date.now()+25_000;
const original=pg.Client.prototype.query;
function configure(delivery:string[]=[],exp:string[]=[],cleanup:string[]=[],deletion:string[]=[]) {
  process.env.E4_CONTINUOUS_ENABLED="true";
  process.env.E4_CONTINUOUS_UNTIL="2026-11-06T10:00:00Z";
  for(const [kind,ids] of [["DELIVERY",delivery],["EXPORT",exp],["CLEANUP",cleanup],["DELETION",deletion]] as const) {
    process.env[`E4_CONTINUOUS_${kind}_ENABLED`]=String(ids.length>0);
    process.env[`E4_CONTINUOUS_${kind}_ACCOUNT_IDS`]=JSON.stringify(ids);
  }
  return continuousPlan()!;
}
const scope=(kind:string,id:string)=>continuousPlan()!.slots.find(s=>s.task===kind&&s.accountId===id)!;
async function seed(due=true,email?:string) {
  const account=randomUUID(),participant=randomUUID(),cat=randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",[account,email??`${account}@internal.example.test`]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')",[participant]);
  await pool.query("INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-02','持续调度合成猫')",[cat,account,participant]);
  await transaction(async db=>initializeCloudCalendar(db,await lockCloudCat(db,account),Date.now()-(due?20*60_000:0)));
  return account;
}
async function snapshot(id:string) {
  const values=[];
  for(const [table,order] of [["accounts","id"],["cat_profiles","id"],["cloud_jobs","id"],["cloud_calendars","cat_id"],["cloud_calendar_nodes","id"],["cloud_letters","id"],["cloud_state","cat_id"],["account_exports","id"],["account_deletions","account_id"]])
    values.push((await admin.query(`SELECT * FROM ${table} WHERE ${table==="accounts"?"id":"account_id"}=$1 ORDER BY ${order}`,[id])).rows);
  return JSON.stringify(values);
}
async function cli(extra:Record<string,string>={},args:string[]=[]) {
  return new Promise<{code:number|null;output:string}>((resolve,reject)=>{
    const child=spawn(process.execPath,["--import","tsx","scripts/continuous-entry.mjs",...args],{env:{...process.env,...extra},stdio:["ignore","pipe","pipe"]});
    let output="";child.stdout.on("data",x=>output+=x);child.stderr.on("data",x=>output+=x);
    child.on("error",reject);child.on("exit",code=>resolve({code,output}));
  });
}
function ackLoss(match:RegExp) {
  let once=true;const touched=new WeakSet<object>();
  pg.Client.prototype.query=(async function(this:pg.Client,...args:any[]) {
    const sql=typeof args[0]==="string"?args[0]:args[0]?.text??"";
    if(match.test(sql))touched.add(this);
    const result=await (original as any).apply(this,args);
    if(once&&sql.trim().toUpperCase()==="COMMIT"&&touched.has(this)) {once=false;throw Error("synthetic_ack_loss_secret_must_not_be_logged");}
    return result;
  }) as any;
  return ()=>{pg.Client.prototype.query=original;assert.equal(once,false,"Fault must hit a real completed COMMIT");};
}
before(async()=>{
  for(const url of [process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS,process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER])assert.equal(new URL(url!).hostname,"127.0.0.1");
  for(const p of [admin,ledger])assert.equal((await p.query("SELECT value FROM local_validation_cluster_nonce")).rows[0].value,process.env.E4_VALIDATION_LOCAL_NONCE);
  await mkdir(dir,{mode:0o700});process.env.E4_CONTINUOUS_STATE_DIRECTORY=dir;process.env.E4_CONTINUOUS_LOCK_HELD="true";
  a=await seed();b=await seed();c=await seed();d=await seed(false);outside=await seed();replacement=await seed(true,"same-email-later@internal.example.test");
  outsideBefore=await snapshot(outside);
});
after(async()=>{
  pg.Client.prototype.query=original;
  await writeFile(join(process.env.E4_VALIDATION_EVIDENCE!,"continuous-cases.json"),JSON.stringify({tests:evidence,scope:"new isolated restricted dual PostgreSQL; reserved .test addresses only; never personal accounts",cloudExecuted:false,emailSent:false,systemdExecuted:false},null,2));
  await closeLifecycleProvider();await pool.end();await admin.end();await ledger.end();
});

test("C01 restricted dual-role preflight retains no DDL/ledger-rewrite privileges",async()=>{
  configure([a]);await preflightContinuous(deadline());
  await assert.rejects(pool.query("ALTER TABLE accounts ADD COLUMN forbidden integer"));
  evidence.push({test:"C01",status:"PASS"});
});
test("C02 disabled and malformed config/arguments fail before DB and redact sentinel secrets",async()=>{
  const secret="postgresql://privateuser:sentinel-password@never-resolve.invalid/private";
  const off=await cli({E4_CONTINUOUS_ENABLED:"false",DATABASE_URL:secret,E4_LEDGER_DATABASE_URL:secret});
  assert.equal(off.code,0);assert.match(off.output,/DISABLED/);assert.ok(!off.output.includes("sentinel")&&!off.output.includes("privateuser"));
  const rejected=await cli({E4_CONTINUOUS_ENABLED:"false"},[outside]);assert.equal(rejected.code,1);assert.match(rejected.output,/REJECTED_CONFIGURATION/);assert.ok(!rejected.output.includes(outside));
  for(const value of ['[]','["*"]',JSON.stringify([a,a]),JSON.stringify(["not-a-uuid"])]) {
    configure([a]);process.env.E4_CONTINUOUS_DELIVERY_ACCOUNT_IDS=value;assert.throws(continuousPlan);
  }
  configure([a]);process.env.E4_CONTINUOUS_DELIVERY_ACCOUNT_IDS=JSON.stringify(Array.from({length:11},()=>randomUUID()));assert.throws(continuousPlan);
  configure([a]);evidence.push({test:"C02",status:"PASS",disabledDatabaseAccess:false});
});
test("C03 forged/expanded/revoked capabilities rejected; old synthetic-only path stays closed",async()=>{
  configure([a]);const real=scope("delivery",a);
  assert.throws(()=>assertContinuousScope({...real},"delivery"));
  assert.throws(()=>assertContinuousScope(real,"delivery",outside));
  await assert.rejects(claimCloudJob(deadline(),{accountId:a,allowBudgetRecovery:true}));
  configure([b]);assert.throws(()=>assertContinuousScope(real,"delivery"));
  evidence.push({test:"C03",status:"PASS"});
});
test("C04 exact real-domain-like internal UUID delivers once; outside and replacement UUID unchanged",async()=>{
  const replacementBefore=await snapshot(replacement);configure([a]);
  assert.equal((await runContinuousSlot(scope("delivery",a),deadline())).status,"SETTLED");
  assert.equal((await runContinuousSlot(scope("delivery",a),deadline())).status,"IDLE");
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",[a])).rows[0].n,1);
  assert.equal(await snapshot(outside),outsideBefore);assert.equal(await snapshot(replacement),replacementBefore);
  evidence.push({test:"C04",status:"PASS",outsideUnchanged:true,otherNewUUIDUnchanged:true});
});
test("C05 concurrent fixed-scope claims own one durable lease and settle once",async()=>{
  configure([b]);const s=scope("delivery",b);const cs={accountId:b,allowBudgetRecovery:true as const,continuous:s};
  const claimed=await Promise.all([claimCloudJob(deadline(),cs),claimCloudJob(deadline(),cs)]);
  assert.equal(claimed.filter(Boolean).length,1);assert.equal((await runClaimedCloudJob(claimed.find(Boolean)!,deadline(),cs)).status,"SETTLED");
  evidence.push({test:"C05",status:"PASS"});
});
test("C06 claim COMMIT ACK loss; natural 60s expiry, fresh-process restart, old token rejected",{timeout:100_000},async()=>{
  configure([c]);const s=scope("delivery",c);const restore=ackLoss(/UPDATE cloud_jobs j SET status='LEASED'/);
  try {await assert.rejects(runContinuousSlot(s,deadline()));}finally{restore();}
  const row=(await admin.query("SELECT * FROM cloud_jobs WHERE account_id=$1",[c])).rows[0];
  assert.equal(row.status,"LEASED");assert.equal(row.last_error,CLOUD_BUDGET_PENDING);assert.equal(row.attempts,1);
  const old:CloudJobClaim={jobId:row.id,accountId:c,catId:row.cat_id,leaseToken:row.lease_token,leaseUntil:row.lease_until.toISOString(),attempts:row.attempts};
  const start=Date.now();await delay(Math.max(1,row.lease_until.getTime()-Date.now()+100));
  const fresh=await cli();assert.equal(fresh.code,0,fresh.output);assert.match(fresh.output,/SETTLED/);assert.ok(!fresh.output.includes(c)&&!fresh.output.includes(row.lease_token));
  assert.equal((await runClaimedCloudJob(old,deadline(),{accountId:c,allowBudgetRecovery:true,continuous:s})).status,"STALE");
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",[c])).rows[0].n,1);
  evidence.push({test:"C06",status:"PASS",actualLeaseExpiryWaitMs:Date.now()-start,clockOrLeaseEdited:false,freshProcess:true});
});
test("C07 export switch separate; scoped concurrent claims publish only an already-requested export",async()=>{
  const requested=await requestAccountExport(d,randomUUID());const excluded=await requestAccountExport(outside,randomUUID());
  outsideBefore=await snapshot(outside);
  configure([a]);assert.equal(continuousPlan()!.slots.filter(s=>s.task==="export").length,0);
  configure([], [d]);const s=scope("export",d);
  const claims=await Promise.all([claimContinuousExport(s,deadline()),claimContinuousExport(s,deadline())]);assert.equal(claims.filter(Boolean).length,1);
  assert.equal((await runClaimedAccountExport(claims.find(Boolean)!,deadline())).status,"READY");
  const job=(await admin.query("SELECT status,expires_at FROM account_exports WHERE id=$1",[requested.job.id])).rows[0];assert.equal(job.status,"READY");assert.ok(job.expires_at.getTime()>Date.now()+23*3600_000);
  assert.equal((await admin.query("SELECT status FROM account_exports WHERE id=$1",[excluded.job.id])).rows[0].status,"QUEUED");assert.equal(await snapshot(outside),outsideBefore);
  evidence.push({test:"C07",status:"PASS",outsideUnchanged:true});
});
test("C08 export publication committed but ACK lost; READY/chunks survive and next slot does not duplicate",async()=>{
  const req=await requestAccountExport(d,randomUUID());configure([],[d]);const s=scope("export",d);
  const restore=ackLoss(/UPDATE account_exports SET status=\$4/);
  try {await assert.rejects(runContinuousSlot(s,deadline()));}finally{restore();}
  const before=(await admin.query("SELECT status,artifact_name FROM account_exports WHERE id=$1",[req.job.id])).rows[0];assert.equal(before.status,"READY");
  const n=(await admin.query("SELECT count(*)::int AS n FROM private_export_chunks WHERE export_id=$1",[req.job.id])).rows[0].n;assert.ok(n>0);
  assert.equal((await runContinuousSlot(s,deadline())).status,"IDLE");
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM private_export_chunks WHERE export_id=$1",[req.job.id])).rows[0].n,n);
  evidence.push({test:"C08",status:"PASS",durablePublishAckLost:true});
});
test("C09 cleanup independent, UUID/100-row bounded, live build kept and global buckets untouched",async()=>{
  configure([],[],[d]);
  await admin.query("UPDATE account_exports SET expires_at=clock_timestamp()-interval '1 second' WHERE account_id=$1 AND status='READY'",[d]);
  const req=await requestAccountExport(d,randomUUID());configure([],[d],[d]);const claim=await claimContinuousExport(scope("export",d),deadline());assert.equal(claim!.id,req.job.id);
  const rateKey=`synthetic-continuous-${randomUUID()}`;await admin.query("INSERT INTO account_rate_limits(key,attempts,window_at) VALUES($1,1,clock_timestamp()-interval '2 days')",[rateKey]);
  const outcome=await cleanupContinuousExports(scope("cleanup",d),deadline());assert.ok(outcome.selected<=100);assert.equal(outcome.rateLimits,0);
  assert.equal((await admin.query("SELECT status FROM account_exports WHERE id=$1",[req.job.id])).rows[0].status,"BUILDING");
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM account_rate_limits WHERE key=$1",[rateKey])).rows[0].n,1);assert.equal(await snapshot(outside),outsideBefore);
  evidence.push({test:"C09",status:"PASS",outsideUnchanged:true,globalBucketsKept:true});
});
test("C10 closed recovery gate blocks scheduler without altering scoped business state",async()=>{
  configure([a]);const before=await snapshot(a);await ledger.query("UPDATE restore_gate SET status='CLOSED'");
  try {await assert.rejects(runContinuousSlot(scope("delivery",a),deadline()));}finally{await ledger.query("UPDATE restore_gate SET status='READY'");}
  assert.equal(await snapshot(a),before);evidence.push({test:"C10",status:"PASS"});
});
test("C11 cursor advances before failure; restart rotates fairly and secrets do not appear in output",async()=>{
  const plan=configure([a,b],[],[d]);const privateDir=join(root,"cursor-fault");await mkdir(privateDir,{mode:0o700});
  const first=await runContinuousCycle(plan,privateDir,deadline(),async()=>{throw Error(`secret-${a}`);});
  assert.equal(first.failed,true);assert.ok(!JSON.stringify(first).includes(a));
  const saved=await readCursor(privateDir,plan.digest,plan.slots.length);assert.equal(saved.next,1);
  const order:string[]=[];await runContinuousCycle(plan,privateDir,deadline(),async s=>{order.push(s.accountId);return{status:"IDLE"};});assert.equal(order[0],plan.slots[1].accountId);
  const before=await readFile(join(privateDir,"cursor.json"),"utf8");const noBudget=await runContinuousCycle(plan,privateDir,Date.now()+6000,async()=>{throw Error("must not call");});assert.equal(noBudget.status,"BUDGET_EXHAUSTED");assert.equal(await readFile(join(privateDir,"cursor.json"),"utf8"),before);
  evidence.push({test:"C11",status:"PASS",beforeWorkCursorDurable:true});
});
test("C12 unsafe/corrupted cursor fails closed; capability cannot move to another task",async()=>{
  const plan=configure([a]);await writeFile(join(dir,"cursor.json"),"broken",{mode:0o600});await assert.rejects(readCursor(dir,plan.digest,1));
  await unlink(join(dir,"cursor.json"));await symlink(join(root,"no-target"),join(dir,"cursor.json"));await assert.rejects(readCursor(dir,plan.digest,1));await unlink(join(dir,"cursor.json"));
  await chmod(dir,0o755);await assert.rejects(cursorDirectory());await chmod(dir,0o700);
  const s=scope("delivery",a);assert.throws(()=>assertContinuousScope(s,"cleanup"));
  evidence.push({test:"C12",status:"PASS"});
});
test("C13 production CLI restart writes only counts/status; service config keeps explicit hard limits",async()=>{
  configure([a]);const first=await cli();assert.equal(first.code,0,first.output);assert.ok(!first.output.includes(a));const second=await cli();assert.equal(second.code,0,second.output);
  const service=await readFile("deploy/continuous-scheduler/cat-letters-background.service","utf8");assert.match(service,/Type=oneshot/);assert.match(service,/TimeoutStartSec=35s/);assert.match(service,/TimeoutStopSec=5s/);assert.match(service,/ProtectSystem=strict/);
  const timer=await readFile("deploy/continuous-scheduler/cat-letters-background.timer","utf8");assert.match(timer,/OnUnitInactiveSec=5s/);
  const wrapper=await readFile("deploy/continuous-scheduler/run.sh","utf8");assert.match(wrapper,/flock --nonblock --conflict-exit-code 75/);
  evidence.push({test:"C13",status:"PASS",actualSystemdRuntime:false,linuxCoordinatorGateRequired:true});
});
test("C14 recreated account with the same email receives no authority from the old configured UUID",async()=>{
  const email=(await admin.query("SELECT email_normalized FROM accounts WHERE id=$1",[a])).rows[0].email_normalized;
  // Local scope fixture only: retire a synthetic row, then register another UUID.
  // This does not stand in for full lifecycle deletion acceptance.
  await admin.query("UPDATE accounts SET status='DELETED',deleted_at=clock_timestamp(),email_normalized=$2 WHERE id=$1",[a,`deleted+${a}@invalid.invalid`]);
  const newer=await seed(true,email);const before=await snapshot(newer);configure([a]);
  assert.equal((await runContinuousSlot(scope("delivery",a),deadline())).status,"IDLE");
  assert.equal(await snapshot(newer),before);
  evidence.push({test:"C14",status:"PASS",sameEmailNewUUIDUnchanged:true,localRetiredAccountFixtureOnly:true});
});
test("C15 short remaining budget refuses a claim without any SQL or changed durable state",async()=>{
  configure([b]);const s=scope("delivery",b);const before=await snapshot(b);let calls=0;
  pg.Client.prototype.query=(function(this:pg.Client,...args:any[]){calls++;return(original as any).apply(this,args);}) as any;
  try {await assert.rejects(runContinuousSlot(s,Date.now()+6000));}finally{pg.Client.prototype.query=original;}
  assert.equal(calls,0);assert.equal(await snapshot(b),before);evidence.push({test:"C15",status:"PASS",databaseCalls:0});
});
test("C16 more than 100 expired exports drain across bounded scoped calls",async()=>{
  configure([],[],[d]);
  for(let i=0;i<105;i++) {
    const id=randomUUID();
    await admin.query(`INSERT INTO account_exports(id,account_id,request_key,status,expires_at,artifact_name,artifact_hash,artifact_bytes)
      VALUES($1,$2,$3,'READY',clock_timestamp()-interval '1 second',$4,$5,1)`,[id,d,randomUUID(),`${id}.${randomUUID()}.json`,"f".repeat(64)]);
  }
  const first=await cleanupContinuousExports(scope("cleanup",d),deadline());assert.equal(first.expired,100);assert.equal(first.selected,100);
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM account_exports WHERE account_id=$1 AND status='READY'",[d])).rows[0].n,5);
  const second=await cleanupContinuousExports(scope("cleanup",d),deadline());assert.equal(second.expired,5);assert.ok(second.selected<=100);assert.equal(await snapshot(outside),outsideBefore);
  evidence.push({test:"C16",status:"PASS",expiredAcrossTwoCalls:[first.expired,second.expired],outsideUnchanged:true});
});
test("C17 accidentally privileged runtime roles fail the real database preflight",async()=>{
  configure([b]);
  await admin.query("ALTER ROLE cat_letters_app SUPERUSER");
  try {await assert.rejects(preflightContinuous(deadline()));}finally{await admin.query("ALTER ROLE cat_letters_app NOSUPERUSER");}
  await ledger.query("ALTER ROLE cat_letters_ledger BYPASSRLS");
  try {await assert.rejects(preflightContinuous(deadline()));}finally{await ledger.query("ALTER ROLE cat_letters_ledger NOBYPASSRLS");}
  await preflightContinuous(deadline());evidence.push({test:"C17",status:"PASS",localDisposableRoleFaultOnly:true});
});
test("C18 near-32MiB product export and real preflight fit 25s with 300ms/query",{timeout:40_000},async()=>{
  const large=await seed(false);const cat=(await admin.query("SELECT id FROM cat_profiles WHERE account_id=$1",[large])).rows[0].id;
  await admin.query(`INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,origin)
    VALUES($1,$2,$3,'DEMAND',jsonb_build_object('title','大导出本地压力夹具','body',repeat('x',$4::int),'catName','合成猫'),'LEGACY')`,
    [randomUUID(),cat,large,32*1024*1024-100_000]);
  const req=await requestAccountExport(large,randomUUID());configure([],[large]);const s=scope("export",large);
  let calls=0;pg.Client.prototype.query=(async function(this:pg.Client,...args:any[]){calls++;await delay(300);return(original as any).apply(this,args);}) as any;
  const start=Date.now();const end=start+25_000;let outcome:{status:string};
  try {await preflightContinuous(end);outcome=await runContinuousSlot(s,end);}finally{pg.Client.prototype.query=original;}
  assert.equal(outcome!.status,"READY");
  const readyElapsedMs=Date.now()-start;
  const row=(await admin.query("SELECT status,artifact_bytes,artifact_hash,artifact_name FROM account_exports WHERE id=$1",[req.job.id])).rows[0];
  assert.equal(row.status,"READY");assert.ok(Number(row.artifact_bytes)>31*1024*1024&&Number(row.artifact_bytes)<=32*1024*1024);assert.ok(Date.now()-start<25_000);
  const parts=(await admin.query("SELECT body FROM private_export_chunks WHERE export_id=$1 AND artifact_name=$2 ORDER BY chunk_index",[req.job.id,row.artifact_name])).rows;
  const bytes=Buffer.concat(parts.map(p=>p.body));assert.equal(bytes.length,Number(row.artifact_bytes));assert.equal(createHash("sha256").update(bytes).digest("hex"),row.artifact_hash);
  const data=JSON.parse(bytes.toString());assert.equal(data.format,"cat-letters-account-export");assert.equal(data.version,1);assert.equal(data.account.id,large);assert.match(data.account.createdAt,/Z$/);assert.equal(data.letters[0].snapshot.body.length,32*1024*1024-100_000);assert.ok(!("sessions" in data));
  evidence.push({test:"C18",status:"PASS",bytes:Number(row.artifact_bytes),elapsedMs:readyElapsedMs,queryCount:calls,injectedDelayPerQueryMs:300,coldTLSCovered:false,allChunksHashVerified:true,formatVersionUnchanged:true});
});
test("C19 asynchronous connection errors are handled without exposing the raw sentinel",async()=>{
  configure([b]);const connect=pg.Client.prototype.connect;let hit=false;
  pg.Client.prototype.connect=(function(this:pg.Client,...args:any[]){
    return (connect as any).apply(this,args).then((r:unknown)=>{
      if((this as any).user==="cat_letters_ledger")queueMicrotask(()=>{hit=true;this.emit("error",Error("PRIVATE_CONNECTION_SENTINEL"));});return r;
    });
  }) as any;
  try {await assert.rejects(preflightContinuous(deadline()),(e:unknown)=>!String(e).includes("PRIVATE_CONNECTION_SENTINEL"));}
  finally {pg.Client.prototype.connect=connect;}
  assert.equal(hit,true);await preflightContinuous(deadline());evidence.push({test:"C19",status:"PASS",asyncErrorHandled:true,rawSentinelExposed:false});
});
