import test, { before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { randomUUID, createHash, randomBytes } from "node:crypto";
import { mkdtemp, writeFile, readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import pg from "pg";
import { NextRequest } from "next/server";
import { GET, POST } from "../../src/app/api/e4/voice/[...path]/route";
import { pool, transaction } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { digest } from "../../src/server/auth";
import { logoutAccount } from "../../src/server/account-auth";
import {
  createVoice,
  readVoice,
  finishVoice,
  claimVoiceUpload,
  storeVoiceUpload,
  transcribeVoice,
  cleanupPrivateVoice,
  availableVoice,
  type VoiceIdentity,
} from "../../src/server/voice-service";
import {
  inspectVoiceAudio,
  normalizeVoiceAudio,
  cleanupVoiceFiles,
} from "../../src/server/voice-probe";
import { voiceCapabilities } from "../../src/server/voice-config";
import { configuredVoicePayloadStore, type PayloadRef } from "../../src/server/voice-payload-store";
import { configuredVoiceProvider } from "../../src/server/voice-provider";
import { verifyTencentDeploymentEvidence } from "../../src/server/tencent-voice-readiness";
import { lockCloudCat } from "../../src/server/cloud-repository";
import { initializeCloudCalendar } from "../../src/server/cloud-calendar";
import { voiceHttp } from "./voice-http";
import { chromium, expect, type Page } from "@playwright/test";
import { syntheticMicrophone } from "./voice-browser";
import {
  countResponseText,
  validResponseText,
  validDraftText,
} from "../../src/shared/response-text";
import { POST as v1Post } from "../../src/app/api/e4/v1/[...path]/route";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const admin = new pg.Pool({
  connectionString: process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS,
});
const ledger = new pg.Pool({
  connectionString: process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER,
});
const evidence: object[] = [];
type User = {
  account: string;
  cat: string;
  letter: string;
  token: string;
  identity: VoiceIdentity;
};
let a: User, b: User;
const wav = (seconds = 1, rate = 16000, channels = 1) => {
  const size = Math.round(seconds * rate) * channels * 2,
    b = Buffer.alloc(44 + size);
  b.write("RIFF");
  b.writeUInt32LE(size + 36, 4);
  b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(channels, 22);
  b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(rate * channels * 2, 28);
  b.writeUInt16LE(channels * 2, 32);
  b.writeUInt16LE(16, 34);
  b.write("data", 36);
  b.writeUInt32LE(size, 40);
  return b;
};
async function seed(): Promise<User> {
  const account = randomUUID(),
    participant = randomUUID(),
    cat = randomUUID(),
    letter = `voice-${randomUUID()}`,
    token = randomBytes(32).toString("hex");
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    account,
    `${account}@voice.example.test`,
  ]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [
    participant,
  ]);
  await pool.query(
    "INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-02','语音合成测试猫')",
    [cat, account, participant],
  );
  await pool.query(
    "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '1 hour')",
    [digest(token), account],
  );
  await transaction(async (db) =>
    initializeCloudCalendar(db, await lockCloudCat(db, account), Date.now()),
  );
  await pool.query(
    "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,read_at) VALUES($1,$2,$3,'DEMAND',$4,now())",
    [
      letter,
      cat,
      account,
      {
        title: "语音本地验证来信",
        body: "你可以写下此刻想说的话。",
        catName: "语音合成测试猫",
      },
    ],
  );
  return { account, cat, letter, token, identity: { token, account } };
}
const input = (user: User, audio = wav(), mime = "audio/wav") => ({
  letterId: user.letter,
  key: randomUUID(),
  hash: createHash("sha256").update(audio).digest("hex"),
  bytes: audio.length,
  mime: mime as "audio/wav",
});
async function uploaded(user = a, audio = wav()) {
  const j = await createVoice(user.identity, input(user, audio));
  const c = await claimVoiceUpload(user.identity, j.id);
  await storeVoiceUpload(user.identity, j.id, c.lease, audio);
  return j;
}
async function browserReply(page: Page, url: string) {
  await page.goto(url + "/local-review", { waitUntil: "networkidle" });
  await page
    .getByRole("button", { name: /来信盒/ })
    .first()
    .click();
  await page.getByRole("button", { name: /语音本地验证来信/ }).click();
  const draft = page.locator("#response");
  const open = page.getByRole("button", { name: "给它回信", exact: true });
  await expect(draft.or(open).first()).toBeVisible();
  if (!(await draft.isVisible())) await open.click();
  await expect(draft).toBeVisible();
  return draft;
}
async function browserDraft(page: Page, text: string) {
  await page.locator("#response").fill(text);
  await expect(
    page.getByText("草稿已保存在本机，尚未发送。", { exact: true }),
  ).toBeVisible();
}
async function browserVoiceReview(page: Page) {
  await page.getByRole("button", { name: "用语音写几句", exact: true }).click();
  const stop = page.getByRole("button", {
    name: "停止并转成文字",
    exact: true,
  });
  await stop.waitFor();
  await delay(500);
  await stop.click();
  const review = page.getByLabel("检查并修改转写文字", { exact: true });
  await review.waitFor();
  await review.fill("我并没有答应。");
  return review;
}
async function browserStoredDraft(page: Page, user: User) {
  return page.evaluate(
    (key) => JSON.parse(localStorage.getItem(key) || "null"),
    `cat-letters:account-draft:v1:${user.account}:${user.cat}:${encodeURIComponent(user.letter)}:reply`,
  );
}
async function payloadRef(id: string, kind: "audio" | "text" = "audio"): Promise<PayloadRef | null> {
  const row = (await admin.query("SELECT * FROM private_voice_jobs WHERE id=$1", [id])).rows[0];
  const version = row?.[`${kind}_version`];
  if (!version || !row.payload_epoch) return null;
  return { jobId: id, kind, version, epoch: row.payload_epoch, bytes: Number(row[`${kind}_bytes`]) };
}
// Count the current metadata-bound payload. Physical remnants are tested separately:
// a SQL trigger cannot unlink filesystem objects and must first revoke readability.
const bytes = async (id: string) => {
  const ref = await payloadRef(id);
  return ref ? (await (await configuredVoicePayloadStore()).read(ref)).length : 0;
};
async function physicalEntries(id: string) {
  return (await (await configuredVoicePayloadStore()).list()).filter(entry => entry.ref?.jobId === id);
}
const mark = (id: string, extra: object = {}) =>
  evidence.push({ id, status: "PASS", ...extra });
async function route(
  user: User,
  path: string,
  body?: unknown,
  headers: Record<string, string> = {},
) {
  const r = new NextRequest(`${process.env.APP_ORIGIN}/api/e4/voice/${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      cookie: `cat_account_session=${user.token}`,
      "x-catletters-account": user.account,
      origin: process.env.APP_ORIGIN!,
      ...(body === undefined ? {} : { "content-type": "application/json" }),
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return (body === undefined ? GET : POST)(r);
}
before(async () => {
  for (const [p, url] of [
    [admin, process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS],
    [ledger, process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER],
  ] as const) {
    assert.equal(new URL(url!).hostname, "127.0.0.1");
    assert.equal(
      (await p.query("SELECT value FROM local_validation_cluster_nonce"))
        .rows[0].value,
      process.env.E4_VALIDATION_LOCAL_NONCE,
    );
  }
  a = await seed();
  b = await seed();
});
beforeEach(async () => {
  for (const key of Object.keys(process.env))
    if (key.startsWith("E4_VOICE_TENCENT_")) delete process.env[key];
  await admin.query("DELETE FROM private_voice_jobs");
  // Fresh synthetic fixture, matching the former SQL-table cascade reset. This
  // is not the production cleanup mechanism exercised by V12/V44.
  const fixtureStore = await configuredVoicePayloadStore();
  for (const entry of await fixtureStore.list()) await fixtureStore.removeEntry(entry, 0);
  // Synthetic runner has no operational timer; each case begins from a healthy
  // cleanup receipt and restores quota altered by isolated capacity cases.
  await admin.query("UPDATE private_voice_budget SET cleanup_failures=0,last_cleanup_at=clock_timestamp(),last_cleanup_error=NULL,max_bytes=67108864,cleanup_epoch=$1 WHERE singleton", [fixtureStore.epoch]);
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([a.account, b.account]);
  process.env.E4_VOICE_ENABLED = "true";
  process.env.E4_VOICE_MODE = "synthetic-v1";
});
after(async () => {
  await writeFile(
    join(process.env.E4_VALIDATION_EVIDENCE!, "voice-cases.json"),
    JSON.stringify(
      {
        cases: evidence,
        realLocalDualPostgres: true,
        restrictedRoles: true,
        realMediaParser: true,
        provider: "synthetic-v1",
        realAsrTested: false,
        cloudExecuted: false,
      },
      null,
      2,
    ),
  );
  await pool.end();
  await closeLifecycleProvider();
  await admin.end();
  await ledger.end();
});

test("V01 default off and missing provider/tools fail closed; role cannot DDL or change quota", async () => {
  assert.equal((await voiceCapabilities(a.account)).available, true);
  process.env.E4_VOICE_ENABLED = "false";
  assert.equal((await voiceCapabilities(a.account)).available, false);
  process.env.E4_VOICE_ENABLED = "true";
  process.env.E4_VOICE_MODE = "unknown-provider";
  assert.equal((await voiceCapabilities(a.account)).available, false);
  assert.throws(configuredVoiceProvider);
  process.env.E4_VOICE_MODE = "synthetic-v1";
  const old = process.env.E4_VOICE_FFMPEG;
  process.env.E4_VOICE_FFMPEG = "/missing-voice-binary";
  assert.equal((await voiceCapabilities(a.account)).available, false);
  process.env.E4_VOICE_FFMPEG = old;
  await assert.rejects(
    pool.query("ALTER TABLE private_voice_jobs ADD COLUMN forbidden text"),
  );
  await assert.rejects(
    pool.query("UPDATE private_voice_budget SET singleton=true"),
  );
  mark("V01");
});
test("V02 strict account/session/letter ownership and Origin on real Next route", async () => {
  const j = await createVoice(a.identity, input(a));
  await assert.rejects(readVoice(b.identity, j.id), /没有找到/);
  await assert.rejects(
    createVoice(a.identity, { ...input(a), letterId: b.letter }),
    /不能使用/,
  );
  assert.equal(
    (await route(a, "jobs", input(a), { origin: "https://other.example.test" }))
      .status,
    403,
  );
  assert.equal(
    (
      await route(a, "capabilities", undefined, {
        "x-catletters-account": b.account,
      })
    ).status,
    401,
  );
  assert.equal(
    (await route(a, "capabilities", undefined, { cookie: "" })).status,
    401,
  );
  const next = randomBytes(32).toString("hex");
  await pool.query(
    "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '1 hour')",
    [digest(next), a.account],
  );
  await assert.rejects(
    readVoice({ ...a.identity, token: next }, j.id),
    /没有找到/,
  );
  mark("V02");
});
test("V03 duplicate create is idempotent, mismatched content rejected, bounded schemas", async () => {
  const v = input(a),
    j = await createVoice(a.identity, v);
  assert.equal((await createVoice(a.identity, v)).id, j.id);
  await assert.rejects(
    createVoice(a.identity, { ...v, hash: "b".repeat(64) }),
    /不一致/,
  );
  assert.equal(
    (await route(a, "jobs", { ...input(a), bytes: 10 * 1024 * 1024 + 1 }))
      .status,
    400,
  );
  assert.equal(
    (
      await route(a, "jobs", {
        ...input(a),
        text: "do not accept transcript here",
      })
    ).status,
    400,
  );
  assert.equal(
    (await admin.query("SELECT count(*)::int AS n FROM private_voice_jobs"))
      .rows[0].n,
    1,
  );
  mark("V03");
});
test("V04 actual 60s large input converts to PCM WAV below base64 3MB", async () => {
  const audio = wav(60, 24000, 2);
  assert.ok(audio.length > 3_000_000 && audio.length < 10 * 1024 * 1024);
  assert.equal(await inspectVoiceAudio(audio, "audio/wav"), 60000);
  const result = await normalizeVoiceAudio(audio, "audio/wav");
  assert.equal(result.readUInt32LE(24), 16000);
  assert.equal(result.readUInt16LE(22), 1);
  assert.equal(result.readUInt16LE(34), 16);
  assert.equal(result.length, 1_920_044);
  assert.ok(result.toString("base64").length < 3_000_000);
  assert.equal(await inspectVoiceAudio(result, "audio/wav"), 60000);
  assert.deepEqual(await readdir(process.env.E4_VOICE_PROBE_DIRECTORY!), []);
  mark("V04", {
    inputBytes: audio.length,
    outputBytes: result.length,
    base64Bytes: result.toString("base64").length,
  });
});
test("V05 rejects disguised, corrupt, oversized and 61s audio", async () => {
  await assert.rejects(inspectVoiceAudio(wav(), "audio/webm"), /格式不正确/);
  await assert.rejects(
    inspectVoiceAudio(Buffer.from("not-audio"), "audio/wav"),
  );
  await assert.rejects(
    inspectVoiceAudio(Buffer.alloc(10 * 1024 * 1024 + 1), "audio/wav"),
  );
  await assert.rejects(inspectVoiceAudio(wav(61), "audio/wav"), /超过60秒/);
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(
    inspectVoiceAudio(wav(), "audio/wav", controller.signal),
  );
  assert.deepEqual(await readdir(process.env.E4_VOICE_PROBE_DIRECTORY!), []);
  mark("V05");
});
test("V06 upload claim duplicate/cancel/late publish never recreates payload", async () => {
  const j = await createVoice(a.identity, input(a));
  const claims = await Promise.allSettled([
    claimVoiceUpload(a.identity, j.id),
    claimVoiceUpload(a.identity, j.id),
  ]);
  assert.equal(claims.filter((c) => c.status === "fulfilled").length, 1);
  const c = claims.find(
    (c) => c.status === "fulfilled",
  ) as PromiseFulfilledResult<Awaited<ReturnType<typeof claimVoiceUpload>>>;
  await finishVoice(a.identity, j.id, "cancel");
  await assert.rejects(
    storeVoiceUpload(a.identity, j.id, c.value.lease, wav()),
    /取消或失效/,
  );
  assert.equal(await bytes(j.id), 0);
  mark("V06");
});
test("V07 provider duplicate lease, cached result, and cancel during actual outstanding call", async () => {
  let resolve!: (x: { text: string }) => void,
    calls = 0;
  const j = await uploaded();
  const provider = {
    mode: "synthetic-v1",
    transcribe: async () => {
      calls++;
      return new Promise<{ text: string }>((r) => (resolve = r));
    },
  };
  const first = transcribeVoice(a.identity, j.id, provider);
  for (let n = 0; n < 100 && !resolve; n++) await delay(10);
  assert.equal(calls, 1);
  assert.equal(
    (await transcribeVoice(a.identity, j.id, provider)).status,
    "TRANSCRIBING",
  );
  await finishVoice(a.identity, j.id, "cancel");
  resolve({ text: "这个晚到结果不可发布" });
  await assert.rejects(first, /取消或失效/);
  assert.equal((await readVoice(a.identity, j.id)).status, "CANCELLED");
  assert.equal(await bytes(j.id), 0);
  mark("V07");
});
test("V08 transcription stays separate; confirm/cancel clear audio and text idempotently", async () => {
  const j = await uploaded();
  const ready = await transcribeVoice(a.identity, j.id);
  assert.equal(ready.status, "READY");
  assert.match(ready.text!, /合成转写/);
  assert.equal((await transcribeVoice(a.identity, j.id)).text, ready.text);
  assert.equal(
    (
      await admin.query(
        "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
        [a.account],
      )
    ).rows[0].n,
    0,
  );
  assert.equal(
    (
      await admin.query(
        "SELECT count(*)::int AS n FROM cloud_letter_sources WHERE account_id=$1",
        [a.account],
      )
    ).rows[0].n,
    0,
  );
  assert.equal(
    (await finishVoice(a.identity, j.id, "confirm")).status,
    "CONFIRMED",
  );
  assert.equal(await bytes(j.id), 0);
  assert.equal(
    (await finishVoice(a.identity, j.id, "confirm")).status,
    "CONFIRMED",
  );
  assert.equal(
    (await finishVoice(a.identity, j.id, "cancel")).status,
    "CONFIRMED",
  );
  assert.equal((await readVoice(a.identity, j.id)).text, undefined);
  mark("V08");
});
test("V09 provider failure, timeout signal, lease recovery and max attempts", async () => {
  const j = await uploaded();
  const failing = {
    mode: "synthetic-v1",
    transcribe: async () => {
      throw Error("provider-secret-sentinel");
    },
  };
  await assert.rejects(
    transcribeVoice(a.identity, j.id, failing),
    (e) => !(e as Error).message.includes("sentinel"),
  );
  assert.equal((await readVoice(a.identity, j.id)).status, "FAILED");
  const cancelled = new AbortController();
  cancelled.abort();
  await assert.rejects(
    transcribeVoice(a.identity, j.id, undefined, cancelled.signal),
  );
  const ready = await transcribeVoice(a.identity, j.id);
  assert.equal(ready.status, "READY");
  const second = await uploaded(b);
  await admin.query(
    "UPDATE private_voice_jobs SET attempts=3,status='FAILED',last_error='TRANSCRIPTION_FAILED' WHERE id=$1",
    [second.id],
  );
  await assert.rejects(transcribeVoice(b.identity, second.id));
  mark("V09");
});
test("V10 actual logout revocation trigger purges; session delete cascades", async () => {
  const u = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
  const j = await uploaded(u);
  assert.ok((await bytes(j.id)) > 0);
  await logoutAccount(u.token);
  assert.equal(await bytes(j.id), 0);
  await assert.rejects(readVoice(u.identity, j.id));
  const row = (
    await admin.query("SELECT status FROM private_voice_jobs WHERE id=$1", [
      j.id,
    ])
  ).rows[0];
  assert.equal(row.status, "CANCELLED");
  await pool.query("DELETE FROM account_sessions WHERE token_hash=$1", [
    digest(u.token),
  ]);
  assert.equal(
    (
      await admin.query(
        "SELECT count(*)::int AS n FROM private_voice_jobs WHERE id=$1",
        [j.id],
      )
    ).rows[0].n,
    0,
  );
  mark("V10");
});
test("V11 account deletion freeze clears immediately, new same-email UUID untouched", async () => {
  const u = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
  const j = await uploaded(u);
  await admin.query("UPDATE accounts SET status='DELETING' WHERE id=$1", [
    u.account,
  ]);
  assert.equal(await bytes(j.id), 0);
  await assert.rejects(readVoice(u.identity, j.id));
  await admin.query(
    "UPDATE accounts SET status='DELETED',deleted_at=now() WHERE id=$1",
    [u.account],
  );
  const replacement = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    replacement,
    `${u.account}@voice.example.test`,
  ]);
  await cleanupPrivateVoice([u.account]);
  assert.equal((await physicalEntries(j.id)).length, 0);
  assert.equal(
    (
      await admin.query("SELECT status FROM accounts WHERE id=$1", [
        replacement,
      ])
    ).rows[0].status,
    "ACTIVE",
  );
  mark("V11");
});
test("V12 actual TTL/session expiry cleanup scope and private crash remnants", async () => {
  const j = await uploaded(a),
    outside = await uploaded(b);
  await admin.query(
    "UPDATE private_voice_jobs SET expires_at=now()-interval '1 second' WHERE id=ANY($1::uuid[])",
    [[j.id, outside.id]],
  );
  assert.equal((await cleanupPrivateVoice([a.account])).cleaned, 1);
  assert.equal(await bytes(j.id), 0);
  assert.ok((await bytes(outside.id)) > 0);
  assert.equal((await readVoice(b.identity, outside.id)).status, "EXPIRED");
  assert.equal(await bytes(outside.id), 0);
  const dir = await mkdtemp(
    join(process.env.E4_VOICE_PROBE_DIRECTORY!, "probe-"),
  );
  await writeFile(join(dir, "audio"), "synthetic-remnant", { mode: 0o600 });
  const { utimes } = await import("node:fs/promises");
  await utimes(
    dir,
    new Date(Date.now() - 120000),
    new Date(Date.now() - 120000),
  );
  assert.equal(await cleanupVoiceFiles(), 1);
  mark("V12");
});
test("V13 HTTP route binary limit/hash validation and no public/audio response", async () => {
  const audio = wav(),
    j = await createVoice(a.identity, input(a, audio));
  const req = new NextRequest(
    `${process.env.APP_ORIGIN}/api/e4/voice/jobs/${j.id}/upload`,
    {
      method: "POST",
      headers: {
        cookie: `cat_account_session=${a.token}`,
        "x-catletters-account": a.account,
        origin: process.env.APP_ORIGIN!,
        "content-type": "application/octet-stream",
      },
      body: new Uint8Array(audio),
    },
  );
  const res = await POST(req);
  assert.equal(res.status, 200);
  assert.match(res.headers.get("cache-control")!, /private.*no-store/);
  const value = await res.json();
  assert.equal(value.status, "UPLOADED");
  assert.equal(value.audio, undefined);
  assert.equal(value.url, undefined);
  const bad = await createVoice(a.identity, input(a));
  const huge = new NextRequest(
    `${process.env.APP_ORIGIN}/api/e4/voice/jobs/${bad.id}/upload`,
    {
      method: "POST",
      headers: {
        cookie: `cat_account_session=${a.token}`,
        "x-catletters-account": a.account,
        origin: process.env.APP_ORIGIN!,
        "content-type": "application/octet-stream",
        "content-length": String(10 * 1024 * 1024 + 1),
      },
      body: "x",
    },
  );
  assert.equal((await POST(huge)).status, 413);
  assert.equal(await bytes(bad.id), 0);
  mark("V13");
});
test("V14 per-account creation limit commits independent of response retry", async () => {
  const j = await createVoice(a.identity, input(a));
  await finishVoice(a.identity, j.id, "cancel");
  const k = await createVoice(a.identity, input(a));
  await finishVoice(a.identity, k.id, "cancel");
  const l = await createVoice(a.identity, input(a));
  await finishVoice(a.identity, l.id, "cancel");
  await assert.rejects(createVoice(a.identity, input(a)), /频繁/);
  mark("V14");
});

test(
  "V15 actual Chromium recording -> real HTTP/dual PG -> corrected local draft -> explicit ordinary send",
  { timeout: 90_000 },
  async () => {
    const u = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
    const bridge = await voiceHttp(u.token, {
      loseConfirm: true,
      confirmDelayMs: 1500,
    });
    const audioPath = join(
      process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
      "browser-audio.wav",
    );
    await writeFile(audioPath, wav(5), { mode: 0o600 });
    const browser = await chromium.launch({
      headless: true,
      args: [
        "--use-fake-device-for-media-stream",
        "--use-fake-ui-for-media-stream",
        `--use-file-for-fake-audio-capture=${audioPath}`,
      ],
    });
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
      permissions: ["microphone"],
    });
    const page = await context.newPage(),
      errors: string[] = [];
    page.setDefaultTimeout(8000);
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (m) => {
      if (m.type() === "error" && !m.text().includes("503"))
        errors.push(m.text());
    });
    const screenshots: string[] = [];
    const evidenceDir = process.env.E4_VALIDATION_EVIDENCE!;
    try {
      await page.addInitScript({
        content: `var __name=(target)=>target;(${syntheticMicrophone.toString()})();`,
      });
      await page.goto(bridge.url + "/local-review", {
        waitUntil: "networkidle",
      });
      await page
        .getByRole("button", { name: /来信盒/ })
        .first()
        .click();
      await page.getByRole("button", { name: /语音本地验证来信/ }).click();
      await page.getByRole("button", { name: "给它回信", exact: true }).click();
      const draft = page.locator("#response");
      await draft.fill("原来的草稿。");
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await page
        .getByRole("button", { name: "停止并转成文字", exact: true })
        .waitFor();
      await delay(1600);
      await page
        .getByRole("button", { name: "停止并转成文字", exact: true })
        .click();
      const review = page.getByLabel("检查并修改转写文字", { exact: true });
      await review.waitFor({ timeout: 20000 });
      assert.match(await review.inputValue(), /合成转写/);
      assert.equal(await draft.inputValue(), "原来的草稿。");
      const family = "👨‍👩‍👧‍👦";
      await review.fill(family.repeat(1993));
      assert.equal(
        await page
          .getByRole("button", { name: "追加到原草稿", exact: true })
          .isEnabled(),
        true,
      );
      await review.fill(family.repeat(1994));
      assert.equal(
        await page
          .getByRole("button", { name: "追加到原草稿", exact: true })
          .isEnabled(),
        false,
      );
      assert.equal(await review.inputValue(), family.repeat(1994));
      const before = (
        await admin.query(
          "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
          [u.account],
        )
      ).rows[0].n;
      assert.equal(before, 0);
      await review.fill("我不想马上答应，我需要慢慢想一想。");
      for (const width of [320, 390, 1280]) {
        await page.setViewportSize({ width, height: 844 });
        const path = join(evidenceDir, `voice-review-${width}.png`);
        await page.screenshot({ path, fullPage: true });
        screenshots.push(path);
        assert.ok(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
        );
      }
      await page.setViewportSize({ width: 390, height: 844 });
      const buttonTypes = await page
        .locator(".e4-voice button")
        .evaluateAll((buttons) => buttons.map((b) => b.getAttribute("type")));
      assert.ok(
        buttonTypes.length > 0 && buttonTypes.every((t) => t === "button"),
      );
      await page
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await page
        .getByText("文字已填入本机草稿，临时录音正在清理；尚未发送。", {
          exact: true,
        })
        .waitFor();
      await expect(
        page.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled({ timeout: 800 });
      await page
        .getByText("文字已填入草稿，服务端临时材料的清理尚未确认。可以继续打字。", {
          exact: true,
        })
        .waitFor();
      const expected = "原来的草稿。\n我不想马上答应，我需要慢慢想一想。";
      assert.equal(await draft.inputValue(), expected);
      assert.equal(
        (
          await admin.query(
            "SELECT count(*)::int AS n FROM private_voice_jobs j WHERE j.account_id=$1 AND (j.audio_version IS NOT NULL OR j.text_version IS NOT NULL)",
            [u.account],
          )
        ).rows[0].n,
        0,
      );
      await page
        .getByRole("button", { name: "重试清理临时录音", exact: true })
        .click();
      await page
        .getByText("文字已填入本机草稿，尚未发送。", { exact: true })
        .waitFor();
      assert.equal(await draft.inputValue(), expected);
      assert.equal(
        (
          await admin.query(
            "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
            [u.account],
          )
        ).rows[0].n,
        0,
      );
      const localDraft = await page.evaluate(() =>
        Object.keys(localStorage)
          .filter((k) => k.startsWith("cat-letters:account-draft:"))
          .map((k) => JSON.parse(localStorage.getItem(k)!)),
      );
      assert.ok(localDraft.some((d) => d.text === expected));
      await page.getByRole("button", { name: "送出去", exact: true }).click();
      await page
        .getByText(/已经收好|送出|收到/)
        .first()
        .waitFor();
      for (let n = 0; n < 100; n++) {
        if (
          (
            await admin.query(
              "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
              [u.account],
            )
          ).rows[0].n
        )
          break;
        await delay(30);
      }
      const final = (
        await admin.query(
          "SELECT text FROM cloud_response_revisions WHERE account_id=$1",
          [u.account],
        )
      ).rows;
      assert.equal(final.length, 1);
      assert.equal(final[0].text, expected);
      assert.ok(
        await page.evaluate(() =>
          (window as any).__syntheticVoiceTracks.every(
            (t: MediaStreamTrack) => t.readyState === "ended",
          ),
        ),
      );
      assert.deepEqual(errors, []);
      mark("V15", {
        realMediaRecorder: true,
        syntheticMicrophoneSource: "generated PCM MediaStreamTrack",
        nativeGetUserMediaTested: false,
        realAsr: false,
        realHttp: true,
        normalSendPreservesCorrectedNegation: true,
        confirmAckLossNoDuplicateAppend: true,
        screenshots,
        browserPlugin: "Browser plugin not available",
        browser: "Chromium",
      });
    } catch (e) {
      await page.screenshot({
        path: join(evidenceDir, "voice-failure.png"),
        fullPage: true,
      });
      await writeFile(
        join(evidenceDir, "voice-failure-dom.txt"),
        await page.locator("body").innerText(),
      );
      await writeFile(
        join(evidenceDir, "voice-failure-runtime.json"),
        JSON.stringify({
          errors,
          capture: await page.evaluate(() => ({
            error: (window as any).__voiceCaptureError ?? null,
            generator: typeof (window as any).MediaStreamTrackGenerator,
            injected: !!(window as any).__nativeGetUserMedia,
          })),
        }),
      );
      throw e;
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V16 media subprocess wall-clock timeout kills process and removes temp file",
  { timeout: 12000 },
  async () => {
    const binary = join(
      process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
      "slow-probe",
    );
    await writeFile(
      binary,
      `#!${process.execPath}\nsetTimeout(()=>{},60000);\n`,
      { mode: 0o700 },
    );
    const prior = process.env.E4_VOICE_FFPROBE;
    process.env.E4_VOICE_FFPROBE = binary;
    const start = Date.now();
    try {
      await assert.rejects(inspectVoiceAudio(wav(), "audio/wav"), /超时/);
      assert.ok(Date.now() - start >= 4900 && Date.now() - start < 10000);
      assert.deepEqual(
        await readdir(process.env.E4_VOICE_PROBE_DIRECTORY!),
        [],
      );
    } finally {
      process.env.E4_VOICE_FFPROBE = prior;
    }
    mark("V16", {
      actualTimeoutMs: Date.now() - start,
      syntheticSlowExecutable: true,
    });
  },
);
test(
  "V17 actual provider deadline fails closed without publishing text",
  { timeout: 38000 },
  async () => {
    const j = await uploaded();
    const start = Date.now();
    const provider = {
      mode: "synthetic-v1",
      transcribe: async ({ signal }: { signal: AbortSignal }) =>
        new Promise<{ text: string }>((_, reject) =>
          signal.addEventListener(
            "abort",
            () => reject(Error("provider-timeout-secret")),
            { once: true },
          ),
        ),
    };
    await assert.rejects(transcribeVoice(a.identity, j.id, provider));
    assert.ok(Date.now() - start >= 29000 && Date.now() - start < 35000);
    assert.equal((await readVoice(a.identity, j.id)).status, "FAILED");
    assert.equal(
      (
        await admin.query(
          "SELECT text_version FROM private_voice_jobs WHERE id=$1",
          [j.id],
        )
      ).rows[0].text_version,
      null,
    );
    mark("V17", { actualTimeoutMs: Date.now() - start });
  },
);
test("V18 expired lease replacement rejects old publisher without altering ready result", async () => {
  const j = await uploaded();
  let resolve!: (v: { text: string }) => void;
  const old = transcribeVoice(a.identity, j.id, {
    mode: "synthetic-v1",
    transcribe: async () => new Promise<{ text: string }>((r) => (resolve = r)),
  });
  for (let n = 0; n < 100 && !resolve; n++) await delay(10);
  assert.ok(resolve);
  await admin.query(
    "UPDATE private_voice_jobs SET lease_until=now()-interval '1 second' WHERE id=$1",
    [j.id],
  );
  const next = await transcribeVoice(a.identity, j.id);
  resolve({ text: "旧租约不可覆盖" });
  await assert.rejects(old);
  assert.equal((await readVoice(a.identity, j.id)).text, next.text);
  mark("V18");
});
test("V19 global upload concurrency and reserved storage bound survive concurrent accounts", async () => {
  const c = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([
    a.account,
    b.account,
    c.account,
  ]);
  const jobs = await Promise.all(
    [a, b, c].map((u) => createVoice(u.identity, input(u))),
  );
  const first = await claimVoiceUpload(a.identity, jobs[0].id),
    second = await claimVoiceUpload(b.identity, jobs[1].id);
  assert.ok(first.lease && second.lease);
  await assert.rejects(claimVoiceUpload(c.identity, jobs[2].id), /繁忙/);
  await finishVoice(a.identity, jobs[0].id, "cancel");
  assert.ok((await claimVoiceUpload(c.identity, jobs[2].id)).lease);
  mark("V19");
});
test("V20 exact60 Opus/AAC padding passes only after strict decoded sample cap", async () => {
  const run = promisify(execFile),
    dir = process.env.E4_VALIDATION_LOCAL_DIRECTORY!;
  for (const [ext, codec, mime] of [
    ["webm", "libopus", "audio/webm"],
    ["m4a", "aac", "audio/mp4"],
  ]) {
    const file = join(dir, `exact60.${ext}`);
    await run(
      process.env.E4_VOICE_FFMPEG!,
      [
        "-nostdin",
        "-v",
        "error",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=440:duration=60",
        "-ar",
        "16000",
        "-ac",
        "1",
        "-c:a",
        codec,
        "-y",
        file,
      ],
      { timeout: 10000, maxBuffer: 4096 },
    );
    const raw = await readFile(file);
    assert.ok((await inspectVoiceAudio(raw, mime)) <= 60000);
    const normalized = await normalizeVoiceAudio(raw, mime);
    assert.equal(normalized.length, 1_920_044);
  }
  const longer = join(dir, "over60.webm");
  await run(
    process.env.E4_VOICE_FFMPEG!,
    [
      "-nostdin",
      "-v",
      "error",
      "-f",
      "lavfi",
      "-i",
      "sine=frequency=440:duration=60.05",
      "-ar",
      "16000",
      "-ac",
      "1",
      "-c:a",
      "libopus",
      "-y",
      longer,
    ],
    { timeout: 10000, maxBuffer: 4096 },
  );
  await assert.rejects(inspectVoiceAudio(await readFile(longer), "audio/webm"));
  mark("V20", {
    encodedPaddingChecked: true,
    actualDecodedOver60Rejected: true,
    neverTruncates: true,
  });
});
test("V21 full real pg_dump and fresh restore contain metadata but no private payload", async () => {
  const j = await uploaded();
  await transcribeVoice(a.identity, j.id);
  const run = promisify(execFile),
    directory = process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
    source = process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS!,
    dump = join(directory, "voice-metadata.dump"),
    control = join(directory, "voice-control.sql");
  await run(
    "pg_dump",
    [
      "--format=custom",
      "--file",
      dump,
      source,
    ],
    { timeout: 10000, maxBuffer: 32768 },
  );
  const listing = (
    await run("pg_restore", ["--list", dump], {
      timeout: 10000,
      maxBuffer: 128000,
    })
  ).stdout;
  // The ordinary dump includes the empty legacy table; no exclusion is necessary.
  assert.ok(listing.includes("TABLE DATA public private_voice_payload"));
  assert.ok(listing.includes("TABLE DATA public private_voice_jobs"));
  await run(
    "pg_dump",
    [
      "--data-only",
      "--table=public.private_voice_payload",
      "--file",
      control,
      source,
    ],
    { timeout: 10000, maxBuffer: 32768 },
  );
  assert.ok(
    !(await readFile(control, "utf8")).includes("这是合成转写演示"),
    "The legacy SQL payload table stays empty even without exclusion",
  );
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM private_voice_payload")).rows[0].n, 0);
  assert.ok((await physicalEntries(j.id)).length >= 2, "Actual synthetic files exist outside PostgreSQL");
  await admin.query("CREATE DATABASE voice_backup_restore_test");
  const restore = new URL(source);
  restore.pathname = "/voice_backup_restore_test";
  await run(
    "pg_restore",
    ["--no-owner", "--no-privileges", "--dbname", restore.href, dump],
    { timeout: 10000, maxBuffer: 32768 },
  );
  const copy = new pg.Pool({ connectionString: restore.href });
  try {
    assert.equal(
      (await copy.query("SELECT count(*)::int AS n FROM private_voice_payload"))
        .rows[0].n,
      0,
    );
    assert.equal(
      (
        await copy.query("SELECT status FROM private_voice_jobs WHERE id=$1", [
          j.id,
        ])
      ).rows[0].status,
      "READY",
    );
  } finally {
    await copy.end();
  }
  mark("V21", {
    realPgDumpAndRestore: true,
    legacyPayloadTableEmptyWithoutExclude: true,
    payloadAbsentInOrdinaryFullBackup: true,
    actualSyntheticFilesystemObjectsOutsideDatabase: true,
    cloudBackupPolicyVerified: false,
    physicalSnapshotsVerified: false,
  });
});
test("V22 2000 visible emoji graphemes round trip ordinary send/edit; 2001 rejected, draft preserved", async () => {
  const family = "👨‍👩‍👧‍👦",
    text = family.repeat(2000);
  assert.equal(countResponseText(text), 2000);
  assert.ok(text.length > 2000 && validResponseText(text));
  assert.equal(validResponseText(text + family), false);
  assert.equal(validDraftText(text + family), true);
  assert.equal(validResponseText("\ud800"), false);
  assert.equal(validResponseText("a" + "\u0301".repeat(64000)), false);
  const u = await seed();
  const request = (path: string, body: unknown) =>
    v1Post(
      new NextRequest(`${process.env.APP_ORIGIN}/api/e4/v1/${path}`, {
        method: "POST",
        headers: {
          cookie: `cat_account_session=${u.token}`,
          "x-catletters-account": u.account,
          origin: process.env.APP_ORIGIN!,
          "content-type": "application/json",
        },
        body: JSON.stringify(body),
      }),
    );
  const response = await request(`letters/${u.letter}/respond`, {
    text,
    key: randomUUID(),
    expectedResponseId: null,
  });
  assert.equal(response.status, 200, await response.clone().text());
  const result = await response.json();
  const revision = (
    await admin.query(
      "SELECT text FROM cloud_response_revisions WHERE account_id=$1",
      [u.account],
    )
  ).rows[0];
  assert.equal(revision.text, text);
  const bad = await request(`responses/${result.responseId}/edit`, {
    text: text + family,
    key: randomUUID(),
    expectedRevision: 1,
  });
  assert.equal(bad.status, 400);
  const edited = await request(`responses/${result.responseId}/edit`, {
    text: "不" + family.repeat(1999),
    key: randomUUID(),
    expectedRevision: 1,
  });
  assert.equal(edited.status, 200, await edited.clone().text());
  mark("V22", {
    visibleGraphemes: 2000,
    utf16Units: text.length,
    utf8Bytes: Buffer.byteLength(text),
    ordinarySendAndEditRealDb: true,
    overLimitDraftPreserved: true,
  });
});

test(
  "V23 controlled browser permission denial/late grant/interruption preserve text and release tracks",
  { timeout: 45000 },
  async () => {
    const u = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
    const bridge = await voiceHttp(u.token);
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 320, height: 800 },
    });
    const page = await context.newPage();
    page.setDefaultTimeout(8000);
    const failures: string[] = [];
    page.on("pageerror", (e) => failures.push(e.message));
    try {
      await page.addInitScript({
        content: `var __name=(target)=>target;(${syntheticMicrophone.toString()})();`,
      });
      await page.goto(bridge.url + "/local-review", {
        waitUntil: "networkidle",
      });
      await page
        .getByRole("button", { name: /来信盒/ })
        .first()
        .click();
      await page.getByRole("button", { name: /语音本地验证来信/ }).click();
      await page.getByRole("button", { name: "给它回信", exact: true }).click();
      const draft = page.locator("#response");
      await draft.fill("不能丢的原稿。");
      await page.evaluate(
        () => ((window as any).__voicePermissionDenied = true),
      );
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await page
        .getByText("没有获得麦克风权限，你仍可以直接打字。", { exact: true })
        .waitFor();
      assert.equal(await draft.inputValue(), "不能丢的原稿。");
      await expect(
        page.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      await page.evaluate(() => {
        (window as any).__voicePermissionDenied = false;
        (window as any).__voicePermissionDelayMs = 500;
      });
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await page.getByText("等待麦克风权限…", { exact: true }).waitFor();
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .waitFor();
      await page.evaluate(() => ((window as any).__voicePermissionDelayMs = 0));
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await page
        .getByRole("button", { name: "停止并转成文字", exact: true })
        .waitFor();
      await delay(700);
      assert.equal(
        await page.evaluate(
          () =>
            (window as any).__syntheticVoiceTracks.filter(
              (t: MediaStreamTrack) => t.readyState === "live",
            ).length,
        ),
        1,
      );
      assert.equal(
        await page.evaluate(
          () =>
            (window as any).__syntheticVoiceTracks.filter(
              (t: MediaStreamTrack) => t.readyState === "ended",
            ).length,
        ),
        1,
      );
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .waitFor();
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await page
        .getByRole("button", { name: "停止并转成文字", exact: true })
        .waitFor();
      await delay(500);
      await page.evaluate(() => {
        Object.defineProperty(document, "hidden", {
          configurable: true,
          value: true,
        });
        document.dispatchEvent(new Event("visibilitychange"));
      });
      await page
        .getByRole("button", { name: "转成文字", exact: true })
        .waitFor();
      assert.equal(
        (
          await admin.query(
            "SELECT count(*)::int AS n FROM private_voice_jobs WHERE account_id=$1",
            [u.account],
          )
        ).rows[0].n,
        0,
        "Interruption must not upload automatically",
      );
      assert.equal(await draft.inputValue(), "不能丢的原稿。");
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .waitFor();
      assert.ok(
        await page.evaluate(() =>
          (window as any).__syntheticVoiceTracks.every(
            (t: MediaStreamTrack) => t.readyState === "ended",
          ),
        ),
      );
      await draft.fill("字".repeat(2001));
      await expect(
        page.getByRole("button", { name: "送出去", exact: true }),
      ).toBeDisabled();
      assert.equal(await draft.inputValue(), "字".repeat(2001));
      // A native Web Lock save is asynchronous. Reopening promises only the
      // acknowledged persistent draft, not a value whose save is still pending.
      await expect
        .poll(async () => (await browserStoredDraft(page, u))?.text)
        .toBe("字".repeat(2001));
      await expect(
        page.getByText("草稿已保存在本机，尚未发送。", { exact: true }),
      ).toBeVisible();
      await page.reload({ waitUntil: "networkidle" });
      await page
        .getByRole("button", { name: /来信盒/ })
        .first()
        .click();
      await page.getByRole("button", { name: /语音本地验证来信/ }).click();
      if (
        await page
          .getByRole("button", { name: "给它回信", exact: true })
          .count()
      )
        await page
          .getByRole("button", { name: "给它回信", exact: true })
          .click();
      assert.equal(await draft.inputValue(), "字".repeat(2001));
      await page.addStyleTag({
        content:
          ".e4-voice,.e4-voice p,.e4-voice button,.e4-voice textarea,.e4-voice label{font-size:32px!important}",
      });
      assert.ok(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      );
      const screenshot = join(
        process.env.E4_VALIDATION_EVIDENCE!,
        "voice-320-large-text.png",
      );
      await page.screenshot({ path: screenshot, fullPage: true });
      assert.deepEqual(failures, []);
      mark("V23", {
        nativePermissionTested: false,
        controlledPermissionDenial: true,
        lateStreamReleasedWithoutStoppingNewTake: true,
        syntheticVisibilityEvent: true,
        interruptionDoesNotUpload: true,
        overLimitDraftSurvivesReload: true,
        durableSaveAcknowledgedBeforeReload: true,
        allTracksEnded: true,
        largeTextScreenshot: screenshot,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);
test("V24 privacy triggers revoke payload pointers without app table privileges or with temp shadow table", async () => {
  const u = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
  const j = await uploaded(u);
  const db = await pool.connect();
  try {
    await db.query("CREATE TEMP TABLE private_voice_payload(job_id uuid)");
    await admin.query(
      "REVOKE ALL ON private_voice_jobs,private_voice_payload FROM cat_letters_app",
    );
    await db.query(
      "UPDATE account_sessions SET revoked_at=now() WHERE token_hash=$1",
      [digest(u.token)],
    );
    assert.equal(await bytes(j.id), 0);
  } finally {
    await db.query("DROP TABLE IF EXISTS pg_temp.private_voice_payload");
    db.release();
    await admin.query(
      await readFile("deploy/private-voice/access.sql", "utf8"),
    );
  }
  await cleanupPrivateVoice([u.account]);
  assert.equal((await physicalEntries(j.id)).length, 0);
  mark("V24", {
    oldAppRevocationCompatible: true,
    triggerRevokesReadabilityNotFilesystemDeletion: true,
    tempShadowCannotBypassCleanup: true,
  });
});
test("V25 private media directory rejects static destinations, aliases and unsafe modes before writes", async () => {
  const { mkdir, symlink, chmod, access } = await import("node:fs/promises");
  const prior = process.env.E4_VOICE_PROBE_DIRECTORY!,
    root = process.env.E4_VALIDATION_LOCAL_DIRECTORY!;
  const publicDir = join(root, "public");
  await mkdir(publicDir, { mode: 0o700 });
  await symlink(publicDir, join(root, "media-alias"));
  try {
    for (const path of [
      join(publicDir, "voice"),
      join(root, "media-alias", "voice"),
    ]) {
      process.env.E4_VOICE_PROBE_DIRECTORY = path;
      assert.equal((await voiceCapabilities(a.account)).available, false);
      await assert.rejects(inspectVoiceAudio(wav(), "audio/wav"));
      await assert.rejects(access(join(publicDir, "voice")));
    }
    const unsafe = join(root, "unsafe-voice");
    await mkdir(unsafe, { mode: 0o755 });
    await chmod(unsafe, 0o755);
    process.env.E4_VOICE_PROBE_DIRECTORY = unsafe;
    assert.equal((await voiceCapabilities(a.account)).available, false);
    assert.deepEqual(await readdir(unsafe), []);
  } finally {
    process.env.E4_VOICE_PROBE_DIRECTORY = prior;
  }
  mark("V25", {
    staticAndAliasRejected: true,
    noPrivateFilesWrittenToPublic: true,
    unsafeModeRejected: true,
  });
});
test("V26 missing private filesystem payload fails safe without a false transcript", async () => {
  const j = await uploaded();
  const ref = await payloadRef(j.id);
  assert.ok(ref);
  await (await configuredVoicePayloadStore()).remove(ref);
  const lost = await transcribeVoice(a.identity, j.id);
  assert.equal(lost.status, "FAILED");
  assert.equal(lost.error, "AUDIO_LOST");
  assert.equal(lost.text, undefined);
  await assert.rejects(claimVoiceUpload(a.identity, j.id), /重新录音|失效/);
  const rerecorded = await uploaded();
  assert.notEqual(rerecorded.id, j.id);
  assert.equal((await transcribeVoice(a.identity, rerecorded.id)).status, "READY");
  mark("V26", {
    actualSyntheticFilesystemPayloadRemoved: true,
    oldJobCannotRevive: true,
    explicitNewRecordingJobRecovers: true,
    noFalseTranscriptOnLoss: true,
  });
});

const TENCENT_URL = "https://asr.tencentcloudapi.com/";
function offlineTencent(user = a) {
  const secretId = "AKIDOffline" + user.account.replaceAll("-", "");
  Object.assign(process.env, {
    E4_VOICE_MODE: "tencent-sentence-v1",
    E4_VOICE_TENCENT_ASR_APPROVED: "true",
    E4_VOICE_TENCENT_FREE_ONLY: "true",
    E4_VOICE_TENCENT_SECRET_ID: secretId,
    E4_VOICE_TENCENT_SECRET_KEY: "OfflineSecretNotRealIntegration000000",
  });
  return secretId;
}
async function offlineReadiness(user = a) {
  const secretId = offlineTencent(user);
  const dir = await mkdtemp(
    join(process.env.E4_VALIDATION_LOCAL_DIRECTORY!, "tencent-proof-"),
  );
  const evidence = Buffer.from(
    "OFFLINE CONTROLLED EVIDENCE ONLY. NOT A LIVE CLOUD QUOTA/SETTINGS CHECK.",
  );
  await writeFile(join(dir, "console-state.txt"), evidence, { mode: 0o600 });
  const receipt = {
    version: 1,
    provider: "tencent-sentence-v1",
    accountFingerprint: digest(user.account),
    credentialFingerprint: digest(secretId),
    userDecision: "FREE_ONLY",
    postpaid: "DISABLED",
    dataOptimization: "DISABLED",
    permissionScope: "asr:SentenceRecognition",
    freeRemainingCalls: 1000,
    verifiedAt: new Date(Date.now() - 1000).toISOString(),
    expiresAt: new Date(Date.now() + 3600000).toISOString(),
    month: new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 7),
    evidence: [
      {
        file: "console-state.txt",
        sha256: createHash("sha256").update(evidence).digest("hex"),
      },
    ],
  };
  const path = join(dir, "readiness.json");
  await writeFile(path, JSON.stringify(receipt), { mode: 0o600 });
  process.env.E4_VOICE_TENCENT_READINESS_FILE = path;
  return { path, dir, receipt };
}
test("V27 runtime has explicit config gates; private deployment preflight is separate and never a daily service lease", async () => {
  const original = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = (async () => {
    calls++;
    throw Error("NO_NETWORK_ALLOWED");
  }) as typeof fetch;
  try {
    process.env.E4_VOICE_MODE = "tencent-sentence-v1";
    assert.equal((await voiceCapabilities(a.account)).available, false);
    const proof = await offlineReadiness();
    assert.ok(verifyTencentDeploymentEvidence().receiptSha256);
    const preflight = await promisify(execFile)(
      process.execPath,
      ["--import", "tsx", "scripts/voice-tencent-preflight.ts"],
      { env: process.env },
    );
    assert.equal(JSON.parse(preflight.stdout).status, "PASS");
    assert.equal(JSON.parse(preflight.stdout).asrCalled, false);
    assert.equal(JSON.parse(preflight.stdout).runtimeDependsOnReceipt, false);
    delete process.env.E4_VOICE_TENCENT_READINESS_FILE;
    assert.equal((await voiceCapabilities(a.account)).available, true);
    assert.throws(() => verifyTencentDeploymentEvidence());
    process.env.E4_VOICE_TENCENT_READINESS_FILE = proof.path;
    assert.equal(
      (await voiceCapabilities(a.account)).mode,
      "tencent-sentence-v1",
    );
    const bad = [
      { postpaid: "ENABLED" },
      { dataOptimization: "ENABLED" },
      { freeRemainingCalls: 0 },
      { permissionScope: "asr:*" },
      { credentialFingerprint: "f".repeat(64) },
      { month: "2000-01" },
      { expiresAt: new Date(Date.now() - 1).toISOString() },
      { verifiedAt: new Date(Date.now() + 60000).toISOString() },
      { evidence: [{ file: "console-state.txt", sha256: "f".repeat(64) }] },
    ];
    for (const change of bad) {
      await writeFile(
        proof.path,
        JSON.stringify({ ...proof.receipt, ...change }),
      );
      assert.throws(() => verifyTencentDeploymentEvidence());
      assert.equal((await voiceCapabilities(a.account)).available, true);
    }
    await writeFile(proof.path, JSON.stringify(proof.receipt));
    const { chmod } = await import("node:fs/promises");
    await chmod(proof.path, 0o644);
    assert.throws(() => verifyTencentDeploymentEvidence());
    assert.equal((await voiceCapabilities(a.account)).available, true);
    await chmod(proof.path, 0o600);
    // Real past timestamps, no clock patch or simulated "next-day" timer.
    const old = Date.now() - 3 * 86400000;
    await writeFile(
      proof.path,
      JSON.stringify({
        ...proof.receipt,
        verifiedAt: new Date(old).toISOString(),
        expiresAt: new Date(old + 3600000).toISOString(),
        month: new Date(old + 8 * 3600000).toISOString().slice(0, 7),
      }),
    );
    assert.throws(() => verifyTencentDeploymentEvidence());
    assert.equal((await voiceCapabilities(a.account)).available, true);
    for (const key of [
      "E4_VOICE_ENABLED",
      "E4_VOICE_TENCENT_ASR_APPROVED",
      "E4_VOICE_TENCENT_FREE_ONLY",
    ]) {
      process.env[key] = "false";
      assert.equal((await voiceCapabilities(a.account)).available, false);
      process.env[key] = "true";
    }
    delete process.env.E4_VOICE_TENCENT_SECRET_KEY;
    assert.equal((await voiceCapabilities(a.account)).available, false);
    assert.equal(calls, 0);
    mark("V27", {
      deploymentPreflightOnly: true,
      actualPreflightCliTested: true,
      missingExpiredUnsafeRecordDoesNotDisableRuntime: true,
      clockNotPatched: true,
      liveBillingVerified: false,
      noQuotaProbeOrAudioNetworkCalls: true,
      explicitRuntimeFlagsAndCredentialsRequired: true,
    });
  } finally {
    globalThis.fetch = original;
  }
});
test("V28 actual HTTP Tencent mode uses converted WAV only and no draft/letter/history; confirm never sends", async () => {
  const u = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
  offlineTencent(u);
  process.env.E4_VOICE_TENCENT_READINESS_FILE =
    "/not/a/runtime/dependency.json";
  const native = globalThis.fetch;
  let calls = 0;
  let jobId = "";
  globalThis.fetch = (async (url, init) => {
    assert.equal(String(url), TENCENT_URL);
    calls++;
    const payload = JSON.parse(init!.body as string),
      audio = Buffer.from(payload.Data, "base64");
    assert.deepEqual(
      Object.keys(payload).sort(),
      [
        "EngSerViceType",
        "SourceType",
        "VoiceFormat",
        "Data",
        "DataLen",
        "WordInfo",
        "FilterDirty",
        "FilterModal",
        "FilterPunc",
        "ConvertNumMode",
      ].sort(),
    );
    assert.equal(payload.SourceType, 1);
    assert.equal(payload.VoiceFormat, "wav");
    assert.equal(audio.readUInt32LE(24), 16000);
    assert.equal(audio.readUInt16LE(22), 1);
    assert.equal(audio.readUInt16LE(34), 16);
    assert.equal(audio.length, 32044);
    assert.equal(payload.DataLen, audio.length);
    assert.ok(payload.Data.length < 3000000);
    for (const privateText of [
      u.account,
      u.cat,
      u.letter,
      jobId,
      "原稿秘密不要传出",
    ]) {
      if (privateText) assert.ok(!String(init!.body).includes(privateText));
    }
    assert.equal(
      new Headers(init!.headers).get("x-tc-action"),
      "SentenceRecognition",
    );
    return Response.json({
      Response: {
        Result: "我不想马上同意，也没有答应。",
        RequestId: "offline-only",
      },
    });
  }) as typeof fetch;
  const bridge = await voiceHttp(u.token);
  const headers = {
    cookie: `cat_account_session=${u.token}`,
    "x-catletters-account": u.account,
    origin: bridge.url,
  };
  const request = async (path: string, value?: unknown, binary?: Buffer) =>
    native(bridge.url + "/api/e4/voice/" + path, {
      method: value !== undefined || binary ? "POST" : "GET",
      headers: {
        ...headers,
        ...(binary
          ? { "content-type": "application/octet-stream" }
          : value !== undefined
            ? { "content-type": "application/json" }
            : {}),
      },
      body: binary
        ? new Uint8Array(binary)
        : value !== undefined
          ? JSON.stringify(value)
          : undefined,
    });
  try {
    const cap = await (await request("capabilities")).json();
    assert.equal(cap.available, true);
    assert.equal(cap.mode, "tencent-sentence-v1");
    assert.match(cap.privacyNotice, /腾讯云/);
    assert.equal(calls, 0);
    const raw = wav(1, 48000, 2),
      created = await request("jobs", input(u, raw));
    assert.equal(created.status, 200);
    const job = await created.json();
    jobId = job.id;
    assert.equal(job.mode, "tencent-sentence-v1");
    assert.equal(
      (await request(`jobs/${job.id}/upload`, undefined, raw)).status,
      200,
    );
    const ready = await request(`jobs/${job.id}/transcribe`, {});
    assert.equal(ready.status, 200);
    const result = await ready.json();
    assert.equal(result.mode, "tencent-sentence-v1");
    assert.equal(result.text, "我不想马上同意，也没有答应。");
    assert.equal(calls, 1);
    assert.equal(
      (
        await admin.query(
          "SELECT provider_mode FROM private_voice_jobs WHERE id=$1",
          [job.id],
        )
      ).rows[0].provider_mode,
      "tencent-sentence-v1",
    );
    assert.equal((await request(`jobs/${job.id}/confirm`, {})).status, 200);
    assert.equal(await bytes(job.id), 0);
    assert.equal(
      (
        await admin.query(
          "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
          [u.account],
        )
      ).rows[0].n,
      0,
    );
    mark("V28", {
      realHttpAndConversion: true,
      transport: "offline injected response",
      providerModeBoundToJob: true,
      raw48000StereoConvertedTo16000Mono: true,
      noDraftHistorySent: true,
      realAsrCalled: false,
      liveQuotaVerified: false,
      runtimeWorksWithoutEvidenceFile: true,
    });
  } finally {
    await bridge.close();
    globalThis.fetch = native;
  }
});
test("V29 dispatch rechecks explicit enable and credentials; provider switch cannot transcribe an old-mode job", async () => {
  offlineTencent();
  let calls = 0;
  const native = globalThis.fetch;
  globalThis.fetch = (async () => {
    calls++;
    return Response.json({ Response: { Result: "offline" } });
  }) as typeof fetch;
  try {
    const configured = configuredVoiceProvider();
    process.env.E4_VOICE_TENCENT_ASR_APPROVED = "false";
    await assert.rejects(
      configured.transcribe({
        audio: wav(),
        mime: "audio/wav",
        jobId: randomUUID(),
        signal: new AbortController().signal,
      }),
    );
    assert.equal(calls, 0);
    process.env.E4_VOICE_TENCENT_ASR_APPROVED = "true";
    const key = process.env.E4_VOICE_TENCENT_SECRET_KEY!;
    process.env.E4_VOICE_TENCENT_SECRET_KEY = key + "Changed";
    await assert.rejects(
      configured.transcribe({
        audio: wav(),
        mime: "audio/wav",
        jobId: randomUUID(),
        signal: new AbortController().signal,
      }),
    );
    assert.equal(calls, 0);
    process.env.E4_VOICE_TENCENT_SECRET_KEY = key;
    const job = await uploaded();
    process.env.E4_VOICE_MODE = "synthetic-v1";
    await assert.rejects(transcribeVoice(a.identity, job.id), /服务已变化/);
    assert.equal(calls, 0);
    mark("V29", {
      explicitDisableCheckedAtDispatch: true,
      credentialReplacementRejectsOldProvider: true,
      modeChangeRejected: true,
      realNetwork: false,
    });
  } finally {
    globalThis.fetch = native;
  }
});
test("V30 quota/auth failures close this runtime configuration without auto retry or receipt renewal", async () => {
  const native = globalThis.fetch;
  let calls = 0;
  const codes = [
    "LimitExceeded",
    "FailedOperation.UserHasNoAmount",
    "FailedOperation.UserHasNoFreeAmount",
    "FailedOperation.ServiceIsolate",
    "AuthFailure.SecretIdNotFound",
  ];
  try {
    for (const code of codes) {
      const user = await seed();
      process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
      offlineTencent(user);
      const beforeCalls = calls;
      globalThis.fetch = (async () => {
        calls++;
        return Response.json({
          Response: {
            Error: { Code: code, Message: "private-secret-sentinel" },
          },
        });
      }) as typeof fetch;
      const job = await uploaded(user);
      await assert.rejects(transcribeVoice(user.identity, job.id), (e) => {
        assert.match((e as Error).message, /继续打字/);
        if (!code.startsWith("AuthFailure"))
          assert.match((e as Error).message, /免费语音额度/);
        assert.ok(!(e as Error).message.includes("sentinel"));
        assert.ok(!(e as Error).message.includes(code));
        return true;
      });
      assert.equal(calls, beforeCalls + 1);
      assert.equal((await voiceCapabilities(user.account)).available, false);
      await assert.rejects(transcribeVoice(user.identity, job.id));
      assert.equal(calls, beforeCalls + 1);
      process.env.E4_VOICE_TENCENT_READINESS_FILE =
        "/record/renewal/cannot/reopen/service.json";
      assert.equal((await voiceCapabilities(user.account)).available, false);
      process.env.E4_VOICE_TENCENT_ASR_APPROVED = "false";
      process.env.E4_VOICE_TENCENT_ASR_APPROVED = "true";
      assert.equal((await voiceCapabilities(user.account)).available, false);
      // An explicit operator credential replacement creates a new configuration;
      // no daily record, automatic reopening or upstream retry is performed.
      process.env.E4_VOICE_TENCENT_SECRET_KEY += "Replaced";
      assert.equal((await voiceCapabilities(user.account)).available, true);
    }
    mark("V30", {
      offlineErrorCodes: codes,
      transportCalls: calls,
      knownQuotaStopsCallsUntilExplicitOperatorRecovery: true,
      receiptRenewalDoesNotReopenService: true,
      noProviderBodyExposed: true,
      realNetwork: false,
    });
  } finally {
    globalThis.fetch = native;
  }
});
test(
  "V31 Tencent-mode browser edits/appends explicitly; known quota failure disables voice and preserves text send",
  { timeout: 45000 },
  async () => {
    const u = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([u.account]);
    offlineTencent(u);
    const native = globalThis.fetch;
    let calls = 0,
      quota = false;
    globalThis.fetch = (async (url, init) => {
      assert.equal(String(url), TENCENT_URL);
      calls++;
      assert.ok(!String(init!.body).includes("原稿私密"));
      if (quota)
        return new Response("offline quota detail must not leak", {
          status: 429,
        });
      return Response.json({ Response: { Result: "我还没有想好。" } });
    }) as typeof fetch;
    const bridge = await voiceHttp(u.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
    });
    page.setDefaultTimeout(10000);
    const pageErrors: string[] = [];
    page.on("pageerror", (e) => pageErrors.push(e.message));
    try {
      await page.goto(bridge.url + "/local-review", {
        waitUntil: "networkidle",
      });
      await page
        .getByRole("button", { name: /来信盒/ })
        .first()
        .click();
      await page.getByRole("button", { name: /语音本地验证来信/ }).click();
      await page.getByRole("button", { name: "给它回信", exact: true }).click();
      const draft = page.locator("#response");
      await draft.fill("原稿私密，先保留。");
      await page.getByText(/录音将交给腾讯云转成文字/).waitFor();
      const capture = async () => {
        await page
          .getByRole("button", { name: "用语音写几句", exact: true })
          .click();
        await page
          .getByRole("button", { name: "停止并转成文字", exact: true })
          .waitFor();
        await delay(700);
        await page
          .getByRole("button", { name: "停止并转成文字", exact: true })
          .click();
      };
      await capture();
      const review = page.getByLabel("检查并修改转写文字", { exact: true });
      await review.waitFor();
      assert.equal(await review.inputValue(), "我还没有想好。");
      assert.equal(await draft.inputValue(), "原稿私密，先保留。");
      await review.fill("我并没有答应。");
      const screenshot = join(
        process.env.E4_VALIDATION_EVIDENCE!,
        "tencent-mode-offline-390.png",
      );
      await page.screenshot({ path: screenshot, fullPage: true });
      await page
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await page
        .getByText("文字已填入本机草稿，尚未发送。", { exact: true })
        .waitFor();
      const expected = "原稿私密，先保留。\n我并没有答应。";
      assert.equal(await draft.inputValue(), expected);
      assert.equal(
        (
          await admin.query(
            "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
            [u.account],
          )
        ).rows[0].n,
        0,
      );
      quota = true;
      await capture();
      await page
        .getByText("免费语音额度暂不可用，你可以继续打字。", { exact: true })
        .waitFor();
      await expect(
        page.getByRole("button", { name: "重试处理这段录音", exact: true }),
      ).toBeDisabled();
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await expect(
        page.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      assert.equal(
        await page
          .getByRole("button", { name: "用语音写几句", exact: true })
          .count(),
        0,
      );
      assert.equal(await draft.inputValue(), expected);
      await page.getByRole("button", { name: "送出去", exact: true }).click();
      await expect
        .poll(
          async () =>
            (
              await admin.query(
                "SELECT count(*)::int AS n FROM cloud_responses WHERE account_id=$1",
                [u.account],
              )
            ).rows[0].n,
        )
        .toBe(1);
      assert.equal(
        (
          await admin.query(
            "SELECT text FROM cloud_response_revisions WHERE account_id=$1",
            [u.account],
          )
        ).rows[0].text,
        expected,
      );
      assert.equal(calls, 2);
      assert.equal(
        (
          await admin.query(
            "SELECT count(*)::int AS n FROM private_voice_jobs j WHERE j.account_id=$1 AND (j.audio_version IS NOT NULL OR j.text_version IS NOT NULL)",
            [u.account],
          )
        ).rows[0].n,
        0,
      );
      assert.deepEqual(pageErrors, []);
      mark("V31", {
        realBrowserAndHttp: true,
        providerMode: "tencent-sentence-v1",
        transport: "offline stub",
        controlledBillingReceipt: true,
        realAsr: false,
        knownQuotaClosesUsableVoice: true,
        textFallbackPreservesEditedNegation: true,
        screenshot,
      });
    } finally {
      await browser.close();
      await bridge.close();
      globalThis.fetch = native;
    }
  },
);

test(
  "V32 real two-tab stale voice append preserves both drafts and review; explicit reload/reconfirm succeeds",
  { timeout: 60000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    });
    const pageA = await context.newPage(),
      pageB = await context.newPage();
    const errors: string[] = [];
    for (const page of [pageA, pageB]) {
      page.setDefaultTimeout(10000);
      page.on("pageerror", (e) => errors.push(e.message));
    }
    try {
      await browserReply(pageA, bridge.url);
      await browserDraft(pageA, "A页原稿，不能丢失。");
      const review = await browserVoiceReview(pageA);
      await browserReply(pageB, bridge.url);
      await expect(pageB.locator("#response")).toHaveValue(
        "A页原稿，不能丢失。",
      );
      const initialVersion = (await browserStoredDraft(pageA, user))
        .localRevision;
      await browserDraft(pageB, "B页临时改写。");
      await browserDraft(pageB, "A页原稿，不能丢失。");
      assert.notEqual(
        (await browserStoredDraft(pageB, user)).localRevision,
        initialVersion,
      );
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await expect(
        pageA.getByRole("button", {
          name: "载入最新草稿，继续校对",
          exact: true,
        }),
      ).toBeVisible();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "A页原稿，不能丢失。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      await pageA
        .getByRole("button", { name: "载入最新草稿，继续校对", exact: true })
        .click();
      await browserDraft(pageB, "B页刚保存的最新草稿。");
      const bVersion = (await browserStoredDraft(pageB, user)).localRevision;
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await expect(
        pageA.getByText(
          "另一页面已更新草稿，本次没有覆盖。原稿与校对文字均保留。",
          { exact: true },
        ),
      ).toBeVisible();
      await expect(pageA.locator("#response")).toHaveValue(
        "A页原稿，不能丢失。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      await expect(
        pageA.getByLabel("检测到的另一页面草稿", { exact: true }),
      ).toHaveValue("B页刚保存的最新草稿。");
      assert.equal(
        (await browserStoredDraft(pageA, user)).localRevision,
        bVersion,
      );
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "B页刚保存的最新草稿。",
      );
      for (const width of [320, 390, 1280]) {
        await pageA.setViewportSize({ width, height: 900 });
        assert.equal(
          await pageA.evaluate(
            () => document.documentElement.scrollWidth > innerWidth,
          ),
          false,
        );
        await pageA.screenshot({
          path: join(
            process.env.E4_VALIDATION_EVIDENCE!,
            `voice-draft-conflict-${width}.png`,
          ),
          fullPage: true,
        });
      }
      const load = pageA.getByRole("button", {
        name: "载入最新草稿，继续校对",
        exact: true,
      });
      await load.click();
      await expect(pageA.locator("#response")).toHaveValue(
        "B页刚保存的最新草稿。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "B页刚保存的最新草稿。",
      );
      // A second edit after reloading must conflict again, never silently rebase.
      await browserDraft(pageB, "B页再次修改，仍要保留。");
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await expect(load).toBeVisible();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "B页再次修改，仍要保留。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      await load.click();
      await expect(pageA.locator("#response")).toHaveValue(
        "B页再次修改，仍要保留。",
      );
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await expect(
        pageA.getByText("文字已填入本机草稿，尚未发送。", { exact: true }),
      ).toBeVisible();
      const merged = "B页再次修改，仍要保留。\n我并没有答应。";
      await expect(pageA.locator("#response")).toHaveValue(merged);
      assert.equal((await browserStoredDraft(pageA, user)).text, merged);
      assert.notEqual(
        (await browserStoredDraft(pageA, user)).localRevision,
        bVersion,
      );
      await expect(
        pageA.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM private_voice_jobs j WHERE j.account_id=$1 AND (j.audio_version IS NOT NULL OR j.text_version IS NOT NULL)",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      assert.deepEqual(errors, []);
      mark("V32", {
        realTwoBrowserTabs: true,
        sharedActualLocalStorage: true,
        webLocks: true,
        revisionComparedInsideMutex: true,
        sameTextNewRevisionConflicts: true,
        bothDraftsAndReviewPreserved: true,
        secondConflictAfterReload: true,
        explicitReloadThenSeparateConfirm: true,
        noAutoSend: true,
        realAsr: false,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V33 actual queued ordinary save and voice CAS cannot interleave; same-page changes while waiting are rechecked",
  { timeout: 60000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    });
    const pageA = await context.newPage(),
      pageB = await context.newPage();
    for (const p of [pageA, pageB]) p.setDefaultTimeout(10000);
    const lock = `cat-letters:account-draft-lock:v1:${user.account}:${user.cat}:${encodeURIComponent(user.letter)}`;
    async function hold() {
      await pageB.evaluate((name) => {
        (window as any).__draftLockHeld = false;
        void navigator.locks.request(
          name,
          () =>
            new Promise<void>((resolve) => {
              (window as any).__releaseDraftLock = resolve;
              (window as any).__draftLockHeld = true;
            }),
        );
      }, lock);
      await expect
        .poll(() => pageB.evaluate(() => (window as any).__draftLockHeld))
        .toBe(true);
    }
    async function pendingTwo() {
      await expect
        .poll(() =>
          pageB.evaluate(
            async (name) =>
              (await navigator.locks.query()).pending!.filter(
                (l) => l.name === name,
              ).length,
            lock,
          ),
        )
        .toBe(2);
    }
    try {
      await browserReply(pageA, bridge.url);
      await browserDraft(pageA, "排队前的原稿。");
      const review = await browserVoiceReview(pageA);
      await browserReply(pageB, bridge.url);
      await hold();
      await pageB.locator("#response").fill("B页已请求保存的新稿。");
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await pendingTwo();
      await pageB.evaluate(() => (window as any).__releaseDraftLock());
      await expect(
        pageB.getByText("草稿已保存在本机，尚未发送。", { exact: true }),
      ).toBeVisible();
      await expect(
        pageA.getByRole("button", {
          name: "载入最新草稿，继续校对",
          exact: true,
        }),
      ).toBeVisible();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "B页已请求保存的新稿。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      await pageA
        .getByRole("button", { name: "载入最新草稿，继续校对", exact: true })
        .click();
      await hold();
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await pageA.locator("#response").fill("A页等待期间自己修改的草稿。");
      await pendingTwo();
      await pageB.evaluate(() => (window as any).__releaseDraftLock());
      await expect(
        pageA.getByText(/本页草稿已变化，文字尚未填入/),
      ).toBeVisible();
      await expect(
        pageA.getByText("草稿已保存在本机，尚未发送。", { exact: true }),
      ).toBeVisible();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "A页等待期间自己修改的草稿。",
      );
      await expect(review).toHaveValue("我并没有答应。");
      await pageA
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await expect(
        pageA.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        "A页等待期间自己修改的草稿。",
      );
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      mark("V33", {
        realTwoBrowserTabs: true,
        actualExclusiveLockQueue: true,
        normalAndConditionalWritersUseSameLock: true,
        noReadThenWriteGap: true,
        samePageEpochCheckedAfterWait: true,
        cancelRetainsPersistentDraft: true,
        noAutoSend: true,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V34 browser without cross-tab mutex keeps voice unavailable and ordinary text draft usable",
  { timeout: 30000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
    });
    try {
      await page.addInitScript(() =>
        Object.defineProperty(navigator, "locks", {
          value: undefined,
          configurable: true,
        }),
      );
      await browserReply(page, bridge.url);
      await browserDraft(page, "只有文字时照常保存。");
      await expect(
        page.getByRole("button", { name: "用语音写几句", exact: true }),
      ).toHaveCount(0);
      assert.equal(
        (await browserStoredDraft(page, user)).text,
        "只有文字时照常保存。",
      );
      await expect(
        page.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM private_voice_jobs WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      mark("V34", {
        missingWebLocksFailsVoiceClosed: true,
        ordinaryTextPreserved: true,
        realAsr: false,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

async function holdVoiceDraftLock(page: Page, user: User) {
  const name = `cat-letters:account-draft-lock:v1:${user.account}:${user.cat}:${encodeURIComponent(user.letter)}`;
  await page.evaluate((name) => {
    (window as any).__voiceHoldReady = false;
    void navigator.locks.request(
      name,
      () =>
        new Promise<void>((resolve) => {
          (window as any).__voiceHoldRelease = resolve;
          (window as any).__voiceHoldReady = true;
        }),
    );
  }, name);
  await expect
    .poll(() => page.evaluate(() => (window as any).__voiceHoldReady))
    .toBe(true);
  return name;
}
async function voiceLockQueue(page: Page, name: string, count: number) {
  await expect
    .poll(() =>
      page.evaluate(
        async (key) =>
          (await navigator.locks.query()).pending!.filter((l) => l.name === key)
            .length,
        name,
      ),
    )
    .toBe(count);
}

test(
  "V35 real queued voice append cannot write after leaving/reopening; local review and original draft survive",
  { timeout: 45000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    });
    const pageA = await context.newPage(),
      pageB = await context.newPage();
    let respondRequests = 0;
    const errors: string[] = [];
    for (const page of [pageA, pageB]) {
      page.setDefaultTimeout(10000);
      page.on("pageerror", (e) => errors.push(e.message));
      page.on("request", (req) => {
        if (req.url().endsWith("/respond")) respondRequests++;
      });
    }
    try {
      await browserReply(pageA, bridge.url);
      await browserDraft(pageA, "离页前的原稿必须保留。");
      await browserVoiceReview(pageA);
      await browserReply(pageB, bridge.url);
      const before = await browserStoredDraft(pageA, user);
      const lock = await holdVoiceDraftLock(pageB, user);
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await voiceLockQueue(pageB, lock, 1);
      await pageA
        .getByRole("button", { name: "← 来信盒", exact: true })
        .click();
      await expect(pageA.locator("#response")).toHaveCount(0);
      // Return before releasing the lock: same letter/text must not revive the
      // previous mount's queued operation (navigation ABA).
      await pageA.getByRole("button", { name: /语音本地验证来信/ }).click();
      await expect(pageA.locator("#response")).toHaveValue(before.text);
      const recovered = pageA.getByLabel("检查并修改转写文字", { exact: true });
      await expect(recovered).toHaveValue("我并没有答应。");
      await pageB.evaluate(() => (window as any).__voiceHoldRelease());
      await voiceLockQueue(pageB, lock, 0);
      assert.deepEqual(await browserStoredDraft(pageA, user), before);
      await expect(recovered).toHaveValue("我并没有答应。");
      await expect
        .poll(
          async () =>
            (
              await admin.query(
                "SELECT status FROM private_voice_jobs WHERE account_id=$1",
                [user.account],
              )
            ).rows[0]?.status,
        )
        .toBe("CANCELLED");
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      assert.equal(respondRequests, 0);
      await pageA.screenshot({
        path: join(
          process.env.E4_VALIDATION_EVIDENCE!,
          "voice-leave-queued-recovered-390.png",
        ),
        fullPage: true,
      });
      // Recovery is useful without reviving/calling the cancelled ASR job. Only
      // a new explicit confirmation may now fill the ordinary draft.
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await expect(
        pageA.getByText("文字已填入本机草稿，尚未发送。", { exact: true }),
      ).toBeVisible();
      const merged = before.text + "\n我并没有答应。";
      assert.equal((await browserStoredDraft(pageA, user)).text, merged);
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM private_voice_jobs WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        1,
      );
      assert.equal(
        (
          await admin.query(
            "SELECT status FROM private_voice_jobs WHERE account_id=$1",
            [user.account],
          )
        ).rows[0].status,
        "CANCELLED",
      );
      await pageA
        .getByRole("button", { name: "← 来信盒", exact: true })
        .click();
      await pageA.getByRole("button", { name: /语音本地验证来信/ }).click();
      await expect(pageA.locator("#response")).toHaveValue(merged);
      await expect(
        pageA.getByLabel("检查并修改转写文字", { exact: true }),
      ).toHaveCount(0);
      assert.equal(respondRequests, 0);
      assert.deepEqual(errors, []);
      mark("V35", {
        realTwoBrowserTabs: true,
        actualLockWait: true,
        leaveAndReturnBeforeRelease: true,
        oldMountNeverAppends: true,
        originalPersistentVersionUnchanged: true,
        localReviewSurvivesWithinPage: true,
        restoredReviewRequiresSeparateConfirm: true,
        noAsrJobRevived: true,
        noDuplicateRecoveryAfterCommit: true,
        respondRequests: 0,
        realAsr: false,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V36 cancel queued fill invalidates old epoch; immediate new confirmation commits once without losing review",
  { timeout: 45000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    });
    const pageA = await context.newPage(),
      pageB = await context.newPage();
    for (const page of [pageA, pageB]) page.setDefaultTimeout(10000);
    try {
      await browserReply(pageA, bridge.url);
      await browserDraft(pageA, "取消填入仍保留的原稿。");
      const review = await browserVoiceReview(pageA);
      await browserReply(pageB, bridge.url);
      const before = await browserStoredDraft(pageA, user);
      const lock = await holdVoiceDraftLock(pageB, user);
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await voiceLockQueue(pageB, lock, 1);
      await pageA
        .getByRole("button", { name: "取消本次填入", exact: true })
        .click();
      await expect(review).toHaveValue("我并没有答应。");
      await expect(pageA.locator("#response")).toHaveValue(before.text);
      assert.deepEqual(await browserStoredDraft(pageA, user), before);
      // The next action is explicit; releasing both queued operations must write
      // only this new operation, not let the old catch/finally clobber its state.
      await pageA
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await voiceLockQueue(pageB, lock, 2);
      await pageB.evaluate(() => (window as any).__voiceHoldRelease());
      await expect(
        pageA.getByText("文字已填入本机草稿，尚未发送。", { exact: true }),
      ).toBeVisible();
      assert.equal(
        (await browserStoredDraft(pageA, user)).text,
        before.text + "\n我并没有答应。",
      );
      await expect(
        pageA.getByRole("button", { name: "送出去", exact: true }),
      ).toBeEnabled();
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      mark("V36", {
        realTwoBrowserTabs: true,
        actualQueuedCancel: true,
        originalAndReviewPreservedOnAbort: true,
        immediateNewConfirmNotClobberedByOldPromise: true,
        exactlyOneAppend: true,
        noAutoSend: true,
      });
    } finally {
      await browser.close();
      await bridge.close();
    }
  },
);

const selectionOf = (page: Page) =>
  page.locator("#response").evaluate((el: HTMLTextAreaElement) => ({
    start: el.selectionStart,
    end: el.selectionEnd,
    direction: el.selectionDirection,
  }));

test(
  "V37 focus handoffs preserve original selection; late cleanup never takes focus back",
  { timeout: 45000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
    });
    page.setDefaultTimeout(10000);
    let confirmSeen!: () => void, releaseConfirm!: () => void;
    let cancelSeen!: () => void, releaseCancel!: () => void;
    const confirmed = new Promise<void>((r) => {
      confirmSeen = r;
    });
    const confirmGate = new Promise<void>((r) => {
      releaseConfirm = r;
    });
    const cancelled = new Promise<void>((r) => {
      cancelSeen = r;
    });
    const cancelGate = new Promise<void>((r) => {
      releaseCancel = r;
    });
    await page.route("**/api/e4/voice/jobs/*/confirm", async (route) => {
      const response = await route.fetch();
      confirmSeen();
      await confirmGate;
      await route.fulfill({ response });
    });
    await page.route("**/api/e4/voice/jobs/*/cancel", async (route) => {
      const response = await route.fetch();
      cancelSeen();
      await cancelGate;
      await route.fulfill({ response });
    });
    try {
      const draft = await browserReply(page, bridge.url);
      await browserDraft(page, "原稿的文字与选区保留。");
      await draft.evaluate((el: HTMLTextAreaElement) =>
        el.setSelectionRange(2, 5, "backward"),
      );
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      const stop = page.getByRole("button", {
        name: "停止并转成文字",
        exact: true,
      });
      await expect(stop).toBeFocused();
      await delay(500);
      await stop.click();
      const review = page.getByLabel("检查并修改转写文字", { exact: true });
      await expect(review).toBeFocused();
      await expect(page.locator('.e4-voice [role="status"]')).toHaveCount(1);
      await expect(page.locator('.e4-voice [role="status"]')).toHaveAttribute(
        "aria-live",
        "polite",
      );
      await review.fill("我并没有答应。");
      await page
        .getByRole("button", { name: "追加到原草稿", exact: true })
        .click();
      await confirmed;
      await expect(draft).toBeFocused();
      assert.deepEqual(await selectionOf(page), {
        start: 2,
        end: 5,
        direction: "backward",
      });
      const merged = "原稿的文字与选区保留。\n我并没有答应。";
      await expect(draft).toHaveValue(merged);
      // User edits while cleanup acknowledgement is deliberately held.
      await browserDraft(page, merged + "继续写一句。");
      const afterTyping = await selectionOf(page);
      releaseConfirm();
      await expect(
        page.getByText("文字已填入本机草稿，尚未发送。", { exact: true }),
      ).toBeVisible();
      await expect(draft).toBeFocused();
      assert.deepEqual(await selectionOf(page), afterTyping);
      await draft.evaluate((el: HTMLTextAreaElement) =>
        el.setSelectionRange(1, 4, "forward"),
      );
      await browserVoiceReview(page);
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await cancelled;
      await expect(draft).toBeFocused();
      assert.deepEqual(await selectionOf(page), {
        start: 1,
        end: 4,
        direction: "forward",
      });
      await draft.press("End");
      const afterCancelMove = await selectionOf(page);
      releaseCancel();
      await expect(
        page.getByText("已取消这段录音，原文字草稿保留。", { exact: true }),
      ).toBeVisible();
      await expect(draft).toBeFocused();
      assert.deepEqual(await selectionOf(page), afterCancelMove);
      await expect(draft).toHaveValue(merged + "继续写一句。");
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      mark("V37", {
        startFocusesStop: true,
        reviewFocusesEditableText: true,
        fillAndCancelReturnOriginalSelection: true,
        lateCleanupDoesNotResetFocusOrSelection: true,
        onePoliteRegion: true,
        noAutoSend: true,
        controlledHttpAcknowledgementHolds: true,
      });
    } finally {
      releaseConfirm?.();
      releaseCancel?.();
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V38 asynchronous review does not steal typing focus; late result after leaving never refocuses old editor",
  { timeout: 45000 },
  async () => {
    const user = await seed();
    process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
    const bridge = await voiceHttp(user.token, { syntheticMic: true });
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
    });
    page.setDefaultTimeout(10000);
    const releases: (() => void)[] = [];
    await page.route("**/api/e4/voice/jobs/*/transcribe", async (route) => {
      const response = await route.fetch();
      await new Promise<void>((resolve) => releases.push(resolve));
      await route.fulfill({ response });
    });
    try {
      const draft = await browserReply(page, bridge.url);
      await browserDraft(page, "录音时仍可继续修改原稿。");
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      const stop = page.getByRole("button", {
        name: "停止并转成文字",
        exact: true,
      });
      await stop.waitFor();
      await draft.focus();
      await delay(1100);
      await expect(draft).toBeFocused(); // timer must not reclaim focus
      await stop.click();
      await expect.poll(() => releases.length).toBe(1);
      await browserDraft(page, "等待结果时我正在输入，没有答应。");
      await draft.evaluate((el: HTMLTextAreaElement) =>
        el.setSelectionRange(3, 7, "backward"),
      );
      const expected = await selectionOf(page);
      releases[0]();
      const review = page.getByLabel("检查并修改转写文字", { exact: true });
      await review.waitFor();
      await expect(draft).toBeFocused();
      assert.deepEqual(await selectionOf(page), expected);
      await expect(draft).toHaveValue("等待结果时我正在输入，没有答应。");
      await page
        .getByRole("button", { name: "取消这段录音", exact: true })
        .click();
      await expect(
        page.getByRole("button", { name: "用语音写几句", exact: true }),
      ).toBeVisible();
      await page
        .getByRole("button", { name: "用语音写几句", exact: true })
        .click();
      await stop.waitFor();
      await delay(500);
      await stop.click();
      await expect.poll(() => releases.length).toBe(2);
      await page.getByRole("button", { name: "← 来信盒", exact: true }).click();
      const inbox = page
        .getByRole("button", { name: "来信盒", exact: true })
        .last();
      await inbox.focus();
      const responseReceived = page.waitForResponse((r) =>
        r.url().endsWith("/transcribe"),
      );
      releases[1]();
      await (await responseReceived).finished();
      await page.evaluate(
        () =>
          new Promise<void>((r) =>
            requestAnimationFrame(() => requestAnimationFrame(() => r())),
          ),
      );
      await expect(inbox).toBeFocused();
      await expect(page.locator("#response")).toHaveCount(0);
      await expect(review).toHaveCount(0);
      assert.equal(
        (await browserStoredDraft(page, user)).text,
        "等待结果时我正在输入，没有答应。",
      );
      assert.equal(
        Number(
          (
            await admin.query(
              "SELECT count(*) n FROM cloud_responses WHERE account_id=$1",
              [user.account],
            )
          ).rows[0].n,
        ),
        0,
      );
      mark("V38", {
        timerDoesNotStealFocus: true,
        asyncReviewPreservesActiveTypingAndSelection: true,
        lateResultAfterLeaveDoesNotRefocus: true,
        controlledActualHttpResponseHold: true,
        noAutoSend: true,
      });
    } finally {
      releases.forEach((r) => r());
      await browser.close();
      await bridge.close();
    }
  },
);

test(
  "V39 real 320/390/1280 and 200-percent text retain whole brand, button hierarchy and reachable controls",
  { timeout: 90000 },
  async () => {
    const browser = await chromium.launch({ headless: true });
    const layouts: object[] = [];
    try {
      for (const [width, scale] of [
        [320, 1],
        [390, 1],
        [1280, 1],
        [320, 2],
        [390, 2],
      ]) {
        const user = await seed();
        process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
        const bridge = await voiceHttp(user.token, { syntheticMic: true });
        const context = await browser.newContext({
          viewport: {
            width,
            height: width === 320 ? 800 : width === 390 ? 844 : 900,
          },
        });
        const page = await context.newPage();
        page.setDefaultTimeout(10000);
        try {
          await browserReply(page, bridge.url);
          await browserDraft(page, "原稿保留，确认后才填入。");
          await browserVoiceReview(page);
          let fontScale: unknown = null;
          if (scale === 2)
            fontScale = await page.evaluate(() => {
              const snapshots = [
                ...document.querySelectorAll<HTMLElement>("html, body, body *"),
              ].map((el) => ({
                el,
                size: parseFloat(getComputedStyle(el).fontSize),
              }));
              const inputBefore = parseFloat(
                getComputedStyle(document.querySelector("#response")!).fontSize,
              );
              const brandBefore = parseFloat(
                getComputedStyle(document.querySelector(".e4-product-brand")!)
                  .fontSize,
              );
              for (const { el, size } of snapshots)
                if (Number.isFinite(size)) el.style.fontSize = `${size * 2}px`;
              return {
                method:
                  "all existing computed font sizes doubled; no zoom or viewport shrink",
                inputBefore,
                inputAfter: parseFloat(
                  getComputedStyle(document.querySelector("#response")!)
                    .fontSize,
                ),
                brandBefore,
                brandAfter: parseFloat(
                  getComputedStyle(document.querySelector(".e4-product-brand")!)
                    .fontSize,
                ),
              };
            });
          await page.mouse.move(0, 0);
          const layout = await page.evaluate(() => {
            const brand =
              document.querySelector<HTMLElement>(".e4-product-brand")!;
            const range = document.createRange();
            range.selectNodeContents(brand);
            const primary = document.querySelector<HTMLButtonElement>(
              ".e4-voice .e4-voice-primary",
            )!;
            const cancel = [
              ...document.querySelectorAll<HTMLButtonElement>(
                ".e4-voice button",
              ),
            ].find((b) => b.textContent === "取消这段录音")!;
            const measure = (el: HTMLElement) => {
              const r = el.getBoundingClientRect(),
                s = getComputedStyle(el);
              return {
                x: r.x,
                right: r.right,
                height: r.height,
                background: s.backgroundColor,
                color: s.color,
                type: (el as HTMLButtonElement).type,
                font: s.fontSize,
              };
            };
            const horizontal = [
              ...document.querySelectorAll<HTMLElement>(
                ".e4-product-header,.e4-account-controls,.e3-app-shell>main,.e4-voice,.e4-voice textarea,.e4-voice button,#response",
              ),
            ].map((el) => ({
              tag: el.tagName,
              text: (el.textContent || "").slice(0, 25),
              width: el.clientWidth,
              scroll: el.scrollWidth,
              x: el.getBoundingClientRect().x,
              right: el.getBoundingClientRect().right,
            }));
            return {
              brand: {
                text: brand.textContent,
                rects: [...range.getClientRects()].map((r) => ({
                  y: r.y,
                  width: r.width,
                })),
                font: getComputedStyle(brand).fontSize,
                whiteSpace: getComputedStyle(brand).whiteSpace,
              },
              primary: measure(primary),
              cancel: measure(cancel),
              horizontal,
              documentOverflow:
                document.documentElement.scrollWidth > innerWidth,
            };
          });
          assert.equal(layout.brand.text, "有猫来信");
          assert.equal(layout.brand.rects.length, 1);
          assert.equal(layout.brand.whiteSpace, "nowrap");
          assert.equal(layout.documentOverflow, false);
          for (const el of layout.horizontal) {
            assert.ok(
              el.scroll <= el.width + 1,
              `${width}/${scale} ${el.tag} horizontal clip`,
            );
            assert.ok(el.x >= -1 && el.right <= width + 1);
          }
          assert.equal(layout.primary.background, "rgb(166, 83, 47)");
          assert.equal(layout.primary.color, "rgb(255, 252, 246)");
          assert.equal(layout.cancel.background, "rgba(0, 0, 0, 0)");
          assert.equal(layout.primary.type, "button");
          assert.equal(layout.cancel.type, "button");
          assert.ok(layout.primary.height >= 44 && layout.cancel.height >= 44);
          if (scale === 2) {
            assert.equal(
              (fontScale as any).inputAfter,
              (fontScale as any).inputBefore * 2,
            );
            assert.equal(
              (fontScale as any).brandAfter,
              (fontScale as any).brandBefore * 2,
            );
          }
          await page.evaluate(() => {
            document.querySelector<HTMLElement>(
              ".e3-app-shell>main",
            )!.scrollTop = 0;
          });
          const name = `${width}-text${scale * 100}`;
          await page.screenshot({
            path: join(
              process.env.E4_VALIDATION_EVIDENCE!,
              `voice-v06-${name}-header.png`,
            ),
          });
          await page.evaluate(() => {
            const main =
              document.querySelector<HTMLElement>(".e3-app-shell>main")!;
            const first = document.querySelector<HTMLElement>(
              ".e4-voice .e4-voice-primary",
            )!;
            const last = [
              ...document.querySelectorAll<HTMLElement>(".e4-voice button"),
            ].find((b) => b.textContent === "取消这段录音")!;
            const a = first.getBoundingClientRect(),
              b = last.getBoundingClientRect(),
              m = main.getBoundingClientRect();
            main.scrollTop +=
              a.top -
              m.top -
              Math.max(0, (main.clientHeight - (b.bottom - a.top)) / 2);
          });
          await expect(
            page.getByRole("button", { name: "追加到原草稿", exact: true }),
          ).toBeInViewport({ ratio: 1 });
          await expect(
            page.getByRole("button", { name: "取消这段录音", exact: true }),
          ).toBeInViewport({ ratio: 1 });
          await page.screenshot({
            path: join(
              process.env.E4_VALIDATION_EVIDENCE!,
              `voice-v06-${name}-controls.png`,
            ),
          });
          layouts.push({ width, scale, layout, fontScale });
          await page
            .getByRole("button", { name: "取消这段录音", exact: true })
            .click();
          await expect(page.locator("#response")).toBeFocused();
        } finally {
          await context.close();
          await bridge.close();
        }
      }
      await writeFile(
        join(process.env.E4_VALIDATION_EVIDENCE!, "v06-layouts.json"),
        JSON.stringify(layouts, null, 2),
      );
      mark("V39", {
        viewports: [320, 390, 1280],
        text200At: [320, 390],
        actualComputedFontsDoubled: true,
        brandOneUnbrokenLine: true,
        noHorizontalOverflowOrControlClip: true,
        brownPrimaryAndOutlinedCancel: true,
        min44px: true,
        screenshots: "voice-v06-*-header.png + voice-v06-*-controls.png",
        realDeviceTextScaling: false,
      });
    } finally {
      await browser.close();
    }
  },
);

test("V40 real-mode storage rejects disk paths and synthetic backend requires explicit test scope", async () => {
  const saved = {
    storage: process.env.E4_VOICE_STORAGE,
    nonce: process.env.E4_VALIDATION_LOCAL_NONCE,
    payload: process.env.E4_VOICE_PAYLOAD_DIRECTORY,
  };
  try {
    process.env.E4_VOICE_STORAGE = "tmpfs-private-v1";
    process.env.E4_VOICE_PAYLOAD_DIRECTORY = process.env.E4_VOICE_TEST_PAYLOAD_ROOT;
    assert.equal((await voiceCapabilities(a.account)).available, false);
    await assert.rejects(createVoice(a.identity, input(a)));
    process.env.E4_VOICE_STORAGE = "synthetic-files-v1";
    delete process.env.E4_VALIDATION_LOCAL_NONCE;
    assert.equal((await voiceCapabilities(a.account)).available, false);
    await assert.rejects(configuredVoicePayloadStore());
  } finally {
    if (saved.storage === undefined) delete process.env.E4_VOICE_STORAGE;
    else process.env.E4_VOICE_STORAGE = saved.storage;
    if (saved.nonce === undefined) delete process.env.E4_VALIDATION_LOCAL_NONCE;
    else process.env.E4_VALIDATION_LOCAL_NONCE = saved.nonce;
    if (saved.payload === undefined) delete process.env.E4_VOICE_PAYLOAD_DIRECTORY;
    else process.env.E4_VOICE_PAYLOAD_DIRECTORY = saved.payload;
  }
  mark("V40", { actualHost: process.platform, noProductionDiskFallback: true, linuxNoswapTested: false });
});

test("V41 durable byte reservations serialize concurrent claims and release after cancellation", async () => {
  const c = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([a.account, b.account, c.account]);
  const expectedBytes = 5 * 1024 * 1024;
  const jobs = await Promise.all([a, b, c].map(user => createVoice(user.identity, {
    ...input(user), bytes: expectedBytes,
  })));
  // 10MiB/job reserves both upload and bounded media-workspace capacity.
  await admin.query("UPDATE private_voice_budget SET max_bytes=$1 WHERE singleton", [20 * 1024 * 1024]);
  const outcomes = await Promise.allSettled([
    claimVoiceUpload(a.identity, jobs[0].id),
    claimVoiceUpload(b.identity, jobs[1].id),
    claimVoiceUpload(c.identity, jobs[2].id),
  ]);
  assert.equal(outcomes.filter(result => result.status === "fulfilled").length, 2);
  assert.equal(Number((await admin.query("SELECT sum(reserved_bytes) AS bytes FROM private_voice_jobs")).rows[0].bytes),
    4 * expectedBytes);
  const winner = outcomes.findIndex(result => result.status === "fulfilled");
  const loser = outcomes.findIndex(result => result.status === "rejected");
  await finishVoice([a, b, c][winner].identity, jobs[winner].id, "cancel");
  assert.ok((await claimVoiceUpload([a, b, c][loser].identity, jobs[loser].id)).lease);
  assert.equal(Number((await admin.query("SELECT sum(reserved_bytes) AS bytes FROM private_voice_jobs")).rows[0].bytes),
    4 * expectedBytes);
  mark("V41", { actualConcurrentPgTransactions: 3, accepted: 2, durableReservationBytes: 4 * expectedBytes,
    cancellationReleasesReservation: true, uploadedBytes: 0 });
});

test("V42 orphan filesystem bytes remain charged even with no database payload pointer", async () => {
  const store = await configuredVoicePayloadStore();
  const stage = await store.stage(randomUUID(), "audio", Buffer.alloc(10 * 1024 * 1024, 7));
  const orphan = await store.publish(stage);
  try {
    await admin.query("UPDATE private_voice_budget SET max_bytes=$1 WHERE singleton", [10 * 1024 * 1024]);
    const j = await createVoice(a.identity, input(a));
    assert.equal(Number((await admin.query("SELECT sum(audio_bytes+text_bytes) AS bytes FROM private_voice_jobs")).rows[0].bytes), 0);
    await assert.rejects(claimVoiceUpload(a.identity, j.id), /繁忙|空间|容量/);
    assert.equal(Number((await admin.query("SELECT reserved_bytes FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0].reserved_bytes), 0);
  } finally {
    await store.remove(orphan);
    await store.discard(stage);
  }
  mark("V42", { actualSyntheticFilesystemOrphanBytes: 10 * 1024 * 1024, databasePointers: 0,
    noQuotaBypassFromOrphan: true, linuxEnospcTested: false });
});

test("V43 stale or repeatedly failed cleanup closes new recordings while existing ordinary text stays usable", async () => {
  const user = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
  await admin.query("UPDATE private_voice_budget SET last_cleanup_at=clock_timestamp()-interval '181 seconds' WHERE singleton");
  assert.equal((await availableVoice(user.identity)).available, false);
  await assert.rejects(createVoice(user.identity, input(user)));
  await cleanupPrivateVoice([user.account]);
  assert.equal((await availableVoice(user.identity)).available, true);
  await admin.query("UPDATE private_voice_budget SET cleanup_failures=3,last_cleanup_error='SYNTHETIC_CLEANUP_FAILURE' WHERE singleton");
  assert.equal((await availableVoice(user.identity)).available, false);
  await assert.rejects(createVoice(user.identity, input(user)));
  const text = "清理暂停时，我仍可以用文字回应。";
  const response = await v1Post(new NextRequest(`${process.env.APP_ORIGIN}/api/e4/v1/letters/${encodeURIComponent(user.letter)}/respond`, {
    method: "POST",
    headers: { origin: process.env.APP_ORIGIN!, cookie: `cat_account_session=${user.token}`,
      "x-catletters-account": user.account, "content-type": "application/json" },
    body: JSON.stringify({ key: randomUUID(), text, expectedResponseId: null }),
  }));
  assert.equal(response.status, 200);
  assert.equal((await admin.query("SELECT text FROM cloud_response_revisions WHERE account_id=$1", [user.account])).rows[0].text, text);
  await cleanupPrivateVoice([user.account]);
  assert.equal((await availableVoice(user.identity)).available, true);
  mark("V43", { staleAfterSeconds: 180, consecutiveFailureThreshold: 3, actualOrdinarySendWhileVoiceClosed: true,
    independentCleanupRecovers: true });
});

test("V44 independent cleanup removes old orphan files while preserving current pointers and active stages", async () => {
  const { utimes } = await import("node:fs/promises");
  const store = await configuredVoicePayloadStore();
  const current = await uploaded(a);
  const inFlight = await createVoice(b.identity, input(b));
  await claimVoiceUpload(b.identity, inFlight.id);
  const protectedStage = await store.stage(inFlight.id, "audio", wav());
  const orphanStage = await store.stage(randomUUID(), "audio", wav());
  const orphan = await store.publish(orphanStage);
  const entries = await store.list();
  for (const entry of entries.filter(entry => entry.ref?.jobId === inFlight.id || entry.ref?.jobId === orphan.jobId))
    await utimes(join(store.root, entry.name), new Date(Date.now() - 180_000), new Date(Date.now() - 180_000));
  try {
    await cleanupPrivateVoice([a.account, b.account]);
    assert.ok((await bytes(current.id)) > 0, "A current metadata-bound object remains available");
    assert.ok((await physicalEntries(inFlight.id)).some(entry => entry.staged), "A valid upload lease protects its old-mtime stage");
    await assert.rejects(store.read(orphan));
    await finishVoice(b.identity, inFlight.id, "cancel");
    await cleanupPrivateVoice([a.account, b.account]);
    assert.equal((await physicalEntries(inFlight.id)).length, 0);
    await assert.rejects(store.publish(protectedStage));
  } finally {
    await store.remove(orphan).catch(() => {});
    await store.discard(orphanStage);
    await store.discard(protectedStage);
  }
  mark("V44", { realSyntheticFilesystemOrphanRemoved: true, currentPointerPreserved: true,
    leaseProtectsOldMtimeStage: true, cancellationPreventsLatePublish: true });
});

test("V45 audio and unconfirmed transcript never enter actual PostgreSQL query parameters or payload tables", async () => {
  const marker = `TMPFS_UNCONFIRMED_${randomUUID()}`;
  const originalConnect = pool.connect;
  let bufferParameters = 0, markerParameters = 0, queries = 0;
  (pool as any).connect = async function () {
    const client = await (originalConnect as unknown as () => Promise<pg.PoolClient>).call(pool);
    const originalQuery = client.query, originalRelease = client.release;
    (client as any).query = function (...args: any[]) {
      queries++;
      const values = typeof args[0] === "object" ? args[0]?.values : args[1];
      if (Array.isArray(values)) for (const value of values) {
        if (Buffer.isBuffer(value)) bufferParameters++;
        if (typeof value === "string" && value.includes(marker)) markerParameters++;
      }
      return (originalQuery as any).apply(client, args);
    };
    (client as any).release = function (...args: any[]) {
      client.query = originalQuery;
      client.release = originalRelease;
      return (originalRelease as any).apply(client, args);
    };
    return client;
  };
  let jobId = "";
  try {
    const j = await uploaded();
    jobId = j.id;
    const result = await transcribeVoice(a.identity, j.id, {
      mode: "synthetic-v1", transcribe: async () => ({ text: marker }),
    });
    assert.equal(result.text, marker);
    assert.ok(queries > 0);
    assert.equal(bufferParameters, 0);
    assert.equal(markerParameters, 0);
  } finally {
    pool.connect = originalConnect;
  }
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM private_voice_payload")).rows[0].n, 0);
  await assert.rejects(pool.query("INSERT INTO private_voice_payload(job_id,audio) VALUES($1,$2)", [jobId, wav()]),
    (error: any) => error.code === "42501", "Runtime has no SQL payload privilege");
  await assert.rejects(admin.query("INSERT INTO private_voice_payload(job_id,audio) VALUES($1,$2)", [jobId, wav()]),
    (error: any) => error.code === "23514", "Legacy payload table rejects even owner writes");
  const textRef = await payloadRef(jobId, "text");
  assert.ok(textRef);
  assert.equal((await (await configuredVoicePayloadStore()).read(textRef)).toString("utf8"), marker);
  mark("V45", { actualBusinessPgQueriesObserved: queries, audioBufferSqlParameters: bufferParameters,
    unconfirmedTextSqlParameters: markerParameters, runtimeAndOwnerPayloadInsertRejected: true,
    contentsPrinted: false });
});

test("V46 payload mount loss plus fresh Node process fails old jobs and retains ordinary database records", async () => {
  const { rm, mkdir } = await import("node:fs/promises");
  const j = await uploaded();
  await transcribeVoice(a.identity, j.id);
  const store = await configuredVoicePayloadStore();
  const oldEpoch = store.epoch;
  const before = JSON.stringify((await admin.query("SELECT * FROM cloud_responses ORDER BY id")).rows);
  await rm(store.root, { recursive: true, force: true });
  await mkdir(store.root, { mode: 0o700 });
  const source = `import {readVoice} from './src/server/voice-service.ts';
import {pool} from './src/server/db.ts';
import {closeLifecycleProvider} from './src/server/lifecycle-provider.ts';
try {const job=await readVoice(${JSON.stringify(a.identity)},${JSON.stringify(j.id)});console.log(JSON.stringify({status:job.status,error:job.error,hasText:'text' in job}));}
finally {await pool.end();await closeLifecycleProvider();}`;
  const child = await promisify(execFile)(process.execPath, ["--import", "tsx", "--input-type=module", "-e", source],
    { env: process.env, timeout: 20_000, maxBuffer: 32768 });
  const result = JSON.parse(child.stdout.trim().split("\n").at(-1)!);
  assert.deepEqual(result, { status: "FAILED", error: "AUDIO_LOST", hasText: false });
  assert.notEqual((await configuredVoicePayloadStore()).epoch, oldEpoch);
  await assert.rejects(store.healthCheck());
  await assert.rejects(claimVoiceUpload(a.identity, j.id));
  const meta = (await admin.query("SELECT reserved_bytes,lease_token,audio_version,text_version FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0];
  assert.equal(Number(meta.reserved_bytes), 0);
  assert.equal(meta.lease_token, null);
  assert.equal(meta.audio_version, null);
  assert.equal(meta.text_version, null);
  assert.equal(JSON.stringify((await admin.query("SELECT * FROM cloud_responses ORDER BY id")).rows), before);
  mark("V46", { actualPayloadDirectoryLoss: true, actualFreshNodeProcess: true,
    oldEpochRejected: true, reservationsReleased: true, ordinaryBusinessRecordsUnchanged: true,
    linuxTmpfsUnmountPerformed: false, automaticAsrCalls: 0 });
});

test("V47 filesystem publication followed by actual PostgreSQL rollback is compensated without readable orphan", async () => {
  const trigger = async (jobId: string, status: "UPLOADED" | "READY") => {
    await admin.query(`CREATE OR REPLACE FUNCTION public.v07_synthetic_publication_rollback() RETURNS trigger LANGUAGE plpgsql AS $$
      BEGIN IF NEW.id='${jobId}'::uuid AND NEW.status='${status}' THEN
        RAISE EXCEPTION 'SYNTHETIC_PUBLICATION_ROLLBACK';
      END IF; RETURN NEW; END $$`);
    await admin.query("CREATE TRIGGER v07_synthetic_publication_rollback BEFORE UPDATE OF status ON public.private_voice_jobs FOR EACH ROW EXECUTE FUNCTION public.v07_synthetic_publication_rollback()");
  };
  const clear = async () => {
    await admin.query("DROP TRIGGER IF EXISTS v07_synthetic_publication_rollback ON public.private_voice_jobs");
    await admin.query("DROP FUNCTION IF EXISTS public.v07_synthetic_publication_rollback()");
  };
  const audio = wav();
  const first = await createVoice(a.identity, input(a, audio));
  try {
    await trigger(first.id, "UPLOADED");
    const response = await POST(new NextRequest(`${process.env.APP_ORIGIN}/api/e4/voice/jobs/${first.id}/upload`, {
      method: "POST", headers: {
        origin: process.env.APP_ORIGIN!, cookie: `cat_account_session=${a.token}`,
        "x-catletters-account": a.account, "content-type": "application/octet-stream",
      }, body: new Uint8Array(audio),
    }));
    assert.equal(response.status, 503);
    assert.ok(!(await response.text()).includes("SYNTHETIC_PUBLICATION_ROLLBACK"));
    const meta = (await admin.query("SELECT status,audio_version,text_version,reserved_bytes FROM private_voice_jobs WHERE id=$1", [first.id])).rows[0];
    assert.equal(meta.status, "FAILED");
    assert.equal(meta.audio_version, null);
    assert.equal(meta.text_version, null);
    assert.equal(Number(meta.reserved_bytes), 0);
    assert.equal((await physicalEntries(first.id)).length, 0);
  } finally { await clear(); }
  const second = await uploaded();
  try {
    await trigger(second.id, "READY");
    await assert.rejects(transcribeVoice(a.identity, second.id, {
      mode: "synthetic-v1", transcribe: async () => ({ text: "这个未提交版本不可读" }),
    }));
    const meta = (await admin.query("SELECT status,audio_version,text_version,reserved_bytes FROM private_voice_jobs WHERE id=$1", [second.id])).rows[0];
    assert.equal(meta.status, "FAILED");
    assert.ok(meta.audio_version);
    assert.equal(meta.text_version, null);
    assert.equal(Number(meta.reserved_bytes), 0);
    const files = await physicalEntries(second.id);
    assert.equal(files.length, 1);
    assert.equal(files[0].ref?.kind, "audio");
    assert.equal((await readVoice(a.identity, second.id)).text, undefined);
  } finally { await clear(); }
  assert.equal((await transcribeVoice(a.identity, second.id)).status, "READY");
  mark("V47", { actualPgTriggerInjectedAfterFilesystemPublish: true, audioAndTextRollbackCovered: true,
    audioUploadFailureReleasesReservation: true, textFailureKeepsOnlyOriginalAudio: true,
    noSyntheticInternalErrorReturnedToBrowser: true, explicitRetryStillWorks: true,
    simulatedOsProcessCrash: false });
});

test("V48 actual killed publisher leaves no committed pointer; expired reservation and orphan are reclaimed", async () => {
  const { utimes } = await import("node:fs/promises");
  const j = await createVoice(a.identity, input(a));
  await claimVoiceUpload(a.identity, j.id);
  const businessBefore = JSON.stringify((await admin.query("SELECT * FROM cloud_responses ORDER BY id")).rows);
  // A separate process follows the publication ordering with the real store and
  // real row/budget locks, then dies at the filesystem/SQL commit boundary.
  const childCode = `import {configuredVoicePayloadStore} from './src/server/voice-payload-store.ts';
import {transaction} from './src/server/db.ts';
await transaction(async db=>{
 await db.query('SELECT id FROM private_voice_jobs WHERE id=$1 FOR UPDATE',[${JSON.stringify(j.id)}]);
 await db.query('SELECT singleton FROM private_voice_budget WHERE singleton FOR UPDATE');
 const store=await configuredVoicePayloadStore();
 const staged=await store.stage(${JSON.stringify(j.id)},'audio',Buffer.from(${JSON.stringify(wav().toString("base64"))},'base64'));
 await store.publish(staged);
 await new Promise(resolve=>process.stdout.write('SYNTHETIC_PUBLISHED_BEFORE_KILL\\n',resolve));
 process.kill(process.pid,'SIGKILL');
});`;
  await assert.rejects(promisify(execFile)(process.execPath,
    ["--import", "tsx", "--input-type=module", "-e", childCode],
    { env: process.env, timeout: 20_000, maxBuffer: 32768 }),
    (error: any) => error.signal === "SIGKILL" && error.stdout.includes("SYNTHETIC_PUBLISHED_BEFORE_KILL"));
  const metadata = (await admin.query("SELECT status,audio_version,text_version,reserved_bytes FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0];
  assert.equal(metadata.status, "UPLOADING");
  assert.equal(metadata.audio_version, null);
  assert.equal(metadata.text_version, null);
  assert.ok(Number(metadata.reserved_bytes) > 0);
  const entries = await physicalEntries(j.id);
  assert.equal(entries.length, 1, "Crash left an actual published file outside the SQL transaction");
  assert.equal(entries[0].staged, false);
  assert.equal((await readVoice(a.identity, j.id)).text, undefined);
  const store = await configuredVoicePayloadStore();
  await utimes(join(store.root, entries[0].name), new Date(Date.now() - 180_000), new Date(Date.now() - 180_000));
  await admin.query("UPDATE private_voice_jobs SET lease_until=clock_timestamp()-interval '1 second' WHERE id=$1", [j.id]);
  await cleanupPrivateVoice([a.account]);
  const after = (await admin.query("SELECT status,reserved_bytes,lease_token FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0];
  assert.equal(after.status, "FAILED");
  assert.equal(Number(after.reserved_bytes), 0);
  assert.equal(after.lease_token, null);
  assert.equal((await physicalEntries(j.id)).length, 0);
  assert.equal(JSON.stringify((await admin.query("SELECT * FROM cloud_responses ORDER BY id")).rows), businessBefore);
  mark("V48", { actualFreshPublisherProcessKilled: "SIGKILL", actualRowAndBudgetLocksHeld: true,
    actualFilesystemPublicationBeforeDeath: true, committedPayloadPointers: 0,
    independentCleanupReclaimsOrphanAndReservation: true, ordinaryRecordsUnchanged: true,
    providerCalls: 0, linuxTmpfsCrashTested: false });
});

async function v07BrowserFixture(width = 390) {
  const user = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([user.account]);
  const bridge = await voiceHttp(user.token, { syntheticMic: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width, height: 844 } });
  page.setDefaultTimeout(10_000);
  const errors: string[] = [], requests: { path: string; method: string }[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => {
    if (!["error", "warning"].includes(message.type())) return;
    const expectedInjectedVoiceError = message.location().url.includes("/api/e4/voice/") &&
      /404|409|503|ERR_FAILED/.test(message.text());
    if (!expectedInjectedVoiceError) errors.push(message.text());
  });
  page.on("request", request => {
    const path = new URL(request.url()).pathname;
    if (path.startsWith("/api/e4/voice/") || path.endsWith("/respond"))
      requests.push({ path, method: request.method() });
  });
  const count = (end: string) => requests.filter(r => r.method === "POST" && r.path.endsWith(end)).length;
  return { user, bridge, browser, page, errors, requests, count,
    close: async () => { await browser.close(); await bridge.close(); } };
}
async function stopSyntheticRecording(page: Page) {
  const stop = page.getByRole("button", { name: "停止并转成文字", exact: true });
  await expect(stop).toBeVisible();
  await delay(500);
  await stop.click();
}

test("V49 browser AUDIO_LOST drops the old task and allows explicit new recording without automatic send", { timeout: 45_000 }, async () => {
  const f = await v07BrowserFixture();
  let oldId = "", injected = false;
  await f.page.route("**/api/e4/voice/jobs/*", async route => {
    if (route.request().method() === "GET" && !injected) {
      injected = true;
      oldId = new URL(route.request().url()).pathname.split("/").at(-1)!;
      await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({
        id: oldId, status: "FAILED", error: "AUDIO_LOST", mode: "synthetic-v1",
        expiresAt: new Date(Date.now() + 60_000).toISOString(),
      }) });
    } else await route.continue();
  });
  try {
    const draft = await browserReply(f.page, f.bridge.url);
    await browserDraft(f.page, "原草稿不因临时录音丢失而改变。");
    await f.page.getByRole("button", { name: "用语音写几句", exact: true }).click();
    await stopSyntheticRecording(f.page);
    await expect(f.page.getByText("这段临时录音已失效，无法继续转写。可以重新录音或直接打字。", { exact: true })).toBeVisible();
    await expect(f.page.getByRole("button", { name: "重试处理这段录音", exact: true })).toHaveCount(0);
    await expect(f.page.getByRole("button", { name: "继续打字", exact: true })).toBeEnabled();
    await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
    assert.ok(oldId);
    assert.equal(f.requests.filter(r => r.path.includes(`/${oldId}/`) && /\/(upload|transcribe)$/.test(r.path)).length, 0);
    assert.equal(await draft.inputValue(), "原草稿不因临时录音丢失而改变。");
    await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, "voice-v07-audio-lost.png"), fullPage: true });
    await f.page.getByRole("button", { name: "重新录音", exact: true }).click();
    await stopSyntheticRecording(f.page);
    await expect(f.page.getByLabel("检查并修改转写文字", { exact: true })).toBeVisible();
    assert.equal(f.count("/upload"), 1);
    assert.equal(f.count("/transcribe"), 1);
    assert.equal(f.requests.filter(r => r.path.includes(`/${oldId}/`) && /\/(upload|transcribe)$/.test(r.path)).length, 0);
    await f.page.getByRole("button", { name: "取消这段录音", exact: true }).click();
    await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
    assert.equal(f.count("/respond"), 0);
    assert.equal((await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [f.user.account])).rows[0].n, 0);
    assert.deepEqual(f.errors, []);
    mark("V49", { uiStatusResponseInjected: "AUDIO_LOST", actualNewRecordingAndHttp: true,
      oldTaskUploads: 0, oldTaskTranscriptions: 0, newTaskTranscriptions: 1, automaticSends: 0,
      originalDraftPreserved: true, linuxMountLossTestedHere: false });
  } finally { await f.close(); }
});

test("V57 terminal voice loss releases ordinary send and offers local typing without retrying the old task", { timeout: 90_000 }, async () => {
  const variants: object[] = [];
  for (const terminal of ["AUDIO_LOST", "EXPIRED", "CANCELLED", "CONFIRMED"]) {
    const f = await v07BrowserFixture(terminal === "EXPIRED" ? 320 : 390);
    let oldId = "";
    await f.page.route("**/api/e4/voice/jobs/*", async route => {
      if (route.request().method() !== "GET") return route.continue();
      oldId = new URL(route.request().url()).pathname.split("/").at(-1)!;
      await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({
        id: oldId, status: terminal === "AUDIO_LOST" ? "FAILED" : terminal,
        error: ["AUDIO_LOST", "EXPIRED"].includes(terminal) ? terminal : null,
        mode: "synthetic-v1", expiresAt: new Date(Date.now() + 60_000).toISOString(),
      }) });
    });
    try {
      const draft = await browserReply(f.page, f.bridge.url);
      const original = `失效后保留原稿：${terminal}，我没有答应。`;
      await browserDraft(f.page, original);
      await draft.evaluate(el => (el as HTMLTextAreaElement).setSelectionRange(3, 8));
      await f.page.getByRole("button", { name: "用语音写几句", exact: true }).click();
      await stopSyntheticRecording(f.page);
      const typing = f.page.getByRole("button", { name: "继续打字", exact: true });
      const rerecord = f.page.getByRole("button", { name: "重新录音", exact: true });
      const send = f.page.getByRole("button", { name: "送出去", exact: true });
      await expect(typing).toBeEnabled();
      await expect(rerecord).toBeEnabled();
      await expect(send).toBeEnabled();
      await expect(draft).toHaveValue(original);
      await expect(f.page.getByRole("button", { name: "重试处理这段录音", exact: true })).toHaveCount(0);
      await expect(f.page.getByRole("button", { name: "取消这段录音", exact: true })).toHaveCount(0);
      assert.equal(f.count("/jobs"), 1);
      assert.equal(f.count("/upload"), 0);
      assert.equal(f.count("/transcribe"), 0);
      assert.equal(f.count("/respond"), 0);
      if (terminal === "EXPIRED") {
        const scale = await f.page.evaluate(() => {
          const sizes = [...document.querySelectorAll<HTMLElement>("body,body *")]
            .map(el => ({ el, size: parseFloat(getComputedStyle(el).fontSize) }));
          for (const { el, size } of sizes) if (Number.isFinite(size)) el.style.fontSize = `${size * 2}px`;
          const main = document.querySelector("main")!;
          return { inputFont: getComputedStyle(document.querySelector("#response")!).fontSize,
            width: innerWidth, scrollWidth: document.documentElement.scrollWidth,
            mainWidth: main.clientWidth, mainScrollWidth: main.scrollWidth };
        });
        assert.equal(scale.inputFont, "32px");
        assert.ok(scale.scrollWidth <= scale.width);
        assert.ok(scale.mainScrollWidth <= scale.mainWidth);
        for (const button of [rerecord, typing]) {
          await button.scrollIntoViewIfNeeded();
          await expect(button).toBeInViewport();
          assert.ok(await button.evaluate(el => {
            const r = el.getBoundingClientRect();
            return r.height >= 44 && r.left >= 0 && r.right <= innerWidth &&
              el === document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
          }));
        }
        await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, "voice-v08-expired-320-text200.png") });
      } else if (terminal === "AUDIO_LOST") {
        await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, "voice-v08-audio-lost-send-unlocked.png"), fullPage: true });
      }
      const requestsBeforeTyping = f.requests.length;
      await typing.click();
      await expect(draft).toBeFocused();
      await expect(draft).toHaveValue(original);
      assert.deepEqual(await draft.evaluate(el => {
        const input = el as HTMLTextAreaElement;
        return [input.selectionStart, input.selectionEnd];
      }), [3, 8]);
      await expect(send).toBeEnabled();
      await expect(f.page.locator('.e4-voice [role="status"]')).toHaveText("已回到文字草稿，原稿保留，尚未发送。");
      await delay(200);
      assert.equal(f.requests.length, requestsBeforeTyping, "Typing fallback makes no voice or send request");
      assert.equal(f.count("/cancel"), 0);
      if (terminal === "EXPIRED") {
        await send.click();
        await expect.poll(async () => (await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [f.user.account])).rows[0].n).toBe(1);
        assert.equal(f.count("/respond"), 1);
      }
      assert.equal(f.requests.filter(r => r.path.includes(`/${oldId}/`) && /\/(upload|transcribe|cancel|confirm)$/.test(r.path)).length, 0);
      assert.deepEqual(f.errors, []);
      variants.push({ terminal, originalDraftAndSelectionPreserved: true, ordinarySendImmediatelyEnabled: true,
        oldTaskMutations: 0, typingRequests: 0, explicitOrdinarySend: terminal === "EXPIRED", realDeviceTested: false });
    } finally { await f.close(); }
  }
  mark("V57", { variants, dtoInjectedOnly: true, actualOrdinarySendToFreshLocalPg: true,
    syntheticPcm: true, realMicOrAsr: false, browserPlugin: "Browser plugin not available; existing Playwright used" });
});

test("V58 retryable voice failure keeps the send lock while available and requires explicit cancellation", { timeout: 45_000 }, async () => {
  const f = await v07BrowserFixture();
  await f.page.route("**/api/e4/voice/jobs/*/transcribe", route => route.fulfill({
    status: 409, contentType: "application/json", body: JSON.stringify({ error: "合成暂时失败，请检查后重试。" }),
  }));
  try {
    const draft = await browserReply(f.page, f.bridge.url);
    await browserDraft(f.page, "暂时失败也不能自动丢弃这段录音。");
    await f.page.getByRole("button", { name: "用语音写几句", exact: true }).click();
    await stopSyntheticRecording(f.page);
    const retry = f.page.getByRole("button", { name: "重试处理这段录音", exact: true });
    const send = f.page.getByRole("button", { name: "送出去", exact: true });
    await expect(retry).toBeEnabled();
    await expect(send).toBeDisabled();
    await expect(f.page.getByRole("button", { name: "继续打字", exact: true })).toHaveCount(0);
    await delay(250);
    await expect(send).toBeDisabled();
    assert.equal(f.count("/transcribe"), 1);
    assert.equal(f.count("/respond"), 0);
    await f.page.getByRole("button", { name: "取消这段录音", exact: true }).click();
    await expect(send).toBeEnabled();
    await expect(draft).toHaveValue("暂时失败也不能自动丢弃这段录音。");
    assert.equal(f.count("/cancel"), 1);
    assert.deepEqual(f.errors, []);
    mark("V58", { injectedHttpStatus: 409, refreshedAvailableCaps: true, retryableTakeRemainsLocked: true,
      explicitCancelReleasesSend: true, automaticRetriesOrSends: 0 });
  } finally { await f.close(); }
});

test("V59 refresh loses only unconfirmed review and correct mailbox navigation restores the persisted ordinary draft", { timeout: 45_000 }, async () => {
  const f = await v07BrowserFixture();
  try {
    const draft = await browserReply(f.page, f.bridge.url);
    const original = "刷新后仍需保留的普通文字。";
    await browserDraft(f.page, original);
    await expect.poll(async () => (await browserStoredDraft(f.page, f.user))?.text).toBe(original);
    const review = await browserVoiceReview(f.page);
    await review.fill("这段没有填入草稿，不应跨刷新保存。");
    assert.equal(f.count("/transcribe"), 1);
    await f.page.reload({ waitUntil: "networkidle" });
    // Read drafts can reopen automatically; either visible mailbox control
    // must be used before selecting the letter again.
    const mailbox = f.page.getByRole("button", { name: /来信盒/ }).first();
    const reloadNavigation = await mailbox.textContent();
    await mailbox.click();
    await f.page.getByRole("button", { name: /语音本地验证来信/ }).click();
    const open = f.page.getByRole("button", { name: "给它回信", exact: true });
    await expect(draft.or(open).first()).toBeVisible();
    if (!(await draft.isVisible())) await open.click();
    await expect(draft).toHaveValue(original);
    await expect(review).toHaveCount(0);
    await expect(f.page.getByRole("button", { name: "用语音写几句", exact: true })).toBeVisible();
    await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
    assert.equal(f.count("/transcribe"), 1);
    assert.equal(f.count("/respond"), 0);
    await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, "voice-v08-refresh-ordinary-draft.png"), fullPage: true });
    assert.deepEqual(f.errors, []);
    mark("V59", { actualReloadAndMailboxNavigation: true, reloadNavigation, durableOrdinaryDraftPreserved: true,
      unconfirmedReviewDropped: true, automaticTranscribeOrSend: 0 });
  } finally { await f.close(); }
});

test("V50 browser keeps an editable local review after actual file loss or task expiry and fills draft without ASR resend", { timeout: 75_000 }, async () => {
  const variants: object[] = [];
  for (const variant of ["payload-directory-loss", "task-expiry"]) {
    const f = await v07BrowserFixture();
    try {
      const draft = await browserReply(f.page, f.bridge.url);
      await browserDraft(f.page, "需要保留的原草稿。");
      const review = await browserVoiceReview(f.page);
      const text = "我还没有答应，需要再想一想。";
      await review.fill(text);
      const job = (await admin.query("SELECT id FROM private_voice_jobs WHERE account_id=$1 AND status='READY'", [f.user.account])).rows[0];
      assert.ok(job);
      assert.equal(f.count("/transcribe"), 1);
      if (variant === "payload-directory-loss") {
        const { rm, mkdir } = await import("node:fs/promises");
        const store = await configuredVoicePayloadStore();
        await rm(store.root, { recursive: true, force: true });
        await mkdir(store.root, { mode: 0o700 });
      } else await admin.query("UPDATE private_voice_jobs SET expires_at=clock_timestamp()-interval '1 second' WHERE id=$1", [job.id]);
      await cleanupPrivateVoice([f.user.account]);
      await expect(review).toHaveValue(text);
      await f.page.getByRole("button", { name: "追加到原草稿", exact: true }).click();
      const expected = "需要保留的原草稿。\n" + text;
      await expect(draft).toHaveValue(expected);
      await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
      await expect.poll(async () => (await browserStoredDraft(f.page, f.user))?.text).toBe(expected);
      assert.equal(f.count("/transcribe"), 1);
      assert.equal(f.count("/upload"), 1);
      assert.equal(f.count("/respond"), 0);
      assert.equal((await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [f.user.account])).rows[0].n, 0);
      const continuation = f.page.getByRole("button", { name: "继续打字", exact: true });
      if (await continuation.isVisible()) await continuation.click();
      await expect(draft).toHaveValue(expected);
      await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, `voice-v07-review-${variant}.png`), fullPage: true });
      assert.deepEqual(f.errors, []);
      variants.push({ variant, actualFilesystemOrPgExpiry: true, locallyEditedReviewPreserved: true,
        explicitAppendPersisted: true, uploadCalls: 1, transcribeCalls: 1, automaticSends: 0 });
    } finally { await f.close(); }
  }
  mark("V50", { variants, realMicOrLinuxTested: false });
});

test("V51 browser provider 503 closes retry and new recording despite capability probe failure, ordinary text still sends", { timeout: 50_000 }, async () => {
  const f = await v07BrowserFixture();
  let capabilityCalls = 0;
  await f.page.route("**/api/e4/voice/capabilities", async route => {
    capabilityCalls++;
    if (capabilityCalls === 1) await route.continue();
    else await route.abort("failed");
  });
  await f.page.route("**/api/e4/voice/jobs/*/transcribe", route => route.fulfill({
    status: 503, contentType: "application/json", body: JSON.stringify({ error: "合成故障：转写暂不可用，请继续打字。" }),
  }));
  try {
    const draft = await browserReply(f.page, f.bridge.url);
    await browserDraft(f.page, "语音出错时保留的文字。");
    await f.page.getByRole("button", { name: "用语音写几句", exact: true }).click();
    await stopSyntheticRecording(f.page);
    await expect(f.page.getByText("合成故障：转写暂不可用，请继续打字。", { exact: true })).toBeVisible();
    await expect(f.page.getByRole("button", { name: "重试处理这段录音", exact: true })).toBeDisabled();
    await expect(f.page.getByRole("button", { name: "重新录音", exact: true })).toBeDisabled();
    assert.equal(await draft.inputValue(), "语音出错时保留的文字。");
    assert.equal(f.count("/transcribe"), 1);
    assert.equal(f.count("/respond"), 0);
    await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
    await f.page.getByRole("button", { name: "取消这段录音", exact: true }).click();
    await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
    await expect(f.page.getByRole("button", { name: "用语音写几句", exact: true })).toHaveCount(0);
    // A fresh view before sending exercises a failed initial capabilities request.
    await f.page.unroute("**/api/e4/voice/capabilities");
    await f.page.route("**/api/e4/voice/capabilities", route => route.abort("failed"));
    await browserReply(f.page, f.bridge.url);
    await expect(f.page.locator('.e4-voice [role="status"]')).toHaveText("语音暂不可用，可以直接打字。");
    await expect(f.page.locator(".e4-voice p")).toHaveCount(1);
    await expect(f.page.getByRole("button", { name: "用语音写几句", exact: true })).toHaveCount(0);
    await f.page.getByRole("button", { name: "送出去", exact: true }).click();
    await expect.poll(async () => (await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [f.user.account])).rows[0].n).toBe(1);
    assert.equal(f.count("/respond"), 1);
    assert.equal(f.count("/transcribe"), 1);
    assert.deepEqual(f.errors, []);
    mark("V51", { injectedProviderHttpStatus: 503, capabilityFailureInjected: true,
      retryAndNewRecordingImmediatelyDisabled: true, explicitOrdinarySendSucceeded: true,
      automaticTranscriptionRetry: 0, failedCapabilitySingleNotice: true, realProviderCalled: false });
  } finally { await f.close(); }
});

test("V52 browser cleanup 404/409 offers text escape without repeat loop, disabled notice remains reachable at320 text200", { timeout: 75_000 }, async () => {
  const variants: object[] = [];
  for (const status of [404, 409]) {
    const f = await v07BrowserFixture(status === 409 ? 320 : 390);
    await f.page.route("**/api/e4/voice/jobs/*/cancel", route => route.fulfill({
      status, contentType: "application/json", body: JSON.stringify({ error: "合成状态：清理目标已失效。" }),
    }));
    try {
      const draft = await browserReply(f.page, f.bridge.url);
      const original = "清理尚未确认也要保留的草稿。";
      await browserDraft(f.page, original);
      await browserVoiceReview(f.page);
      await f.page.getByRole("button", { name: "取消这段录音", exact: true }).click();
      await expect(f.page.getByRole("button", { name: "继续打字", exact: true })).toBeVisible();
      await expect(f.page.getByRole("button", { name: "重试清理临时录音", exact: true })).toHaveCount(0);
      await expect(f.page.getByRole("button", { name: "送出去", exact: true })).toBeEnabled();
      await expect(draft).toHaveValue(original);
      await f.page.getByRole("button", { name: "继续打字", exact: true }).click();
      await expect(draft).toBeFocused();
      await expect(draft).toHaveValue(original);
      await delay(250);
      assert.equal(f.count("/cancel"), 1);
      assert.equal(f.count("/respond"), 0);
      await f.page.route("**/api/e4/voice/capabilities", route => route.fulfill({
        status: 200, contentType: "application/json", body: JSON.stringify({
          available: false, mode: "disabled", reason: "disabled", maxMs: 60_000, maxBytes: 10_485_760,
          mimes: ["audio/webm", "audio/ogg", "audio/mp4", "audio/wav"],
        }),
      }));
      await browserReply(f.page, f.bridge.url);
      await expect(f.page.locator('.e4-voice [role="status"]')).toHaveText("语音尚未启用，可以直接打字。");
      await expect(f.page.locator(".e4-voice p")).toHaveCount(1);
      await expect(f.page.getByRole("button", { name: "用语音写几句", exact: true })).toHaveCount(0);
      if (status === 409) {
        const scale = await f.page.evaluate(() => {
          const sizes = [...document.querySelectorAll<HTMLElement>("html,body,body *")]
            .map(el => ({ el, size: parseFloat(getComputedStyle(el).fontSize) }));
          const input = document.querySelector<HTMLTextAreaElement>("#response")!;
          const before = parseFloat(getComputedStyle(input).fontSize);
          for (const { el, size } of sizes) if (Number.isFinite(size)) el.style.fontSize = `${size * 2}px`;
          return { before, after: parseFloat(getComputedStyle(input).fontSize),
            width: innerWidth, scrollWidth: document.documentElement.scrollWidth };
        });
        assert.equal(scale.after, scale.before * 2);
        assert.ok(scale.scrollWidth <= scale.width);
        const notice = f.page.locator('.e4-voice [role="status"]');
        await notice.scrollIntoViewIfNeeded();
        await expect(notice).toBeInViewport({ ratio: 1 });
        await f.page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => resolve())));
        await f.page.screenshot({ path: join(process.env.E4_VALIDATION_EVIDENCE!, "voice-v07-disabled-320-text200.png"), fullPage: false });
      }
      await expect(draft).toHaveValue(original);
      assert.deepEqual(f.errors, []);
      variants.push({ injectedCleanupStatus: status, cleanupRequestsBeforeTextEscape: 1,
        automaticRetries: 0, ordinarySendEnabled: true, draftAndFocusPreserved: true });
    } finally { await f.close(); }
  }
  mark("V52", { variants, defaultDisabledOneNotice: true, sample320ComputedText200: true,
    fullV06VisualMatrixRerun: false, realDeviceTested: false });
});

test("V53 fresh cleanup time cannot authorize a replacement payload epoch until independent cleanup succeeds", async () => {
  const { rm, mkdir } = await import("node:fs/promises");
  const c = await seed();
  process.env.E4_VOICE_ACCOUNT_IDS = JSON.stringify([a.account, b.account, c.account]);
  const ready = await uploaded(a);
  await transcribeVoice(a.identity, ready.id);
  const pending = await createVoice(b.identity, input(b));
  const waiting = await uploaded(c);
  const store = await configuredVoicePayloadStore();
  const beforeReceipt = (await admin.query("SELECT cleanup_epoch,last_cleanup_at FROM private_voice_budget WHERE singleton")).rows[0];
  assert.equal(beforeReceipt.cleanup_epoch, store.epoch);
  assert.ok(Date.now() - beforeReceipt.last_cleanup_at.getTime() < 180_000);
  const ordinaryBefore = JSON.stringify((await admin.query("SELECT * FROM cloud_response_revisions ORDER BY cat_id,response_id,revision")).rows);
  await rm(store.root, { recursive: true, force: true });
  await mkdir(store.root, { mode: 0o700 });
  const replacementStore = await configuredVoicePayloadStore();
  assert.notEqual(replacementStore.epoch, store.epoch);
  const unchangedReceipt = (await admin.query("SELECT cleanup_epoch,last_cleanup_at FROM private_voice_budget WHERE singleton")).rows[0];
  assert.equal(unchangedReceipt.cleanup_epoch, store.epoch);
  assert.equal(unchangedReceipt.last_cleanup_at.toISOString(), beforeReceipt.last_cleanup_at.toISOString());
  assert.equal((await availableVoice(a.identity)).available, false);
  await assert.rejects(createVoice(b.identity, input(b)));
  await assert.rejects(claimVoiceUpload(b.identity, pending.id));
  let providerCalls = 0;
  const provider = { mode: "synthetic-v1", transcribe: async () => {
    providerCalls++;
    return { text: "清理新代际完成后才会请求的合成转写。" };
  } };
  await assert.rejects(transcribeVoice(c.identity, waiting.id, provider));
  assert.equal(providerCalls, 0);
  const lostReview = await readVoice(a.identity, ready.id);
  assert.equal(lostReview.status, "FAILED");
  assert.equal(lostReview.error, "AUDIO_LOST");
  assert.equal(lostReview.text, undefined);
  await cleanupPrivateVoice([a.account, b.account, c.account]);
  const receipt = (await admin.query("SELECT cleanup_epoch,cleanup_failures,last_cleanup_at FROM private_voice_budget WHERE singleton")).rows[0];
  assert.equal(receipt.cleanup_epoch, replacementStore.epoch);
  assert.equal(receipt.cleanup_failures, 0);
  assert.ok(receipt.last_cleanup_at.getTime() >= beforeReceipt.last_cleanup_at.getTime());
  assert.equal((await availableVoice(b.identity)).available, true);
  const oldWaiting = await transcribeVoice(c.identity, waiting.id, provider);
  assert.equal(oldWaiting.status, "FAILED");
  assert.equal(oldWaiting.error, "AUDIO_LOST");
  assert.equal(oldWaiting.text, undefined);
  await assert.rejects(claimVoiceUpload(c.identity, waiting.id));
  assert.equal(providerCalls, 0);
  const fresh = await uploaded(b);
  assert.notEqual(fresh.id, waiting.id);
  assert.equal((await transcribeVoice(b.identity, fresh.id, provider)).status, "READY");
  assert.equal(providerCalls, 1);
  assert.equal(JSON.stringify((await admin.query("SELECT * FROM cloud_response_revisions ORDER BY cat_id,response_id,revision")).rows), ordinaryBefore);
  mark("V53", { actualSyntheticPayloadRootReplaced: true, lastCleanupStillWithin180Seconds: true,
    oldCleanupEpochCannotAuthorizeNewRecording: true, createClaimAndTranscribeBlocked: true,
    oldJobsCannotReturnTextOrTriggerAsr: true, independentCleanupBindsNewEpoch: true,
    explicitNewRecordingSucceedsAfterCleanup: true, providerCallsBeforeCleanup: 0,
    providerCallsAfterExplicitRecording: 1, ordinaryBusinessTextUnchanged: true,
    linuxRemountPerformed: false });
});

test("V54 cleanup snapshot before publication cannot invalidate audio or text committed before its row lock", { timeout: 45_000 }, async () => {
  const pauseCleanupBeforeRowLock = () => {
    const originalConnect = pool.connect;
    let release!: () => void, signalReached!: () => void, paused = false;
    const reached = new Promise<void>(resolve => { signalReached = resolve; });
    const gate = new Promise<void>(resolve => { release = resolve; });
    (pool as any).connect = async function () {
      const client = await (originalConnect as unknown as () => Promise<pg.PoolClient>).call(pool);
      const originalQuery = client.query, originalRelease = client.release;
      (client as any).query = function (...args: any[]) {
        const sql = typeof args[0] === "string" ? args[0] : args[0]?.text ?? "";
        if (!paused && sql.includes("FROM private_voice_jobs j LEFT JOIN account_sessions") &&
            sql.includes("j.account_id=ANY") && sql.includes("FOR UPDATE OF j SKIP LOCKED")) {
          // cleanup has already obtained store.list(). Pause before its actual
          // SQL row-lock acquisition, without a production fault/config switch.
          paused = true;
          signalReached();
          return gate.then(() => (originalQuery as any).apply(client, args));
        }
        return (originalQuery as any).apply(client, args);
      };
      (client as any).release = function (...args: any[]) {
        client.query = originalQuery;
        client.release = originalRelease;
        return (originalRelease as any).apply(client, args);
      };
      return client;
    };
    const result = cleanupPrivateVoice([a.account]);
    return { result, release,
      reached: Promise.race([reached, result.then(() => { throw Error("cleanup did not reach the controlled row-lock boundary"); })]),
      finish: async () => {
        release();
        try { await result; } finally { pool.connect = originalConnect; }
      } };
  };
  const j = await createVoice(a.identity, input(a));
  const uploadClaim = await claimVoiceUpload(a.identity, j.id);
  const uploadCleanup = pauseCleanupBeforeRowLock();
  try {
    await uploadCleanup.reached;
    assert.equal((await physicalEntries(j.id)).length, 0, "Cleanup snapshot precedes audio publication");
    assert.equal((await admin.query("SELECT status FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0].status, "UPLOADING");
    const publishing = storeVoiceUpload(a.identity, j.id, uploadClaim.lease, wav());
    assert.equal((await publishing).status, "UPLOADED");
    assert.equal((await physicalEntries(j.id)).length, 1, "Audio file and PG pointer commit before cleanup gets its lock");
    uploadCleanup.release();
    const cleaned = await uploadCleanup.result;
    assert.equal(cleaned.cleaned, 0, "A current audio pointer must not be compared with a stale directory snapshot");
    const status = await readVoice(a.identity, j.id);
    assert.equal(status.status, "UPLOADED");
    assert.equal(status.error, null);
    assert.ok((await bytes(j.id)) > 0);
  } finally { await uploadCleanup.finish(); }

  let completeProvider!: (value: { text: string }) => void, enteredProvider!: () => void;
  const entered = new Promise<void>(resolve => { enteredProvider = resolve; });
  let providerCalls = 0;
  const processing = transcribeVoice(a.identity, j.id, {
    mode: "synthetic-v1",
    transcribe: async () => {
      providerCalls++;
      enteredProvider();
      return new Promise<{ text: string }>(resolve => { completeProvider = resolve; });
    },
  });
  await Promise.race([entered, processing.then(() => { throw Error("provider did not reach its controlled response boundary"); })]);
  const textCleanup = pauseCleanupBeforeRowLock();
  const text = "我还没有答应，这段已提交的校对文字不应被清理误删。";
  try {
    await textCleanup.reached;
    const before = await physicalEntries(j.id);
    assert.equal(before.length, 1);
    assert.equal(before[0].ref?.kind, "audio", "Cleanup snapshot contains audio but precedes text publication");
    assert.equal((await admin.query("SELECT status FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0].status, "TRANSCRIBING");
    completeProvider({ text });
    assert.equal((await processing).status, "READY");
    assert.equal((await physicalEntries(j.id)).length, 2, "Text file and PG pointer commit before cleanup gets its lock");
    textCleanup.release();
    const cleaned = await textCleanup.result;
    assert.equal(cleaned.cleaned, 0, "Current text pointer survives a directory snapshot that did not yet contain it");
    const status = await readVoice(a.identity, j.id);
    assert.equal(status.status, "READY");
    assert.equal(status.error, null);
    assert.equal(status.text, text);
    assert.equal((await physicalEntries(j.id)).length, 2);
    assert.equal(providerCalls, 1);
    assert.equal((await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [a.account])).rows[0].n, 0);
    mark("V54", { actualPgRowLockBoundaryPausedByTestWrapper: true,
      snapshotsBeforeAudioAndTextPublication: true, actualFilesystemAndPgCommitsBeforeCleanupLock: true,
      audioAndReadyTextPreserved: true, falseAudioLostTransitions: 0,
      providerCalls: 1, automaticSends: 0, productionFaultSwitchAdded: false,
      linuxTmpfsRaceTested: false });
  } finally {
    completeProvider?.({ text });
    await processing.catch(() => {});
    await textCleanup.finish();
  }
});

test("V55 lost acknowledgement after real COMMIT preserves referenced audio and ready text without another provider call", { timeout: 45_000 }, async () => {
  const losePublishCommitAck = (status: "UPLOADED" | "READY") => {
    const originalConnect = pool.connect;
    let injected = 0, successfulRealCommits = 0, compensationReads = 0;
    (pool as any).connect = async function () {
      const client = await (originalConnect as unknown as () => Promise<pg.PoolClient>).call(pool);
      const originalQuery = client.query, originalRelease = client.release;
      let publicationUpdateOnThisClient = false;
      (client as any).query = function (...args: any[]) {
        const sql = typeof args[0] === "string" ? args[0] : args[0]?.text ?? "";
        if (sql.includes(`UPDATE private_voice_jobs SET status='${status}'`))
          publicationUpdateOnThisClient = true;
        if (injected > 0 && sql === "SELECT * FROM private_voice_jobs WHERE id=$1 FOR UPDATE")
          compensationReads++;
        const result = (originalQuery as any).apply(client, args);
        if (publicationUpdateOnThisClient && sql.trim().toUpperCase() === "COMMIT" && injected === 0) {
          return Promise.resolve(result).then(() => {
            // The real database COMMIT has completed; only its acknowledgement
            // to the application is lost. Subsequent compensation queries work.
            successfulRealCommits++;
            injected++;
            publicationUpdateOnThisClient = false;
            throw Error("SYNTHETIC_COMMIT_ACK_LOST");
          });
        }
        if (sql.trim().toUpperCase() === "ROLLBACK") publicationUpdateOnThisClient = false;
        return result;
      };
      (client as any).release = function (...args: any[]) {
        client.query = originalQuery;
        client.release = originalRelease;
        return (originalRelease as any).apply(client, args);
      };
      return client;
    };
    return { restore: () => { pool.connect = originalConnect; },
      counts: () => ({ injected, successfulRealCommits, compensationReads }) };
  };
  const audio = wav();
  const j = await createVoice(a.identity, input(a, audio));
  const audioFault = losePublishCommitAck("UPLOADED");
  try {
    const response = await POST(new NextRequest(`${process.env.APP_ORIGIN}/api/e4/voice/jobs/${j.id}/upload`, {
      method: "POST", headers: {
        origin: process.env.APP_ORIGIN!, cookie: `cat_account_session=${a.token}`,
        "x-catletters-account": a.account, "content-type": "application/octet-stream",
      }, body: new Uint8Array(audio),
    }));
    assert.equal(response.status, 503, "The caller sees the uncertain upload outcome");
    assert.ok(!(await response.text()).includes("SYNTHETIC_COMMIT_ACK_LOST"));
    assert.equal(audioFault.counts().injected, 1);
    assert.equal(audioFault.counts().successfulRealCommits, 1);
    assert.ok(audioFault.counts().compensationReads >= 1, "Compensation checks current pointer under a fresh real row lock");
    const row = (await admin.query("SELECT status,audio_version,text_version,last_error,reserved_bytes FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0];
    assert.equal(row.status, "UPLOADED");
    assert.ok(row.audio_version);
    assert.equal(row.text_version, null);
    assert.equal(row.last_error, null);
    assert.equal(Number(row.reserved_bytes), 0);
    const pointer = await payloadRef(j.id, "audio");
    assert.ok(pointer);
    assert.ok((await (await configuredVoicePayloadStore()).read(pointer)).equals(audio));
    assert.equal((await physicalEntries(j.id)).length, 1);
    assert.equal((await readVoice(a.identity, j.id)).status, "UPLOADED");
  } finally { audioFault.restore(); }

  let providerCalls = 0;
  const text = "我没有同意；已经提交的转写文字不能因回执丢失而被删除。";
  const provider = { mode: "synthetic-v1", transcribe: async () => {
    providerCalls++;
    return { text };
  } };
  const textFault = losePublishCommitAck("READY");
  try {
    await assert.rejects(transcribeVoice(a.identity, j.id, provider),
      error => !(error as Error).message.includes("SYNTHETIC_COMMIT_ACK_LOST"));
    assert.equal(textFault.counts().injected, 1);
    assert.equal(textFault.counts().successfulRealCommits, 1);
    assert.ok(textFault.counts().compensationReads >= 1);
    const row = (await admin.query("SELECT status,audio_version,text_version,last_error,reserved_bytes FROM private_voice_jobs WHERE id=$1", [j.id])).rows[0];
    assert.equal(row.status, "READY");
    assert.ok(row.audio_version);
    assert.ok(row.text_version);
    assert.equal(row.last_error, null);
    assert.equal(Number(row.reserved_bytes), 0);
    const ready = await readVoice(a.identity, j.id);
    assert.equal(ready.status, "READY");
    assert.equal(ready.text, text);
    assert.equal(ready.error, null);
    const pointer = await payloadRef(j.id, "text");
    assert.ok(pointer);
    assert.equal((await (await configuredVoicePayloadStore()).read(pointer)).toString("utf8"), text);
    assert.equal((await physicalEntries(j.id)).length, 2);
    const repeated = await transcribeVoice(a.identity, j.id, provider);
    assert.equal(repeated.status, "READY");
    assert.equal(repeated.text, text);
    assert.equal(providerCalls, 1, "A committed READY task is read, never sent to the provider again");
    assert.equal((await admin.query("SELECT count(*)::int n FROM cloud_responses WHERE account_id=$1", [a.account])).rows[0].n, 0);
    mark("V55", { uploadRealCommitThenAckFault: audioFault.counts(), textRealCommitThenAckFault: textFault.counts(),
      referencedAudioAndTextRetained: true, falseAudioLostTransitions: 0,
      providerCalls: 1, providerCallsOnDuplicateReadyRequest: 0, automaticSends: 0,
      productionFaultSwitchAdded: false, realNetworkFailureSimulated: false,
      databaseAcknowledgementLossInjectedAfterActualCommit: true });
  } finally { textFault.restore(); }
});

test("V56 injected zero free space blocks recording while independent cleanup reclaims actual payload and probe remnants", { timeout: 45_000 }, async () => {
  const { mkdir, utimes, rm } = await import("node:fs/promises");
  const store = await configuredVoicePayloadStore();
  const stage = await store.stage(randomUUID(), "audio", Buffer.alloc(4096, 7));
  const orphan = await store.publish(stage);
  const entry = (await store.list()).find(candidate => candidate.ref?.version === orphan.version)!;
  assert.ok(entry);
  const old = new Date(Date.now() - 180_000);
  await utimes(join(store.root, entry.name), old, old);
  const probeRoot = process.env.E4_VOICE_PROBE_DIRECTORY!;
  await mkdir(probeRoot, { recursive: true, mode: 0o700 });
  const probeCrash = await mkdtemp(join(probeRoot, "probe-"));
  await writeFile(join(probeCrash, "audio"), Buffer.from("SYNTHETIC_PROBE_CRASH_REMNANT"), { mode: 0o600 });
  await utimes(probeCrash, old, old);
  const source = `
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {syncBuiltinESMExports} from 'node:module';
const originalStatfs=fs.promises.statfs;
fs.promises.statfs=async(...args)=>({...await originalStatfs(...args),bavail:0,bfree:0,ffree:0});
syncBuiltinESMExports();
const {voiceCapabilities}=await import('./src/server/voice-config.ts');
const {cleanupPrivateVoice}=await import('./src/server/voice-service.ts');
const {cleanupVoiceFiles}=await import('./src/server/voice-probe.ts');
const {syntheticVoice}=await import('./src/server/voice-provider.ts');
const {pool}=await import('./src/server/db.ts');
const {closeLifecycleProvider}=await import('./src/server/lifecycle-provider.ts');
let providerCalls=0;
const originalTranscribe=syntheticVoice.transcribe;
syntheticVoice.transcribe=async()=>{providerCalls++;throw Error('SYNTHETIC_PROVIDER_MUST_NOT_RUN');};
try {
 const unavailable=await voiceCapabilities(${JSON.stringify(a.account)});
 assert.equal(unavailable.available,false);
 const cleanup=await cleanupPrivateVoice([${JSON.stringify(a.account)}]);
 assert.ok(cleanup.files>0);
 assert.ok(cleanup.probeFiles>0);
 await assert.rejects(fs.promises.lstat(${JSON.stringify(join(store.root, entry.name))}),error=>error.code==='ENOENT');
 await assert.rejects(fs.promises.lstat(${JSON.stringify(probeCrash)}),error=>error.code==='ENOENT');
 // Even a missing probe root must not require allocating an inode for cleanup.
 await fs.promises.rm(${JSON.stringify(probeRoot)},{recursive:true,force:true});
 const missingProbeCleaned=await cleanupVoiceFiles();
 assert.equal(missingProbeCleaned,0);
 await assert.rejects(fs.promises.lstat(${JSON.stringify(probeRoot)}),error=>error.code==='ENOENT');
 fs.promises.statfs=originalStatfs;
 syncBuiltinESMExports();
 const recovered=await voiceCapabilities(${JSON.stringify(a.account)});
 assert.equal(recovered.available,true);
 assert.equal(providerCalls,0);
 console.log(JSON.stringify({recordingUnavailableWithInjectedZeroFree:!unavailable.available,
  actualPayloadFilesDeleted:cleanup.files,actualProbeDirectoriesDeleted:cleanup.probeFiles,
  missingProbeRootNotCreated:true,capabilitiesRecoverAfterCapacityRestored:recovered.available,
  providerCalls,linuxEnospcTested:false}));
} finally {
 fs.promises.statfs=originalStatfs;syncBuiltinESMExports();
 syntheticVoice.transcribe=originalTranscribe;
 await pool.end();await closeLifecycleProvider();
}`;
  try {
    const result = await promisify(execFile)(process.execPath,
      ["--import", "tsx", "--input-type=module", "-e", source],
      { env: process.env, timeout: 30_000, maxBuffer: 32768 });
    const proof = JSON.parse(result.stdout.trim().split("\n").at(-1)!);
    assert.equal(proof.recordingUnavailableWithInjectedZeroFree, true);
    assert.ok(proof.actualPayloadFilesDeleted > 0);
    assert.ok(proof.actualProbeDirectoriesDeleted > 0);
    assert.equal(proof.missingProbeRootNotCreated, true);
    assert.equal(proof.capabilitiesRecoverAfterCapacityRestored, true);
    assert.equal(proof.providerCalls, 0);
    assert.equal((await physicalEntries(orphan.jobId)).length, 0);
    mark("V56", { capacityStateInjectedThroughStatfs: { bavail: 0, bfree: 0, ffree: 0 },
      actualFreshNodeProcess: true, actualFilesystemDeletion: true, ...proof,
      productionFaultSwitchAdded: false });
  } finally {
    await store.remove(orphan).catch(() => {});
    await store.discard(stage);
    await rm(probeCrash, { recursive: true, force: true });
  }
});
