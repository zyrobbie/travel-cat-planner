/** Controlled generated PCM stream. Tests real MediaRecorder/container bytes;
 * does NOT test native getUserMedia, permissions, hardware or real speech. */
export function syntheticMicrophone() {
  const native = navigator.mediaDevices.getUserMedia.bind(
    navigator.mediaDevices,
  );
  const controlled = async () => {
    const Generator = (window as any).MediaStreamTrackGenerator;
    if (!Generator) throw Error("SYNTHETIC_AUDIO_GENERATOR_UNAVAILABLE");
    const track = new Generator({ kind: "audio" }),
      writer = track.writable.getWriter();
    let frame = 0,
      closed = false;
    const clock = setInterval(() => {
      if (closed) return;
      const data = new Float32Array(480);
      for (let i = 0; i < 480; i++)
        data[i] =
          Math.sin(((frame * 480 + i) * 2 * Math.PI * 440) / 48000) * 0.05;
      const audio = new (window as any).AudioData({
        format: "f32",
        sampleRate: 48000,
        numberOfFrames: 480,
        numberOfChannels: 1,
        timestamp: frame++ * 10000,
        data,
      });
      void writer
        .write(audio)
        .catch(() => {})
        .finally(() => audio.close());
    }, 10);
    const stop = track.stop.bind(track);
    track.stop = () => {
      if (!closed) {
        closed = true;
        clearInterval(clock);
        void writer.close().catch(() => {});
        stop();
      }
    };
    (window as any).__syntheticVoiceTracks ??= [];
    (window as any).__syntheticVoiceTracks.push(track);
    return new MediaStream([track]);
  };
  navigator.mediaDevices.getUserMedia = async (input) => {
    if ((window as any).__voicePermissionDelayMs)
      await new Promise((resolve) =>
        setTimeout(resolve, (window as any).__voicePermissionDelayMs),
      );
    if ((window as any).__voicePermissionDenied)
      throw new DOMException("Synthetic permission denial", "NotAllowedError");
    return controlled();
  };
  (window as any).__nativeGetUserMedia = native;
}
