import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest


SCRIPT = Path("deploy/private-voice/linux/prepare-build-context.py").resolve()
VERIFY = Path("deploy/private-voice/linux/verify-build-input.mjs").resolve()
DOCKERIGNORE = Path("deploy/private-voice/linux/.dockerignore").read_bytes()


class FrozenLinuxContext(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="cat-linux-context-test-")
        self.root = Path(self.temporary.name)
        self.files = {
            "package.json": b'{"name":"synthetic-build-input"}\n',
            "deploy/private-voice/linux/Dockerfile.build": b"# synthetic fixture only\n",
            "deploy/private-voice/linux/.dockerignore": DOCKERIGNORE,
            "deploy/private-voice/linux/verify-build-input.mjs": VERIFY.read_bytes(),
        }

    def tearDown(self):
        self.temporary.cleanup()

    def prepare(self, files=None, manifest=None, extra=(), wrong_hash=False, existing=False, unsafe=None):
        files = self.files if files is None else files
        archive = self.root / "source.tar.gz"
        with tarfile.open(archive, "w:gz") as bundle:
            for relative, data in list(files.items()) + list(extra):
                member = tarfile.TarInfo("cat-letters/" + relative)
                member.size = len(data)
                member.mode = 0o644
                bundle.addfile(member, io.BytesIO(data))
            if unsafe is not None:
                bundle.addfile(unsafe)
        expected = {path: hashlib.sha256(data).hexdigest() for path, data in files.items()} if manifest is None else manifest
        freeze = self.root / "freeze.json"
        freeze.write_text(json.dumps({"filesSha256": expected}))
        checksum = "0" * 64 if wrong_hash else hashlib.sha256(archive.read_bytes()).hexdigest()
        destination = self.root / "context"
        if existing:
            destination.mkdir()
            (destination / "preserve").write_text("keep")
        result = subprocess.run(["python3", str(SCRIPT), "--archive", str(archive), "--freeze", str(freeze),
                                 "--sha256", checksum, "--destination", str(destination)], capture_output=True, text=True)
        return result, destination

    def rejected(self, **kwargs):
        result, destination = self.prepare(**kwargs)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("LINUX_BUILD_CONTEXT_REJECTED", result.stderr)
        self.assertEqual(result.stdout, "")
        self.assertFalse(destination.exists())

    def test_valid_source_is_exact_and_verifier_rejects_late_extra(self):
        result, destination = self.prepare()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["sourceFiles"], len(self.files))
        self.assertEqual((destination / ".dockerignore").read_bytes(), DOCKERIGNORE)
        for path, content in self.files.items():
            self.assertEqual((destination / path).read_bytes(), content)
        passed = subprocess.run(["node", str(VERIFY)], cwd=destination, capture_output=True, text=True)
        self.assertEqual(passed.returncode, 0, passed.stderr)
        (destination / "unexpected.txt").write_text("unfrozen input")
        failed = subprocess.run(["node", str(VERIFY)], cwd=destination, capture_output=True, text=True)
        self.assertNotEqual(failed.returncode, 0)
        self.assertIn("LINUX_BUILD_INPUT_REJECTED", failed.stderr)

    def test_archive_checksum_mismatch(self):
        self.rejected(wrong_hash=True)

    def test_source_checksum_mismatch(self):
        manifest = {path: hashlib.sha256(data).hexdigest() for path, data in self.files.items()}
        manifest["package.json"] = "0" * 64
        self.rejected(manifest=manifest)

    def test_unlisted_extra(self):
        self.rejected(extra=[("unlisted.txt", b"unexpected")])

    def test_missing_source_file(self):
        manifest = {path: hashlib.sha256(data).hexdigest() for path, data in self.files.items()}
        manifest["missing.txt"] = "0" * 64
        self.rejected(manifest=manifest)

    def test_environment_rejected_even_if_listed(self):
        self.rejected(files={**self.files, ".env": b"SYNTHETIC_DO_NOT_COPY=1"})

    def test_native_dependency_rejected_even_if_listed(self):
        self.rejected(files={**self.files, "node_modules/fake-addon.node": b"synthetic-native-file"})

    def test_backslash_source_filename_still_rejected(self):
        self.rejected(files={**self.files, "deploy/private-voice/linux/run-cat\\x2dvoice.mount.in": b"[Mount]\n"})

    def test_full_working_candidate_source_types_prepare_without_unsafe_mount_names(self):
        source = SCRIPT.parents[3]
        manifest_path = source / "SOURCE-MANIFEST.sha256"
        baseline = source.parents[2] / "outputs/E4-2026-10-24/voice/engineering/source-freeze-v06.json"
        if manifest_path.exists():
            paths = {line.split("  ", 1)[1] for line in manifest_path.read_text().splitlines()}
        elif baseline.exists():
            paths = set(json.loads(baseline.read_text())["filesSha256"])
        else:
            paths = {name for name in (".env.example", "netlify.toml", "next-env.d.ts", "next.config.ts", "package-lock.json",
                     "package.json", "playwright.config.ts", "playwright.e4-lifecycle.config.ts", "playwright.e4.config.ts", "tsconfig.json")
                     if (source / name).is_file()}
            for top in ("ui-components-v1", "ui-daily-core-v1", "netlify"):
                paths.update(str(path.relative_to(source)) for path in (source / top).rglob("*") if path.is_file())
        extensions = {".ts", ".tsx", ".mjs", ".js", ".css", ".sql", ".md", ".sh", ".py", ".json", ".example",
                      ".service", ".timer", ".conf", ".slice", ".in"}
        for top in ("src", "static-app", "scripts", "tests", "db", "deploy"):
            for directory, dirs, files in os.walk(source / top, followlinks=False):
                dirs[:] = [name for name in dirs if name not in {"node_modules", ".next", ".git", "public", "dist", ".local", "__pycache__"}]
                for name in files:
                    path = Path(directory) / name
                    if path.suffix in extensions or path.name in {"Dockerfile.build", ".dockerignore"}:
                        paths.add(str(path.relative_to(source)))
        self.assertGreater(len(paths), 350, "Full candidate fixture must include the complete application, not four placeholder files")
        for name in ("private-tmpfs.mount.in", "proxy-tmpfs.mount.in", "nginx.conf", "catvoice.slice", "Dockerfile.build", ".dockerignore"):
            self.assertIn("deploy/private-voice/linux/" + name, paths)
        self.assertFalse(any("\\" in name for name in paths))
        files = {name: (source / name).read_bytes() for name in sorted(paths)}
        result, destination = self.prepare(files=files)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["sourceFiles"], len(files))
        verified = subprocess.run(["node", str(VERIFY)], cwd=destination, capture_output=True, text=True)
        self.assertEqual(verified.returncode, 0, verified.stderr)
        print(json.dumps({"fullCandidateFixtureFiles": len(files), "sourceTypes": sorted({Path(name).suffix for name in paths}),
                          "archivePrepare": "PASS", "exactInputVerify": "PASS", "linuxBuildExecuted": False}))

    def test_csv_rejected_even_if_listed(self):
        self.rejected(files={**self.files, "unrelated.csv": b"synthetic,do-not-copy"})

    def test_traversal_rejected(self):
        self.rejected(files={**self.files, "../escape.txt": b"synthetic"})
        self.assertFalse((self.root / "escape.txt").exists())

    def test_link_rejected(self):
        link = tarfile.TarInfo("cat-letters/link")
        link.type = tarfile.SYMTYPE
        link.linkname = "../../outside"
        self.rejected(unsafe=link)

    def test_duplicate_member_rejected(self):
        self.rejected(extra=[("package.json", self.files["package.json"])])

    def test_existing_context_preserved(self):
        result, destination = self.prepare(existing=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((destination / "preserve").read_text(), "keep")
        self.assertEqual(sorted(p.name for p in destination.iterdir()), ["preserve"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
