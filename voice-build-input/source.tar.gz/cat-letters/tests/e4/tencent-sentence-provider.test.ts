import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  createTencentSentenceProvider,
  assertNormalizedWav,
  tc3Signature,
  TENCENT_VOICE_MODE,
  VoiceProviderError,
  type VoiceProviderCode,
} from "../../src/server/tencent-sentence-provider";

// These are deliberately fake constants, never read real process credentials.
const env = {
  APP_MODE: "INTERNAL",
  E4_VOICE_ENABLED: "true",
  E4_VOICE_MODE: TENCENT_VOICE_MODE,
  E4_VOICE_TENCENT_ASR_APPROVED: "true",
  E4_VOICE_TENCENT_SECRET_ID: "AKIDOfflineTestOnly000000000000",
  E4_VOICE_TENCENT_SECRET_KEY: "OfflineSecretNotARealCredential0000",
};
const clock = () => 1792800000000;
const input = (audio = wav(16_000), signal = new AbortController().signal) => ({
  audio,
  mime: "audio/wav",
  jobId: "private-job-do-not-transmit",
  signal,
});
function wav(samples: number): Buffer {
  const b = Buffer.alloc(44 + samples * 2);
  b.write("RIFF");
  b.writeUInt32LE(b.length - 8, 4);
  b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22);
  b.writeUInt32LE(16_000, 24);
  b.writeUInt32LE(32_000, 28);
  b.writeUInt16LE(2, 32);
  b.writeUInt16LE(16, 34);
  b.write("data", 36);
  b.writeUInt32LE(samples * 2, 40);
  return b;
}
const response = (text = "我没有不开心。不要替我改掉否定词。") =>
  Response.json({ Response: { Result: text, RequestId: "synthetic-request" } });
const fake = (
  fn: (url: string | URL | Request, init?: RequestInit) => Promise<Response>,
): typeof fetch => fn as typeof fetch;
const codeIs = (code: VoiceProviderCode) => (e: unknown) =>
  e instanceof VoiceProviderError && e.code === code;

test("configuration is explicitly gated, cannot enable from credentials alone", () => {
  for (const key of [
    "APP_MODE",
    "E4_VOICE_ENABLED",
    "E4_VOICE_MODE",
    "E4_VOICE_TENCENT_ASR_APPROVED",
    "E4_VOICE_TENCENT_SECRET_ID",
    "E4_VOICE_TENCENT_SECRET_KEY",
  ]) {
    const missing: Record<string, string> = { ...env };
    delete missing[key];
    assert.throws(
      () => createTencentSentenceProvider(missing),
      codeIs("NOT_CONFIGURED"),
    );
  }
  assert.throws(
    () =>
      createTencentSentenceProvider({
        ...env,
        E4_VOICE_TENCENT_SECRET_KEY: "secret\r\nheader",
      }),
    codeIs("NOT_CONFIGURED"),
  );
  assert.throws(
    () =>
      createTencentSentenceProvider({
        ...env,
        E4_VOICE_TENCENT_TOKEN: "\ninvalid",
      }),
    codeIs("NOT_CONFIGURED"),
  );
  assert.throws(
    () => createTencentSentenceProvider(env, { timeoutMs: 12_001 }),
    codeIs("NOT_CONFIGURED"),
  );
});

test("Tencent published canonical request hashes and UTC date match", () => {
  const signed = tc3Signature({
    body: '{"Limit": 1, "Filters": [{"Values": ["\\u672a\\u547d\\u540d"], "Name": "instance-name"}]}',
    host: "cvm.tencentcloudapi.com",
    service: "cvm",
    action: "DescribeInstances",
    timestamp: 1551113065,
    secretId: "AKIDPublicExample",
    secretKey: "PublicFakeSecret",
  });
  assert.equal(
    signed.bodyHash,
    "35e9c5b0e3ae67532d3c9f17ead6c90222632e5b1ff7f6e89887f1398934f064",
  );
  assert.equal(
    signed.canonicalHash,
    "7019a55be8395899b900fb5564e4200d984910f34794a27cb3fb7d10ff6a1e84",
  );
  assert.equal(signed.date, "2019-02-25");
});

test("ASR signature matches independent Python golden vector", () => {
  const fixture = JSON.parse(
    readFileSync(
      new URL("./fixtures/tencent-signature-vector.json", import.meta.url),
      "utf8",
    ),
  );
  const signed = tc3Signature(fixture.input);
  assert.deepEqual(signed, fixture.expected);
});

test("only fixed endpoint is used; exact bytes signed; no job/account/URL fields transmitted", async () => {
  let calls = 0;
  const audio = wav(16_000);
  const original =
    "  我没有不开心。不要修改二十三。\n<script>仅作为文字</script>";
  const provider = createTencentSentenceProvider(
    { ...env, E4_VOICE_TENCENT_TOKEN: "OfflineTokenOnly" },
    {
      now: clock,
      fetch: fake(async (url, init) => {
        calls++;
        assert.equal(url, "https://asr.tencentcloudapi.com/");
        assert.equal(init!.redirect, "error");
        assert.equal(init!.method, "POST");
        assert.equal(init!.credentials, "omit");
        assert.equal(init!.cache, "no-store");
        const headers = new Headers(init!.headers);
        const body = JSON.parse(init!.body as string);
        assert.equal(headers.get("x-tc-action"), "SentenceRecognition");
        assert.equal(headers.get("x-tc-version"), "2019-06-14");
        assert.equal(headers.get("x-tc-token"), "OfflineTokenOnly");
        assert.equal(headers.get("x-tc-region"), null);
        assert.equal(body.EngSerViceType, "16k_zh");
        assert.equal(body.SourceType, 1);
        assert.equal(body.VoiceFormat, "wav");
        assert.equal(body.DataLen, audio.length);
        assert.equal(body.Data, audio.toString("base64"));
        assert.deepEqual(
          Object.keys(body).sort(),
          [
            "EngSerViceType",
            "SourceType",
            "VoiceFormat",
            "Data",
            "DataLen",
            "WordInfo",
            "FilterDirty",
            "FilterModal",
            "FilterPunc",
            "ConvertNumMode",
          ].sort(),
        );
        for (const key of [
          "WordInfo",
          "FilterDirty",
          "FilterModal",
          "FilterPunc",
          "ConvertNumMode",
        ])
          assert.equal(body[key], 0);
        const signed = tc3Signature({
          body: init!.body as string,
          host: "asr.tencentcloudapi.com",
          service: "asr",
          action: "SentenceRecognition",
          timestamp: Math.floor(clock() / 1000),
          secretId: env.E4_VOICE_TENCENT_SECRET_ID,
          secretKey: env.E4_VOICE_TENCENT_SECRET_KEY,
        });
        assert.equal(headers.get("authorization"), signed.authorization);
        assert(!String(init!.body).includes("private-job"));
        return response(original);
      }),
    },
  );
  assert.deepEqual(await provider.transcribe(input(audio)), { text: original });
  assert.equal(calls, 1);
});

test("60s normalized WAV remains under base64 size cap; >60s rejected before network", async () => {
  const max = wav(60 * 16_000);
  assert.equal(assertNormalizedWav(max, "audio/wav").length, 1_920_044);
  assert(max.toString("base64").length < 3_000_000);
  let calls = 0;
  const provider = createTencentSentenceProvider(env, {
    now: clock,
    fetch: fake(async () => {
      calls++;
      return response();
    }),
  });
  await provider.transcribe(input(max));
  await assert.rejects(
    provider.transcribe(input(wav(60 * 16_000 + 1))),
    codeIs("INVALID_AUDIO"),
  );
  assert.equal(calls, 1);
});

test("rejects mislabeled WebM, wrong format/rate/channels, unaccounted trailing bytes and bad PCM length", () => {
  assert.throws(
    () => assertNormalizedWav(wav(1), "audio/webm"),
    codeIs("INVALID_AUDIO"),
  );
  for (const [offset, value] of [
    [20, 3],
    [22, 2],
    [24, 44_100],
    [28, 48_000],
    [32, 4],
    [34, 24],
  ] as const) {
    const b = wav(1);
    b.writeUInt16LE(value, offset);
    assert.throws(
      () => assertNormalizedWav(b, "audio/wav"),
      codeIs("INVALID_AUDIO"),
    );
  }
  const wrong = wav(1);
  wrong.write("webm", 0);
  assert.throws(
    () => assertNormalizedWav(wrong, "audio/wav"),
    codeIs("INVALID_AUDIO"),
  );
  assert.throws(
    () =>
      assertNormalizedWav(
        Buffer.concat([wav(1), Buffer.alloc(2)]),
        "audio/wav",
      ),
    codeIs("INVALID_AUDIO"),
  );
  assert.throws(
    () => assertNormalizedWav(wav(0), "audio/wav"),
    codeIs("INVALID_AUDIO"),
  );
});

test("upstream errors are classified without echoing sensitive message/body", async () => {
  for (const [upstream, expected] of [
    ["AuthFailure.SecretIdNotFound", "AUTH_FAILED"],
    ["LimitExceeded", "QUOTA_OR_LIMIT"],
    ["RequestLimitExceeded", "QUOTA_OR_LIMIT"],
    ["ResourceUnavailable", "QUOTA_OR_LIMIT"],
    ["FailedOperation.UserHasNoAmount", "QUOTA_OR_LIMIT"],
    ["FailedOperation.UserHasNoFreeAmount", "QUOTA_OR_LIMIT"],
    ["FailedOperation.ServiceIsolate", "QUOTA_OR_LIMIT"],
    ["FailedOperation.ErrorRecognize", "SERVICE_UNAVAILABLE"],
    ["FailedOperation", "SERVICE_UNAVAILABLE"],
  ] as const) {
    const provider = createTencentSentenceProvider(env, {
      fetch: fake(async () =>
        Response.json({
          Response: {
            Error: {
              Code: upstream,
              Message: "private-audio-and-secret-do-not-leak",
            },
          },
        }),
      ),
    });
    await assert.rejects(provider.transcribe(input()), (error: unknown) => {
      assert(codeIs(expected)(error));
      assert(!String(error).includes("private-audio"));
      return true;
    });
  }
});

test("empty/invalid/malformed/oversized text is never a successful transcription", async () => {
  const fixtures: [() => Response, VoiceProviderCode][] = [
    [() => response(" \n\t"), "NO_TEXT"],
    [() => Response.json({ Response: { Result: 5 } }), "INVALID_RESPONSE"],
    [() => Response.json({ other: "no response" }), "INVALID_RESPONSE"],
    [() => new Response("not json"), "INVALID_RESPONSE"],
    [() => response("a\u0000b"), "INVALID_RESPONSE"],
    [() => response("x".repeat(16_001)), "INVALID_RESPONSE"],
  ];
  for (const [make, expected] of fixtures) {
    await assert.rejects(
      createTencentSentenceProvider(env, {
        fetch: fake(async () => make()),
      }).transcribe(input()),
      codeIs(expected),
    );
  }
});

test("response bounds apply to streamed bytes as well as content-length", async () => {
  const large = () =>
    new Response(
      new ReadableStream({
        start(c) {
          c.enqueue(new Uint8Array(65_537));
          c.close();
        },
      }),
    );
  const declared = () =>
    new Response("{}", { headers: { "content-length": "65537" } });
  for (const make of [large, declared])
    await assert.rejects(
      createTencentSentenceProvider(env, {
        fetch: fake(async () => make()),
      }).transcribe(input()),
      codeIs("INVALID_RESPONSE"),
    );
});

test("HTTP status/network failures do not expose exception text or auto-retry", async () => {
  for (const [status, expected] of [
    [401, "AUTH_FAILED"],
    [403, "AUTH_FAILED"],
    [429, "QUOTA_OR_LIMIT"],
    [500, "SERVICE_UNAVAILABLE"],
    [302, "SERVICE_UNAVAILABLE"],
  ] as const) {
    let calls = 0;
    await assert.rejects(
      createTencentSentenceProvider(env, {
        fetch: fake(async () => {
          calls++;
          return new Response("private", { status });
        }),
      }).transcribe(input()),
      codeIs(expected),
    );
    assert.equal(calls, 1);
  }
  await assert.rejects(
    createTencentSentenceProvider(env, {
      fetch: fake(async () => {
        throw Error("SecretAccessKey=private");
      }),
    }).transcribe(input()),
    codeIs("NETWORK"),
  );
});

test("already-cancelled work makes no transport call", async () => {
  const control = new AbortController();
  control.abort();
  let calls = 0;
  await assert.rejects(
    createTencentSentenceProvider(env, {
      fetch: fake(async () => {
        calls++;
        return response();
      }),
    }).transcribe(input(wav(1), control.signal)),
    codeIs("CANCELLED"),
  );
  assert.equal(calls, 0);
});

test("cancel aborts in-flight transport; late result is discarded", async () => {
  const control = new AbortController();
  let transportSignal: AbortSignal | undefined;
  let finish!: (r: Response) => void;
  const p = createTencentSentenceProvider(env, {
    fetch: fake(async (_url, init) => {
      transportSignal = init!.signal!;
      return await new Promise((r) => {
        finish = r;
      });
    }),
  }).transcribe(input(wav(1), control.signal));
  control.abort();
  await assert.rejects(p, codeIs("CANCELLED"));
  assert(transportSignal!.aborted);
  finish(response("late result"));
  await new Promise((r) => setTimeout(r, 0));
});

test("timeout settles even if offline transport ignores abort", async () => {
  let transportSignal: AbortSignal | undefined;
  const began = Date.now();
  await assert.rejects(
    createTencentSentenceProvider(env, {
      timeoutMs: 20,
      fetch: fake(async (_url, init) => {
        transportSignal = init!.signal!;
        return await new Promise<Response>(() => {});
      }),
    }).transcribe(input()),
    codeIs("TIMEOUT"),
  );
  assert(transportSignal!.aborted);
  assert(Date.now() - began < 1000);
});

test("cancellation during response body stops the reader", async () => {
  const control = new AbortController();
  let cancelled = false;
  const p = createTencentSentenceProvider(env, {
    fetch: fake(
      async () =>
        new Response(
          new ReadableStream({
            cancel() {
              cancelled = true;
            },
          }),
        ),
    ),
  }).transcribe(input(wav(1), control.signal));
  await new Promise((r) => setTimeout(r, 0));
  control.abort();
  await assert.rejects(p, codeIs("CANCELLED"));
  await new Promise((r) => setTimeout(r, 0));
  assert(cancelled);
});
