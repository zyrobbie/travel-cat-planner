/** Registration/default-OFF checks only; never starts a database or worker. */
import test, { after } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import pg from "pg";
import handler, { config } from "../../netlify/functions/e4-cloud-scheduled.mjs";
const fields = ["APP_MODE", "E4_AUTO_DELIVERY_ENABLED", "E4_AUTO_DELIVERY_ACCOUNT_ID", "E4_AUTO_DELIVERY_UNTIL"];
const prior = Object.fromEntries(fields.map(key => [key, process.env[key]]));
const originalConnect = pg.Pool.prototype.connect, originalQuery = pg.Client.prototype.query;
let dbCalls = 0;
(pg.Pool.prototype as any).connect = () => { dbCalls++; throw Error("database access forbidden in config check"); };
(pg.Client.prototype as any).query = () => { dbCalls++; throw Error("SQL forbidden in config check"); };
const request = () => new Request("https://local.invalid/.netlify/functions/e4-cloud-scheduled", {
  method: "POST", body: JSON.stringify({ next_run: new Date().toISOString() }),
});
after(() => {
  pg.Pool.prototype.connect = originalConnect; pg.Client.prototype.query = originalQuery;
  for (const key of fields) { if (prior[key] === undefined) delete process.env[key]; else process.env[key] = prior[key]; }
});
test("S01 function config is explicitly empty and TOML adds no schedule", async () => {
  assert.deepEqual(config, {});
  const toml = (await readFile(new URL("../../netlify.toml", import.meta.url), "utf8"))
    .split("\n").filter(line => !line.trim().startsWith("#")).join("\n");
  assert.doesNotMatch(toml, /schedule\s*=/);
});
test("S02 missing and false runtime enable both return DISABLED with zero database access", async () => {
  process.env.APP_MODE = "INTERNAL";
  for (const enabled of [undefined, "false"]) {
    if (enabled === undefined) delete process.env.E4_AUTO_DELIVERY_ENABLED; else process.env.E4_AUTO_DELIVERY_ENABLED = enabled;
    const response = await handler(request(), { deploy: { context: "production", published: true } });
    assert.equal(response.status, 200); assert.equal((await response.json()).status, "DISABLED");
  }
  assert.equal(dbCalls, 0);
});
test("S03 enabled but unpublished context still rejects before loading a worker", async () => {
  process.env.E4_AUTO_DELIVERY_ENABLED = "true";
  const response = await handler(request(), { deploy: { context: "deploy-preview", published: false } });
  assert.equal(response.status, 403); assert.equal((await response.json()).status, "REJECTED");
  assert.equal(dbCalls, 0);
});
test("S04 original 25s budget and disabled registration coexist without worker/SQL changes", async () => {
  const source = await readFile(new URL("../../netlify/functions/e4-cloud-scheduled.mts", import.meta.url), "utf8");
  assert.match(source, /const INVOCATION_MS = 25_000/);
  assert.match(source, /const MIN_START_MS = 7_000/);
  assert.match(source, /export const config = \{\}/);
  assert.equal(dbCalls, 0);
});
