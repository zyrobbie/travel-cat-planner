import test, { after, before } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { pool } from "../../src/server/db";
import { requestCode, verifyCode, accountIdentity, accountSession } from "../../src/server/account-auth";
import { createResendOtpDelivery } from "../../src/server/resend-otp-delivery";
import { HttpError } from "../../src/server/errors";

before(async () => {
  assert.equal((await pool.query("SELECT current_database() AS name")).rows[0].name, "catletters_e4_resend_test");
  assert.equal(process.env.APP_MODE, "INTERNAL");
  assert.equal(process.env.OTP_ADAPTER, "resend-v1");
});
after(async () => { await pool.end(); });
const address = () => `resend-synthetic-${randomUUID()}@example.test`;
const adapter = (send: typeof globalThis.fetch, timeoutMs = 1_000) => createResendOtpDelivery({
  apiKey: "re_transaction_test_not_a_real_key", from: "有猫来信 <login@auth.example.test>",
}, { fetch: send, timeoutMs });
const sent = () => new Response(JSON.stringify({ id: "mock-provider-acceptance-only" }));
const errorStatus = (status: number) => (error: unknown) => error instanceof HttpError && error.status === status;

test("R01: real transaction commits SENT after mocked acceptance; repeat request is rate-limited without sending", async () => {
  const email = address();
  let calls = 0;
  let code = "";
  const delivery = adapter(async (_, init) => {
    calls++;
    code = JSON.parse(String(init!.body)).text.match(/登录验证码：(\d{6})/)[1];
    return sent();
  });
  const asked = await requestCode(email, delivery);
  assert.equal(asked.mode, "resend-v1");
  assert.equal(asked.accepted, true);
  const row = (await pool.query("SELECT delivery_status,revoked_at,expires_at,code_hash FROM email_challenges WHERE id=$1", [asked.challengeId])).rows[0];
  assert.equal(row.delivery_status, "SENT");
  assert.equal(row.revoked_at, null);
  assert.notEqual(row.code_hash, code);
  assert.ok(row.expires_at.getTime() > Date.now());
  await assert.rejects(requestCode(email, delivery), errorStatus(429));
  assert.equal(calls, 1);
  const login = await verifyCode(asked.challengeId, email, code);
  assert.equal(await accountIdentity(login.rawToken), login.accountId);
  await assert.rejects(verifyCode(asked.challengeId, email, code), errorStatus(401));
});

test("R02: unknown provider outcome revokes the committed challenge and prevents verification; no automatic send retry", async () => {
  const email = address();
  let calls = 0;
  let code = "";
  let id = "";
  const delivery = adapter(async (_, init) => {
    calls++;
    code = JSON.parse(String(init!.body)).text.match(/登录验证码：(\d{6})/)[1];
    id = new Headers(init!.headers).get("Idempotency-Key")!.split("/")[1];
    // Simulate provider accepting the message, then losing the response.
    throw Error("simulated response loss after provider acceptance");
  });
  await assert.rejects(requestCode(email, delivery), errorStatus(503));
  const row = (await pool.query("SELECT delivery_status,revoked_at FROM email_challenges WHERE id=$1", [id])).rows[0];
  assert.equal(row.delivery_status, "FAILED");
  assert.ok(row.revoked_at);
  await assert.rejects(verifyCode(id, email, code), errorStatus(401));
  await assert.rejects(requestCode(email, delivery), errorStatus(429));
  assert.equal(calls, 1);
  assert.equal((await pool.query("SELECT count(*)::int AS n FROM accounts WHERE email_normalized=$1", [email])).rows[0].n, 0);
});

test("R03: actual adapter timeout commits FAILED/revoked and leaves the real transaction connection usable", async () => {
  const email = address();
  let code = "";
  let id = "";
  let signal: AbortSignal | null | undefined;
  const delivery = adapter(async (_, init) => {
    code = JSON.parse(String(init!.body)).text.match(/登录验证码：(\d{6})/)[1];
    id = new Headers(init!.headers).get("Idempotency-Key")!.split("/")[1];
    signal = init!.signal;
    return new Promise<Response>(() => {});
  }, 20);
  await assert.rejects(requestCode(email, delivery), errorStatus(503));
  assert.equal(signal?.aborted, true);
  const row = (await pool.query("SELECT delivery_status,revoked_at FROM email_challenges WHERE id=$1", [id])).rows[0];
  assert.equal(row.delivery_status, "FAILED");
  assert.ok(row.revoked_at);
  await assert.rejects(verifyCode(id, email, code), errorStatus(401));
  assert.equal((await pool.query("SELECT 1 AS healthy")).rows[0].healthy, 1);
});

test("R04: HTTP verification of a mocked-Resend challenge reports OTP mode separately from safety and creates a usable session", async () => {
  const email = address();
  let code = "";
  const asked = await requestCode(email, adapter(async (_, init) => {
    code = JSON.parse(String(init!.body)).text.match(/登录验证码：(\d{6})/)[1];
    return sent();
  }));
  const origin = process.env.E4_TEST_ORIGIN!;
  assert.match(origin, /^http:\/\/127\.0\.0\.1:\d+$/);
  const response = await fetch(`${origin}/api/e4/auth/verify-code`, {
    method: "POST", headers: { Origin: origin, "Content-Type": "application/json" },
    body: JSON.stringify({ challengeId: asked.challengeId, email, code }),
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.ok, true);
  assert.equal(body.mode, "resend-v1");
  assert.equal(body.safetyAdapter, "synthetic-v1");
  assert.equal(body.account.id, body.accountId);
  assert.equal(body.account.email_normalized, email);
  assert.equal(body.account.cat, null);
  assert.equal(body.rawToken, undefined);
  const cookie = response.headers.get("set-cookie")!;
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /Secure/i);
  assert.match(cookie, /SameSite=strict/i);
  const session = cookie.match(/cat_account_session=([^;]+)/)![1];
  assert.equal(await accountIdentity(session), body.accountId);
  assert.deepEqual(await accountSession(session), body.account);
  const staleTab = await fetch(`${origin}/api/e4/account`, {
    headers: { Cookie: `cat_account_session=${session}`, "X-Catletters-Account": randomUUID() },
  });
  assert.equal(staleTab.status, 401);
  assert.ok((await pool.query("SELECT consumed_at FROM email_challenges WHERE id=$1", [asked.challengeId])).rows[0].consumed_at);
});
