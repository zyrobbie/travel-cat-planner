import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { fork, execFile, type ChildProcess } from "node:child_process";
import { promisify } from "node:util";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID, createHash } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import pg from "pg";
import { NextRequest } from "next/server";
import { pool, transaction } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import {
  validationScope,
  validationDeadline,
  validationEmail,
} from "../../src/server/cloud-lifecycle-validation-scope";
import {
  preflightValidation,
  runValidationExport,
  cleanupValidationExports,
  observeValidationAccount,
} from "../../src/server/cloud-lifecycle-validation-worker";
import {
  runValidationFlow,
  privateState,
  validationHttp,
} from "../../scripts/cloud-lifecycle-validation";

const exec = promisify(execFile),
  cases: object[] = [];
const ownerUrls = [
  process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS!,
  process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER!,
];
for (const value of ownerUrls) {
  const u = new URL(value);
  assert.equal(u.hostname, "127.0.0.1");
  assert.equal(u.pathname, "/catletters_cloud_lifecycle_validation_test");
}
const admin = new pg.Pool({ connectionString: ownerUrls[0] }),
  ledgerAdmin = new pg.Pool({ connectionString: ownerUrls[1] });
let server: Server,
  dropDeleteReply = false,
  excluded: string,
  excludedBefore: string,
  oldDump: string,
  newDump: string;
const scopeId = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID!;
const allQueries = pg.Client.prototype.query;
async function one(sql: string, values: unknown[] = [], db: pg.Pool = admin) {
  return (await db.query(sql, values)).rows[0];
}
async function snapshotExcluded() {
  return JSON.stringify({
    account: await one("SELECT * FROM accounts WHERE id=$1", [excluded]),
    exports: (
      await admin.query(
        "SELECT * FROM account_exports WHERE account_id=$1 ORDER BY id",
        [excluded],
      )
    ).rows,
    chunks: (
      await admin.query(
        "SELECT p.* FROM private_export_chunks p JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1 ORDER BY p.export_id",
        [excluded],
      )
    ).rows,
    rates: (
      await admin.query("SELECT * FROM account_rate_limits WHERE key=$1", [
        `privacy:${excluded}`,
      ])
    ).rows,
  });
}
async function localAdminSafety() {
  for (const db of [admin, ledgerAdmin])
    assert.equal(
      (await one("SELECT value FROM local_validation_cluster_nonce", [], db))
        .value,
      process.env.E4_VALIDATION_LOCAL_NONCE,
    );
}
const passed = (id: string, data: object = {}) =>
  cases.push({ ...data, test: id, status: "PASS" });
before(async () => {
  await localAdminSafety();
  assert.notEqual(
    (await one("SELECT system_identifier FROM pg_control_system()"))
      .system_identifier,
    (
      await one(
        "SELECT system_identifier FROM pg_control_system()",
        [],
        ledgerAdmin,
      )
    ).system_identifier,
  );
  const auth = await import("../../src/app/api/e4/[...path]/route");
  const privacy = await import("../../src/app/api/e4/privacy/[...path]/route");
  const v1 = await import("../../src/app/api/e4/v1/[...path]/route");
  const health = await import("../../src/app/api/[...path]/route");
  server = createServer(async (req, res) => {
    try {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers))
        if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(",") : v);
      const request = new NextRequest(process.env.APP_ORIGIN! + req.url, {
        method: req.method,
        headers,
        ...(chunks.length ? { body: Buffer.concat(chunks) } : {}),
      });
      const route =
        req.url === "/api/health"
          ? health
          : req.url!.startsWith("/api/e4/privacy/")
            ? privacy
            : req.url!.startsWith("/api/e4/v1/")
              ? v1
              : auth;
      const response = await (req.method === "POST" ? route.POST : route.GET)(
        request,
      );
      if (dropDeleteReply && req.url === "/api/e4/privacy/deletions/retry") {
        dropDeleteReply = false;
        res.destroy();
        return;
      }
      res.statusCode = response.status;
      response.headers.forEach((v, k) => {
        if (k.toLowerCase() !== "set-cookie") res.setHeader(k, v);
      });
      if (response.headers.getSetCookie().length)
        res.setHeader("Set-Cookie", response.headers.getSetCookie());
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch {
      res.statusCode = 500;
      res.end("local bridge error");
    }
  });
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  process.env.APP_ORIGIN = `http://127.0.0.1:${(server.address() as any).port}`;
  oldDump = join(
    process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
    "before-deletion.dump",
  );
  newDump = join(
    process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
    "after-deletion.dump",
  );
  excluded = randomUUID();
  await admin.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    excluded,
    `${excluded}@example.invalid`,
  ]);
  for (const status of ["READY", "BUILDING"]) {
    const id = randomUUID(),
      artifact = `${id}.${randomUUID()}.json`,
      body = Buffer.from("excluded synthetic chunk"),
      hash = createHash("sha256").update(body).digest("hex");
    await admin.query(
      `INSERT INTO account_exports(id,account_id,request_key,status,expires_at,artifact_name,artifact_hash,artifact_bytes,lease_token,lease_until,attempts) VALUES($1,$2,$3,$4,clock_timestamp()-interval '1 day',$5,$6,$7,$8,$9,5)`,
      [
        id,
        excluded,
        randomUUID(),
        status,
        artifact,
        hash,
        body.length,
        status === "BUILDING" ? randomUUID() : null,
        status === "BUILDING" ? new Date(Date.now() - 60_000) : null,
      ],
    );
    await admin.query(
      "INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body) VALUES($1,$2,0,$3,$4,$5)",
      [id, artifact, body.length, hash, body],
    );
  }
  await admin.query(
    "INSERT INTO account_rate_limits(key,attempts,window_at) VALUES($1,1,clock_timestamp()-interval '2 days')",
    [`privacy:${excluded}`],
  );
  excludedBefore = await snapshotExcluded();
});
after(async () => {
  pg.Client.prototype.query = allQueries;
  await writeFile(
    join(process.env.E4_VALIDATION_EVIDENCE!, "cases.json"),
    JSON.stringify(
      {
        scope:
          "two fresh local PostgreSQL clusters; exact reviewed runtime roles/RLS; real HTTP bridge invokes unchanged Next route handlers",
        cloudExecuted: false,
        browserExecuted: false,
        emailSent: false,
        cases,
      },
      null,
      2,
    ) + "\n",
  );
  await new Promise<void>((r) => server?.close(() => r()));
  await closeLifecycleProvider();
  await pool.end();
  await admin.end();
  await ledgerAdmin.end();
});

test("L01 disabled, expired, invalid scope and owner URLs reject before SQL", async () => {
  let calls = 0;
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    calls++;
    return (allQueries as Function).apply(this, args);
  } as typeof allQueries;
  const saved = { ...process.env };
  try {
    for (const [key, value] of [
      ["E4_CLOUD_LIFECYCLE_VALIDATION_ENABLED", "false"],
      ["APP_MODE", "PUBLIC"],
      ["E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID", "all"],
      [
        "E4_CLOUD_LIFECYCLE_VALIDATION_UNTIL",
        new Date(Date.now() - 1).toISOString(),
      ],
      [
        "E4_CLOUD_LIFECYCLE_VALIDATION_UNTIL",
        new Date(Date.now() + 2 * 3_600_000).toISOString(),
      ],
      ["DATABASE_URL", ownerUrls[0]],
      [
        "DATABASE_URL",
        "postgresql://cat_letters_app:synthetic@pooler.example.invalid:6543/postgres",
      ],
      ["E4_LIFECYCLE_RECOVERY", "true"],
    ]) {
      process.env[key] = value;
      assert.throws(() => validationScope());
      Object.assign(process.env, saved);
    }
    assert.equal(calls, 0);
  } finally {
    Object.assign(process.env, saved);
    pg.Client.prototype.query = allQueries;
  }
  passed("L01", { rejectedSqlCalls: 0 });
});
test("L02 exact restricted roles and full guard pass; missing RLS visibility fails closed", async () => {
  const pre = await preflightValidation();
  assert.equal(pre.status, "READY");
  assert.equal(pre.business.role.role, "cat_letters_app");
  assert.equal(pre.ledger.role.role, "cat_letters_ledger");
  await assert.rejects(
    pool.query("SELECT * FROM schema_migrations"),
    (e: any) => e.code === "42501",
  );
  const runtimeLedger = new pg.Pool({
    connectionString: process.env.E4_LEDGER_DATABASE_URL,
  });
  try {
    await assert.rejects(
      runtimeLedger.query("UPDATE ledger_events SET hash='' WHERE sequence=-1"),
      (e: any) => e.code === "42501",
    );
    await assert.rejects(
      runtimeLedger.query("UPDATE restore_gate SET status='READY'"),
      (e: any) => e.code === "42501",
    );
  } finally {
    await runtimeLedger.end();
  }
  await admin.query(
    "ALTER POLICY e4_runtime_select ON private_export_budget USING (false)",
  );
  try {
    await assert.rejects(preflightValidation());
  } finally {
    await admin.query(
      "ALTER POLICY e4_runtime_select ON private_export_budget USING (true)",
    );
  }
  passed("L02", {
    runtimeRoles: ["cat_letters_app", "cat_letters_ledger"],
    ddl: false,
    bypassRls: false,
    schemaMigrationsDenied: true,
    ledgerRewriteDenied: true,
    gateWriteDenied: true,
  });
});
test("L03 coordinator script seeds only fixed accounts; normal HTTP export is complete and cross-account denied", async () => {
  await runValidationFlow("seed");
  const result: any = await runValidationFlow("export");
  assert.equal(result.results.export.crossAccountDenied, 3);
  assert.equal(await snapshotExcluded(), excludedBefore);
  await dump(oldDump);
  passed("L03", {
    ...result.results.export,
    excludedRowsAndPrivateBytesUnchanged: true,
  });
});
test("L04 scoped cleanup clears expired/unpublished own chunks, keeps live build and all excluded rows", async () => {
  const { state } = await privateState();
  const own = [];
  for (const kind of ["expired-ready", "expired-build", "live-build"]) {
    const id = randomUUID(),
      artifact = `${id}.${randomUUID()}.json`,
      body = Buffer.from(kind),
      hash = createHash("sha256").update(body).digest("hex");
    own.push({ id, kind });
    await admin.query(
      `INSERT INTO account_exports(id,account_id,request_key,status,expires_at,cat_id,captured_revision,artifact_name,artifact_hash,artifact_bytes,lease_token,lease_until) VALUES($1,$2,$3,$4,$5,$6,1,$7,$8,$9,$10,$11)`,
      [
        id,
        scopeId,
        randomUUID(),
        kind === "expired-ready" ? "READY" : "BUILDING",
        new Date(Date.now() - 1000),
        state.catId,
        artifact,
        hash,
        body.length,
        kind === "expired-ready" ? null : randomUUID(),
        kind === "expired-ready"
          ? null
          : new Date(Date.now() + (kind === "live-build" ? 60_000 : -60_000)),
      ],
    );
    await admin.query(
      "INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body) VALUES($1,$2,0,$3,$4,$5)",
      [id, artifact, body.length, hash, body],
    );
  }
  const cleaned = await cleanupValidationExports();
  assert.equal(cleaned.expired, 1);
  assert.equal(cleaned.rateLimits, 0);
  for (const { id, kind } of own)
    assert.equal(
      (
        await one(
          "SELECT count(*)::int AS n FROM private_export_chunks WHERE export_id=$1",
          [id],
        )
      ).n,
      kind === "live-build" ? 1 : 0,
    );
  assert.equal(await snapshotExcluded(), excludedBefore);
  passed("L04", {
    expiredOwnCleared: true,
    unpublishedExpiredBuildCleared: true,
    liveBuildKept: true,
    excludedExpiredJobsAndChunksKept: true,
    globalRateLimitsUntouched: true,
  });
});
test("L05 normal response deletion revokes published export and removes chunks atomically", async () => {
  const r: any = await runValidationFlow("revoke");
  assert.equal(r.results.revoke.chunksAfterRevocation, 0);
  assert.equal(await snapshotExcluded(), excludedBefore);
  passed("L05", r.results.revoke);
});

async function temporaryScope(work: () => Promise<void>) {
  const saved = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID!;
  const id = randomUUID();
  process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID = id;
  try {
    await admin.query(
      "INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",
      [id, validationEmail(id)],
    );
    await work();
  } finally {
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID = saved;
  }
}
async function queued() {
  const { requestAccountExport } =
    await import("../../src/server/account-export");
  return (await requestAccountExport(validationScope().accountId, randomUUID()))
    .job.id;
}
function crashing(mode: "claim" | "publish") {
  const processChild = fork(
    "scripts/cloud-lifecycle-crash-fixture.ts",
    [mode],
    { execArgv: ["--import", "tsx"], silent: true, env: { ...process.env } },
  );
  return {
    processChild,
    held: new Promise<void>((resolve, reject) => {
      const timer = setTimeout(
        () => reject(Error("Crash fixture phase timeout")),
        20_000,
      );
      processChild.on("message", (m: any) => {
        if (m.phase === "COMMITTED_REPLY_HELD") {
          clearTimeout(timer);
          resolve();
        }
      });
      processChild.once("error", reject);
      processChild.once("exit", (code) => {
        if (code !== null) {
          clearTimeout(timer);
          reject(Error("Crash child exited early"));
        }
      });
    }),
  };
}
async function kill(child: ChildProcess) {
  if (child.exitCode !== null || child.signalCode !== null) return;
  const done = new Promise((r) => child.once("exit", r));
  child.kill("SIGKILL");
  await done;
}
test(
  "L06 lost export claim COMMIT acknowledgement persists one lease and recovers after real 60s expiry",
  { timeout: 95_000 },
  async () => {
    await temporaryScope(async () => {
      const id = await queued(),
        child = crashing("claim");
      try {
        await child.held;
        await kill(child.processChild);
      } finally {
        await kill(child.processChild);
      }
      let job = await one(
        "SELECT status,lease_until,attempts FROM account_exports WHERE id=$1",
        [id],
      );
      assert.equal(job.status, "BUILDING");
      assert.equal(job.attempts, 1);
      assert.equal((await runValidationExport()).status, "IDLE");
      const start = Date.now();
      console.log(
        "L06 waiting for the persisted export lease; no lease or clock edits.",
      );
      for (let i = 0; i < 140; i++) {
        if (
          (
            await one(
              "SELECT lease_until<=clock_timestamp() AS expired FROM account_exports WHERE id=$1",
              [id],
            )
          ).expired
        )
          break;
        await delay(500);
      }
      assert.equal(
        (
          await one(
            "SELECT lease_until<=clock_timestamp() AS expired FROM account_exports WHERE id=$1",
            [id],
          )
        ).expired,
        true,
      );
      assert.equal((await runValidationExport()).status, "READY");
      assert.equal((await runValidationExport()).status, "IDLE");
      passed("L06", {
        durableClaimReplyLost: true,
        actualExpiryWaitMs: Date.now() - start,
        leaseEdited: false,
        clockEdited: false,
        recoveredOnce: true,
      });
    });
  },
);
test(
  "L07 lost export publication COMMIT acknowledgement preserves READY and does not duplicate chunks",
  { timeout: 25_000 },
  async () => {
    await temporaryScope(async () => {
      const id = await queued(),
        child = crashing("publish");
      try {
        await child.held;
        await kill(child.processChild);
      } finally {
        await kill(child.processChild);
      }
      const before = await one(
        "SELECT status,artifact_name,artifact_hash,lease_token FROM account_exports WHERE id=$1",
        [id],
      );
      assert.equal(before.status, "READY");
      assert.equal(before.lease_token, null);
      const count = (
        await one(
          "SELECT count(*)::int AS n FROM private_export_chunks WHERE export_id=$1",
          [id],
        )
      ).n;
      assert.equal(count, 1);
      assert.equal((await runValidationExport()).status, "IDLE");
      assert.deepEqual(
        await one(
          "SELECT status,artifact_name,artifact_hash,lease_token FROM account_exports WHERE id=$1",
          [id],
        ),
        before,
      );
      passed("L07", {
        durablePublishReplyLost: true,
        readyPreserved: true,
        chunks: count,
        duplicateArtifacts: 0,
      });
    });
  },
);
test(
  "L08 lost normal deletion HTTP reply is queryable and retries the original completed request",
  { timeout: 30_000 },
  async () => {
    dropDeleteReply = true;
    await assert.rejects(runValidationFlow("delete"));
    const queried: any = await runValidationFlow("query");
    assert.equal(queried.deletion.status, "COMPLETE");
    const { state } = await privateState();
    const before = (
      await one(
        "SELECT count(*)::int AS n FROM ledger_events WHERE account_id=$1 AND kind='DELETE_COMPLETE'",
        [scopeId],
        ledgerAdmin,
      )
    ).n;
    const r: any = await runValidationFlow("delete");
    assert.equal(r.results.deletion.oldSessionRejected, true);
    assert.equal(queried.deletion.requestId, state.requestId);
    assert.equal(
      (
        await one(
          "SELECT count(*)::int AS n FROM ledger_events WHERE account_id=$1 AND kind='DELETE_COMPLETE'",
          [scopeId],
          ledgerAdmin,
        )
      ).n,
      before,
    );
    assert.equal(before, 1);
    passed("L08", {
      acknowledgementLostAfterRealHttpHandlerCommit: true,
      sameRequestQueryableAndRetryable: true,
      oldSessionRejected: true,
      deleteCompleteEvents: 1,
      controlUnchanged: true,
    });
  },
);
test("L09 same-email login creates a new isolated account; old receipt cannot erase it; finish preserves new session", async () => {
  const fresh: any = await runValidationFlow("new-account");
  assert.equal(fresh.results.replacement.freshAccountIsDistinct, true);
  const done: any = await runValidationFlow("finish");
  assert.equal(done.results.finish.newSessionPreserved, true);
  await dump(newDump);
  passed("L09", { ...fresh.results.replacement, ...done.results.finish });
});
test("L10 closed gate and damaged ledger reject CLI/HTTP without changing scoped or excluded data", async () => {
  const { state } = await privateState();
  const api = validationHttp(state, false, true);
  await ledgerAdmin.query("UPDATE restore_gate SET status='CLOSED'");
  try {
    await assert.rejects(preflightValidation());
    await api.json("/api/e4/account", undefined, 503);
    assert.equal(await snapshotExcluded(), excludedBefore);
  } finally {
    await ledgerAdmin.query("UPDATE restore_gate SET status='READY'");
  }
  const head = await one("SELECT hash FROM ledger_head", [], ledgerAdmin);
  await ledgerAdmin.query("UPDATE ledger_head SET hash=''");
  try {
    await assert.rejects(observeValidationAccount());
    await api.json("/api/e4/account", undefined, 503);
  } finally {
    await ledgerAdmin.query("UPDATE ledger_head SET hash=$1", [head.hash]);
  }
  passed("L10", {
    closedGateFailsClosed: true,
    invalidLedgerFailsClosed: true,
    excludedUnchanged: true,
  });
});

async function dump(path: string) {
  await localAdminSafety();
  await exec(
    "pg_dump",
    ["--dbname", ownerUrls[0], "--format=custom", "--file", path],
    {
      env: { PATH: process.env.PATH, LANG: "C.UTF-8", NODE_ENV: "test" },
      timeout: 30_000,
    },
  );
}
async function lifecycle(args: string[], ok = true) {
  await localAdminSafety();
  let output: string;
  try {
    const r = await exec(
      process.execPath,
      ["--import", "tsx", "scripts/lifecycle.ts", ...args],
      {
        env: {
          ...process.env,
          DATABASE_URL: ownerUrls[0],
          E4_LEDGER_DATABASE_URL: ownerUrls[1],
          E4_LIFECYCLE_RECOVERY: "true",
        },
        timeout: 60_000,
      },
    );
    output = r.stdout;
  } catch (e) {
    if (ok) throw e;
    return null;
  }
  assert.ok(ok, "Recovery unexpectedly succeeded");
  return JSON.parse(output.trim().split("\n").at(-1)!);
}
for (const variant of ["old", "new"])
  test(
    `L11-${variant} physical business restore keeps independent gate closed; replay re-erases old account`,
    { timeout: 90_000 },
    async () => {
      await localAdminSafety();
      const operation = randomUUID();
      const closed = await lifecycle(["restore-lock", operation]);
      assert.equal(closed.closed, true);
      await exec(
        "pg_restore",
        [
          "--dbname",
          ownerUrls[0],
          "--clean",
          "--if-exists",
          "--single-transaction",
          variant === "old" ? oldDump : newDump,
        ],
        {
          env: { PATH: process.env.PATH, LANG: "C.UTF-8", NODE_ENV: "test" },
          timeout: 30_000,
        },
      );
      await localAdminSafety();
      const { state } = await privateState();
      const api = validationHttp(state, false, true);
      await api.json("/api/e4/account", undefined, 503);
      await assert.rejects(observeValidationAccount());
      await lifecycle(["reconcile", randomUUID(), String(closed.epoch)], false);
      await api.json("/api/e4/account", undefined, 503);
      if (variant === "old") {
        assert.equal(
          (await one("SELECT status FROM accounts WHERE id=$1", [scopeId]))
            .status,
          "ACTIVE",
        );
        assert.ok(
          (
            await one(
              "SELECT count(*)::int AS n FROM private_export_chunks p JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1",
              [scopeId],
            )
          ).n > 0,
        );
        await admin.query(
          `CREATE FUNCTION local_replay_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'synthetic replay fault'; END $$; CREATE TRIGGER local_replay_fault BEFORE DELETE ON cloud_letters FOR EACH ROW EXECUTE FUNCTION local_replay_fault()`,
        );
        try {
          await lifecycle(
            ["reconcile", operation, String(closed.epoch)],
            false,
          );
          await api.json("/api/e4/account", undefined, 503);
        } finally {
          await admin.query(
            "DROP TRIGGER local_replay_fault ON cloud_letters; DROP FUNCTION local_replay_fault()",
          );
        }
      }
      const result = await lifecycle([
        "reconcile",
        operation,
        String(closed.epoch),
      ]);
      assert.equal(result.ready, true);
      assert.equal(
        (await one("SELECT status FROM accounts WHERE id=$1", [scopeId]))
          .status,
        "DELETED",
      );
      assert.equal(
        (
          await one(
            "SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",
            [scopeId],
          )
        ).n,
        0,
      );
      assert.equal(
        (
          await one(
            "SELECT count(*)::int AS n FROM private_export_chunks p JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1",
            [scopeId],
          )
        ).n,
        0,
      );
      const oldApi = validationHttp(state);
      await oldApi.json("/api/e4/account", undefined, 401);
      if (variant === "new") {
        assert.equal(
          (await api.json("/api/e4/account")).id,
          state.replacement!.accountId,
        );
        assert.equal((await api.json("/api/e4/account")).cat, null);
      } else await api.json("/api/e4/account", undefined, 401);
      assert.equal(await snapshotExcluded(), excludedBefore);
      passed(`L11-${variant}`, {
        physicalPgRestore: true,
        independentLedgerNotRestored: true,
        wrongOperationRejected: true,
        gateClosedBeforeReplay: true,
        failedReplayStaysClosed: variant === "old",
        oldDataAndChunksErased: true,
        newSameEmailAccountPreservedWhenInBackup: variant === "new",
        notInOldBackup: variant === "old",
        cloudRestoreExecuted: false,
      });
    },
  );

test("L12 staged coordinator run resumes its same private journal; CLI UUID overrides and restore commands are rejected", async () => {
  const before = (
    await one(
      "SELECT count(*)::int AS n FROM ledger_events WHERE kind='DELETE_COMPLETE' AND account_id=$1",
      [scopeId],
      ledgerAdmin,
    )
  ).n;
  const again: any = await runValidationFlow("run");
  assert.equal(again.results.export.crossAccountDenied, 3);
  assert.equal(again.results.finish.newSessionPreserved, true);
  assert.equal(
    (
      await one(
        "SELECT count(*)::int AS n FROM ledger_events WHERE kind='DELETE_COMPLETE' AND account_id=$1",
        [scopeId],
        ledgerAdmin,
      )
    ).n,
    before,
  );
  for (const args of [
    ["export", "--account=" + excluded],
    ["cleanup", "all"],
    ["restore"],
  ]) {
    let rejected = false;
    try {
      await exec(
        process.execPath,
        ["--import", "tsx", "scripts/cloud-lifecycle-worker.ts", ...args],
        { env: process.env, timeout: 20_000 },
      );
    } catch (e: any) {
      assert.equal(e.code, 1);
      assert.match(e.stderr, /REJECTED/);
      assert.ok(!e.stderr.includes(excluded));
      rejected = true;
    }
    assert.equal(rejected, true);
  }
  assert.equal(await snapshotExcluded(), excludedBefore);
  passed("L12", {
    sameJournalResumed: true,
    noNewDeleteEvent: true,
    cliRequestOverridesRejected: true,
    noRestoreCommand: true,
    excludedUnchanged: true,
  });
});

test("L13 anonymized UUID observation requires this fixture receipt bound to the signed ledger intent", async () => {
  const saved = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE!;
  const path = join(
    process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
    "private",
    "wrong-capability.json",
  );
  await writeFile(
    path,
    JSON.stringify({
      accountId: scopeId,
      seeded: true,
      receipt: randomUUID() + "." + "1".repeat(64),
    }),
    { mode: 0o600, flag: "wx" },
  );
  process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE = path;
  try {
    await assert.rejects(observeValidationAccount());
  } finally {
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE = saved;
  }
  assert.equal((await observeValidationAccount()).status, "DELETED");
  passed("L13", {
    wrongPrivateCapabilityDenied: true,
    anonymizedUuidAloneInsufficient: true,
    correctSignedIntentCapabilityAccepted: true,
  });
});

test(
  "L14 ledger DELETE_REQUESTED COMMIT acknowledgement loss stays queryable; full writes fail closed until local original replay",
  { timeout: 40_000 },
  async () => {
    const savedId = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID!,
      savedControl = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_CONTROL_ID!,
      savedState = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE!;
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID = randomUUID();
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_CONTROL_ID = randomUUID();
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE = join(
      process.env.E4_VALIDATION_LOCAL_DIRECTORY!,
      "private",
      "ledger-gap.json",
    );
    try {
      await runValidationFlow("seed");
      await runValidationFlow("export");
      await runValidationFlow("revoke");
      const { state, save } = await privateState();
      const api = validationHttp(state);
      const prepared = await api.json("/api/e4/privacy/deletions/prepare", {
        key: state.keys.deletion,
      });
      state.requestId = prepared.deletion.requestId;
      await save();
      let pendingCommit = false,
        injected = false;
      pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
        const sql = typeof args[0] === "string" ? args[0] : args[0].text;
        if (
          sql.includes("INSERT INTO ledger_events") &&
          args[1]?.[1] === "DELETE_REQUESTED"
        )
          pendingCommit = true;
        const result = (allQueries as Function).apply(this, args);
        if (sql === "COMMIT" && pendingCommit && !injected) {
          pendingCommit = false;
          injected = true;
          return result.then(() => {
            throw Error("local lost DELETE_REQUESTED commit reply");
          });
        }
        return result;
      } as typeof allQueries;
      try {
        await api.json(
          "/api/e4/privacy/deletions/confirm",
          { requestId: state.requestId, confirm: true },
          503,
        );
      } finally {
        pg.Client.prototype.query = allQueries;
      }
      assert.equal(injected, true);
      await assert.rejects(preflightValidation());
      const progress: any = await runValidationFlow("query");
      assert.equal(progress.deletion.status, "PENDING");
      assert.equal(progress.deletion.requestId, state.requestId);
      await api.json(
        "/api/e4/privacy/deletions/retry",
        { requestId: state.requestId },
        503,
      );
      await api.json("/api/e4/account", undefined, 503);
      // Only this nonce-validated disposable local harness has maintenance access.
      const operation = randomUUID();
      const closed = await lifecycle(["restore-lock", operation]);
      await lifecycle(["reconcile", operation, String(closed.epoch)]);
      const resumed: any = await runValidationFlow("delete");
      assert.equal(resumed.results.deletion.status, "COMPLETE");
      assert.equal(
        (await runValidationFlow("query")).deletion.status,
        "COMPLETE",
      );
      assert.equal(
        (
          await one(
            "SELECT count(*)::int AS n FROM ledger_events WHERE account_id=$1 AND kind='DELETE_REQUESTED'",
            [state.accountId],
            ledgerAdmin,
          )
        ).n,
        1,
      );
      passed("L14", {
        durableDeleteIntentReplyLost: true,
        receiptPrefixQueryStillAvailable: true,
        normalWritesRemainClosed: true,
        noFalseSuccess: true,
        originalLocalLockAndReplayRepairs: true,
        sameRequestRecovered: true,
        cloudRestoreOrFaultInjection: false,
      });
    } finally {
      pg.Client.prototype.query = allQueries;
      process.env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID = savedId;
      process.env.E4_CLOUD_LIFECYCLE_VALIDATION_CONTROL_ID = savedControl;
      process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE = savedState;
    }
  },
);

test(
  "L15 the actual coordinator CLI entry points execute with restricted roles and emit no private capabilities",
  { timeout: 30_000 },
  async () => {
    for (const [file, action] of [
      ["scripts/cloud-lifecycle-worker.ts", "preflight"],
      ["scripts/cloud-lifecycle-worker.ts", "observe"],
      ["scripts/cloud-lifecycle-validation.ts", "preflight"],
      ["scripts/cloud-lifecycle-validation.ts", "query"],
    ]) {
      const r = await exec(
        process.execPath,
        ["--import", "tsx", file, action],
        { env: process.env, timeout: 20_000 },
      );
      const result = JSON.parse(r.stdout.trim().split("\n").at(-1)!);
      if (action === "preflight")
        assert.equal(result.result?.status ?? result.status, "READY");
      if (action === "query") assert.equal(result.deletion.status, "COMPLETE");
      const { state } = await privateState();
      for (const secret of [
        state.raw,
        state.controlRaw,
        state.receipt,
        state.replacement?.rawToken,
      ])
        assert.ok(!r.stdout.includes(secret!));
    }
    await temporaryScope(async () => {
      const id = await queued();
      const built = await exec(
        process.execPath,
        ["--import", "tsx", "scripts/cloud-lifecycle-worker.ts", "export"],
        { env: process.env, timeout: 20_000 },
      );
      assert.equal(
        JSON.parse(built.stdout.trim().split("\n").at(-1)!).result.status,
        "READY",
      );
      const clean = await exec(
        process.execPath,
        ["--import", "tsx", "scripts/cloud-lifecycle-worker.ts", "cleanup"],
        { env: process.env, timeout: 20_000 },
      );
      assert.equal(
        JSON.parse(clean.stdout.trim().split("\n").at(-1)!).result.status,
        "CLEANED",
      );
      assert.equal(
        (await one("SELECT status FROM account_exports WHERE id=$1", [id]))
          .status,
        "READY",
      );
    });
    passed("L15", {
      actualCliPreflightAndQuery: true,
      actualCliExportAndCleanup: true,
      privateCapabilitiesAbsentFromStdout: true,
    });
  },
);
