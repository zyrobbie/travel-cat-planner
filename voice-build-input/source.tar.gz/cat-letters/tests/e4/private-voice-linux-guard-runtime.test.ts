import test, { beforeEach, afterEach, after, mock } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { syncBuiltinESMExports } from "node:module";
import { createHash } from "node:crypto";
import { join } from "node:path";
import { enforcePrivateVoiceLinux } from "../../scripts/private-voice-linux-guard";
import { validatePayloadLinuxEvidence } from "../../src/server/voice-payload-store";

// Calls the complete product guard. Only process.platform and read-only
// proc/cgroup metadata are injected; this does not claim a Linux execution.
const platform = Object.getOwnPropertyDescriptor(process, "platform")!;
const originalRead = fs.readFileSync;
const evidence: object[] = [];
let files: Record<string, string>;
function profile(role = "business", tail = "     ") {
  files = {
    "/proc/self/cgroup": `0::/catvoice.slice/cat-voice-${role}.service\n`,
    [`/sys/fs/cgroup/catvoice.slice/cat-voice-${role}.service/memory.max`]:
      "134217728\n",
    [`/sys/fs/cgroup/catvoice.slice/cat-voice-${role}.service/memory.swap.max`]:
      "0\n",
    "/sys/fs/cgroup/catvoice.slice/memory.max": "805306368\n",
    "/sys/fs/cgroup/catvoice.slice/memory.high": "671088640\n",
    "/sys/fs/cgroup/catvoice.slice/memory.swap.max": "0\n",
    "/proc/self/limits": `Limit                     Soft Limit           Hard Limit           Units\nMax core file size        0                    0                    bytes${tail}\n`,
  };
}
beforeEach(() => {
  profile();
  Object.defineProperty(process, "platform", { ...platform, value: "linux" });
  mock.method(
    fs,
    "readFileSync",
    (path: fs.PathOrFileDescriptor, encoding?: unknown) => {
      assert.equal(encoding, "utf8");
      const key = String(path);
      assert.ok(
        Object.hasOwn(files, key),
        `Guard attempted unexpected filesystem read: ${key}`,
      );
      return files[key];
    },
  );
  syncBuiltinESMExports();
});
afterEach(() => {
  mock.restoreAll();
  syncBuiltinESMExports();
  Object.defineProperty(process, "platform", platform);
});
after(() => {
  if (process.env.E4_VALIDATION_EVIDENCE) {
    fs.mkdirSync(process.env.E4_VALIDATION_EVIDENCE, { recursive: true });
    fs.writeFileSync(
      join(process.env.E4_VALIDATION_EVIDENCE, "guard-runtime.json"),
      JSON.stringify(
        {
          guardSourceSha256: createHash("sha256")
            .update(originalRead("scripts/private-voice-linux-guard.ts"))
            .digest("hex"),
          payloadSourceSha256: createHash("sha256")
            .update(originalRead("src/server/voice-payload-store.ts"))
            .digest("hex"),
          actualProductFunction: "enforcePrivateVoiceLinux",
          injectedProcAndPlatform: true,
          linuxExecuted: false,
          realCgroupOrKernelVerified: false,
          cases: evidence,
        },
        null,
        2,
      ) + "\n",
    );
  }
});

test("G01 actual Linux guard accepts core zero values with only trailing spaces or tabs", () => {
  for (const role of ["business", "ledger"] as const) {
    for (const tail of ["", "     ", "\t", " \t  \t"]) {
      profile(role, tail);
      assert.deepEqual(enforcePrivateVoiceLinux(role), {
        result: "PASS",
        role,
        entry: "closed",
        voice: "disabled",
        storage: "not-applicable",
      });
      evidence.push({
        id: "G01",
        role,
        trailing: JSON.stringify(tail),
        accepted: true,
      });
    }
  }
});

test("G02 actual guard still rejects nonzero/unlimited core limits, wrong units and non-space/tab suffixes", () => {
  for (const line of [
    "Max core file size 1 0 bytes     ",
    "Max core file size 0 1 bytes\t",
    "Max core file size unlimited unlimited bytes     ",
    "Max core file size 0 unlimited bytes",
    "Max core file size 00 0 bytes ",
    "Max core file size 0 0 kbytes ",
    "Max core file size 0 0 byte ",
    "Max core file size 0 0 bytes junk",
    "Max core file size 0 0 bytes\u00a0",
    "Max core file size 0 0 bytes\u000b",
    "Max core file size 0 0 bytes\f",
  ]) {
    profile();
    files["/proc/self/limits"] = line + "\n";
    assert.throws(
      () => enforcePrivateVoiceLinux("business"),
      /PRIVATE_VOICE_LINUX_GUARD_FAILED/,
    );
    evidence.push({ id: "G02", injectedCoreLine: line, rejected: true });
  }
});

test("G03 actual guard still rejects wrong role/unit/slice, nonzero swap and unbounded/excess memory", () => {
  for (const group of [
    "/catvoice.slice/cat-voice-guard-metadata-business-20261026.service",
    "/catvoice.slice/cat-voice-app.service",
    "/system.slice/cat-voice-business.service",
    "/catvoice.slice/cat-voice-business.service/suffix",
    "/catvoice.slice/cat-voice-business.service-extra",
  ]) {
    profile();
    files["/proc/self/cgroup"] = `0::${group}\n`;
    assert.throws(
      () => enforcePrivateVoiceLinux("business"),
      /PRIVATE_VOICE_LINUX_GUARD_FAILED/,
    );
    evidence.push({ id: "G03", group, rejected: true });
  }
  for (const [key, value] of [
    [
      "/sys/fs/cgroup/catvoice.slice/cat-voice-business.service/memory.max",
      "max",
    ],
    [
      "/sys/fs/cgroup/catvoice.slice/cat-voice-business.service/memory.max",
      "134217729",
    ],
    [
      "/sys/fs/cgroup/catvoice.slice/cat-voice-business.service/memory.max",
      "0",
    ],
    [
      "/sys/fs/cgroup/catvoice.slice/cat-voice-business.service/memory.swap.max",
      "1",
    ],
    ["/sys/fs/cgroup/catvoice.slice/memory.max", "805306369"],
    ["/sys/fs/cgroup/catvoice.slice/memory.high", "671088641"],
    ["/sys/fs/cgroup/catvoice.slice/memory.swap.max", "1"],
  ]) {
    profile();
    files[key] = value;
    assert.throws(
      () => enforcePrivateVoiceLinux("business"),
      /PRIVATE_VOICE_LINUX_GUARD_FAILED/,
    );
    evidence.push({
      id: "G03",
      metadataPath: key,
      injectedValue: value,
      rejected: true,
    });
  }
});

test("G04 actual payload host validator accepts only zero core with space/tab padding and keeps other boundaries", () => {
  const good = {
    platform: "linux",
    mountInfo:
      "100 23 0:72 / /run/cat-voice-private rw,nosuid,nodev,noexec,relatime - tmpfs tmpfs rw,size=131072k,nr_inodes=4096,mode=700,uid=991,gid=991,noswap\n",
    cgroup: "0::/catvoice.slice/cat-voice-app.service\n",
    swapMax: "0\n",
    sliceSwapMax: "0\n",
    memoryMax: "402653184\n",
    sliceMemoryMax: "805306368\n",
    limits: "Max core file size 0 0 bytes",
    execArgs: [] as string[],
  };
  for (const tail of ["", "     ", "\t", " \t  \t"]) {
    assert.doesNotThrow(() =>
      validatePayloadLinuxEvidence({
        ...good,
        limits: good.limits + tail + "\n",
      }),
    );
    evidence.push({
      id: "G04",
      trailing: JSON.stringify(tail),
      accepted: true,
    });
  }
  for (const line of [
    "Max core file size 1 0 bytes ",
    "Max core file size 0 1 bytes\t",
    "Max core file size unlimited unlimited bytes ",
    "Max core file size 0 0 kbytes ",
    "Max core file size 0 0 bytes extra",
    "Max core file size 0 0 bytes\u00a0",
    "Max core file size 0 0 bytes\u000b",
    "Max core file size 0 0 bytes\f",
  ]) {
    assert.throws(() =>
      validatePayloadLinuxEvidence({ ...good, limits: line + "\n" }),
    );
    evidence.push({ id: "G04", injectedCoreLine: line, rejected: true });
  }
  for (const cgroup of [
    "0::/catvoice.slice/cat-voice-app.service-extra\n",
    "0::/catvoice.slice/cat-voice-app.service/suffix\n",
    "0::/system.slice/cat-voice-app.service\n",
  ])
    assert.throws(() => validatePayloadLinuxEvidence({ ...good, cgroup }));
});
