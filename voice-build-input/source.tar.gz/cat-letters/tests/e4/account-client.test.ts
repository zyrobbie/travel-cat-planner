import test from "node:test";
import assert from "node:assert/strict";
import { createAccountClient } from "../../static-app/account-client";
import type { ViewState } from "../../static-app/app-client";

const when = "2026-10-07T00:00:00.000Z";
const detail = {
  id: "letter:1",
  type: "DEMAND",
  snapshot: {
    title: "正式标题",
    body: "打开后才能看见",
    catName: "小咪",
    tip: null,
    scene: null,
    season: null,
    timeOfDay: null,
    contentId: "D-07",
  },
  deliveredAt: when,
  readAt: when,
  skippedAt: null,
  response: null,
  responseStatus: null,
};
function memory() {
  const values = new Map<string, string>();
  return {
    getItem: (k: string) => values.get(k) ?? null,
    setItem: (k: string, v: string) => {
      values.set(k, v);
    },
    removeItem: (k: string) => {
      values.delete(k);
    },
  };
}
function setup() {
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: memory(),
  });
  Object.defineProperty(globalThis, "sessionStorage", {
    configurable: true,
    value: memory(),
  });
  const calls: {
    path: string;
    body: Record<string, unknown> | undefined;
    account: string | null;
    method: string | undefined;
  }[] = [];
  let read = false,
    skipped = false,
    revision = 1;
  const route = async (input: RequestInfo | URL, options?: RequestInit) => {
    const path = String(input).replace("/api/e4/", ""),
      body = options?.body ? JSON.parse(String(options.body)) : undefined;
    calls.push({
      path,
      body,
      account: new Headers(options?.headers).get("X-Catletters-Account"),
      method: options?.method,
    });
    let data: unknown;
    if (path === "v1/view")
      data = {
        world: {
          cat: { id: "cat", name: "小咪", appearanceId: "cat-01" },
          world: { status: "HOME", tripId: null },
          safety: "CLEAR",
          stateRevision: revision,
        },
        mailbox: {
          letters: [
            {
              id: "letter:1",
              type: "DEMAND",
              title: read ? "正式标题" : "有一封来信，还没打开",
              deliveredAt: when,
              readAt: read ? when : null,
              skippedAt: skipped ? when : null,
            },
          ],
          stateRevision: revision,
        },
        sent: { responses: [], stateRevision: revision },
      };
    else if (path === "v1/letters/letter%3A1/skip") {
      if (!read || !skipped) revision++;
      read = true;
      skipped = true;
      data = { ok: true, stateRevision: revision };
    } else if (path === "v1/letters/letter%3A1/read") {
      if (!read) revision++;
      read = true;
      data = { letter: detail, firstRead: true, stateRevision: revision };
    } else if (path === "v1/letters/letter%3A1/detail")
      data = { letter: detail, stateRevision: revision };
    else if (path === "v1/letters/letter%3A1/respond") {
      revision++;
      data = {
        message: "送出去啦。",
        responseId: "r1",
        revision: 1,
        stateRevision: revision,
      };
    } else throw new Error(`unexpected ${path}`);
    return new Response(JSON.stringify(data), { status: 200 });
  };
  globalThis.fetch = route;
  return {
    calls,
    route,
    client: (id = "account-a", expired = () => {}) =>
      createAccountClient(
        {
          id,
          email_normalized: "synthetic@example.test",
          cat: { id: "cat", name: "测试小猫" },
        },
        expired,
      ),
  };
}

test("cloud Home receives metadata only; explicit read supplies detail without a second fetch", async () => {
  const { client, calls } = setup(),
    c = client();
  const home = (await c.api("state")) as ViewState;
  assert.equal(home.letters[0].snapshot.body, "");
  assert.equal(home.calendar, undefined);
  assert.deepEqual(
    calls.map((x) => x.path),
    ["v1/view"],
  );
  const before = calls.length;
  const opened = (await c.api("letters/letter:1/read", {})) as {
    state: ViewState;
    firstRead: boolean;
  };
  assert.equal(calls.length, before + 1);
  assert.equal(opened.state.letters[0].snapshot.body, "打开后才能看见");
  assert.equal(opened.firstRead, true);
  assert.ok(calls.every((x) => x.account === "account-a"));
  c.dispose();
});

test("history opening uses GET detail after the first read; later refresh is fresh", async () => {
  const { client, calls } = setup(),
    c = client();
  await c.api("state");
  await c.api("letters/letter:1/read", {});
  const result = (await c.api("letters/letter:1/read", {})) as {
    firstRead: boolean;
  };
  assert.equal(result.firstRead, false);
  assert.deepEqual(calls.at(-1), {
    path: "v1/letters/letter%3A1/detail",
    method: "GET",
    body: undefined,
    account: "account-a",
  });
  await c.api("state");
  assert.equal(calls.filter((x) => x.path === "v1/view").length, 2);
  c.dispose();
});

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}
test("simultaneous refreshes share only the pending request and do not cache authorization", async () => {
  const { client, route, calls } = setup(),
    c = client(),
    gate = deferred<void>();
  globalThis.fetch = async (input, options) => {
    await gate.promise;
    return route(input, options);
  };
  const a = c.api("state"),
    b = c.api("state"),
    d = c.api("state");
  gate.resolve();
  const results = await Promise.all([a, b, d]);
  assert.equal(calls.length, 1);
  assert.equal(results[0], results[1]);
  globalThis.fetch = async () =>
    new Response(JSON.stringify({ error: "会话已撤销" }), { status: 401 });
  await assert.rejects(c.api("state"), /会话已撤销/);
  c.dispose();
});

test("an older pending projection cannot overwrite a committed read result", async () => {
  const { client, route } = setup(),
    c = client(),
    gate = deferred<void>();
  await c.api("state");
  globalThis.fetch = async (input, options) => {
    const response = await route(input, options);
    if (String(input).endsWith("v1/view")) await gate.promise;
    return response;
  };
  const pending = c.api("state");
  await c.api("letters/letter:1/read", {});
  gate.resolve();
  const result = (await pending) as ViewState;
  assert.equal(result.letters[0].read_at, when);
  assert.equal(result.letters[0].snapshot.body, detail.snapshot.body);
  c.dispose();
});

test("failed or pending first-read POST never marks the client read", async () => {
  const { client, route } = setup(),
    c = client(),
    gate = deferred<void>();
  await c.api("state");
  globalThis.fetch = async (input, options) => {
    if (String(input).endsWith("/read")) {
      await gate.promise;
      return new Response(JSON.stringify({ error: "数据库未提交" }), {
        status: 503,
      });
    }
    return route(input, options);
  };
  const pending = c.api("letters/letter:1/read", {});
  const rejected = assert.rejects(pending, /数据库未提交/);
  const before = (await c.api("state")) as ViewState;
  assert.equal(before.letters[0].read_at, null);
  assert.equal(before.letters[0].snapshot.body, "");
  gate.resolve();
  await rejected;
  const after = (await c.api("state")) as ViewState;
  assert.equal(after.letters[0].read_at, null);
  assert.equal(after.letters[0].snapshot.body, "");
  c.dispose();
});

test("drafts remain local and isolated by account; malformed storage does not hide cloud letters", async () => {
  const { client, calls } = setup(),
    a = client(),
    b = client("account-b");
  await a.api("state");
  await a.api("letters/letter:1/read", {});
  const before = calls.length;
  await a.saveDraft("cat", "letter:1", "reply", "仅账号A草稿", null, null);
  assert.equal(calls.length, before);
  assert.equal(
    ((await a.api("state")) as ViewState).drafts["letter:1"].text,
    "仅账号A草稿",
  );
  assert.deepEqual(
    Object.keys(((await b.api("state")) as ViewState).drafts),
    [],
  );
  localStorage.setItem(
    "cat-letters:account-draft:v1:account-a:cat:letter%3A1:reply",
    "broken json",
  );
  const restored = (await a.api("state")) as ViewState;
  assert.equal(restored.letters.length, 1);
  assert.match(restored.storageNotice!, /格式异常/);
  a.dispose();
  b.dispose();
});

test("successful submit is not reported failed when local draft cleanup throws", async () => {
  const { client } = setup(),
    c = client();
  await c.api("state");
  await c.api("letters/letter:1/read", {});
  await c.saveDraft("cat", "letter:1", "reply", "待提交", null, null);
  Object.defineProperty(localStorage, "removeItem", {
    value: () => {
      throw new Error("storage disabled");
    },
  });
  const result = await c.api("letters/letter:1/respond", {
    text: "待提交",
    expectedResponseId: null,
  });
  assert.equal((result as { message: string }).message, "送出去啦。");
  const restored = (await c.api("state")) as ViewState;
  assert.deepEqual(Object.keys(restored.drafts), []);
  assert.match(restored.storageNotice!, /提交已成功/);
  c.dispose();
});

test("lost mutation response recovers through scoped request result with the original key", async () => {
  const { client, route } = setup(),
    c = client();
  await c.api("state");
  let key = "";
  globalThis.fetch = async (input, options) => {
    if (String(input).endsWith("/respond")) {
      key = JSON.parse(String(options?.body)).key;
      throw new Error("connection lost after commit");
    }
    if (String(input).includes("/requests/SEND_RESPONSE/")) {
      assert.ok(key);
      assert.ok(String(input).endsWith(key));
      return new Response(
        JSON.stringify({
          message: "送出去啦。",
          responseId: "r1",
          revision: 1,
        }),
      );
    }
    return route(input, options);
  };
  assert.equal(
    (
      (await c.api("letters/letter:1/respond", {
        text: "合成回应",
        expectedResponseId: null,
      })) as { message: string }
    ).message,
    "送出去啦。",
  );
  c.dispose();
});

test("401 expires visible client state and never falls back to local data", async () => {
  let expired = 0;
  const { client } = setup(),
    c = client("account-a", () => {
      expired++;
    });
  globalThis.fetch = async () =>
    new Response(JSON.stringify({ error: "登录状态已变化" }), { status: 401 });
  await assert.rejects(c.api("state"));
  assert.equal(expired, 1);
  await assert.rejects(
    c.saveDraft("cat", "letter:1", "reply", "不应保存", null, null),
    /登录状态已变化/,
  );
  await assert.rejects(c.api("state"));
  assert.equal(expired, 1);
});

test("legacy response IDs named __proto__ remain ordinary own records across detail merges", async () => {
  const { client, route } = setup(),
    c = client();
  globalThis.fetch = async (input, options) => {
    if (String(input).endsWith("v1/view")) {
      const view = await (await route(input, options)).json();
      return new Response(
        JSON.stringify({
          ...view,
          sent: {
            responses: [
              {
                id: "__proto__",
                letterId: "letter:1",
                currentRevision: 1,
                status: "ACTIVE",
                text: "合法旧ID",
                at: when,
              },
            ],
            stateRevision: 1,
          },
        }),
      );
    }
    return route(input, options);
  };
  const state = (await c.api("state")) as ViewState;
  assert.equal(Object.getPrototypeOf(state.responses), null);
  assert.equal(Object.hasOwn(state.responses, "__proto__"), true);
  assert.equal(state.responses["__proto__"].revisions[0].text, "合法旧ID");
  const merged = await c.detail!("letter:1");
  assert.equal(Object.getPrototypeOf(merged.responses), null);
  assert.equal(Object.hasOwn(merged.responses, "__proto__"), true);
  c.dispose();
});

test("skip commits invalidate a delayed view started before the write", async () => {
  const { client, route, calls } = setup(),
    c = client(),
    held = deferred<void>(),
    release = deferred<void>();
  await c.api("state");
  let delayView = true;
  globalThis.fetch = async (input, options) => {
    const response = await route(input, options);
    if (String(input).endsWith("v1/view") && delayView) {
      delayView = false;
      held.resolve();
      await release.promise;
    }
    return response;
  };
  const old = c.api("state");
  await held.promise;
  await c.api("letters/letter:1/skip", {});
  const fresh = (await c.api("state")) as ViewState;
  assert.equal(calls.filter((call) => call.path === "v1/view").length, 3);
  assert.equal(fresh.letters[0].skipped_at, when);
  assert.equal(fresh.letters[0].read_at, when);
  release.resolve();
  assert.equal(((await old) as ViewState).letters[0].skipped_at, when);
  c.dispose();
});

test("post-skip refresh cannot reuse a view started while skip was pending", async () => {
  const { client, route, calls } = setup(),
    c = client(),
    skipHeld = deferred<void>(),
    skipRelease = deferred<void>(),
    viewHeld = deferred<void>(),
    viewRelease = deferred<void>();
  await c.api("state");
  let delayView = true;
  globalThis.fetch = async (input, options) => {
    if (String(input).endsWith("/skip")) {
      skipHeld.resolve();
      await skipRelease.promise;
    }
    const response = await route(input, options);
    if (String(input).endsWith("v1/view") && delayView) {
      delayView = false;
      viewHeld.resolve();
      await viewRelease.promise;
    }
    return response;
  };
  const skip = c.api("letters/letter:1/skip", {});
  await skipHeld.promise;
  const during = c.api("state");
  await viewHeld.promise;
  skipRelease.resolve();
  await skip;
  const fresh = (await c.api("state")) as ViewState;
  assert.equal(calls.filter((call) => call.path === "v1/view").length, 3);
  assert.equal(fresh.letters[0].skipped_at, when);
  viewRelease.resolve();
  assert.equal(((await during) as ViewState).letters[0].skipped_at, when);
  c.dispose();
});

for (const reading of ["detail", "history", "unread"] as const) {
  for (const change of ["new-view", "edit", "delete"] as const) {
    test(`late ${reading} cannot restore response state after confirmed ${change}`, async () => {
      const { client, route } = setup(),
        c = client(),
        held = deferred<void>(),
        release = deferred<void>(),
        otherHeld = deferred<void>(),
        otherRelease = deferred<void>();
      let changed = false;
      const response = () => ({
        id: "r1",
        revision: changed ? 2 : 1,
        text: changed ? "已确认的新回应" : "不应复活的旧回应",
        at: when,
      });
      const currentDetail = (id: string) => ({
        ...detail,
        id,
        response:
          id === "letter:2" ||
          (reading === "unread" && !changed) ||
          (changed && change === "delete")
            ? null
            : response(),
        responseStatus:
          id === "letter:2" || (reading === "unread" && !changed)
            ? null
            : changed && change === "delete"
              ? "DELETED"
              : "ACTIVE",
      });
      globalThis.fetch = async (input, options) => {
        const path = String(input);
        if (path.endsWith("v1/view")) {
          const view = await (await route(input, options)).json();
          const revision = changed ? 2 : 1;
          view.world.stateRevision =
            view.mailbox.stateRevision =
            view.sent.stateRevision =
              revision;
          view.mailbox.letters[0] = {
            ...view.mailbox.letters[0],
            readAt: reading === "unread" && !changed ? null : when,
            responseId: "r1",
            responseStatus:
              changed && change === "delete" ? "DELETED" : "ACTIVE",
          };
          view.mailbox.letters.push({
            id: "letter:2",
            type: "DEMAND",
            title: "另一封历史来信",
            deliveredAt: when,
            readAt: when,
            skippedAt: null,
          });
          view.sent.responses =
            reading === "unread" && !changed
              ? []
              : [
                  {
                    id: "r1",
                    letterId: "letter:1",
                    currentRevision: revision,
                    status:
                      changed && change === "delete" ? "DELETED" : "ACTIVE",
                    text:
                      changed && change === "delete" ? null : response().text,
                    at: when,
                  },
                ];
          return new Response(JSON.stringify(view));
        }
        if (
          path.endsWith("/letter%3A1/detail") ||
          path.endsWith("/letter%3A1/read")
        ) {
          const snapshot = {
            letter: currentDetail("letter:1"),
            stateRevision: changed ? 2 : 1,
            firstRead: reading === "unread",
          };
          held.resolve();
          await release.promise;
          return new Response(JSON.stringify(snapshot));
        }
        if (path.endsWith("/letter%3A2/detail")) {
          otherHeld.resolve();
          await otherRelease.promise;
          return new Response(
            JSON.stringify({
              letter: currentDetail("letter:2"),
              stateRevision: 2,
            }),
          );
        }
        if (
          path.endsWith("/responses/r1/edit") ||
          path.endsWith("/responses/r1/delete")
        ) {
          changed = true;
          return new Response(
            JSON.stringify({ responseId: "r1", revision: 2, stateRevision: 2 }),
          );
        }
        return route(input, options);
      };
      await c.api("state");
      const old =
        reading === "detail"
          ? c.detail!("letter:1")
          : c.api("letters/letter:1/read", {});
      const rejected = assert.rejects(old, /记录已更新/);
      await held.promise;
      if (change === "edit")
        await c.editResponse!(
          "cat",
          "r1",
          1,
          "已确认的新回应",
          crypto.randomUUID(),
        );
      else if (change === "delete") await c.deleteResponse!("cat", "r1", 1);
      else changed = true;
      const confirmed = (await c.api("state")) as ViewState;
      assert.equal(
        confirmed.responses.r1.status,
        change === "delete" ? "DELETED" : "ACTIVE",
      );
      const otherPending = c.detail!("letter:2");
      await otherHeld.promise;
      release.resolve();
      await rejected;
      otherRelease.resolve();
      // Opening another letter returns the whole current projection, exposing
      // any private-client rollback even when App ignored the original result.
      const afterOther = await otherPending;
      assert.equal(
        afterOther.responses.r1.status,
        change === "delete" ? "DELETED" : "ACTIVE",
      );
      assert.equal(afterOther.responses.r1.currentRevision, 2);
      assert.equal(
        afterOther.letters.find((letter) => letter.id === "letter:1")!.response,
        change === "delete" ? null : "已确认的新回应",
      );
      assert.equal(
        JSON.stringify(afterOther).includes("不应复活的旧回应"),
        false,
      );
      c.dispose();
    });
  }
}

test("two valid same-revision detail requests both keep their body after another merge", async () => {
  const { client, route } = setup(),
    c = client(),
    releaseB = deferred<void>(),
    heldB = deferred<void>();
  await c.api("state");
  globalThis.fetch = async (input, options) => {
    if (String(input).endsWith("/detail")) {
      const second = String(input).includes("letter%3A2");
      if (second) {
        heldB.resolve();
        await releaseB.promise;
      }
      return new Response(
        JSON.stringify({
          letter: {
            ...detail,
            id: second ? "letter:2" : "letter:1",
            snapshot: {
              ...detail.snapshot,
              body: second ? "有效B正文" : "有效A正文",
            },
          },
          stateRevision: 1,
        }),
      );
    }
    return route(input, options);
  };
  const b = c.detail!("letter:2");
  await heldB.promise;
  const a = await c.detail!("letter:1");
  assert.equal(
    a.letters.find((letter) => letter.id === "letter:1")!.snapshot.body,
    "有效A正文",
  );
  releaseB.resolve();
  const both = await b;
  assert.equal(
    both.letters.find((letter) => letter.id === "letter:1")!.snapshot.body,
    "有效A正文",
  );
  assert.equal(
    both.letters.find((letter) => letter.id === "letter:2")!.snapshot.body,
    "有效B正文",
  );
  c.dispose();
});
