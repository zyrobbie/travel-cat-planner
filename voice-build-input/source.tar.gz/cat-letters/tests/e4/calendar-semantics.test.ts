/** Frozen before/after semantic comparison, using disposable loopback DBs only. */
import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";
import { pool, transaction } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import {
  lockCloudCat,
  readCloudLetter,
} from "../../src/server/cloud-repository";
import {
  initializeCloudCalendar,
  settleCloudCalendar,
} from "../../src/server/cloud-calendar";

const OLD_SOURCE_SHA =
  "42a5c4eee8942cb7a819566921fdfe99b997900c7cfe3e5984c863f2014087fe";
const recording = process.env.E4_CALENDAR_BASELINE_RECORD === "true";
const baselinePath = new URL(
  "./fixtures/cloud-calendar-semantics.json",
  import.meta.url,
);
const BASE = Date.UTC(2026, 0, 1),
  WALL = BASE + 20 * 60_000;
const originalQuery = pg.Client.prototype.query;
let baseline: Record<string, unknown> = {};
const observed: Record<string, unknown> = {};
type Fixture = { account: string; cat: string; trips: string[] };
function stable(value: any): any {
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((k) => [k, stable(value[k])]),
    );
  return value;
}
const sha = (value: unknown) =>
  createHash("sha256")
    .update(JSON.stringify(stable(value)))
    .digest("hex");
async function one(sql: string, values: unknown[] = []) {
  return (await pool.query(sql, values)).rows[0];
}
async function fixture(): Promise<Fixture> {
  const account = randomUUID(),
    participant = randomUUID(),
    cat = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    account,
    `${account}@example.invalid`,
  ]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [
    participant,
  ]);
  await pool.query(
    "INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-02','语义合成猫')",
    [cat, account, participant],
  );
  await transaction(async (db) => {
    const owned = await lockCloudCat(db, account);
    await initializeCloudCalendar(db, owned, BASE);
  });
  // Golden-only deterministic fixture, never a cloud/natural observation clock.
  await pool.query(
    "UPDATE cloud_calendar_nodes SET planned_at=$2 WHERE account_id=$1 AND id='welcome:d0'",
    [account, new Date(BASE + 7 * 60_000)],
  );
  const trips = (
    await pool.query(
      "SELECT trip_id FROM cloud_calendar_nodes WHERE account_id=$1 AND kind='START' ORDER BY node_order",
      [account],
    )
  ).rows.map((row) => row.trip_id);
  return { account, cat, trips };
}
async function due(f: Fixture, ids: string[]) {
  await pool.query(
    "UPDATE cloud_calendar_nodes SET planned_at=CASE WHEN id=ANY($2::text[]) THEN $3::timestamptz+node_order*interval '1 millisecond' ELSE $4 END WHERE account_id=$1",
    [
      f.account,
      ids,
      new Date(BASE + 10 * 60_000),
      new Date(BASE + 30 * 86_400_000),
    ],
  );
}
async function settle(f: Fixture) {
  return transaction(async (db) =>
    settleCloudCalendar(db, await lockCloudCat(db, f.account)),
  );
}
async function seedLetter(
  f: Fixture,
  id: string,
  unread: boolean,
  type = "DEMAND",
) {
  await pool.query(
    "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,origin,read_at,delivered_at) VALUES($1,$2,$3,$4,$5,'LEGACY',$6,$7)",
    [
      id,
      f.cat,
      f.account,
      type,
      { title: "合成旧信", body: "冻结旧正文", catName: "语义合成猫" },
      unread ? null : new Date(BASE),
      new Date(BASE),
    ],
  );
}
function normalize(f: Fixture, value: any, key = ""): any {
  if (value instanceof Date)
    return key === "read_at" ? "<read>" : value.toISOString();
  if (typeof value === "string") {
    let text = value
      .split(f.account)
      .join("<account>")
      .split(f.cat)
      .join("<cat>");
    f.trips.forEach((trip, i) => {
      text = text.split(trip).join(`<trip${i + 1}>`);
    });
    return text;
  }
  if (Array.isArray(value))
    return value
      .map((item) => normalize(f, item))
      .sort((a, b) =>
        JSON.stringify(stable(a)).localeCompare(JSON.stringify(stable(b))),
      );
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [k, normalize(f, v, k)]),
    );
  return value;
}
async function capture(f: Fixture) {
  const specs: Record<string, string> = {
    calendar:
      "SELECT version,initialized_at,base_at,offset_ms,last_effective_at,processed_count,node_count FROM cloud_calendars WHERE account_id=$1",
    nodes:
      "SELECT id,planned_at,node_order,kind,trip_id,scene,content_id,origin,result_outcome,result_reason,written_at,effective_at,letter_id FROM cloud_calendar_nodes WHERE account_id=$1",
    trips:
      "SELECT id,scene,status,started_at,ended_at,planned_start_at,planned_end_at,origin FROM cloud_trips WHERE account_id=$1",
    letters:
      "SELECT id,type,content_id,content_version,snapshot,trip_id,story_id,calendar_node_id,delivered_at,planned_at,effective_at,read_at,skipped_at,origin FROM cloud_letters WHERE account_id=$1",
    reviews:
      "SELECT id,trip_id,story_id,fallback_id,kind,status,reason,review_authority,reviewed_by,reviewed_at FROM cloud_reviews WHERE account_id=$1",
    sources:
      "SELECT letter_id,source_order,response_id,revision,claim,start_offset,end_offset,assessment,attested FROM cloud_letter_sources WHERE account_id=$1",
    state: "SELECT revision FROM cloud_state WHERE account_id=$1",
    job: "SELECT status,next_run_at,lease_token,lease_until,attempts,last_error FROM cloud_jobs WHERE account_id=$1",
  };
  const result: Record<string, unknown> = {};
  for (const [name, sql] of Object.entries(specs)) {
    const rows = (await pool.query(sql, [f.account])).rows;
    if (name === "letters")
      for (const row of rows)
        row.snapshot = {
          sha256: sha(row.snapshot),
          title: row.snapshot.title,
          contentId: row.snapshot.contentId ?? null,
        };
    result[name] = normalize(f, rows);
  }
  return stable(result);
}
async function review(f: Fixture, valid: boolean, authorized = true) {
  await seedLetter(f, "source", false);
  const trip = f.trips[0];
  await pool.query(
    "INSERT INTO cloud_trips(id,cat_id,account_id,scene,status,started_at) VALUES($1,$2,$3,'FIREFLY','ACTIVE',$4)",
    [trip, f.cat, f.account, new Date(BASE)],
  );
  await transaction(async (db) => {
    for (const id of ["response-one", "response-two"]) {
      await seedResponse(
        db,
        f,
        id,
        id === "response-one" ? "source" : "source-two",
        valid ? 1 : 2,
      );
    }
    await db.query(
      "INSERT INTO cloud_reviews(id,cat_id,account_id,trip_id,story_id,fallback_id,kind,status,reason,review_authority,reviewed_by,reviewed_at) VALUES('review',$1,$2,$3,'L-FIREFLY','O-FIREFLY-01','LINKED','SELECTED','fixture',$4,$5,$6)",
      [
        f.cat,
        f.account,
        trip,
        authorized ? "INTERNAL_ADMIN" : "UNREVIEWED",
        authorized ? "fixture-admin" : null,
        authorized ? new Date(BASE) : null,
      ],
    );
    for (const [order, claim] of ["companionship", "care_value"].entries())
      await db.query(
        "INSERT INTO cloud_review_sources(cat_id,account_id,review_id,source_order,response_id,revision,claim,start_offset,end_offset,assessment,attested) VALUES($1,$2,'review',$3,$4,1,$5,0,2,'SUPPORTED',true)",
        [
          f.cat,
          f.account,
          order,
          order === 0 ? "response-one" : "response-two",
          claim,
        ],
      );
  });
}
async function seedResponse(
  db: pg.PoolClient,
  f: Fixture,
  id: string,
  letter: string,
  current: number,
) {
  if (letter !== "source")
    await db.query(
      "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,origin,read_at,delivered_at) VALUES($1,$2,$3,'DEMAND',$4,'LEGACY',$5,$5)",
      [
        letter,
        f.cat,
        f.account,
        { title: "合成来源", body: "来源正文", catName: "语义合成猫" },
        new Date(BASE),
      ],
    );
  await db.query(
    "INSERT INTO cloud_responses(id,cat_id,account_id,letter_id,current_revision,status) VALUES($1,$2,$3,$4,$5,'ACTIVE')",
    [id, f.cat, f.account, letter, current],
  );
  for (let revision = 1; revision <= current; revision++)
    await db.query(
      "INSERT INTO cloud_response_revisions(cat_id,account_id,response_id,revision,text,at) VALUES($1,$2,$3,$4,'同行', $5)",
      [f.cat, f.account, id, revision, new Date(BASE)],
    );
}
const scenarios: Record<string, (f: Fixture) => Promise<unknown>> = {
  "all13-empty": async (f) => {
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=$2 WHERE account_id=$1",
      [f.account, 15 * 86_400_000],
    );
    await settle(f);
    return capture(f);
  },
  "all13-existing-multiple-unread": async (f) => {
    await seedLetter(f, "old-demand", true);
    await seedLetter(f, "old-postcard", true, "POSTCARD");
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=$2 WHERE account_id=$1",
      [f.account, 15 * 86_400_000],
    );
    await settle(f);
    return capture(f);
  },
  "all13-unrelated-active-trip": async (f) => {
    await pool.query(
      "INSERT INTO cloud_trips(id,cat_id,account_id,scene,status,started_at) VALUES('unrelated',$1,$2,'RHINE','ACTIVE',$3)",
      [f.cat, f.account, new Date(BASE)],
    );
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=$2 WHERE account_id=$1",
      [f.account, 15 * 86_400_000],
    );
    await settle(f);
    return capture(f);
  },
  "no-due": async (f) => {
    await due(f, []);
    await settle(f);
    return capture(f);
  },
  "earliest-demand-wins": async (f) => {
    await due(f, ["fixed:d1", "fixed:d3", "fixed:d5"]);
    await settle(f);
    return capture(f);
  },
  "missing-ordinary-skips": async (f) => {
    await due(f, ["fixed:d12", "fixed:d13"]);
    const row = await one(
      "SELECT * FROM cloud_content_versions WHERE content_id='O-LIGHTHOUSE-01'",
    );
    await pool.query(
      "DELETE FROM cloud_content_versions WHERE content_id=$1 AND version=$2",
      [row.content_id, row.version],
    );
    try {
      await settle(f);
      return await capture(f);
    } finally {
      await pool.query(
        "INSERT INTO cloud_content_versions(content_id,version,type,payload,body_checksum,payload_checksum) VALUES($1,$2,$3,$4,$5,$6)",
        [
          row.content_id,
          row.version,
          row.type,
          row.payload,
          row.body_checksum,
          row.payload_checksum,
        ],
      );
    }
  },
  "sequential-normal-travel": async (f) => {
    const sequence = (
      await pool.query(
        "SELECT id,planned_at FROM cloud_calendar_nodes WHERE account_id=$1 ORDER BY planned_at,node_order",
        [f.account],
      )
    ).rows;
    const steps = [];
    for (const node of sequence) {
      await pool.query(
        "UPDATE cloud_calendars SET offset_ms=$2 WHERE account_id=$1",
        [f.account, Math.max(0, node.planned_at.getTime() - WALL)],
      );
      await settle(f);
      for (const letter of (
        await pool.query(
          "SELECT id FROM cloud_letters WHERE account_id=$1 AND read_at IS NULL",
          [f.account],
        )
      ).rows)
        await readCloudLetter(f.account, letter.id);
      steps.push(await capture(f));
    }
    return steps;
  },
  "ordinary-postcard": async (f) => {
    await due(f, ["fixed:d6", "fixed:d7"]);
    await settle(f);
    return capture(f);
  },
  "linked-postcard": async (f) => {
    await review(f, true);
    await due(f, ["fixed:d7"]);
    await settle(f);
    return capture(f);
  },
  "stale-source-fallback": async (f) => {
    await review(f, false);
    await due(f, ["fixed:d7"]);
    await settle(f);
    return capture(f);
  },
  "corrupt-used-content-rolls-back-even-with-unread": async (f) => {
    await seedLetter(f, "unread", true);
    const before = await capture(f);
    const row = await one(
      "SELECT * FROM cloud_content_versions WHERE content_id='D-07'",
    );
    await pool.query(
      "ALTER TABLE cloud_content_versions DISABLE TRIGGER cloud_content_immutable",
    );
    await pool.query(
      "UPDATE cloud_content_versions SET payload_checksum='corrupt' WHERE content_id='D-07'",
    );
    try {
      await assert.rejects(settle(f), /checksum/);
      assert.deepEqual(await capture(f), before);
      return before;
    } finally {
      await pool.query(
        "UPDATE cloud_content_versions SET payload_checksum=$1 WHERE content_id='D-07'",
        [row.payload_checksum],
      );
      await pool.query(
        "ALTER TABLE cloud_content_versions ENABLE TRIGGER cloud_content_immutable",
      );
    }
  },
  "last-node-write-fault-rolls-back-entire-world": async (f) => {
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=$2 WHERE account_id=$1",
      [f.account, 15 * 86_400_000],
    );
    const before = await capture(f);
    await pool.query(
      `CREATE FUNCTION semantic_node_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.id='fixed:d14' THEN RAISE EXCEPTION 'synthetic node failure'; END IF; RETURN NEW; END $$; CREATE TRIGGER semantic_node_fault BEFORE UPDATE ON cloud_calendar_nodes FOR EACH ROW EXECUTE FUNCTION semantic_node_fault()`,
    );
    try {
      await assert.rejects(settle(f), /synthetic node failure/);
      assert.deepEqual(await capture(f), before);
      return before;
    } finally {
      await pool.query(
        "DROP TRIGGER semantic_node_fault ON cloud_calendar_nodes; DROP FUNCTION semantic_node_fault()",
      );
    }
  },
};
before(async () => {
  for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
    const url = new URL(process.env[key]!);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(url.pathname, "/catletters_automatic_delivery_test");
  }
  if (recording)
    assert.equal(
      createHash("sha256")
        .update(await readFile("src/server/cloud-calendar.ts"))
        .digest("hex"),
      OLD_SOURCE_SHA,
      "Never record a new golden from modified production logic",
    );
  else {
    const data = JSON.parse(await readFile(baselinePath, "utf8"));
    assert.equal(data.sourceSha256, OLD_SOURCE_SHA);
    baseline = data.cases;
  }
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    const sql = typeof args[0] === "string" ? args[0] : args[0].text;
    if (sql === "SELECT clock_timestamp() AS now")
      return Promise.resolve({
        command: "SELECT",
        rowCount: 1,
        fields: [],
        rows: [{ now: new Date(WALL) }],
      });
    return (originalQuery as Function).apply(this, args);
  } as typeof originalQuery;
});
after(async () => {
  pg.Client.prototype.query = originalQuery;
  if (recording) {
    assert.equal(Object.keys(observed).length, Object.keys(scenarios).length);
    await writeFile(
      baselinePath,
      JSON.stringify(
        {
          sourceSha256: OLD_SOURCE_SHA,
          scope:
            "old implementation on isolated DBs; deterministic test-only clock, IDs/read timestamps normalized; snapshots SHA256",
          cases: observed,
        },
        null,
        2,
      ) + "\n",
      { flag: "wx" },
    );
  }
  await writeFile(
    join(process.env.E4_AUTOMATIC_EVIDENCE!, "calendar-semantics.json"),
    JSON.stringify(
      {
        recording,
        sourceSha256: createHash("sha256")
          .update(await readFile("src/server/cloud-calendar.ts"))
          .digest("hex"),
        goldenSourceSha256: OLD_SOURCE_SHA,
        cases: Object.keys(observed),
        status:
          Object.keys(observed).length === Object.keys(scenarios).length
            ? "PASS"
            : "INCOMPLETE",
      },
      null,
      2,
    ) + "\n",
  );
  await closeLifecycleProvider();
  await pool.end();
});
for (const [name, run] of Object.entries(scenarios))
  test(`C ${name}`, async () => {
    const f = await fixture();
    if (!recording && name.includes("rolls-back")) {
      // The old golden captured this job's original random welcome due time.
      // Replay that initial fixture value, retaining exact before/after rollback
      // checks and an unchanged golden, rather than comparing two random draws.
      const initial = (baseline[name] as { job: { next_run_at: string }[] })
        .job[0].next_run_at;
      assert.ok(
        Date.parse(initial) >= BASE + 300_000 &&
          Date.parse(initial) <= BASE + 600_000,
      );
      await pool.query(
        "UPDATE cloud_jobs SET next_run_at=$2 WHERE account_id=$1",
        [f.account, new Date(initial)],
      );
    }
    const value = await run(f);
    if (!recording) assert.deepEqual(value, baseline[name]);
    observed[name] = value;
  });
