import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { fork, type ChildProcess } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";
import handler, {
  config,
} from "../../netlify/functions/e4-cloud-scheduled.mjs";
import { pool, transaction } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { lockCloudCat } from "../../src/server/cloud-repository";
import { initializeCloudCalendar } from "../../src/server/cloud-calendar";
import { cloudTick } from "../../src/server/scheduled-candidate";
import {
  claimCloudJob,
  CLOUD_BUDGET_PENDING,
  runClaimedCloudJob,
  type CloudJobClaim,
} from "../../src/server/cloud-worker";

const ledger = new pg.Pool({
  connectionString: process.env.E4_LEDGER_DATABASE_URL,
});
const published = { deploy: { context: "production", published: true } };
let selected: string, other: string, sentinel: string;
const evidence: object[] = [];
const auditLogs: string[] = [];
const originalInfo = console.info;
const req = (
  body: unknown = { next_run: new Date(Date.now() + 60_000).toISOString() },
  query = "",
) =>
  new Request(
    `https://local.invalid/.netlify/functions/e4-cloud-scheduled${query}`,
    {
      method: "POST",
      body: JSON.stringify(body),
    },
  );
async function invoke(body?: unknown, query = "") {
  return handler(req(body, query), published);
}
function target(id: string) {
  process.env.E4_AUTO_DELIVERY_ENABLED = "true";
  process.env.E4_AUTO_DELIVERY_ACCOUNT_ID = id;
  process.env.E4_AUTO_DELIVERY_UNTIL = new Date(
    Date.now() + 3600_000,
  ).toISOString();
}
async function seed(due = true, domain = "example.invalid", baseAt?: number) {
  const accountId = randomUUID(),
    participantId = randomUUID(),
    catId = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    accountId,
    `${accountId}@${domain}`,
  ]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [
    participantId,
  ]);
  await pool.query(
    "INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-02','自动投递合成猫')",
    [catId, accountId, participantId],
  );
  await transaction(async (db) => {
    const cat = await lockCloudCat(db, accountId);
    // Local due-state fixture only. Natural cloud acceptance never uses this clock.
    await initializeCloudCalendar(
      db,
      cat,
      baseAt ?? Date.now() - (due ? 20 * 60_000 : 0),
    );
  });
  return accountId;
}
async function snapshot(id: string) {
  const rows = [];
  for (const [table, order] of [
    ["accounts", "id"],
    ["cat_profiles", "id"],
    ["cloud_jobs", "id"],
    ["cloud_calendars", "cat_id"],
    ["cloud_calendar_nodes", "id"],
    ["cloud_letters", "id"],
    ["cloud_state", "cat_id"],
    ["account_exports", "id"],
    ["account_deletions", "account_id"],
  ])
    rows.push(
      (
        await pool.query(
          `SELECT * FROM ${table} WHERE ${table === "accounts" ? "id" : "account_id"}=$1 ORDER BY ${order}`,
          [id],
        )
      ).rows,
    );
  return JSON.stringify(rows);
}
async function one(sql: string, values: unknown[] = []) {
  return (await pool.query(sql, values)).rows[0];
}
async function calls<T>(work: () => Promise<T>) {
  const original = pg.Client.prototype.query;
  let count = 0;
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    count++;
    return (original as Function).apply(this, args);
  } as typeof original;
  try {
    return { value: await work(), count };
  } finally {
    pg.Client.prototype.query = original;
  }
}
async function letters(id: string) {
  return (
    await one(
      "SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",
      [id],
    )
  ).n;
}
before(async () => {
  for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
    const url = new URL(process.env[key]!);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(url.pathname, "/catletters_automatic_delivery_test");
  }
  assert.equal(process.env.E4_SCHEDULED_RUN, "true");
  assert.equal(pool.options.max, 2);
  assert.equal(pool.options.idleTimeoutMillis, 5000);
  const a = (
    await pool.query("SELECT system_identifier FROM pg_control_system()")
  ).rows[0];
  const b = (
    await ledger.query("SELECT system_identifier FROM pg_control_system()")
  ).rows[0];
  assert.notEqual(a.system_identifier, b.system_identifier);
  selected = await seed();
  other = await seed();
  sentinel = await seed(true, "ordinary.example.test");
  target(selected);
  console.info = (...parts: unknown[]) => {
    const line = parts.map(String).join(" ");
    auditLogs.push(line);
    originalInfo(line);
  };
});
after(async () => {
  console.info = originalInfo;
  assert.equal(
    auditLogs.some(
      (line) =>
        line.includes("@") ||
        line.includes(selected) ||
        line.includes("synthetic_private_failure"),
    ),
    false,
  );
  await writeFile(
    join(process.env.E4_AUTOMATIC_EVIDENCE!, "cases.json"),
    JSON.stringify(
      {
        scope:
          "two independent local PostgreSQL clusters; trusted platform context mocked, real runner/locks/leases",
        cloudExecuted: false,
        naturalFirstLetterObserved: false,
        cases: evidence,
      },
      null,
      2,
    ) + "\n",
  );
  await closeLifecycleProvider();
  await Promise.all([pool.end(), ledger.end()]);
});

test("A01 schedule remains unregistered and all disabled/config/context/request gates do zero SQL", async () => {
  assert.deepEqual(config, {});
  async function denied(status: number, work: () => Promise<Response>) {
    const result = await calls(work);
    assert.equal(result.value.status, status);
    assert.equal(result.count, 0);
  }
  process.env.E4_AUTO_DELIVERY_ENABLED = "false";
  await denied(200, () => invoke());
  process.env.E4_AUTO_DELIVERY_ENABLED = "true";
  process.env.APP_MODE = "PUBLIC";
  await denied(200, () => invoke());
  process.env.APP_MODE = "INTERNAL";
  for (const deploy of [
    undefined,
    { context: "deploy-preview", published: false },
    { context: "production", published: false },
  ])
    await denied(403, () => handler(req(), { deploy }));
  const fake = req();
  fake.headers.set("x-netlify-scheduled", "true");
  await denied(403, () => handler(fake));
  for (const value of ["", "all", "not-a-uuid"]) {
    process.env.E4_AUTO_DELIVERY_ACCOUNT_ID = value;
    await denied(503, () => invoke());
  }
  target(selected);
  for (const value of ["", "invalid", "2026-10-15T08:00:00+08:00"]) {
    process.env.E4_AUTO_DELIVERY_UNTIL = value;
    await denied(503, () => invoke());
  }
  process.env.E4_AUTO_DELIVERY_UNTIL = new Date(
    Date.now() - 1000,
  ).toISOString();
  await denied(200, () => invoke());
  target(selected);
  for (const query of [
    `?accountId=${other}`,
    "?all=true",
    "?kind=privacy",
    "?kind=cleanup",
    "?jobId=x",
  ])
    await denied(400, () => invoke(undefined, query));
  for (const body of [
    { next_run: "2099-01-01T00:00:00Z", accountId: other },
    { next_run: "2099-01-01T00:00:00Z", all: true },
    { next_run: "2099-01-01T00:00:00Z", allowBudgetRecovery: true },
    { kind: "cleanup" },
    [],
    null,
    { next_run: "x" },
    { next_run: "x".repeat(2000) },
  ])
    await denied(400, () => invoke(body));
  evidence.push({
    test: "A01",
    status: "PASS",
    sqlCallsForRejectedOrDisabledInvocation: 0,
  });
});

test("A02 future welcome stays future; request next_run cannot advance the business clock", async () => {
  const id = await seed(false);
  target(id);
  const before = await snapshot(id);
  const result = await invoke({ next_run: "2099-01-01T00:00:00Z" });
  assert.equal(result.status, 200);
  assert.equal((await result.json()).status, "IDLE");
  assert.equal(await letters(id), 0);
  assert.equal(await snapshot(id), before);
  evidence.push({
    test: "A02",
    status: "PASS",
    noTimeAdvance: true,
    noLetterCreated: true,
  });
});

test("A03 overlapping scheduler calls deliver once and preserve outside jobs/privacy rows byte-for-byte", async () => {
  target(selected);
  await pool.query(
    "UPDATE cloud_jobs SET status='LEASED',attempts=5,lease_token=$2,lease_until=clock_timestamp()-interval '1 minute',next_run_at=clock_timestamp()-interval '1 minute' WHERE account_id=ANY($1::uuid[])",
    [[other, sentinel], randomUUID()],
  );
  for (const id of [selected, other, sentinel]) {
    await pool.query(
      "INSERT INTO account_exports(id,account_id,request_key,status) VALUES($1,$2,$3,'QUEUED')",
      [randomUUID(), id, randomUUID()],
    );
    await pool.query(
      "INSERT INTO account_deletions(account_id,request_id,status) VALUES($1,$2,'PENDING')",
      [id, randomUUID()],
    );
  }
  const outside = await Promise.all([other, sentinel].map(snapshot));
  const privateBefore = JSON.stringify(
    (await pool.query("SELECT id,status FROM account_exports ORDER BY id"))
      .rows,
  );
  process.env.E4_SCHEDULED_EXPORTS_ENABLED = "true"; // This entry still cannot invoke privacy.
  const result = await Promise.all([invoke(), invoke()]);
  assert.ok(result.every((response) => response.status === 200));
  const data = await Promise.all(result.map((response) => response.json()));
  assert.equal(data.filter((value) => value.status === "SETTLED").length, 1);
  assert.ok(data.every((value) => value.attempted <= 1));
  assert.equal(await letters(selected), 1);
  assert.deepEqual(await Promise.all([other, sentinel].map(snapshot)), outside);
  assert.equal(
    JSON.stringify(
      (await pool.query("SELECT id,status FROM account_exports ORDER BY id"))
        .rows,
    ),
    privateBefore,
  );
  assert.equal(
    (
      await one(
        "SELECT count(*)::int AS n FROM account_deletions WHERE status='PENDING'",
      )
    ).n,
    3,
  );
  assert.equal((await (await invoke()).json()).status, "IDLE");
  process.env.E4_SCHEDULED_EXPORTS_ENABLED = "false";
  evidence.push({
    test: "A03",
    status: "PASS",
    overlapSettled: 1,
    letters: 1,
    outsideUntouched: true,
    privacyUntouched: true,
  });
});

test("A04 nonexistent/wrong-domain/DELETING scope and closed/damaged ledger fail without business changes", async () => {
  for (const id of [randomUUID(), sentinel]) {
    target(id);
    const before = await Promise.all([selected, other, sentinel].map(snapshot));
    await assert.rejects(invoke(), /UNKNOWN_CHECK_DURABLE_STATE/);
    assert.deepEqual(
      await Promise.all([selected, other, sentinel].map(snapshot)),
      before,
    );
  }
  target(selected);
  await pool.query("UPDATE accounts SET status='DELETING' WHERE id=$1", [
    selected,
  ]);
  const before = await snapshot(selected);
  await assert.rejects(invoke(), /UNKNOWN_CHECK_DURABLE_STATE/);
  assert.equal(await snapshot(selected), before);
  await pool.query("UPDATE accounts SET status='ACTIVE' WHERE id=$1", [
    selected,
  ]);
  for (const corrupt of ["gate", "watermark", "head"]) {
    const unchanged = await snapshot(selected);
    if (corrupt === "gate")
      await ledger.query("UPDATE restore_gate SET status='CLOSED'");
    if (corrupt === "watermark")
      await pool.query("UPDATE lifecycle_control SET ledger_hash='mismatch'");
    if (corrupt === "head")
      await ledger.query("UPDATE ledger_head SET hash='mismatch'");
    try {
      await assert.rejects(invoke(), /UNKNOWN_CHECK_DURABLE_STATE/);
      assert.equal(await snapshot(selected), unchanged);
    } finally {
      if (corrupt === "gate")
        await ledger.query("UPDATE restore_gate SET status='READY'");
      if (corrupt === "watermark")
        await pool.query("UPDATE lifecycle_control SET ledger_hash=''");
      if (corrupt === "head")
        await ledger.query("UPDATE ledger_head SET hash=''");
    }
  }
  evidence.push({ test: "A04", status: "PASS", failClosed: true });
});

test("A05 technical failure rolls back; durable backoff retries once without duplicating", async () => {
  const id = await seed();
  target(id);
  await pool.query(`CREATE FUNCTION synthetic_auto_failure() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'synthetic_private_failure'; END $$;
    CREATE TRIGGER synthetic_auto_failure BEFORE INSERT ON cloud_letters FOR EACH ROW EXECUTE FUNCTION synthetic_auto_failure()`);
  let retryAt: Date;
  try {
    const response = await invoke();
    assert.equal((await response.json()).status, "RETRY");
    assert.equal(await letters(id), 0);
    const row = await one(
      "SELECT status,attempts,last_error,next_run_at,lease_token FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.equal(row.status, "READY");
    assert.equal(row.attempts, 1);
    assert.equal(row.last_error, "TECHNICAL:P0001");
    assert.equal(row.lease_token, null);
    retryAt = row.next_run_at;
    assert.equal(
      (
        await one(
          "SELECT processed_count FROM cloud_calendars WHERE account_id=$1",
          [id],
        )
      ).processed_count,
      0,
    );
    assert.equal((await (await invoke()).json()).status, "IDLE");
  } finally {
    await pool.query(
      "DROP TRIGGER synthetic_auto_failure ON cloud_letters; DROP FUNCTION synthetic_auto_failure()",
    );
  }
  await delay(Math.max(0, retryAt!.getTime() - Date.now() + 30));
  assert.equal((await (await invoke()).json()).status, "SETTLED");
  assert.equal(await letters(id), 1);
  assert.equal((await (await invoke()).json()).status, "IDLE");
  assert.equal(await letters(id), 1);
  evidence.push({
    test: "A05",
    status: "PASS",
    rollback: true,
    realBackoffWait: true,
    duplicateLetters: 0,
  });
});

test("A06 entry/stop-time budget is not reset after setup; automatic path makes only one claim", async () => {
  target(selected);
  const tooLate = await calls(() =>
    cloudTick(
      { accountId: selected },
      { invocationDeadlineAt: Date.now() + 6000, maxJobs: 1 },
    ),
  );
  assert.equal(tooLate.count, 0);
  assert.equal(tooLate.value.attempted, 0);
  process.env.E4_AUTO_DELIVERY_UNTIL = new Date(
    Date.now() + 1000,
  ).toISOString();
  const ending = await calls(() => invoke());
  assert.equal(ending.count, 0);
  assert.equal((await ending.value.json()).status, "DEFERRED");
  target(selected);
  const realNow = Date.now;
  const at = realNow();
  let fakeNow = at;
  Date.now = () => fakeNow;
  try {
    const stream = new ReadableStream<Uint8Array>({
      pull(controller) {
        fakeNow = at + 19_000;
        controller.enqueue(
          new TextEncoder().encode(
            JSON.stringify({ next_run: "2099-01-01T00:00:00Z" }),
          ),
        );
        controller.close();
      },
    });
    const slow = new Request(
      "https://local.invalid/.netlify/functions/e4-cloud-scheduled",
      { method: "POST", body: stream, duplex: "half" } as RequestInit,
    );
    const result = await calls(() => handler(slow, published));
    assert.equal(result.count, 0);
    assert.equal((await result.value.json()).status, "DEFERRED");
  } finally {
    Date.now = realNow;
  }
  const id = await seed();
  target(id);
  const original = pg.Client.prototype.query;
  let claims = 0;
  const localLimits = { statement: 0, lock: 0, idle: 0 };
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    const sql = typeof args[0] === "string" ? args[0] : args[0].text;
    if (sql.includes("WITH eligible AS")) claims++;
    if (sql.startsWith("SET LOCAL statement_timeout")) localLimits.statement++;
    if (sql.startsWith("SET LOCAL lock_timeout")) localLimits.lock++;
    if (sql.startsWith("SET LOCAL idle_in_transaction_session_timeout"))
      localLimits.idle++;
    return (original as Function).apply(this, args);
  } as typeof original;
  try {
    assert.equal((await (await invoke()).json()).status, "SETTLED");
  } finally {
    pg.Client.prototype.query = original;
  }
  assert.equal(claims, 1);
  assert.deepEqual(localLimits, { statement: 2, lock: 2, idle: 2 });
  evidence.push({
    test: "A06",
    status: "PASS",
    setupConsumesOriginalBudget: true,
    stopTimeClampsBudget: true,
    claimsPerInvocation: 1,
    localLimitsInstalledOncePerTransaction: true,
  });
});

test("A07 unread exclusions and missed nodes remain permanent; freeing unread does not backfill", async () => {
  const blocked = await seed();
  target(blocked);
  const cat = await one("SELECT id FROM cat_profiles WHERE account_id=$1", [
    blocked,
  ]);
  await pool.query(
    "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,origin) VALUES($1,$2,$3,'DEMAND',$4,'LEGACY')",
    [
      randomUUID(),
      cat.id,
      blocked,
      { title: "已有未读", body: "合成未读", catName: "合成猫" },
    ],
  );
  assert.equal((await (await invoke()).json()).status, "SETTLED");
  assert.equal(await letters(blocked), 1);
  const welcome = await one(
    "SELECT result_outcome,result_reason FROM cloud_calendar_nodes WHERE account_id=$1 AND id='welcome:d0'",
    [blocked],
  );
  assert.equal(welcome.result_outcome, "SKIPPED");
  assert.match(welcome.result_reason, /未读/);
  const late = await seed(
    true,
    "example.invalid",
    Date.now() - 15 * 86_400_000,
  );
  target(late);
  assert.equal((await (await invoke()).json()).status, "SETTLED");
  assert.equal(await letters(late), 1);
  const plan = await one(
    "SELECT node_count,processed_count FROM cloud_calendars WHERE account_id=$1",
    [late],
  );
  assert.equal(plan.processed_count, plan.node_count);
  assert.equal(
    (
      await one(
        "SELECT count(*)::int AS n FROM cloud_calendar_nodes WHERE account_id=$1 AND result_outcome='SKIPPED'",
        [late],
      )
    ).n > 0,
    true,
  );
  assert.equal(
    (await one("SELECT status FROM cloud_jobs WHERE account_id=$1", [late]))
      .status,
    "COMPLETE",
  );
  const delivered = await one(
    "SELECT id FROM cloud_letters WHERE account_id=$1",
    [late],
  );
  const { readCloudLetter } = await import("../../src/server/cloud-repository");
  await readCloudLetter(late, delivered.id);
  assert.equal((await (await invoke()).json()).status, "IDLE");
  assert.equal(await letters(late), 1);
  evidence.push({
    test: "A07",
    status: "PASS",
    syntheticPastCalendarOnly: true,
    unreadSkipped: true,
    missedNodesNotBackfilled: true,
  });
});

function child(
  mode:
    | "settling"
    | "committed"
    | "claim-committed"
    | "commit-request-lost"
    | "claim-commit-request-lost",
  id: string,
) {
  const businessUrl = new URL(process.env.DATABASE_URL!),
    ledgerUrl = new URL(process.env.E4_LEDGER_DATABASE_URL!);
  businessUrl.searchParams.set("application_name", "e4_auto_crash_business");
  ledgerUrl.searchParams.set("application_name", "e4_auto_crash_ledger");
  const processChild = fork(
    "scripts/automatic-delivery-crash-fixture.ts",
    [mode],
    {
      execArgv: ["--import", "tsx"],
      silent: true,
      env: {
        ...process.env,
        DATABASE_URL: businessUrl.href,
        E4_LEDGER_DATABASE_URL: ledgerUrl.href,
        E4_AUTO_DELIVERY_ACCOUNT_ID: id,
      },
    },
  );
  let rejectPhase: (reason: Error) => void = () => {};
  const phases = new Set<string>();
  let claimed: CloudJobClaim | undefined;
  const listeners = new Map<string, () => void>();
  processChild.on("message", (message: unknown) => {
    claimed = (message as { claim?: CloudJobClaim })?.claim ?? claimed;
    const phase = (message as { phase?: string })?.phase;
    if (phase) {
      phases.add(phase);
      listeners.get(phase)?.();
    }
  });
  processChild.once("error", () =>
    rejectPhase(Error("Synthetic child failed")),
  );
  processChild.once("exit", (code) => {
    if (code !== null)
      rejectPhase(Error("Synthetic child exited before expected phase"));
  });
  return {
    processChild,
    claim: () => claimed,
    wait: (phase: string) =>
      new Promise<void>((resolve, reject) => {
        if (phases.has(phase)) {
          resolve();
          return;
        }
        const timer = setTimeout(
          () => reject(Error("Synthetic child phase timed out")),
          20_000,
        );
        rejectPhase = (error) => {
          clearTimeout(timer);
          reject(error);
        };
        listeners.set(phase, () => {
          clearTimeout(timer);
          resolve();
        });
      }),
  };
}
async function kill(processChild: ChildProcess) {
  if (processChild.exitCode !== null || processChild.signalCode !== null)
    return;
  const done = new Promise<void>((resolve) =>
    processChild.once("exit", () => resolve()),
  );
  processChild.kill("SIGKILL");
  await done;
}
async function childBackendsGone() {
  for (let i = 0; i < 80; i++) {
    const n = (
      await one(
        "SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4_auto_crash_business'",
      )
    ).n;
    if (n === 0) return;
    await delay(100);
  }
  assert.fail("Crashed backend did not release locks");
}

test(
  "A08 killed settlement rolls back; persisted 60-second lease really expires and next tick recovers",
  { timeout: 90_000 },
  async () => {
    const id = await seed();
    target(id);
    await pool.query(`CREATE FUNCTION synthetic_auto_pause() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN PERFORM pg_sleep(3); RETURN NEW; END $$;
    CREATE TRIGGER synthetic_auto_pause BEFORE INSERT ON cloud_letters FOR EACH ROW EXECUTE FUNCTION synthetic_auto_pause()`);
    const fixture = child("settling", id);
    try {
      await fixture.wait("SETTLING");
      let sleeping = false;
      for (let i = 0; i < 30; i++) {
        sleeping =
          (
            await one(
              "SELECT count(*)::int AS n FROM pg_stat_activity WHERE application_name='e4_auto_crash_business' AND wait_event='PgSleep'",
            )
          ).n > 0;
        if (sleeping) break;
        await delay(20);
      }
      assert.equal(sleeping, true);
      await kill(fixture.processChild);
      await childBackendsGone();
    } finally {
      await kill(fixture.processChild);
      await pool.query(
        "DROP TRIGGER synthetic_auto_pause ON cloud_letters; DROP FUNCTION synthetic_auto_pause()",
      );
    }
    const row = await one(
      "SELECT status,attempts,lease_until FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.equal(row.status, "LEASED");
    assert.equal(row.attempts, 1);
    assert.equal(await letters(id), 0);
    assert.equal(
      (
        await one(
          "SELECT processed_count FROM cloud_calendars WHERE account_id=$1",
          [id],
        )
      ).processed_count,
      0,
    );
    assert.equal((await (await invoke()).json()).status, "IDLE");
    const waitStarted = Date.now();
    originalInfo(
      "A08 waiting for the actual persisted 60-second lease; no clock/lease edits.",
    );
    for (let i = 0; i < 140; i++) {
      if (
        (
          await one(
            "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
            [id],
          )
        ).expired
      )
        break;
      await delay(500);
    }
    assert.equal(
      (
        await one(
          "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
          [id],
        )
      ).expired,
      true,
    );
    assert.equal((await (await invoke()).json()).status, "SETTLED");
    assert.equal(await letters(id), 1);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    assert.equal(await letters(id), 1);
    evidence.push({
      test: "A08",
      status: "PASS",
      processKilledDuringRealSql: true,
      rollback: true,
      leaseSeconds: 60,
      actualExpiryWaitMs: Date.now() - waitStarted,
      leaseEdited: false,
      clockEdited: false,
      recoveredOnce: true,
    });
  },
);

test(
  "A09 process dies after durable commit before invocation acknowledgement; next tick never duplicates",
  { timeout: 25_000 },
  async () => {
    const id = await seed();
    target(id);
    const fixture = child("committed", id);
    try {
      await fixture.wait("COMMITTED_REPLY_HELD");
      await kill(fixture.processChild);
      await childBackendsGone();
    } finally {
      await kill(fixture.processChild);
    }
    assert.equal(await letters(id), 1);
    const job = await one(
      "SELECT status,lease_token,lease_until FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.equal(job.status, "READY");
    assert.equal(job.lease_token, null);
    assert.equal(job.lease_until, null);
    const before = await snapshot(id);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    assert.equal(await snapshot(id), before);
    const oldClaim = fixture.claim()!;
    assert.ok(oldClaim);
    assert.equal(
      (
        await runClaimedCloudJob(oldClaim, Date.now() + 25_000, {
          accountId: id,
        })
      ).status,
      "STALE",
    );
    assert.equal(await snapshot(id), before);
    // Local lease-ownership fixture only: make the idle job eligible to acquire
    // a newer token without editing immutable calendar nodes or letters.
    await pool.query(
      "UPDATE cloud_jobs SET next_run_at=clock_timestamp()-interval '1 second' WHERE account_id=$1",
      [id],
    );
    const newClaim = (await claimCloudJob(Date.now() + 25_000, {
      accountId: id,
    }))!;
    assert.ok(newClaim);
    assert.notEqual(newClaim.leaseToken, oldClaim.leaseToken);
    const newer = await snapshot(id);
    assert.equal(
      (
        await runClaimedCloudJob(oldClaim, Date.now() + 25_000, {
          accountId: id,
        })
      ).status,
      "STALE",
    );
    assert.equal(await snapshot(id), newer);
    assert.equal(
      (
        await runClaimedCloudJob(newClaim, Date.now() + 25_000, {
          accountId: id,
        })
      ).status,
      "SETTLED",
    );
    assert.equal(await letters(id), 1);
    evidence.push({
      test: "A09",
      status: "PASS",
      durableCommitThenProcessKill: true,
      invocationAcknowledgementWithheld: true,
      duplicateLetters: 0,
      oldClaimRejectedAsStale: true,
      newerLeasePreserved: true,
      durable: {
        letters: 1,
        processedCount: (
          await one(
            "SELECT processed_count FROM cloud_calendars WHERE account_id=$1",
            [id],
          )
        ).processed_count,
        jobStatus: job.status,
        leaseCleared: job.lease_token === null && job.lease_until === null,
      },
    });
  },
);

test(
  "A10 claim commit acknowledgement is lost; persisted lease expires naturally and recovers",
  { timeout: 90_000 },
  async () => {
    const id = await seed();
    target(id);
    const fixture = child("claim-committed", id);
    try {
      await fixture.wait("CLAIM_COMMITTED_REPLY_HELD");
      await kill(fixture.processChild);
      await childBackendsGone();
    } finally {
      await kill(fixture.processChild);
    }
    const job = await one(
      "SELECT status,attempts,lease_until FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.equal(job.status, "LEASED");
    assert.equal(job.attempts, 1);
    assert.equal(await letters(id), 0);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    const waitStarted = Date.now();
    originalInfo(
      "A10 waiting for actual claim-commit lease expiry after acknowledgement loss.",
    );
    for (let i = 0; i < 140; i++) {
      if (
        (
          await one(
            "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
            [id],
          )
        ).expired
      )
        break;
      await delay(500);
    }
    assert.equal(
      (
        await one(
          "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
          [id],
        )
      ).expired,
      true,
    );
    assert.equal((await (await invoke()).json()).status, "SETTLED");
    assert.equal(await letters(id), 1);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    evidence.push({
      test: "A10",
      status: "PASS",
      claimCommitDurable: true,
      claimAcknowledgementWithheld: true,
      leaseEdited: false,
      clockEdited: false,
      actualExpiryWaitMs: Date.now() - waitStarted,
      recoveredOnce: true,
      durableAfterLostClaimReply: {
        jobStatus: job.status,
        attempts: job.attempts,
        letters: 0,
        leasePresent: job.lease_until instanceof Date,
      },
    });
  },
);

test(
  "A11 limited per-query delay: welcome and all 13 overdue nodes must complete within budget",
  { timeout: 70_000 },
  async () => {
    const queryDelayMs = Number(process.env.E4_AUTO_TEST_QUERY_DELAY_MS ?? 200);
    assert.ok(queryDelayMs === 200 || queryDelayMs === 300);
    const cases: object[] = [];
    const check = {
      test: "A11",
      status: "INCOMPLETE",
      scope: "local protocol-delay injection, excludes TLS/connect/cold start",
      cases,
    };
    evidence.push(check);
    for (const overdue of [false, true]) {
      const id = await seed(
        true,
        "example.invalid",
        overdue ? Date.now() - 15 * 86_400_000 : undefined,
      );
      target(id);
      const original = pg.Client.prototype.query;
      let queryCalls = 0;
      pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
        queryCalls++;
        return delay(queryDelayMs).then(() =>
          (original as Function).apply(this, args),
        );
      } as typeof original;
      const started = Date.now();
      let status: string;
      try {
        const response = await invoke();
        status = (await response.json()).status;
      } catch (error) {
        assert.match((error as Error).message, /UNKNOWN_CHECK_DURABLE_STATE/);
        status = "UNKNOWN";
      } finally {
        pg.Client.prototype.query = original;
      }
      const elapsedMs = Date.now() - started;
      assert.ok(
        elapsedMs < 29_000,
        `bounded invocation exceeded safety margin: ${elapsedMs}`,
      );
      const calendar = await one(
        "SELECT node_count,processed_count FROM cloud_calendars WHERE account_id=$1",
        [id],
      );
      const job = await one(
        "SELECT status,lease_token,attempts FROM cloud_jobs WHERE account_id=$1",
        [id],
      );
      const delivered = await letters(id);
      if (status === "SETTLED") {
        assert.equal(delivered, 1);
        assert.equal(calendar.processed_count, overdue ? 13 : 1);
      } else {
        assert.equal(status, "UNKNOWN");
        assert.equal(delivered, 0);
        assert.equal(calendar.processed_count, 0);
        assert.equal(job.status, "LEASED");
        assert.ok(job.lease_token);
      }
      const value = {
        case: overdue ? "13-overdue-nodes" : "welcome-only",
        queryDelayMs,
        queryCalls,
        elapsedMs,
        status,
        processedCount: calendar.processed_count,
        delivered,
        within30SecondPlatformLimit: true,
        availabilityProvenForThisFixture: status === "SETTLED",
        marginTo25SecondDeadlineMs: 25_000 - elapsedMs,
        marginTo30SecondPlatformLimitMs: 30_000 - elapsedMs,
      };
      cases.push(value);
      originalInfo(JSON.stringify({ latencyBoundary: value }));
      assert.equal(
        status,
        "SETTLED",
        "Availability requires actual completion, not a bounded rollback",
      );
    }
    check.status = "PASS";
  },
);

test(
  "A12 unconfirmed bounded leases retain their attempt; five confirmed technical failures still stop",
  { timeout: 45_000 },
  async () => {
    const id = await seed(
      true,
      "example.invalid",
      Date.now() - 15 * 86_400_000,
    );
    target(id);
    const scope = { accountId: id, allowBudgetRecovery: true as const };
    // Four historical confirmed failures, with the fifth attempt still unknown.
    await pool.query(
      "UPDATE cloud_jobs SET attempts=4,last_error='TECHNICAL:P0001' WHERE account_id=$1",
      [id],
    );
    let claim = (await claimCloudJob(Date.now() + 25_000, scope))!;
    assert.ok(claim);
    for (let round = 0; round < 6; round++) {
      assert.equal(claim.attempts, 5);
      const before = await snapshot(id);
      await assert.rejects(
        runClaimedCloudJob(claim, Date.now() - 1, scope),
        (e: any) => e.code === "SCHEDULER_DEADLINE",
      );
      assert.equal(await snapshot(id), before);
      assert.equal(await letters(id), 0);
      // A08/A10 wait for a real 60s expiry. This counter-policy fixture advances
      // only the synthetic job's lease to cover six recoveries without 6min wait.
      await pool.query(
        "UPDATE cloud_jobs SET lease_until=clock_timestamp()-interval '1 second' WHERE account_id=$1",
        [id],
      );
      const oldClaim = claim;
      claim = (await claimCloudJob(Date.now() + 25_000, scope))!;
      assert.ok(claim);
      assert.notEqual(claim.leaseToken, oldClaim.leaseToken);
      const job = await one(
        "SELECT status,attempts,last_error FROM cloud_jobs WHERE account_id=$1",
        [id],
      );
      assert.deepEqual(job, {
        status: "LEASED",
        attempts: 5,
        last_error: CLOUD_BUDGET_PENDING,
      });
      const newer = await snapshot(id);
      assert.equal(
        (await runClaimedCloudJob(oldClaim, Date.now() + 25_000, scope)).status,
        "STALE",
      );
      assert.equal(await snapshot(id), newer);
    }
    await pool.query(
      "UPDATE cloud_jobs SET lease_until=clock_timestamp()-interval '1 second' WHERE account_id=$1",
      [id],
    );
    const original = pg.Client.prototype.query;
    let queryCalls = 0;
    pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
      queryCalls++;
      return delay(300).then(() => (original as Function).apply(this, args));
    } as typeof original;
    const started = Date.now();
    try {
      assert.equal((await (await invoke()).json()).status, "SETTLED");
    } finally {
      pg.Client.prototype.query = original;
    }
    const recoveryElapsedMs = Date.now() - started;
    assert.ok(recoveryElapsedMs < 25_000);
    assert.equal(await letters(id), 1);
    assert.equal(
      (
        await one(
          "SELECT processed_count FROM cloud_calendars WHERE account_id=$1",
          [id],
        )
      ).processed_count,
      13,
    );
    assert.deepEqual(
      await one(
        "SELECT status,attempts,last_error,lease_token FROM cloud_jobs WHERE account_id=$1",
        [id],
      ),
      { status: "COMPLETE", attempts: 0, last_error: null, lease_token: null },
    );
    assert.equal((await (await invoke()).json()).status, "IDLE");

    const failing = await seed();
    target(failing);
    await pool.query(
      "UPDATE cloud_jobs SET attempts=4,last_error='TECHNICAL:P0001' WHERE account_id=$1",
      [failing],
    );
    await pool.query(`CREATE FUNCTION synthetic_auto_final_failure() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'synthetic_private_failure'; END $$;
    CREATE TRIGGER synthetic_auto_final_failure BEFORE INSERT ON cloud_letters FOR EACH ROW EXECUTE FUNCTION synthetic_auto_final_failure()`);
    try {
      assert.equal((await (await invoke()).json()).status, "FAILED");
    } finally {
      await pool.query(
        "DROP TRIGGER synthetic_auto_final_failure ON cloud_letters; DROP FUNCTION synthetic_auto_final_failure()",
      );
    }
    assert.deepEqual(
      await one(
        "SELECT status,attempts,last_error FROM cloud_jobs WHERE account_id=$1",
        [failing],
      ),
      { status: "FAILED", attempts: 5, last_error: "TECHNICAL:P0001" },
    );
    assert.equal(await letters(failing), 0);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    evidence.push({
      test: "A12",
      status: "PASS",
      unconfirmedReclaims: 6,
      attemptsRetained: 5,
      expiredDeadlineWrites: 0,
      oldLeaseRejected: true,
      recoveryQueryDelayMs: 300,
      recoveryQueryCalls: queryCalls,
      recoveryElapsedMs,
      marginTo25SecondDeadlineMs: 25_000 - recoveryElapsedMs,
      processedCount: 13,
      delivered: 1,
      confirmedFailureCap: 5,
      clockOrLeaseEditedForCounterFixture: true,
      naturalLeaseExpiryCoveredBy: ["A08", "A10"],
    });
  },
);

test(
  "A13 settlement COMMIT request is lost before the DB receives it; real rollback and natural lease recovery",
  { timeout: 90_000 },
  async () => {
    const id = await seed();
    target(id);
    const fixture = child("commit-request-lost", id);
    try {
      await fixture.wait("COMMIT_REQUEST_LOST");
      await kill(fixture.processChild);
      await childBackendsGone();
    } finally {
      await kill(fixture.processChild);
    }
    assert.equal(await letters(id), 0);
    const job = await one(
      "SELECT status,attempts,last_error,lease_until FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.equal(job.status, "LEASED");
    assert.equal(job.attempts, 1);
    assert.equal(job.last_error, CLOUD_BUDGET_PENDING);
    assert.equal(
      (
        await one(
          "SELECT processed_count FROM cloud_calendars WHERE account_id=$1",
          [id],
        )
      ).processed_count,
      0,
    );
    assert.equal((await (await invoke()).json()).status, "IDLE");
    const waitStarted = Date.now();
    originalInfo(
      "A13 waiting for the actual persisted lease after a lost settlement COMMIT request.",
    );
    for (let i = 0; i < 140; i++) {
      if (
        (
          await one(
            "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
            [id],
          )
        ).expired
      )
        break;
      await delay(500);
    }
    assert.equal(
      (
        await one(
          "SELECT lease_until<=clock_timestamp() AS expired FROM cloud_jobs WHERE account_id=$1",
          [id],
        )
      ).expired,
      true,
    );
    assert.equal((await (await invoke()).json()).status, "SETTLED");
    assert.equal(await letters(id), 1);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    evidence.push({
      test: "A13",
      status: "PASS",
      faultBoundary:
        "driver COMMIT requested; transport request withheld before native send; process killed",
      durableBeforeRecovery: {
        letters: 0,
        processedCount: 0,
        jobStatus: job.status,
        attempts: job.attempts,
        leasePresent: true,
        lastError: job.last_error,
      },
      clockEdited: false,
      leaseEdited: false,
      actualExpiryWaitMs: Date.now() - waitStarted,
      recoveredOnce: true,
      duplicateLetters: 0,
    });
  },
);

test(
  "A14 claim COMMIT request is lost before the DB receives it; no lease persists and next tick recovers immediately",
  { timeout: 25_000 },
  async () => {
    const id = await seed();
    target(id);
    const before = await snapshot(id);
    const fixture = child("claim-commit-request-lost", id);
    try {
      await fixture.wait("COMMIT_REQUEST_LOST");
      await kill(fixture.processChild);
      await childBackendsGone();
    } finally {
      await kill(fixture.processChild);
    }
    assert.equal(await snapshot(id), before);
    const job = await one(
      "SELECT status,attempts,lease_token,lease_until,last_error FROM cloud_jobs WHERE account_id=$1",
      [id],
    );
    assert.deepEqual(job, {
      status: "READY",
      attempts: 0,
      lease_token: null,
      lease_until: null,
      last_error: null,
    });
    assert.equal((await (await invoke()).json()).status, "SETTLED");
    assert.equal(await letters(id), 1);
    assert.equal((await (await invoke()).json()).status, "IDLE");
    evidence.push({
      test: "A14",
      status: "PASS",
      faultBoundary:
        "driver claim COMMIT requested; transport request withheld before native send; process killed",
      durableAfterLostRequest: job,
      recoveredWithoutLeaseWait: true,
      duplicateLetters: 0,
    });
  },
);
