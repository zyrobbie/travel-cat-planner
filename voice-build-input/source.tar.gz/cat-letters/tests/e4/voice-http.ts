import { createServer } from "node:http";
import { Readable } from "node:stream";
import { readFile } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { NextRequest } from "next/server";
import {
  GET as voiceGet,
  POST as voicePost,
} from "../../src/app/api/e4/voice/[...path]/route";
import {
  GET as v1Get,
  POST as v1Post,
} from "../../src/app/api/e4/v1/[...path]/route";
import {
  GET as accountGet,
  POST as accountPost,
} from "../../src/app/api/e4/[...path]/route";
import {
  GET as privacyGet,
  POST as privacyPost,
} from "../../src/app/api/e4/privacy/[...path]/route";
import { syntheticMicrophone } from "./voice-browser";
import { setTimeout as delay } from "node:timers/promises";

/** Local test bridge to the actual Next handlers; never part of deployed routes. */
export async function voiceHttp(
  token: string,
  options: {
    loseConfirm?: boolean;
    syntheticMic?: boolean;
    confirmDelayMs?: number;
    port?: number;
  } = {},
) {
  let lost = false;
  const root = resolve(
    process.env.E4_LOCAL_ACCOUNT_CLIENT_DIRECTORY ?? "public/account-app",
  );
  const server = createServer(async (req, res) => {
    try {
      const origin = process.env.APP_ORIGIN!;
      const url = new URL(req.url!, origin);
      if (url.pathname === "/local-review") {
        res.writeHead(302, {
          "Set-Cookie": `cat_account_session=${token}; Path=/; HttpOnly; SameSite=Strict`,
          Location: "/account-app/?product=1",
          "Cache-Control": "no-store",
        });
        res.end();
        return;
      }
      if (url.pathname.startsWith("/api/e4/")) {
        const aborted = new AbortController();
        req.once("aborted", () => aborted.abort());
        res.once("close", () => {
          if (!res.writableFinished) aborted.abort();
        });
        const r = new NextRequest(url, {
          method: req.method,
          headers: req.headers as Record<string, string>,
          signal: aborted.signal,
          ...(req.method === "POST"
            ? { body: Readable.toWeb(req), duplex: "half" }
            : {}),
        } as any);
        const pair = url.pathname.startsWith("/api/e4/voice/")
          ? [voiceGet, voicePost]
          : url.pathname.startsWith("/api/e4/v1/")
            ? [v1Get, v1Post]
            : url.pathname.startsWith("/api/e4/privacy/")
              ? [privacyGet, privacyPost]
              : [accountGet, accountPost];
        const result = await pair[req.method === "POST" ? 1 : 0](r);
        if (options.confirmDelayMs && url.pathname.endsWith("/confirm"))
          await delay(Math.min(options.confirmDelayMs, 10000));
        if (
          options.loseConfirm &&
          !lost &&
          url.pathname.endsWith("/confirm") &&
          result.ok
        ) {
          lost = true;
          res.writeHead(503, {
            "Content-Type": "application/json",
            "Cache-Control": "no-store",
          });
          res.end(
            '{"error":"合成测试：确认已提交但回执丢失，请重试确认清理。"}',
          );
          return;
        }
        const headers: Record<string, string | string[]> = {};
        result.headers.forEach((v, k) => {
          if (k !== "set-cookie") headers[k] = v;
        });
        const cookies = result.headers.getSetCookie();
        if (cookies.length) headers["set-cookie"] = cookies;
        res.writeHead(result.status, headers);
        res.end(Buffer.from(await result.arrayBuffer()));
        return;
      }
      if (!url.pathname.startsWith("/account-app/")) {
        res.writeHead(404).end();
        return;
      }
      const path = resolve(
        root,
        decodeURIComponent(
          url.pathname.slice("/account-app/".length) || "index.html",
        ),
      );
      if (!path.startsWith(root + sep)) {
        res.writeHead(404).end();
        return;
      }
      const types: Record<string, string> = {
        ".html": "text/html; charset=utf-8",
        ".js": "text/javascript",
        ".css": "text/css",
        ".webp": "image/webp",
        ".png": "image/png",
        ".svg": "image/svg+xml",
      };
      let bytes = await readFile(path);
      if (options.syntheticMic && extname(path) === ".html")
        bytes = Buffer.from(
          bytes
            .toString()
            .replace(
              "</head>",
              `<script>var __name=(target)=>target;(${syntheticMicrophone.toString()})();</script></head>`,
            )
            .replace(
              "<body>",
              '<body><aside style="padding:12px;font:14px/1.7 sans-serif;background:#fbeee2;color:#493d34">本地合成验证：音源为生成的PCM流，转写为固定合成文字。没有使用真实麦克风、真实ASR或云端账号。</aside>',
            ),
        );
      res.writeHead(200, {
        "Content-Type": types[extname(path)] ?? "application/octet-stream",
        "Cache-Control": "no-store",
      });
      res.end(bytes);
    } catch {
      if (!res.headersSent)
        res.writeHead(503, { "Content-Type": "application/json" });
      res.end('{"error":"LOCAL_VOICE_BRIDGE_ERROR"}');
    }
  });
  if (
    options.port !== undefined &&
    (!Number.isInteger(options.port) ||
      options.port < 0 ||
      options.port > 65535)
  )
    throw Error("LOCAL_PORT_INVALID");
  await new Promise<void>((yes, no) => {
    server.once("error", no);
    server.listen(options.port ?? 0, "127.0.0.1", yes);
  });
  const address = server.address();
  if (!address || typeof address === "string")
    throw Error("LOCAL_LISTEN_FAILED");
  process.env.APP_ORIGIN = `http://127.0.0.1:${address.port}`;
  return {
    url: process.env.APP_ORIGIN,
    server,
    close: () =>
      new Promise<void>((r, e) => server.close((x) => (x ? e(x) : r()))),
  };
}
