/** Dedicated new loopback database and private file ledger only. */
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import pg from "pg";
import { pool } from "../../src/server/db";
import { requestCode, verifyCode, accountSession } from "../../src/server/account-auth";
import { SyntheticMailbox } from "../../src/server/otp-delivery";
import { adoptCat } from "../../src/server/account-service";
import { prepareAccountDeletion, cancelAccountDeletion, confirmAccountDeletion, deletionStatus } from "../../src/server/account-lifecycle";
import { readLedger } from "../../src/server/lifecycle-ledger";

const url = new URL(process.env.DATABASE_URL!);
assert.equal(url.hostname, "127.0.0.1"); assert.equal(url.pathname, "/catletters_deletion_ux_file_test");
assert.equal(process.env.E4_LIFECYCLE_ADAPTER, "file-v1");
const ownerUrl = new URL(process.env.E4_VALIDATION_LOCAL_FILE_OWNER!);
assert.equal(ownerUrl.hostname, url.hostname); assert.equal(ownerUrl.pathname, url.pathname);
const owner = new pg.Pool({ connectionString: ownerUrl.href });
const results: object[] = [];
try {
  assert.equal((await owner.query("SELECT value FROM local_validation_cluster_nonce")).rows[0].value,
    process.env.E4_VALIDATION_LOCAL_NONCE);
  assert.equal((await pool.query("SELECT current_user AS role")).rows[0].role, "cat_letters_app");
  for (const firstKind of ["cancel", "confirm"]) {
    const email = `file-cancel-${randomUUID()}@example.invalid`, mailbox = new SyntheticMailbox();
    const asked = await requestCode(email, mailbox);
    const login = await verifyCode(asked.challengeId, email, mailbox.messages.get(asked.challengeId)!.code);
    mailbox.messages.clear();
    await adoptCat(login.accountId, { key: randomUUID(), name: "合成文件账本猫", appearanceId: "cat-02" });
    const key = randomUUID(), prepared = await prepareAccountDeletion(login.accountId, key);
    const original = pg.Client.prototype.query;
    let enter!: () => void, release!: () => void, lookups = 0;
    const entered = new Promise<void>(resolve => { enter = resolve; });
    const barrier = new Promise<void>(resolve => { release = resolve; });
    (pg.Client.prototype as any).query = function (...args: any[]) {
      if (args[0] === "SELECT * FROM deletion_preparations WHERE request_id=$1" && args[1]?.[0] === prepared.deletion.requestId && ++lookups === 1) {
        enter(); return barrier.then(() => Reflect.apply(original, this, args));
      }
      return Reflect.apply(original, this, args);
    };
    const cancel = () => cancelAccountDeletion(login.accountId, prepared.deletion.requestId, prepared.receipt);
    const confirm = () => confirmAccountDeletion(login.accountId, prepared.deletion.requestId, prepared.receipt);
    try {
      const first = firstKind === "cancel" ? cancel() : confirm();
      await Promise.race([entered, first.then(() => { throw Error("file lock barrier was not entered"); })]);
      const second = firstKind === "cancel" ? confirm() : cancel();
      await delay(20); assert.equal(lookups, 1); release();
      const result = await Promise.allSettled([first, second]);
      assert.equal(result[0].status, "fulfilled"); assert.equal(result[1].status, "rejected");
      const events = readLedger().events.filter(event => event.requestId === prepared.deletion.requestId);
      assert.deepEqual(events.map(event => event.kind), [firstKind === "cancel" ? "DELETE_CANCELLED" : "DELETE_REQUESTED"]);
      assert.equal((await deletionStatus(prepared.receipt)).deletion!.status, firstKind === "cancel" ? "CANCELLED" : "PENDING");
      if (firstKind === "cancel") {
        assert.equal((await accountSession(login.rawToken)).id, login.accountId);
        const next = await prepareAccountDeletion(login.accountId, key);
        assert.notEqual(next.deletion.requestId, prepared.deletion.requestId);
        await assert.rejects(confirm(), error => (error as any).status === 409);
      } else await assert.rejects(accountSession(login.rawToken), error => (error as any).status === 401);
      results.push({ test: "FILE_" + firstKind.toUpperCase() + "_WINS", status: "PASS", deterministicRealLockBarrier: true });
    } finally { release?.(); pg.Client.prototype.query = original; }
  }
  await writeFile(join(process.env.E4_VALIDATION_EVIDENCE!, "file-adapter-results.json"), JSON.stringify({
    result: "PASS", tests: results, adapter: "file-v1", runtimeRole: "cat_letters_app",
    cloudExecuted: false, emailSent: false, separateNewLoopbackDatabase: true,
  }, null, 2));
  console.log(JSON.stringify({ result: "PASS_FILE_ADAPTER", tests: results.length, cloudExecuted: false }));
} finally { await pool.end(); await owner.end(); }
