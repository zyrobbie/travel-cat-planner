import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { performance } from "node:perf_hooks";
import { randomUUID, createHash } from "node:crypto";
import {
  mkdtemp,
  mkdir,
  readFile,
  writeFile,
  readdir,
  rm,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, isAbsolute } from "node:path";
import {
  inspectVoiceAudio,
  normalizeVoiceAudio,
} from "../../src/server/voice-probe";

// Local synthetic media only. No database, browser, human recording or provider.
const run = promisify(execFile);
const reference =
  process.env.E4_MEDIA_FIXTURE_FFMPEG ?? "/opt/homebrew/bin/ffmpeg";
const ffmpeg = process.env.E4_LOCAL_FFMPEG ?? "/opt/homebrew/bin/ffmpeg";
const ffprobe = process.env.E4_LOCAL_FFPROBE ?? "/opt/homebrew/bin/ffprobe";
const evidence: object[] = [];
let root: string;
before(async () => {
  for (const p of [reference, ffmpeg, ffprobe]) assert.ok(isAbsolute(p));
  root = await mkdtemp(join(tmpdir(), "cat-private-voice-aac-"));
  Object.assign(process.env, {
    APP_MODE: "INTERNAL",
    NODE_ENV: "test",
    DOTENV_CONFIG_PATH: "/dev/null",
    E4_VOICE_STORAGE: "synthetic-files-v1",
    E4_VALIDATION_LOCAL_NONCE: randomUUID(),
    E4_VOICE_TEST_PAYLOAD_ROOT: root,
    E4_VOICE_PAYLOAD_DIRECTORY: join(root, "payload"),
    E4_VOICE_PROBE_DIRECTORY: join(root, "probe"),
    E4_VOICE_FFMPEG: ffmpeg,
    E4_VOICE_FFPROBE: ffprobe,
  });
});
after(async () => {
  if (process.env.E4_VALIDATION_EVIDENCE) {
    await mkdir(process.env.E4_VALIDATION_EVIDENCE, { recursive: true });
    await writeFile(
      join(process.env.E4_VALIDATION_EVIDENCE, "voice-probe-compat.json"),
      JSON.stringify(
        {
          sourceSha256: createHash("sha256")
            .update(await readFile("src/server/voice-probe.ts"))
            .digest("hex"),
          platform: process.platform,
          arch: process.arch,
          ffmpegVersion: (await run(ffmpeg, ["-version"])).stdout.split(
            "\n",
          )[0],
          fixturesSynthetic: true,
          realAsr: false,
          realMicrophone: false,
          cloudExecuted: false,
          cases: evidence,
        },
        null,
        2,
      ) + "\n",
    );
  }
  await rm(root, { recursive: true, force: true });
});
function tone(samples: number, rate: number) {
  const b = Buffer.alloc(44 + samples * 2);
  b.write("RIFF");
  b.writeUInt32LE(b.length - 8, 4);
  b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22);
  b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(rate * 2, 28);
  b.writeUInt16LE(2, 32);
  b.writeUInt16LE(16, 34);
  b.write("data", 36);
  b.writeUInt32LE(samples * 2, 40);
  for (let i = 0; i < samples; i++)
    b.writeInt16LE(
      Math.round(4000 * Math.sin((2 * Math.PI * 440 * i) / rate)),
      44 + i * 2,
    );
  return b;
}
async function encode(samples: number, rate: number, fragmented = false) {
  const input = join(root, `${randomUUID()}.wav`);
  await writeFile(input, tone(samples, rate), { mode: 0o600, flag: "wx" });
  const output = join(root, `${randomUUID()}.m4a`);
  const args = [
    "-nostdin",
    "-v",
    "error",
    "-i",
    input,
    "-map",
    "0:a:0",
    "-c:a",
    "aac",
    "-movie_timescale",
    String(rate),
    ...(fragmented
      ? ["-movflags", "empty_moov+frag_keyframe+default_base_moof"]
      : []),
    "-f",
    "mp4",
    fragmented ? "pipe:1" : output,
  ];
  const result = await run(reference, args, {
    timeout: 15_000,
    maxBuffer: 10 * 1024 * 1024,
    encoding: "buffer",
  });
  return fragmented ? result.stdout : readFile(output);
}
async function probe(audio: Buffer, entries: string) {
  const file = join(root, `${randomUUID()}.m4a`);
  await writeFile(file, audio, { mode: 0o600 });
  return JSON.parse(
    (
      await run(
        ffprobe,
        ["-v", "error", "-show_entries", entries, "-of", "json", file],
        { timeout: 5000, maxBuffer: 1024 * 1024 },
      )
    ).stdout,
  );
}
async function clean() {
  assert.deepEqual(
    await readdir(join(root, "probe")),
    [],
    "probe/convert remnants survived",
  );
}
function checkPcm(wav: Buffer, samples?: number) {
  assert.equal(wav.toString("ascii", 0, 4), "RIFF");
  assert.equal(wav.readUInt32LE(24), 16000);
  assert.equal(wav.readUInt16LE(22), 1);
  assert.equal(wav.readUInt16LE(34), 16);
  assert.equal(wav.readUInt32LE(40), wav.length - 44);
  assert.ok(wav.length > 44 && wav.length <= 1_920_044);
  assert.ok(wav.toString("base64").length <= 3_000_000);
  if (samples !== undefined) assert.equal(wav.length, 44 + samples * 2);
  let sum = 0;
  for (let i = 44; i < wav.length; i += 2) sum += wav.readInt16LE(i) ** 2;
  assert.ok(
    Math.sqrt(sum / ((wav.length - 44) / 2)) > 100,
    "synthetic tone became silent",
  );
}

test("M01 fragmented AAC missing packet duration uses decoded time, not the shorter container duration", async () => {
  const audio = await encode(44100, 44100, true);
  const raw = await probe(audio, "packet=duration_time:stream=duration");
  const missing = raw.packets.filter(
    (p: any) => p.duration_time === undefined,
  ).length;
  if ((await run(ffprobe, ["-version"])).stdout.includes("version 6.1.6"))
    assert.ok(missing > 0);
  const ms = await inspectVoiceAudio(audio, "audio/mp4");
  const wav = await normalizeVoiceAudio(audio, "audio/mp4");
  checkPcm(wav);
  assert.ok(ms >= 1000 && ms <= 1080);
  assert.ok(Math.abs((wav.length - 44) / 32 - ms) <= 1);
  await clean();
  evidence.push({
    id: "M01",
    missingPacketDurations: missing,
    containerSeconds: raw.streams[0].duration,
    provedMs: ms,
    actualPcmMs: (wav.length - 44) / 32,
  });
});

test("M02 exact60 AAC at 16k/44.1k/48k removes only declared final-frame padding", async () => {
  for (const rate of [16000, 44100, 48000]) {
    const audio = await encode(60 * rate, rate);
    assert.equal(await inspectVoiceAudio(audio, "audio/mp4"), 60000);
    checkPcm(await normalizeVoiceAudio(audio, "audio/mp4"), 960000);
    await clean();
  }
  evidence.push({
    id: "M02",
    rates: [16000, 44100, 48000],
    exactOutputSamples: 960000,
  });
});

test("M03 AAC true over60 by one source sample, 1ms, 50ms or 1s is rejected without truncation", async () => {
  for (const extra of [1, 48, 2400, 48000]) {
    const audio = await encode(60 * 48000 + extra, 48000);
    await assert.rejects(normalizeVoiceAudio(audio, "audio/mp4"), /超过60秒/);
    await clean();
  }
  evidence.push({
    id: "M03",
    rate: 48000,
    overSamplesRejected: [1, 48, 2400, 48000],
    movieTimescale: 48000,
  });
});

test("M04 fragmented AAC with unproven priming cannot claim a60s duration to hide extra decoded samples", async () => {
  for (const seconds of [60, 61]) {
    await assert.rejects(
      normalizeVoiceAudio(
        await encode(seconds * 48000, 48000, true),
        "audio/mp4",
      ),
      /超过60秒/,
    );
    await clean();
  }
  evidence.push({
    id: "M04",
    sourceSeconds: [60, 61],
    unprovenFragmentPrimingNotRemoved: true,
  });
});

async function injectedProbe(
  packets: any,
  frames: any,
  delayFirst = 0,
  delaySecond = 0,
) {
  const file = join(root, `${randomUUID()}-ffprobe.cjs`);
  await writeFile(
    file,
    `#!${process.execPath}\nconst second=process.argv.includes('frame=pts,nb_samples');\nsetTimeout(()=>process.stdout.write(JSON.stringify(second?${JSON.stringify(frames)}:${JSON.stringify(packets)})),second?${delaySecond}:${delayFirst});\n`,
    { mode: 0o700 },
  );
  return file;
}
const packetEntries =
  "stream=index,codec_type,codec_name,sample_rate,time_base,start_pts,duration_ts:packet=stream_index,pts,duration:packet_side_data=side_data_type,skip_samples";

test("M05 inconsistent metadata, missing/duplicate/gapped frames and interior short packets never authorize trimming", async () => {
  const audio = await encode(48000, 48000);
  const packets = await probe(audio, packetEntries),
    frames = await probe(audio, "frame=pts,nb_samples");
  const variants: [string, (p: any, f: any) => void][] = [
    [
      "short-duration-tag",
      (p) => {
        p.streams[0].duration_ts = 1;
        p.packets.at(-1).duration = 1;
      },
    ],
    [
      "missing-frame",
      (_p, f) => {
        f.frames.splice(1, 1);
      },
    ],
    [
      "duplicate-frame",
      (_p, f) => {
        f.frames.splice(1, 0, f.frames[0]);
      },
    ],
    [
      "gapped-frame",
      (_p, f) => {
        f.frames[1].pts++;
      },
    ],
    [
      "interior-short-packet",
      (p) => {
        p.packets.find((v: any) => v.pts === 0).duration = 1;
      },
    ],
    [
      "invalid-packet-duration",
      (p) => {
        p.packets[1].duration = -1;
      },
    ],
    [
      "extra-unmatched-packet",
      (p) => {
        p.packets.push({ pts: 999999, duration: 1024, stream_index: 0 });
      },
    ],
  ];
  try {
    for (const [name, change] of variants) {
      const p = structuredClone(packets),
        f = structuredClone(frames);
      change(p, f);
      process.env.E4_VOICE_FFPROBE = await injectedProbe(p, f);
      await assert.rejects(
        normalizeVoiceAudio(audio, "audio/mp4"),
        /时间信息无效/,
      );
      await clean();
      evidence.push({
        id: "M05",
        injectedProbeVariant: name,
        rejected: true,
        realMediaCorruptionTest: false,
      });
    }
  } finally {
    process.env.E4_VOICE_FFPROBE = ffprobe;
  }
});

test(
  "M06 two AAC probes share the original5s deadline and cancellation removes private files",
  { timeout: 12_000 },
  async () => {
    const audio = await encode(48000, 48000);
    const packets = await probe(audio, packetEntries),
      frames = await probe(audio, "frame=pts,nb_samples");
    try {
      process.env.E4_VOICE_FFPROBE = await injectedProbe(
        packets,
        frames,
        2800,
        2800,
      );
    const originalNow = Date.now;
    const start = performance.now();
    const rollback = setTimeout(() => {
      Date.now = () => originalNow() - 60_000;
    }, 1000);
    try {
      await assert.rejects(inspectVoiceAudio(audio, "audio/mp4"), /超时/);
    } finally {
      clearTimeout(rollback);
      Date.now = originalNow;
    }
    const elapsedMs = performance.now() - start;
      assert.ok(elapsedMs >= 4500 && elapsedMs < 5500);
      await clean();
      process.env.E4_VOICE_FFPROBE = await injectedProbe(
        packets,
        frames,
        0,
        5000,
      );
      const controller = new AbortController();
      const cancel = setTimeout(() => controller.abort(), 200);
      try {
        await assert.rejects(
          inspectVoiceAudio(audio, "audio/mp4", controller.signal),
          /超时/,
        );
      } finally {
        clearTimeout(cancel);
      }
      await clean();
      evidence.push({
        id: "M06",
        sharedProbeDeadlineMs: elapsedMs,
        inProgressCancellation: true,
        injectedSlowProbe: true,
      wallClockRollbackMs: 60_000,
      });
    } finally {
      process.env.E4_VOICE_FFPROBE = ffprobe;
    }
  },
);
