import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:https";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID, createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import pg from "pg";
import { request, type APIRequestContext } from "@playwright/test";
import { NextRequest } from "next/server";

// This process only uses the runner's two fresh nonce-checked loopback databases.
// Set names before importing the real route modules, matching a server restart.
process.env.ACCOUNT_COOKIE_NAME = "cat_voice_test_session";
process.env.DELETION_COOKIE_NAME = "cat_voice_test_deletion";
const { ACCOUNT_COOKIE, requestCode, verifyCode, accountSession } = await import("../../src/server/account-auth");
const { DELETION_COOKIE, prepareAccountDeletion, deletionStatus } = await import("../../src/server/account-lifecycle");
const { SyntheticMailbox } = await import("../../src/server/otp-delivery");
const accountRoutes = await import("../../src/app/api/e4/[...path]/route");
const privacyRoutes = await import("../../src/app/api/e4/privacy/[...path]/route");
const voiceRoutes = await import("../../src/app/api/e4/voice/[...path]/route");
const { pool } = await import("../../src/server/db");
const { closeLifecycleProvider } = await import("../../src/server/lifecycle-provider");

const owners = [process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS!, process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER!];
const admin = new pg.Pool({ connectionString: owners[0] });
const ledger = new pg.Pool({ connectionString: owners[1] });
const servers: Server[] = [], clients: APIRequestContext[] = [];
const evidence: object[] = [];
let directory: string, oldOrigin: string, newOrigin: string;

async function makeIdentity() {
  const mailbox = new SyntheticMailbox();
  const email = `cookie-${randomUUID()}@example.invalid`;
  const challenged = await requestCode(email, mailbox);
  const code = mailbox.messages.get(challenged.challengeId)!.code;
  return { email, challengeId: challenged.challengeId, code };
}
const cookieValue = (header: string, name: string) =>
  header.split(";").map(p => p.trim()).find(p => p.startsWith(name + "="))?.slice(name.length + 1);

async function start(old: boolean, cert: Buffer, key: Buffer) {
  const server = createServer({ cert, key }, async (req, res) => {
    try {
      const url = new URL(req.url!, old ? oldOrigin : newOrigin);
      if (old) {
        // Legacy control reader uses the old names and actual account/deletion
        // services. It never sets a cookie or receives the new adapter's names.
        const header = req.headers.cookie ?? "";
        const result = url.pathname.endsWith("deletions/status")
          ? await deletionStatus(cookieValue(header, "cat_deletion_receipt"))
          : await accountSession(cookieValue(header, "cat_account_session"));
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(result));
        return;
      }
      const chunks: Buffer[] = [];
      for await (const chunk of req) chunks.push(Buffer.from(chunk));
      const pair = url.pathname.startsWith("/api/e4/privacy/") ? privacyRoutes
        : url.pathname.startsWith("/api/e4/voice/") ? voiceRoutes : accountRoutes;
      const handler = req.method === "POST" ? pair.POST : pair.GET;
      const result = await handler(new NextRequest(url, {
        method: req.method,
        headers: req.headers as Record<string, string>,
        ...(req.method === "POST" ? { body: Buffer.concat(chunks) } : {}),
      }));
      const headers: Record<string, string | string[]> = {};
      result.headers.forEach((value, name) => { if (name !== "set-cookie") headers[name] = value; });
      const cookies = result.headers.getSetCookie();
      if (cookies.length) headers["set-cookie"] = cookies;
      res.writeHead(result.status, headers);
      res.end(Buffer.from(await result.arrayBuffer()));
    } catch {
      res.writeHead(503, { "Content-Type": "application/json" });
      res.end('{"error":"ISOLATED_COOKIE_BRIDGE_FAILED"}');
    }
  });
  servers.push(server);
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert(address && typeof address !== "string");
  return `https://127.0.0.1:${address.port}`;
}

before(async () => {
  for (const [index, db] of [admin, ledger].entries()) {
    assert.equal(new URL(owners[index]).hostname, "127.0.0.1");
    assert.equal(new URL(owners[index]).pathname, "/catletters_cloud_lifecycle_validation_test");
    assert.equal((await db.query("SELECT value FROM local_validation_cluster_nonce")).rows[0].value,
      process.env.E4_VALIDATION_LOCAL_NONCE);
  }
  directory = await mkdtemp(join(tmpdir(), "cat-cookie-entry-"));
  await promisify(execFile)("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
    "-subj", "/CN=isolated-cookie-test.invalid", "-keyout", join(directory, "key.pem"), "-out", join(directory, "cert.pem")]);
  const [cert, key] = await Promise.all([readFile(join(directory, "cert.pem")), readFile(join(directory, "key.pem"))]);
  oldOrigin = await start(true, cert, key);
  newOrigin = await start(false, cert, key);
  process.env.APP_ORIGIN = newOrigin;
});

after(async () => {
  for (const client of clients) await client.dispose();
  for (const server of servers) await new Promise<void>(resolve => server.close(() => resolve()));
  await Promise.all([pool.end(), admin.end(), ledger.end(), closeLifecycleProvider()]);
  if (directory) await rm(directory, { recursive: true, force: true });
  await writeFile(join(process.env.E4_VALIDATION_EVIDENCE!, "cookie-entry-cases.json"), JSON.stringify({
    realCredentialsRead: false, realEmailSent: false, cloudExecuted: false,
    transport: "two fresh loopback HTTPS servers; APIRequestContext cookie jar; synthetic short-lived certificate",
    realOldObservationServerTested: false, cases: evidence,
  }, null, 2) + "\n");
});

test("C01 actual new-cookie login/logout and deletion prepare/cancel preserve legacy cookies and control sessions", async () => {
  assert.equal(ACCOUNT_COOKIE, "cat_voice_test_session");
  assert.equal(DELETION_COOKIE, "cat_voice_test_deletion");
  const prior = await makeIdentity();
  const control = await verifyCode(prior.challengeId, prior.email, prior.code);
  const preparation = await prepareAccountDeletion(control.accountId, randomUUID());
  const expiry = Math.floor(Date.now() / 1000) + 3600;
  const oldCookies = [
    { name: "cat_account_session", value: control.rawToken, domain: "127.0.0.1", path: "/", httpOnly: true, secure: true, sameSite: "Strict" as const, expires: expiry },
    { name: "cat_deletion_receipt", value: preparation.receipt, domain: "127.0.0.1", path: "/api/e4/privacy", httpOnly: true, secure: true, sameSite: "Strict" as const, expires: expiry },
  ];
  const api = await request.newContext({ ignoreHTTPSErrors: true, storageState: { cookies: oldCookies, origins: [] } });
  clients.push(api);
  const legacy = async () => {
    assert.equal((await (await api.get(oldOrigin + "/api/e4/account")).json()).id, control.accountId);
    assert.equal((await (await api.get(oldOrigin + "/api/e4/privacy/deletions/status")).json()).deletion.requestId,
      preparation.deletion.requestId);
    const cookies = (await api.storageState()).cookies.filter(c => oldCookies.some(old => old.name === c.name));
    assert.deepEqual(cookies.sort((a, b) => a.name.localeCompare(b.name)), [...oldCookies].sort((a, b) => a.name.localeCompare(b.name)));
  };
  await legacy();
  // The same old cookie is sent to the new port, but is not an alternate login.
  assert.equal((await api.get(newOrigin + "/api/e4/account")).status(), 401);
  const who = await makeIdentity();
  const loggedIn = await api.post(newOrigin + "/api/e4/auth/verify-code", {
    headers: { Origin: newOrigin }, data: who,
  });
  assert.equal(loggedIn.status(), 200);
  const account = (await loggedIn.json()).accountId as string;
  const accountCookie = (await api.storageState()).cookies.find(c => c.name === ACCOUNT_COOKIE)!;
  assert(accountCookie && accountCookie.httpOnly && accountCookie.secure && accountCookie.sameSite === "Strict");
  assert.equal(accountCookie.path, "/");
  assert.equal((await (await api.get(newOrigin + "/api/e4/account", {
    headers: { "x-catletters-account": account },
  })).json()).id, account);
  await legacy();
  const prepared = await api.post(newOrigin + "/api/e4/privacy/deletions/prepare", {
    headers: { Origin: newOrigin, "x-catletters-account": account }, data: { key: randomUUID() },
  });
  assert.equal(prepared.status(), 200);
  const task = (await prepared.json()).deletion;
  const receiptCookie = (await api.storageState()).cookies.find(c => c.name === DELETION_COOKIE)!;
  assert(receiptCookie && receiptCookie.httpOnly && receiptCookie.secure && receiptCookie.sameSite === "Strict");
  assert.equal(receiptCookie.path, "/api/e4/privacy");
  assert.equal((await (await api.get(newOrigin + "/api/e4/privacy/deletions/status")).json()).deletion.requestId, task.requestId);
  assert.equal((await api.post(newOrigin + "/api/e4/privacy/deletions/cancel", {
    headers: { Origin: newOrigin, "x-catletters-account": account }, data: { requestId: task.requestId },
  })).status(), 200);
  await legacy();
  const loggedOut = await api.post(newOrigin + "/api/e4/auth/logout", {
    headers: { Origin: newOrigin, "x-catletters-account": account }, data: {},
  });
  assert.equal(loggedOut.status(), 200);
  assert(!(await api.storageState()).cookies.some(c => c.name === ACCOUNT_COOKIE));
  assert.equal((await api.get(newOrigin + "/api/e4/account")).status(), 401);
  await legacy();
  evidence.push({ id: "C01", result: "PASS", legacyCookieAttributeHash: createHash("sha256").update(JSON.stringify(oldCookies.map(({value, ...rest}) => rest))).digest("hex"),
    preserved: ["old cookie values/path/expiry", "old account session", "old deletion receipt"], newCookieOnly: true });
});

test("C02 cross-port and missing Origin writes are rejected before OTP or DB changes", async () => {
  const api = await request.newContext({ ignoreHTTPSErrors: true });
  clients.push(api);
  const before = Number((await admin.query("SELECT count(*) AS n FROM email_challenges")).rows[0].n);
  for (const origin of [oldOrigin, "https://127.0.0.1", "null", undefined]) {
    const response = await api.post(newOrigin + "/api/e4/auth/request-code", {
      ...(origin ? { headers: { Origin: origin } } : {}), data: { email: "blocked@example.invalid" },
    });
    assert.equal(response.status(), 403);
    assert.equal(response.headers()["set-cookie"], undefined);
  }
  assert.equal(Number((await admin.query("SELECT count(*) AS n FROM email_challenges")).rows[0].n), before);
  evidence.push({ id: "C02", result: "PASS", rejectedOriginVariants: 4, otpChallengeCountUnchanged: true });
});
