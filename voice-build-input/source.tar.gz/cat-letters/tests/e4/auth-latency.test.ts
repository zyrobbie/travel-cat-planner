import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";
import { NextRequest } from "next/server";
import { pool } from "../../src/server/db";
import { assertLifecycleReady } from "../../src/server/lifecycle-ledger";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import {
  requestCode,
  verifyCode,
  accountIdentity,
  accountSession,
} from "../../src/server/account-auth";
import { SyntheticMailbox } from "../../src/server/otp-delivery";
import { adoptCat } from "../../src/server/account-service";
import { digest } from "../../src/server/auth";
import { GET, POST } from "../../src/app/api/e4/[...path]/route";
import { GET as privacyGET } from "../../src/app/api/e4/privacy/[...path]/route";

const ledger = new pg.Pool({
  connectionString: process.env.E4_LEDGER_DATABASE_URL,
});
const mailbox = new SyntheticMailbox();
const address = () => `latency-${randomUUID()}@example.test`;
const originalQuery = pg.Client.prototype.query;
let capture: string[] | null = null;
const counts: Record<string, number> = {};
let emptyScope = 0;
let session: Awaited<ReturnType<typeof verifyCode>>;
function request(
  path: string,
  body?: unknown,
  raw?: string,
  expected?: string,
) {
  return new NextRequest(`${process.env.APP_ORIGIN}/api/e4/${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      Origin: process.env.APP_ORIGIN!,
      "Content-Type": "application/json",
      ...(raw ? { Cookie: `cat_account_session=${raw}` } : {}),
      ...(expected ? { "X-Catletters-Account": expected } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
async function measured<T>(label: string, work: () => Promise<T>) {
  const queries: string[] = [];
  capture = queries;
  try {
    return { value: await work(), queries };
  } finally {
    capture = null;
    counts[label] = queries.length;
  }
}
async function challenge() {
  const email = address();
  const asked = await requestCode(email, mailbox);
  return mailbox.messages.get(asked.challengeId)!;
}
before(async () => {
  for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
    const url = new URL(process.env[key]!);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(url.pathname, "/catletters_auth_latency_test");
  }
  assert.equal(process.env.E4_LIFECYCLE_ADAPTER, "postgres-v1");
  assert.equal(process.env.OTP_ADAPTER, "synthetic-v1");
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    if (capture)
      capture.push(typeof args[0] === "string" ? args[0] : args[0].text);
    return (originalQuery as Function).apply(this, args);
  } as typeof originalQuery;
  emptyScope = (await measured("emptyGuard", assertLifecycleReady)).queries
    .length;
  const c = await challenge();
  session = await verifyCode(c.challengeId, c.email, c.code);
});
after(async () => {
  pg.Client.prototype.query = originalQuery;
  await writeFile(
    join(process.env.E4_AUTH_EVIDENCE!, "query-counts.json"),
    JSON.stringify(counts, null, 2) + "\n",
  );
  await closeLifecycleProvider();
  await Promise.all([pool.end(), ledger.end()]);
});

test("P01 missing/malformed cookies and absent recovery receipt perform zero queries", async () => {
  for (const raw of [undefined, "short", "g".repeat(64)]) {
    const probe = await measured(
      `anonymous:${raw ? raw.length : "none"}`,
      async () => {
        const res = await GET(request("account", undefined, raw));
        assert.equal(res.status, 401);
        await assert.rejects(accountIdentity(raw), /请重新登录/);
      },
    );
    assert.equal(probe.queries.length, 0);
  }
  const recovery = await measured("noRecovery", () =>
    privacyGET(request("privacy/deletions/status")),
  );
  assert.equal(recovery.value.status, 200);
  assert.deepEqual(await recovery.value.json(), { deletion: null });
  assert.equal(recovery.queries.length, 0);
  const staleLogout = await measured("logoutMissingContextCookie", () =>
    POST(request("auth/logout", {}, undefined, randomUUID())));
  assert.equal(staleLogout.value.status, 401);
  assert.equal(staleLogout.queries.length, 0);
});

test("P02 account endpoint uses one guarded scope and still rejects stale-tab ownership", async () => {
  const result = await measured("authenticatedAccount", () =>
    GET(request("account", undefined, session.rawToken, session.accountId)),
  );
  assert.equal(result.value.status, 200);
  assert.equal((await result.value.json()).id, session.accountId);
  assert.equal(result.queries.length, emptyScope + 2);
  const foreign = await GET(
    request("account", undefined, session.rawToken, randomUUID()),
  );
  assert.equal(foreign.status, 401);
  assert.equal("email_normalized" in (await foreign.json()), false);
});

test("P03 request and verification reuse locks; response includes committed account projection", async () => {
  const email = address();
  const asked = await measured("requestCode", () =>
    POST(request("auth/request-code", { email })),
  );
  assert.equal(asked.value.status, 200);
  const { challengeId } = await asked.value.json();
  const c = JSON.parse(
    await readFile(
      join(process.env.E4_SYNTHETIC_MAILBOX_DIR!, `${challengeId}.json`),
      "utf8",
    ),
  );
  const login = await measured("verifyCode", () =>
    POST(request("auth/verify-code", { email, challengeId, code: c.code })),
  );
  assert.equal(login.value.status, 200);
  const body = await login.value.json();
  assert.equal(body.account.id, body.accountId);
  assert.equal(body.account.email_normalized, email);
  assert.equal(body.account.cat, null);
  assert.equal(body.rawToken, undefined);
  const cookie = login.value.headers.get("set-cookie")!;
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /Secure/);
  assert.match(cookie, /SameSite=strict/i);
  const raw = cookie.match(/cat_account_session=([^;]+)/)![1];
  assert.deepEqual(await accountSession(raw), body.account);
  // Each guarded transaction keeps a fresh snapshot; only lock acquisition is reused.
  assert.equal(asked.queries.length, (emptyScope - 5) * 4 + 5 + 8);
  assert.equal(login.queries.length, (emptyScope - 5) * 3 + 5 + 9);
  assert.equal(
    asked.queries.filter((q) => /pg_advisory_lock_shared/.test(q)).length,
    2,
  );
  assert.equal(
    login.queries.filter((q) => /pg_advisory_lock_shared/.test(q)).length,
    2,
  );
  const adopted = await adoptCat(body.accountId, {
    name: "延时合成", appearanceId: "cat-01", key: randomUUID(),
  });
  await pool.query("UPDATE email_challenges SET created_at=now()-interval '2 hours' WHERE email_normalized=$1", [email]);
  const next = await POST(request("auth/request-code", { email }));
  assert.equal(next.status, 200);
  const nextId = (await next.json()).challengeId;
  const nextCode = JSON.parse(await readFile(join(process.env.E4_SYNTHETIC_MAILBOX_DIR!, `${nextId}.json`), "utf8"));
  const existing = await measured("verifyExistingAccount", () => POST(request("auth/verify-code", {
    email, challengeId: nextId, code: nextCode.code,
  })));
  assert.equal(existing.value.status, 200);
  const projection = (await existing.value.json()).account;
  assert.equal(projection.id, body.accountId);
  assert.equal(projection.cat.id, adopted.cat.id);
  assert.equal(projection.cat.name, "延时合成");
  assert.equal(existing.queries.length, (emptyScope - 5) * 3 + 5 + 8);
});

test("P04 failed OTP and rate-limit counters survive 401 and 429 independently", async () => {
  const c = await challenge(),
    wrong = c.code === "000000" ? "999999" : "000000";
  await pool.query(
    "INSERT INTO account_rate_limits(key,attempts,window_at) VALUES('verify-global',119,now()) ON CONFLICT(key) DO UPDATE SET attempts=119,window_at=now()",
  );
  try {
    assert.equal(
      (
        await POST(
          request("auth/verify-code", {
            email: c.email,
            challengeId: c.challengeId,
            code: wrong,
          }),
        )
      ).status,
      401,
    );
    assert.equal(
      (
        await pool.query("SELECT failures FROM email_challenges WHERE id=$1", [
          c.challengeId,
        ])
      ).rows[0].failures,
      1,
    );
    assert.equal(
      (
        await pool.query(
          "SELECT attempts FROM account_rate_limits WHERE key='verify-global'",
        )
      ).rows[0].attempts,
      120,
    );
    assert.equal(
      (
        await POST(
          request("auth/verify-code", {
            email: c.email,
            challengeId: c.challengeId,
            code: c.code,
          }),
        )
      ).status,
      429,
    );
    assert.equal(
      (
        await pool.query(
          "SELECT attempts FROM account_rate_limits WHERE key='verify-global'",
        )
      ).rows[0].attempts,
      121,
    );
    assert.equal(
      (
        await pool.query("SELECT failures FROM email_challenges WHERE id=$1", [
          c.challengeId,
        ])
      ).rows[0].failures,
      1,
    );
  } finally {
    await pool.query(
      "DELETE FROM account_rate_limits WHERE key='verify-global'",
    );
  }
  await pool.query(
    "UPDATE account_rate_limits SET attempts=30,window_at=now() WHERE key=$1",
    [`verify:${digest(c.email)}`],
  );
  const limited = await POST(
    request("auth/verify-code", {
      email: c.email,
      challengeId: c.challengeId,
      code: c.code,
    }),
  );
  assert.equal(limited.status, 429);
  assert.equal(
    (
      await pool.query(
        "SELECT attempts FROM account_rate_limits WHERE key=$1",
        [`verify:${digest(c.email)}`],
      )
    ).rows[0].attempts,
    31,
  );
});

test("P04b rejected global request limit stays committed and creates no challenge", async () => {
  const email = address();
  await pool.query("INSERT INTO account_rate_limits(key,attempts,window_at) VALUES('request-global',60,now()) ON CONFLICT(key) DO UPDATE SET attempts=60,window_at=now()");
  try {
    assert.equal((await POST(request("auth/request-code", { email }))).status, 429);
    assert.equal((await pool.query("SELECT attempts FROM account_rate_limits WHERE key='request-global'")).rows[0].attempts, 61);
    assert.equal((await pool.query("SELECT count(*)::int AS n FROM email_challenges WHERE email_normalized=$1", [email])).rows[0].n, 0);
  } finally { await pool.query("DELETE FROM account_rate_limits WHERE key='request-global'"); }
});

test("P05 revoked, expired and deleting-account sessions cannot return the combined projection", async () => {
  for (const statement of [
    "UPDATE account_sessions SET revoked_at=now() WHERE token_hash=$1",
    "UPDATE account_sessions SET expires_at=now()-interval '1 second' WHERE token_hash=$1",
  ]) {
    await pool.query(statement, [digest(session.rawToken)]);
    assert.equal(
      (await GET(request("account", undefined, session.rawToken))).status,
      401,
    );
    await pool.query(
      "UPDATE account_sessions SET revoked_at=NULL,expires_at=now()+interval '7 days' WHERE token_hash=$1",
      [digest(session.rawToken)],
    );
  }
  await pool.query("UPDATE accounts SET status='DELETING' WHERE id=$1", [
    session.accountId,
  ]);
  try {
    assert.equal(
      (await GET(request("account", undefined, session.rawToken))).status,
      401,
    );
  } finally {
    await pool.query("UPDATE accounts SET status='ACTIVE' WHERE id=$1", [
      session.accountId,
    ]);
  }
});

test("P06 closed restore gate and mismatched ledger watermark remain 503 for protected work", async () => {
  for (const [db, close, reopen] of [
    [
      ledger,
      "UPDATE restore_gate SET status='CLOSED' WHERE singleton=true",
      "UPDATE restore_gate SET status='READY' WHERE singleton=true",
    ],
    [
      pool,
      "UPDATE lifecycle_control SET ledger_sequence=ledger_sequence+1 WHERE singleton=true",
      "UPDATE lifecycle_control SET ledger_sequence=ledger_sequence-1 WHERE singleton=true",
    ],
  ] as const) {
    const c = await challenge();
    await db.query(close);
    try {
      const anonymous = await measured("closedGateAnonymous", () => GET(request("account")));
      assert.equal(anonymous.value.status, 401);
      assert.equal(anonymous.queries.length, 0);
      assert.equal(
        (await GET(request("account", undefined, session.rawToken))).status,
        503,
      );
      assert.equal(
        (await POST(request("auth/request-code", { email: address() }))).status,
        503,
      );
      const res = await POST(
        request("auth/verify-code", {
          email: c.email,
          challengeId: c.challengeId,
          code: c.code,
        }),
      );
      assert.equal(res.status, 503);
      assert.equal(res.headers.get("set-cookie"), null);
      assert.equal((await POST(request("auth/logout", {}))).status, 503);
    } finally {
      await db.query(reopen);
    }
    assert.equal(
      (
        await pool.query(
          "SELECT consumed_at FROM email_challenges WHERE id=$1",
          [c.challengeId],
        )
      ).rows[0].consumed_at,
      null,
    );
  }
});

test("P07 configuration and Origin errors retain 503/403 before accepting work", async () => {
  const saved = process.env.E4_LIFECYCLE_ADAPTER;
  process.env.E4_LIFECYCLE_ADAPTER = "invalid";
  try {
    assert.equal((await GET(request("account"))).status, 503);
  } finally {
    process.env.E4_LIFECYCLE_ADAPTER = saved;
  }
  const foreign = new NextRequest(
    `${process.env.APP_ORIGIN}/api/e4/auth/request-code`,
    {
      method: "POST",
      headers: { Origin: "https://foreign.example.test" },
      body: JSON.stringify({ email: address() }),
    },
  );
  assert.equal((await POST(foreign)).status, 403);
});
