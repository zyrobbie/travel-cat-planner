import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server } from "node:http";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve, extname, join } from "node:path";
import { randomUUID, createHash } from "node:crypto";
import { setTimeout as delay } from "node:timers/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import pg from "pg";
import { NextRequest } from "next/server";
import { chromium, request, expect, type APIRequestContext, type Browser } from "@playwright/test";
import { pool } from "../../src/server/db";
import { IndependentLedger } from "../../src/server/independent-ledger";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { requestCode, verifyCode } from "../../src/server/account-auth";
import { SyntheticMailbox } from "../../src/server/otp-delivery";
import { prepareAccountDeletion, cancelAccountDeletion, confirmAccountDeletion } from "../../src/server/account-lifecycle";

const ownerUrls = [process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS!, process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER!];
for (const value of ownerUrls) {
  const url = new URL(value);
  assert.equal(url.hostname, "127.0.0.1");
  assert.equal(url.pathname, "/catletters_deletion_ux_test");
}
const admin = new pg.Pool({ connectionString: ownerUrls[0] });
const ledgerAdmin = new pg.Pool({ connectionString: ownerUrls[1] });
const cases: object[] = [], apis: APIRequestContext[] = [];
const evidence = process.env.E4_VALIDATION_EVIDENCE!;
const shots = "/private/tmp/cat-deletion-ux-shots-20261018";
let server: Server, browser: Browser, origin: string, controlId: string, controlBefore: string;
const passed = (name: string, facts = {}) => cases.push({ test: name, status: "PASS", ...facts });
async function nonce() {
  for (const db of [admin, ledgerAdmin])
    assert.equal((await db.query("SELECT value FROM local_validation_cluster_nonce")).rows[0].value,
      process.env.E4_VALIDATION_LOCAL_NONCE);
}
async function controlHash() {
  const rows = [];
  for (const table of ["accounts", "account_sessions", "cat_profiles", "cloud_letters", "cloud_responses", "cloud_trips", "account_exports", "account_deletions"])
    rows.push((await admin.query(`SELECT * FROM ${table} WHERE ${table === "accounts" ? "id" : "account_id"}=$1 ORDER BY 1`, [controlId])).rows);
  return createHash("sha256").update(JSON.stringify(rows)).digest("hex");
}
async function http(api: APIRequestContext, path: string, body?: object, expected = 200) {
  const response = body === undefined ? await api.get(path) : await api.post(path, { data: body });
  assert.equal(response.status(), expected, `unexpected status on ${path.split("/").at(-1)}`);
  assert.match(response.headers()["cache-control"], /no-store/);
  return { response, data: await response.json() };
}
async function identity(email = `deletion-ux-${randomUUID()}@example.invalid`, adopt = true) {
  const mailbox = new SyntheticMailbox();
  const asked = await requestCode(email, mailbox);
  const login = await verifyCode(asked.challengeId, email, mailbox.messages.get(asked.challengeId)!.code);
  mailbox.messages.clear();
  const api = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin }, storageState: {
    cookies: [{ name: "cat_account_session", value: login.rawToken, domain: "127.0.0.1", path: "/",
      httpOnly: true, secure: false, sameSite: "Strict", expires: -1 }], origins: [],
  } });
  apis.push(api);
  const adopted = adopt ? await http(api, "/api/e4/cat/adopt", { key: randomUUID(), name: "合成复核猫", appearanceId: "cat-02" }) : null;
  return { api, id: login.accountId, email, catId: adopted?.data.cat.id ?? null };
}
type Identity = Awaited<ReturnType<typeof identity>>;
async function prepare(a: Identity) {
  const key = randomUUID();
  const { data } = await http(a.api, "/api/e4/privacy/deletions/prepare", { key });
  return { key, task: data.deletion, receipt: (await a.api.storageState()).cookies.find(c => c.name === "cat_deletion_receipt")!.value };
}
async function pageFor(a: Identity, task: any) {
  const context = await browser.newContext({ storageState: await a.api.storageState(), viewport: { width: 390, height: 844 } });
  await context.addInitScript(({ accountId, requestId }) => {
    const seeded = "synthetic-deletion-seeded:" + accountId;
    if (sessionStorage.getItem(seeded)) return;
    sessionStorage.setItem(seeded, "true");
    localStorage.setItem(`cat-letters:account-draft:v1:${accountId}:synthetic:reply`, "SYNTHETIC_DRAFT_KEEP");
    sessionStorage.setItem(`cat-letters:account-request:v1:${accountId}:synthetic:SEND_RESPONSE`, "SYNTHETIC_PENDING_KEEP");
    localStorage.setItem("cat-letters:account-draft:v1:00000000-0000-4000-8000-000000000001:other:reply", "SYNTHETIC_OTHER_KEEP");
    sessionStorage.setItem("cat-letters:account-deletion-intent:v1", JSON.stringify({ accountId, requestId }));
  }, { accountId: a.id, requestId: task.requestId });
  const page = await context.newPage();
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("console", message => {
    if (message.type() === "error" && !/status of (401|409|503)|net::ERR_FAILED/.test(message.text())) errors.push(message.text());
  });
  await page.goto(origin + "/account-app/");
  return { context, page, errors };
}
async function localKeys(page: any, id: string) {
  return page.evaluate((accountId: string) => ({
    draft: localStorage.getItem(`cat-letters:account-draft:v1:${accountId}:synthetic:reply`),
    request: sessionStorage.getItem(`cat-letters:account-request:v1:${accountId}:synthetic:SEND_RESPONSE`),
    other: localStorage.getItem("cat-letters:account-draft:v1:00000000-0000-4000-8000-000000000001:other:reply"),
    intent: sessionStorage.getItem("cat-letters:account-deletion-intent:v1"),
  }), id);
}
before(async () => {
  await nonce(); await mkdir(shots, { recursive: true });
  const auth = await import("../../src/app/api/e4/[...path]/route");
  const privacy = await import("../../src/app/api/e4/privacy/[...path]/route");
  const v1 = await import("../../src/app/api/e4/v1/[...path]/route");
  server = createServer(async (req, res) => {
    try {
      const path = new URL(req.url!, "http://127.0.0.1").pathname;
      if (!path.startsWith("/api/")) {
        const root = path.startsWith("/account-app/") ? resolve("public") : resolve(".");
        assert.ok(["/account-app/", "/ui-daily-core-v1/", "/ui-components-v1/"].some(prefix => path.startsWith(prefix)));
        const file = resolve(root, "." + (path.endsWith("/") ? path + "index.html" : path));
        assert.ok(file.startsWith(root + "/"));
        const types: Record<string, string> = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".webp": "image/webp", ".svg": "image/svg+xml", ".json": "application/json" };
        res.setHeader("Content-Type", types[extname(file)] ?? "application/octet-stream");
        res.end(await readFile(file)); return;
      }
      const chunks = []; for await (const chunk of req) chunks.push(chunk);
      const headers = new Headers();
      for (const [key, value] of Object.entries(req.headers)) if (value !== undefined)
        headers.set(key, Array.isArray(value) ? value.join(",") : value);
      const request = new NextRequest(origin + req.url, { method: req.method, headers,
        ...(chunks.length ? { body: Buffer.concat(chunks) } : {}) });
      const route = path.startsWith("/api/e4/privacy/") ? privacy : path.startsWith("/api/e4/v1/") ? v1 : auth;
      const response = await (req.method === "POST" ? route.POST : route.GET)(request);
      res.statusCode = response.status;
      response.headers.forEach((value, key) => { if (key.toLowerCase() !== "set-cookie") res.setHeader(key, value); });
      if (response.headers.getSetCookie().length) res.setHeader("Set-Cookie", response.headers.getSetCookie());
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch { res.statusCode = 503; res.end("local test bridge failed"); }
  });
  await new Promise<void>(done => server.listen(0, "127.0.0.1", done));
  origin = `http://127.0.0.1:${(server.address() as any).port}`; process.env.APP_ORIGIN = origin;
  browser = await chromium.launch({ headless: true });
  const control = await identity(); controlId = control.id; controlBefore = await controlHash();
});
after(async () => {
  try {
  if (controlId) assert.equal(await controlHash(), controlBefore);
  await writeFile(join(evidence, "deletion-ux-results.json"), JSON.stringify({
    tests: cases, cloudExecuted: false, emailSent: false, browserExecuted: !!browser,
    adapter: "postgres-v1", restrictedRoles: ["cat_letters_app", "cat_letters_ledger"],
    controlUnchanged: controlId ? await controlHash() === controlBefore : false, screenshots: shots,
  }, null, 2));
  } finally {
  await browser?.close(); await Promise.all(apis.map(api => api.dispose()));
  if (server) await new Promise<void>(done => server.close(() => done()));
  await closeLifecycleProvider(); await pool.end(); await admin.end(); await ledgerAdmin.end();
  }
});

test("U00 old ledger CHECK blocks cancel with unchanged head, event count, business watermark and preparation; 002 enables same request", async () => {
  await nonce(); const a = await identity(), p = await prepare(a);
  const snapshot = async () => createHash("sha256").update(JSON.stringify({
    head: (await ledgerAdmin.query("SELECT * FROM ledger_head")).rows,
    count: (await ledgerAdmin.query("SELECT count(*)::int AS n FROM ledger_events")).rows,
    watermark: (await admin.query("SELECT * FROM lifecycle_control")).rows,
    preparation: (await admin.query("SELECT * FROM deletion_preparations WHERE account_id=$1", [a.id])).rows,
  })).digest("hex");
  await ledgerAdmin.query("BEGIN; ALTER TABLE ledger_events DROP CONSTRAINT ledger_events_kind_check; ALTER TABLE ledger_events ADD CONSTRAINT ledger_events_kind_check CHECK(kind IN ('DELETE_REQUESTED','DELETE_COMPLETE','RESPONSE_DELETED')); COMMIT");
  const before = await snapshot();
  try {
    await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId }, 503);
    assert.equal(await snapshot(), before);
    assert.equal((await http(a.api, "/api/e4/account")).data.cat.id, a.catId);
    assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "PREPARED");
  } finally {
    await ledgerAdmin.query("BEGIN");
    try { await ledgerAdmin.query(await readFile("db/ledger-migrations/002_deletion_cancellation.sql", "utf8")); await ledgerAdmin.query("COMMIT"); }
    catch (error) { await ledgerAdmin.query("ROLLBACK"); throw error; }
  }
  assert.equal((await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId })).data.deletion.status, "CANCELLED");
  assert.equal((await http(a.api, "/api/e4/account")).data.id, a.id);
  passed("U00_OLD_CHECK_ATOMIC_WRITE_GATE_THEN_002_SAME_REQUEST_SUCCEEDS");
});

test("U01 durable cancellation rejects old confirm and preserves ACTIVE account, cat and session", async () => {
  const a = await identity(), p = await prepare(a);
  const cancelled = await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId });
  assert.equal(cancelled.data.deletion.status, "CANCELLED");
  assert.equal(cancelled.response.headersArray().some(h => h.name.toLowerCase() === "set-cookie"), false);
  assert.equal((await http(a.api, "/api/e4/account")).data.id, a.id);
  assert.equal((await http(a.api, "/api/e4/account")).data.cat.id, a.catId);
  await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId });
  assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "CANCELLED");
  await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true }, 409);
  assert.equal((await ledgerAdmin.query("SELECT count(*)::int AS n FROM ledger_events WHERE request_id=$1", [p.task.requestId])).rows[0].n, 1);
  const originalStorage = await a.api.storageState();
  const next = await http(a.api, "/api/e4/privacy/deletions/prepare", { key: p.key });
  assert.notEqual(next.data.deletion.requestId, p.task.requestId);
  // Real HTTP replay retains the original receipt after a new prepare replaced the shared cookie.
  const oldReceipt = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin }, storageState: originalStorage });
  apis.push(oldReceipt);
  await http(oldReceipt, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true }, 409);
  assert.equal((await ledgerAdmin.query("SELECT count(*)::int AS n FROM ledger_events WHERE request_id=$1 AND kind='DELETE_REQUESTED'", [p.task.requestId])).rows[0].n, 0);
  await a.api.dispose(); apis.splice(apis.indexOf(a.api), 1);
  passed("U01_CANCELLED_durable_idempotent_no_cookies_old_key_new_capability");
});

async function race(firstKind: "cancel" | "confirm") {
  const a = await identity(), prepared = await prepareAccountDeletion(a.id, randomUUID());
  const original = pg.Client.prototype.query;
  let enter!: () => void, release!: () => void, lookups = 0;
  const entered = new Promise<void>(resolve => { enter = resolve; });
  const barrier = new Promise<void>(resolve => { release = resolve; });
  (pg.Client.prototype as any).query = function (...args: any[]) {
    if (args[0] === "SELECT * FROM deletion_preparations WHERE request_id=$1" && args[1]?.[0] === prepared.deletion.requestId && ++lookups === 1) {
      enter(); return barrier.then(() => Reflect.apply(original, this, args));
    }
    return Reflect.apply(original, this, args);
  };
  const cancel = () => cancelAccountDeletion(a.id, prepared.deletion.requestId, prepared.receipt);
  const confirm = () => confirmAccountDeletion(a.id, prepared.deletion.requestId, prepared.receipt);
  try {
    const first = firstKind === "cancel" ? cancel() : confirm();
    await Promise.race([entered, first.then(() => { throw Error("lock barrier was not entered"); })]);
    // First actor is inside the real lifecycle exclusive lock.
    const second = firstKind === "cancel" ? confirm() : cancel();
    await delay(20); assert.equal(lookups, 1); release();
    const result = await Promise.allSettled([first, second]);
    assert.equal(result[0].status, "fulfilled"); assert.equal(result[1].status, "rejected");
    const events = (await ledgerAdmin.query("SELECT kind FROM ledger_events WHERE request_id=$1", [prepared.deletion.requestId])).rows;
    assert.deepEqual(events.map(row => row.kind), [firstKind === "cancel" ? "DELETE_CANCELLED" : "DELETE_REQUESTED"]);
    const state = (await admin.query("SELECT status FROM accounts WHERE id=$1", [a.id])).rows[0].status;
    assert.equal(state, firstKind === "cancel" ? "ACTIVE" : "DELETING");
  } finally { release?.(); pg.Client.prototype.query = original; }
}
test("U02 deterministic barriers: cancel wins and confirm wins serialize on the same actual lock", async () => {
  await race("cancel"); await race("confirm"); passed("U02_BOTH_DETERMINISTIC_LOCK_ORDERS");
});

test("U03 actual UI: confirm never reaches server; UNKNOWN preserves drafts, then cancel ACK loss recovers original task", async () => {
  const a = await identity(), p = await prepare(a), ui = await pageFor(a, p.task);
  try {
    await expect(ui.page.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    await ui.page.route("**/api/e4/privacy/deletions/confirm", route => route.abort("failed"));
    await ui.page.route("**/api/e4/privacy/deletions/status", route => route.abort("failed"));
    await ui.page.getByRole("button", { name: "继续确认注销", exact: true }).click();
    await expect(ui.page.getByRole("heading", { name: "正在确认注销结果", exact: true })).toBeVisible();
    assert.equal(await ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true }).count(), 0);
    assert.equal((await localKeys(ui.page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    assert.equal((await admin.query("SELECT count(*)::int AS n FROM account_deletions WHERE account_id=$1", [a.id])).rows[0].n, 0);
    await ui.page.screenshot({ path: join(shots, "unknown-390.png") });
    await ui.page.unroute("**/api/e4/privacy/deletions/status"); await ui.page.reload();
    await expect(ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true })).toBeVisible();
    await ui.page.screenshot({ path: join(shots, "prepared-390.png") });
    await ui.page.route("**/api/e4/privacy/deletions/cancel", async route => { assert.equal((await route.fetch()).status(), 200); await route.abort("failed"); });
    await ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true }).click();
    await expect(ui.page.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    const keys = await localKeys(ui.page, a.id);
    assert.equal(keys.draft, "SYNTHETIC_DRAFT_KEEP"); assert.equal(keys.request, "SYNTHETIC_PENDING_KEEP"); assert.equal(keys.intent, null);
    await ui.page.reload(); await expect(ui.page.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    assert.deepEqual(ui.errors, []);
    passed("U03_NOT_SUBMITTED_UNKNOWN_CANCEL_ACK_LOSS_REFRESH_DRAFTS_RETAINED");
  } finally { await ui.context.close(); }
});

test("U04 actual UI: committed confirmation ACK loss stays protected and keeps drafts until matching COMPLETE", async () => {
  const a = await identity(), p = await prepare(a), ui = await pageFor(a, p.task);
  try {
    await expect(ui.page.getByRole("button", { name: "继续确认注销", exact: true })).toBeVisible();
    await ui.page.route("**/api/e4/privacy/deletions/confirm", async route => { assert.equal((await route.fetch()).status(), 200); await route.abort("failed"); });
    await ui.page.getByRole("button", { name: "继续确认注销", exact: true }).click();
    await expect(ui.page.getByRole("heading", { name: "正在注销账号", exact: true })).toBeVisible();
    assert.equal((await localKeys(ui.page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    await ui.page.reload(); await expect(ui.page.getByRole("heading", { name: "正在注销账号", exact: true })).toBeVisible();
    assert.equal((await localKeys(ui.page, a.id)).request, "SYNTHETIC_PENDING_KEEP");
    await ui.page.getByRole("button", { name: "查询注销进度", exact: true }).click();
    const complete = await http(a.api, "/api/e4/privacy/deletions/retry", { requestId: p.task.requestId });
    assert.equal(complete.data.deletion.status, "COMPLETE");
    await ui.page.getByRole("button", { name: "查询注销进度", exact: true }).click();
    await expect(ui.page.getByRole("heading", { name: "账号已注销", exact: true })).toBeVisible();
    await expect.poll(async () => (await localKeys(ui.page, a.id)).draft).toBe(null);
    const keys = await localKeys(ui.page, a.id); assert.equal(keys.request, null); assert.equal(keys.other, "SYNTHETIC_OTHER_KEEP");
    for (const width of [390, 430, 1280, 1366]) {
      await ui.page.setViewportSize({ width, height: width < 700 ? 844 : 720 });
      const layout = await ui.page.locator(".e4-deletion-keep-phrase").evaluate(element => ({
        lines: element.getClientRects().length, width: element.getBoundingClientRect().width,
        overflow: document.documentElement.scrollWidth > innerWidth,
      }));
      assert.equal(layout.lines, 1); assert.equal(layout.overflow, false);
      await ui.page.screenshot({ path: join(shots, `complete-${width}.png`) });
    }
    assert.deepEqual(ui.errors, []); passed("U04_PENDING_REFRESH_COMPLETE_TARGETED_CLEANUP_VISUAL_4_WIDTHS");
  } finally { await ui.context.close(); }
});

async function repairOriginalLedger() {
  await nonce();
  const adapter = new IndependentLedger(admin, ledgerAdmin, process.env.E4_LEDGER_SECRET!);
  const operation = randomUUID(), closed = await adapter.closeRestoreGate(operation);
  const result = await promisify(execFile)(process.execPath,
    ["--import", "tsx", "scripts/lifecycle.ts", "reconcile", operation, String(closed.epoch)],
    { env: { ...process.env, DATABASE_URL: ownerUrls[0], E4_LEDGER_DATABASE_URL: ownerUrls[1], E4_LIFECYCLE_RECOVERY: "true" }, timeout: 60000 });
  assert.match(result.stdout, /"ready":true/);
}
test("U05 DELETE_REQUESTED committed before failed freeze cannot be cancelled using an ACTIVE business snapshot", async () => {
  await nonce(); const a = await identity(), p = await prepare(a);
  await admin.query(`CREATE FUNCTION ux_freeze_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
    IF NEW.id='${a.id}'::uuid AND NEW.status='DELETING' THEN RAISE EXCEPTION 'synthetic freeze failure'; END IF;
    RETURN NEW; END $$; CREATE TRIGGER ux_freeze_fail BEFORE UPDATE ON accounts FOR EACH ROW EXECUTE FUNCTION ux_freeze_fail()`);
  try {
    await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true }, 503);
    assert.equal((await admin.query("SELECT status FROM accounts WHERE id=$1", [a.id])).rows[0].status, "ACTIVE");
    assert.equal((await admin.query("SELECT count(*)::int AS n FROM account_deletions WHERE account_id=$1", [a.id])).rows[0].n, 0);
    assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "PENDING");
    await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId }, 503);
    assert.equal((await ledgerAdmin.query("SELECT count(*)::int AS n FROM ledger_events WHERE request_id=$1 AND kind='DELETE_CANCELLED'", [p.task.requestId])).rows[0].n, 0);
    await http(a.api, "/api/e4/account", undefined, 503);
  } finally {
    await admin.query("DROP TRIGGER ux_freeze_fail ON accounts; DROP FUNCTION ux_freeze_fail()");
    await repairOriginalLedger();
  }
  passed("U05_LEDGER_FIRST_FREEZE_FAILURE_CANCEL_FAILS_CLOSED");
});

test("U06 cancellation decision survives failed preparation cleanup; only explicit original replay reopens writes", async () => {
  await nonce(); const a = await identity(), p = await prepare(a);
  await admin.query(`CREATE FUNCTION ux_cancel_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
    IF OLD.account_id='${a.id}'::uuid THEN RAISE EXCEPTION 'synthetic preparation rollback'; END IF;
    RETURN OLD; END $$; CREATE TRIGGER ux_cancel_fail BEFORE DELETE ON deletion_preparations FOR EACH ROW EXECUTE FUNCTION ux_cancel_fail()`);
  try {
    await http(a.api, "/api/e4/privacy/deletions/cancel", { requestId: p.task.requestId }, 503);
    assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "CANCELLED");
    await http(a.api, "/api/e4/account", undefined, 503);
    await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true }, 503);
  } finally {
    await admin.query("DROP TRIGGER ux_cancel_fail ON deletion_preparations; DROP FUNCTION ux_cancel_fail()");
    await repairOriginalLedger();
  }
  assert.equal((await http(a.api, "/api/e4/account")).data.id, a.id);
  assert.equal((await admin.query("SELECT count(*)::int AS n FROM deletion_preparations WHERE account_id=$1", [a.id])).rows[0].n, 0);
  await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true }, 409);
  passed("U06_DURABLE_CANCEL_STALE_PREPARATION_REPLAY_NO_ACCOUNT_UNFREEZE");
});

test("U07 cancellation authorization rejects foreign origin, context, request and receipt without changing the decision", async () => {
  const a = await identity(), p = await prepare(a), path = "/api/e4/privacy/deletions/cancel";
  const foreign = await a.api.post(path, { data: { requestId: p.task.requestId }, headers: { Origin: "https://foreign.invalid" } });
  assert.equal(foreign.status(), 403);
  const wrongContext = await a.api.post(path, { data: { requestId: p.task.requestId }, headers: { "X-Catletters-Account": controlId } });
  assert.equal(wrongContext.status(), 401);
  await http(a.api, path, { requestId: randomUUID() }, 401);
  const badReceipt = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin }, storageState: {
    cookies: [...(await a.api.storageState()).cookies.filter(cookie => cookie.name !== "cat_deletion_receipt"),
      { name: "cat_deletion_receipt", value: randomUUID() + "." + "0".repeat(64), domain: "127.0.0.1", path: "/api/e4/privacy", expires: -1, httpOnly: true, secure: false, sameSite: "Strict" }], origins: [],
  } }); apis.push(badReceipt);
  await http(badReceipt, path, { requestId: p.task.requestId }, 401);
  const anonymous = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin }, storageState: {
    cookies: (await a.api.storageState()).cookies.filter(cookie => cookie.name === "cat_deletion_receipt"), origins: [],
  } }); apis.push(anonymous);
  await http(anonymous, path, { requestId: p.task.requestId }, 401);
  await http(anonymous, "/api/e4/account", undefined, 401);
  assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "PREPARED");
  assert.equal((await ledgerAdmin.query("SELECT count(*)::int AS n FROM ledger_events WHERE request_id=$1", [p.task.requestId])).rows[0].n, 0);
  passed("U07_ORIGIN_CONTEXT_REQUEST_RECOVERY_CAPABILITY_AUTHORIZATION");
});

test("U08 delayed old cancel reply and broadcast preserve same-email new UUID, session, receipt and drafts", async () => {
  const a = await identity(), p = await prepare(a), ui = await pageFor(a, p.task);
  let delivered!: () => void, release!: () => void;
  const committed = new Promise<void>(resolve => { delivered = resolve; });
  const barrier = new Promise<void>(resolve => { release = resolve; });
  try {
    await expect(ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true })).toBeVisible();
    await ui.page.route("**/api/e4/privacy/deletions/cancel", async route => {
      const response = await route.fetch(); assert.equal(response.status(), 200);
      assert.equal(response.headersArray().some(header => header.name.toLowerCase() === "set-cookie"), false);
      delivered(); await barrier;
      try { await route.fulfill({ response }); } catch { /* Original page can abort after the session changes. */ }
    });
    await ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true }).click();
    await committed;
    const second = await prepare(a);
    await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: second.task.requestId, confirm: true });
    await http(a.api, "/api/e4/privacy/deletions/retry", { requestId: second.task.requestId });
    const replacement = await identity(a.email, false); assert.notEqual(replacement.id, a.id);
    const replacementPrepared = await prepare(replacement);
    const latestCookies = (await replacement.api.storageState()).cookies;
    await ui.context.addCookies(latestCookies);
    await ui.page.evaluate(id => {
      localStorage.setItem(`cat-letters:account-draft:v1:${id}:synthetic:reply`, "NEW_ACCOUNT_DRAFT_KEEP");
      sessionStorage.setItem(`cat-letters:account-request:v1:${id}:synthetic:SEND_RESPONSE`, "NEW_ACCOUNT_REQUEST_KEEP");
    }, replacement.id);
    const secondPage = await ui.context.newPage(); await secondPage.goto(origin + "/account-app/");
    await secondPage.evaluate(id => { const channel = new BroadcastChannel("cat-letters:account-session:v1"); channel.postMessage({ type: "SESSION_CHANGED", accountId: id }); channel.close(); }, replacement.id);
    await expect(ui.page.getByLabel("邮箱", { exact: true })).toBeVisible();
    release(); await ui.page.reload();
    await expect(ui.page.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    const before = latestCookies.filter(cookie => ["cat_account_session", "cat_deletion_receipt"].includes(cookie.name)).map(cookie => [cookie.name, cookie.value]).sort();
    const after = (await ui.context.cookies()).filter(cookie => ["cat_account_session", "cat_deletion_receipt"].includes(cookie.name)).map(cookie => [cookie.name, cookie.value]).sort();
    assert.ok(JSON.stringify(after) === JSON.stringify(before), "new session and receipt cookies changed");
    const keys = await localKeys(ui.page, replacement.id);
    assert.equal(keys.draft, "NEW_ACCOUNT_DRAFT_KEEP"); assert.equal(keys.request, "NEW_ACCOUNT_REQUEST_KEEP");
    await secondPage.evaluate(({ accountId, requestId }) => { const channel = new BroadcastChannel("cat-letters:account-session:v1"); channel.postMessage({ type: "ACCOUNT_DELETING", accountId, requestId }); channel.close(); }, { accountId: a.id, requestId: p.task.requestId });
    await expect(ui.page.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    assert.equal((await http(replacement.api, "/api/e4/account")).data.cat, null);
    assert.equal((await http(replacement.api, "/api/e4/privacy/deletions/status")).data.deletion.requestId, replacementPrepared.task.requestId);
    await secondPage.close(); passed("U08_DELAYED_CANCEL_NEW_SAME_EMAIL_UUID_COOKIES_DRAFTS_BROADCAST_ISOLATED");
  } finally { release?.(); await ui.context.close(); }
});

test("U10 normal confirmation entry and broadcast: request never reaches server, both tabs preserve drafts and refresh stays in recovery", async () => {
  const a = await identity();
  const context = await browser.newContext({ storageState: await a.api.storageState(), viewport: { width: 390, height: 844 } });
  const page = await context.newPage(), secondPage = await context.newPage();
  try {
    await page.goto(origin + "/account-app/"); await secondPage.goto(origin + "/account-app/");
    await expect(page.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    await expect(secondPage.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    await page.evaluate(id => {
      localStorage.setItem(`cat-letters:account-draft:v1:${id}:synthetic:reply`, "SYNTHETIC_DRAFT_KEEP");
      sessionStorage.setItem(`cat-letters:account-request:v1:${id}:synthetic:SEND_RESPONSE`, "SYNTHETIC_PENDING_KEEP");
    }, a.id);
    await page.getByRole("button", { name: "账号设置", exact: true }).click();
    await page.getByRole("button", { name: "注销账号", exact: true }).click();
    await page.route("**/api/e4/privacy/deletions/confirm", route => route.abort("failed"));
    await page.route("**/api/e4/privacy/deletions/status", route => route.abort("failed"));
    await page.getByRole("button", { name: "确认注销", exact: true }).click();
    await expect(page.getByRole("heading", { name: "正在确认注销结果", exact: true })).toBeVisible();
    await expect(secondPage.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    assert.equal((await localKeys(page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    assert.equal((await localKeys(secondPage, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    await secondPage.reload();
    await expect(secondPage.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    assert.equal((await admin.query("SELECT count(*)::int AS n FROM account_deletions WHERE account_id=$1", [a.id])).rows[0].n, 0);
    await secondPage.getByRole("button", { name: "暂不注销，返回小猫", exact: true }).click();
    await expect(secondPage.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    assert.equal((await localKeys(secondPage, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    await secondPage.getByRole("button", { name: "账号设置", exact: true }).click();
    await secondPage.getByRole("button", { name: "注销账号", exact: true }).click();
    await secondPage.getByRole("button", { name: "暂不注销", exact: true }).click();
    await expect(secondPage.getByRole("button", { name: "生成个人资料文件", exact: true })).toBeVisible();
    assert.equal((await localKeys(secondPage, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    passed("U10_NORMAL_ENTRY_PRE_SERVER_FAILURE_BROADCAST_REFRESH_DRAFTS_SAFE");
  } finally { await context.close(); }
});

test("U12 mismatched COMPLETE responses cannot clean local drafts or replace the original recovery request", async () => {
  const a = await identity(), p = await prepare(a), ui = await pageFor(a, p.task);
  let invalid: any;
  try {
    await expect(ui.page.getByRole("heading", { name: "注销尚未提交", exact: true })).toBeVisible();
    await ui.page.route("**/api/e4/privacy/deletions/status", route => route.fulfill({
      status: 200, contentType: "application/json", body: JSON.stringify({ deletion: invalid }),
    }));
    for (const mismatch of [{ requestId: randomUUID() }, { accountId: controlId }]) {
      invalid = { ...p.task, ...mismatch, status: "COMPLETE" };
      await ui.page.getByRole("button", { name: "查询注销进度", exact: true }).click();
      await expect(ui.page.getByRole("alert")).toContainText("注销进度与原请求不一致");
      await expect(ui.page.getByRole("heading", { name: "正在确认注销结果", exact: true })).toBeVisible();
      const keys = await localKeys(ui.page, a.id);
      assert.equal(keys.draft, "SYNTHETIC_DRAFT_KEEP"); assert.equal(keys.request, "SYNTHETIC_PENDING_KEEP");
      assert.equal(JSON.parse(keys.intent!).requestId, p.task.requestId);
      assert.equal(await ui.page.getByRole("heading", { name: "账号已注销", exact: true }).count(), 0);
    }
    await ui.page.unroute("**/api/e4/privacy/deletions/status");
    await ui.page.route("**/api/e4/privacy/deletions/status", route => route.abort("failed"));
    await ui.page.getByRole("button", { name: "查询注销进度", exact: true }).click();
    await expect(ui.page.getByRole("heading", { name: "正在确认注销结果", exact: true })).toBeVisible();
    assert.equal((await localKeys(ui.page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    passed("U12_FOREIGN_COMPLETE_OR_QUERY_FAILURE_STAYS_UNKNOWN_DRAFTS_RETAINED");
  } finally { await ui.context.close(); }
});

test("U11 a new same-UUID deletion broadcast invalidates the cancelled task's delayed ACTIVE return reply", async () => {
  const a = await identity(), p = await prepare(a), ui = await pageFor(a, p.task);
  let captured!: () => void, release!: () => void, hold = true;
  const activeCaptured = new Promise<void>(resolve => { captured = resolve; });
  const barrier = new Promise<void>(resolve => { release = resolve; });
  const secondPage = await ui.context.newPage();
  try {
    await secondPage.goto(origin + "/account-app/");
    await expect(ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true })).toBeVisible();
    await ui.page.route("**/api/e4/account", async route => {
      if (!hold) { await route.continue(); return; }
      hold = false;
      const response = await route.fetch(); assert.equal(response.status(), 200);
      captured(); await barrier;
      try { await route.fulfill({ response }); } catch { /* The old return request is aborted on epoch change. */ }
    });
    await ui.page.getByRole("button", { name: "暂不注销，返回小猫", exact: true }).click();
    await activeCaptured;
    const next = await ui.context.request.post(origin + "/api/e4/privacy/deletions/prepare", {
      headers: { Origin: origin }, data: { key: randomUUID() },
    }); assert.equal(next.status(), 200);
    const nextTask = (await next.json()).deletion;
    const confirmed = await ui.context.request.post(origin + "/api/e4/privacy/deletions/confirm", {
      headers: { Origin: origin, "X-Catletters-Account": a.id }, data: { requestId: nextTask.requestId, confirm: true },
    }); assert.equal(confirmed.status(), 200);
    await secondPage.evaluate(({ accountId, requestId }) => {
      const channel = new BroadcastChannel("cat-letters:account-session:v1");
      channel.postMessage({ type: "ACCOUNT_DELETING", accountId, requestId }); channel.close();
    }, { accountId: a.id, requestId: nextTask.requestId });
    await expect(ui.page.getByRole("heading", { name: "正在注销账号", exact: true })).toBeVisible();
    release();
    await expect(ui.page.getByRole("heading", { name: "正在注销账号", exact: true })).toBeVisible();
    assert.equal(await ui.page.getByRole("button", { name: "账号设置", exact: true }).count(), 0);
    const keys = await localKeys(ui.page, a.id);
    assert.equal(JSON.parse(keys.intent!).requestId, nextTask.requestId);
    assert.equal(keys.draft, "SYNTHETIC_DRAFT_KEEP"); assert.equal(keys.request, "SYNTHETIC_PENDING_KEEP");
    await ui.page.screenshot({ path: join(shots, "new-request-broadcast-390.png") });
    passed("U11_SAME_UUID_NEW_REQUEST_BROADCAST_INVALIDATES_DELAYED_ACTIVE_REPLY");
  } finally { release?.(); await secondPage.close(); await ui.context.close(); }
});

test("U09 FAILED retains drafts; local cleanup error cannot downgrade COMPLETE and retry only clears original UUID", async () => {
  await nonce(); const a = await identity(), p = await prepare(a);
  await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true });
  await admin.query(`CREATE FUNCTION ux_erase_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
    IF OLD.account_id='${a.id}'::uuid THEN RAISE EXCEPTION 'synthetic erase failure'; END IF;
    RETURN OLD; END $$; CREATE TRIGGER ux_erase_fail BEFORE DELETE ON cat_profiles FOR EACH ROW EXECUTE FUNCTION ux_erase_fail()`);
  try { await http(a.api, "/api/e4/privacy/deletions/retry", { requestId: p.task.requestId }, 503); }
  finally { await admin.query("DROP TRIGGER ux_erase_fail ON cat_profiles; DROP FUNCTION ux_erase_fail()"); }
  const ui = await pageFor(a, p.task);
  try {
    await expect(ui.page.getByRole("heading", { name: "注销尚未完成", exact: true })).toBeVisible();
    assert.equal((await localKeys(ui.page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    await ui.page.screenshot({ path: join(shots, "failed-390.png") });
    await ui.page.evaluate(id => {
      const original = Storage.prototype.removeItem;
      (window as any).syntheticCleanupBlocked = true;
      Storage.prototype.removeItem = function (key: string) {
        if ((window as any).syntheticCleanupBlocked && key.startsWith(`cat-letters:account-draft:v1:${id}:`))
          throw Error("synthetic storage unavailable");
        return original.call(this, key);
      };
    }, a.id);
    await ui.page.getByRole("button", { name: "重试注销", exact: true }).click();
    await expect(ui.page.getByRole("heading", { name: "账号已注销", exact: true })).toBeVisible();
    await expect(ui.page.getByRole("button", { name: "重试清理本机记录", exact: true })).toBeVisible();
    assert.equal((await localKeys(ui.page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    assert.equal((await http(a.api, "/api/e4/privacy/deletions/status")).data.deletion.status, "COMPLETE");
    await ui.page.evaluate(() => { (window as any).syntheticCleanupBlocked = false; });
    await ui.page.getByRole("button", { name: "重试清理本机记录", exact: true }).click();
    await expect.poll(async () => (await localKeys(ui.page, a.id)).draft).toBe(null);
    assert.equal((await localKeys(ui.page, a.id)).other, "SYNTHETIC_OTHER_KEEP");
    assert.deepEqual(ui.errors, []); passed("U09_FAILED_DRAFT_RETENTION_COMPLETE_STORAGE_FAILURE_TARGETED_RETRY");
  } finally { await ui.context.close(); }
});

test("U13 saving the deletion intent fails before any confirm or cancel is sent; normal page and drafts stay intact", async () => {
  const a = await identity();
  const context = await browser.newContext({ storageState: await a.api.storageState(), viewport: { width: 390, height: 844 } });
  const page = await context.newPage(); let decisions = 0;
  page.on("request", request => { if (/\/deletions\/(confirm|cancel)$/.test(new URL(request.url()).pathname)) decisions++; });
  try {
    await page.goto(origin + "/account-app/");
    await expect(page.getByRole("button", { name: "账号设置", exact: true })).toBeVisible();
    await page.evaluate(id => {
      localStorage.setItem(`cat-letters:account-draft:v1:${id}:synthetic:reply`, "SYNTHETIC_DRAFT_KEEP");
      const original = Storage.prototype.setItem;
      Storage.prototype.setItem = function (key: string, value: string) {
        if (key === "cat-letters:account-deletion-intent:v1") throw Error("synthetic intent storage failure");
        return original.call(this, key, value);
      };
    }, a.id);
    await page.getByRole("button", { name: "账号设置", exact: true }).click();
    await page.getByRole("button", { name: "注销账号", exact: true }).click();
    await page.getByRole("button", { name: "确认注销", exact: true }).click();
    await expect(page.getByRole("alert")).toContainText("尚未提交注销");
    assert.equal(decisions, 0); assert.equal((await localKeys(page, a.id)).draft, "SYNTHETIC_DRAFT_KEEP");
    assert.equal((await admin.query("SELECT status FROM accounts WHERE id=$1", [a.id])).rows[0].status, "ACTIVE");
    passed("U13_INTENT_STORAGE_FAILURE_NO_DECISION_REQUEST_NO_DRAFT_LOSS");
  } finally { await context.close(); }
});

test("U14 failed result-page finish leaves COMPLETE and cleared drafts; retry closes only the original task", async () => {
  const a = await identity(), p = await prepare(a);
  await http(a.api, "/api/e4/privacy/deletions/confirm", { requestId: p.task.requestId, confirm: true });
  await http(a.api, "/api/e4/privacy/deletions/retry", { requestId: p.task.requestId });
  const ui = await pageFor(a, p.task);
  try {
    await expect(ui.page.getByRole("heading", { name: "账号已注销", exact: true })).toBeVisible();
    await expect.poll(async () => (await localKeys(ui.page, a.id)).draft).toBe(null);
    await ui.page.route("**/api/e4/privacy/deletions/finish", route => route.abort("failed"));
    await ui.page.route("**/api/e4/privacy/deletions/status", route => route.abort("failed"));
    await ui.page.getByRole("button", { name: "重新注册", exact: true }).click();
    await expect(ui.page.getByRole("alert")).toContainText("注销已完成");
    await expect(ui.page.getByRole("heading", { name: "账号已注销", exact: true })).toBeVisible();
    await ui.page.screenshot({ path: join(shots, "finish-failure-390.png") });
    assert.equal((await localKeys(ui.page, a.id)).draft, null);
    await ui.page.unroute("**/api/e4/privacy/deletions/finish"); await ui.page.unroute("**/api/e4/privacy/deletions/status");
    const finished = ui.page.waitForResponse(response => response.url().endsWith("/privacy/deletions/finish") && response.status() === 200);
    await ui.page.getByRole("button", { name: "重新注册", exact: true }).click();
    assert.equal((await (await finished).headersArray()).some(header => header.name.toLowerCase() === "set-cookie"), false);
    await expect(ui.page.getByLabel("邮箱", { exact: true })).toBeVisible();
    assert.deepEqual(ui.errors, []); passed("U14_FINISH_NETWORK_FAILURE_REMAINS_COMPLETE_RETRY_NO_COOKIE_MUTATION");
  } finally { await ui.context.close(); }
});
