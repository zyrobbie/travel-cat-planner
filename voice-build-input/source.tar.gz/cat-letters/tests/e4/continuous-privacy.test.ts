import test,{before,after} from "node:test";
import assert from "node:assert/strict";
import {randomUUID,createHash} from "node:crypto";
import {spawn} from "node:child_process";
import {mkdir,readFile,writeFile} from "node:fs/promises";
import {join} from "node:path";
import {pathToFileURL} from "node:url";
import pg from "pg";
import {pool,transaction} from "../../src/server/db";
import {closeLifecycleProvider} from "../../src/server/lifecycle-provider";
import {lockCloudCat} from "../../src/server/cloud-repository";
import {initializeCloudCalendar} from "../../src/server/cloud-calendar";
import {continuousPlan,continuousUntil} from "../../src/server/continuous-scope";
import {runContinuousSlot,cleanupContinuousExports,claimContinuousExport} from "../../src/server/continuous-worker";
import {runContinuousCycle} from "../../src/server/continuous-runner";
import {prepareAccountDeletion,confirmAccountDeletion,deletionStatus,runDeletionWorkerOnce} from "../../src/server/account-lifecycle";
import {requestAccountExport,runClaimedAccountExport} from "../../src/server/account-export";
const admin=new pg.Pool({connectionString:process.env.E4_VALIDATION_LOCAL_OWNER_BUSINESS});
const ledger=new pg.Pool({connectionString:process.env.E4_VALIDATION_LOCAL_OWNER_LEDGER});
const original=pg.Client.prototype.query;
const tests:object[]=[];const dir=join(process.env.E4_VALIDATION_LOCAL_DIRECTORY!,"privacy-cursor");
const deadline=()=>Date.now()+25_000;
let outside:string,outsideBefore:string,doneId:string,doneReceipt:string,doneRequest:string;
function configure(kind:"delivery"|"deletion"|"export"|"cleanup",ids:string[]) {
 process.env.E4_CONTINUOUS_ENABLED="true";process.env.E4_CONTINUOUS_UNTIL="2026-11-06T10:00:00Z";
 for(const k of ["delivery","deletion","export","cleanup"]){process.env[`E4_CONTINUOUS_${k.toUpperCase()}_ENABLED`]=String(k===kind);process.env[`E4_CONTINUOUS_${k.toUpperCase()}_ACCOUNT_IDS`]=JSON.stringify(k===kind?ids:[]);}
 return continuousPlan()!;
}
async function seed(email?:string) {
 const id=randomUUID(),pid=randomUUID(),cat=randomUUID();
 await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)",[id,email??`${id}@privacy.example.test`]);
 await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')",[pid]);
 await pool.query("INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-01','隐私调度合成猫')",[cat,id,pid]);
 await transaction(async db=>initializeCloudCalendar(db,await lockCloudCat(db,id),Date.now()));return id;
}
async function confirmed(id:string) {
 const p=await prepareAccountDeletion(id,randomUUID());await confirmAccountDeletion(id,p.deletion.requestId,p.receipt);return p;
}
async function snapshot(id:string) {
 const rows=[];for(const [table,key] of [["accounts","id"],["cat_profiles","account_id"],["cloud_letters","account_id"],["cloud_jobs","account_id"],["account_exports","account_id"],["account_deletions","account_id"]])rows.push((await admin.query(`SELECT to_jsonb(t) AS row FROM ${table} t WHERE ${key}=$1 ORDER BY to_jsonb(t)::text`,[id])).rows);
 rows.push((await admin.query("SELECT to_jsonb(p) AS row FROM private_export_chunks p JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1 ORDER BY p.export_id,p.artifact_name,p.chunk_index",[id])).rows);
 return JSON.stringify(rows);
}
async function cli(extra:Record<string,string>={}) {
 return new Promise<{code:number|null;text:string}>((yes,no)=>{const p=spawn(process.execPath,["--import","tsx","scripts/continuous-entry.mjs"],{env:{...process.env,...extra},stdio:["ignore","pipe","pipe"]});let text="";p.stdout.on("data",x=>text+=x);p.stderr.on("data",x=>text+=x);p.once("error",no);p.once("exit",code=>yes({code,text}));});
}
before(async()=>{
 for(const p of [admin,ledger])assert.equal((await p.query("SELECT value FROM local_validation_cluster_nonce")).rows[0].value,process.env.E4_VALIDATION_LOCAL_NONCE);
 await mkdir(dir,{mode:0o700});process.env.E4_CONTINUOUS_STATE_DIRECTORY=dir;process.env.E4_CONTINUOUS_LOCK_HELD="true";
 outside=await seed();await confirmed(outside);await admin.query("UPDATE account_deletions SET attempts=3 WHERE account_id=$1",[outside]);outsideBefore=await snapshot(outside);
});
after(async()=>{pg.Client.prototype.query=original;await writeFile(join(process.env.E4_VALIDATION_EVIDENCE!,"privacy-cases.json"),JSON.stringify({tests,cloudExecuted:false,emailSent:false,scope:"fresh local nonce-guarded restricted dual databases; all accounts synthetic .test fixtures"},null,2));await closeLifecycleProvider();await pool.end();await admin.end();await ledger.end();});

test("P01 PREPARED is never initiated by timer; outside exhausted PENDING remains unchanged",async()=>{
 const id=await seed();const prep=await prepareAccountDeletion(id,randomUUID());const plan=configure("deletion",[id]);
 assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");assert.equal((await deletionStatus(prep.receipt)).deletion!.status,"PREPARED");assert.equal(await snapshot(outside),outsideBefore);tests.push({test:"P01",status:"PASS"});
});
test("P02 confirmed scoped PENDING completes once; signed decision and outside data protected",async()=>{
 doneId=await seed();const p=await confirmed(doneId);doneReceipt=p.receipt;doneRequest=p.deletion.requestId;const plan=configure("deletion",[doneId]);
 assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"COMPLETE");assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");assert.equal((await deletionStatus(doneReceipt)).deletion!.status,"COMPLETE");
 const events=(await ledger.query("SELECT kind FROM ledger_events WHERE account_id=$1",[doneId])).rows.map(x=>x.kind);assert.deepEqual(events,["DELETE_REQUESTED","DELETE_COMPLETE"]);assert.equal(await snapshot(outside),outsideBefore);tests.push({test:"P02",status:"PASS"});
});
test("P03 scoped exhausted transition never changes outside attempts; FAILED never auto-erases",async()=>{
 const id=await seed();await confirmed(id);await admin.query("UPDATE account_deletions SET attempts=3 WHERE account_id=$1",[id]);const plan=configure("deletion",[id]);
 assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");assert.equal((await admin.query("SELECT status FROM account_deletions WHERE account_id=$1",[id])).rows[0].status,"FAILED");const before=await snapshot(id);
 assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");assert.equal(await snapshot(id),before);assert.equal(await snapshot(outside),outsideBefore);tests.push({test:"P03",status:"PASS"});
});
test("P04 pending row without a signed user confirmation fails closed without erasure",async()=>{
 const id=await seed();await admin.query("INSERT INTO account_deletions(account_id,request_id,status) VALUES($1,$2,'PENDING')",[id,randomUUID()]);const before=await snapshot(id);const plan=configure("deletion",[id]);await assert.rejects(runContinuousSlot(plan.slots[0],deadline()));assert.equal(await snapshot(id),before);tests.push({test:"P04",status:"PASS"});
});
test("P05 injected erasure failure records only original scoped request and requires manual recovery",async()=>{
 const id=await seed();await confirmed(id);const plan=configure("deletion",[id]);let hit=false;
 pg.Client.prototype.query=(function(this:pg.Client,...args:any[]){const sql=typeof args[0]==="string"?args[0]:args[0]?.text??"";if(!hit&&/DELETE FROM cloud_letters WHERE account_id=\$1/.test(sql)&&args[1]?.[0]===id){hit=true;return Promise.reject(Error("synthetic-private-error"));}return(original as any).apply(this,args);}) as any;
 try{await assert.rejects(runContinuousSlot(plan.slots[0],deadline()));}finally{pg.Client.prototype.query=original;}assert.equal(hit,true);
 assert.equal((await admin.query("SELECT status FROM account_deletions WHERE account_id=$1",[id])).rows[0].status,"FAILED");assert.equal((await admin.query("SELECT count(*)::int AS n FROM cat_profiles WHERE account_id=$1",[id])).rows[0].n,1);
 const before=await snapshot(id);assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");assert.equal(await snapshot(id),before);assert.equal(await snapshot(outside),outsideBefore);tests.push({test:"P05",status:"PASS"});
});
test("P06 complete COMMIT acknowledgement lost; durable COMPLETE is never erased or repeated",async()=>{
 const id=await seed();const p=await confirmed(id);const plan=configure("deletion",[id]);let marker=false,commits=0,hit=false;
 pg.Client.prototype.query=(async function(this:pg.Client,...args:any[]){const sql=typeof args[0]==="string"?args[0]:args[0]?.text??"";if(/UPDATE account_deletions SET status='COMPLETE'/.test(sql))marker=true;const r=await(original as any).apply(this,args);if(marker&&sql.trim()==="COMMIT"&&++commits===2){hit=true;throw Error("synthetic_ack_loss");}return r;}) as any;
 try{await assert.rejects(runContinuousSlot(plan.slots[0],deadline()));}finally{pg.Client.prototype.query=original;}assert.equal(hit,true);
 assert.equal((await deletionStatus(p.receipt)).deletion!.status,"COMPLETE");assert.equal((await runContinuousSlot(plan.slots[0],deadline())).status,"IDLE");
 assert.equal((await ledger.query("SELECT count(*)::int AS n FROM ledger_events WHERE account_id=$1 AND kind='DELETE_COMPLETE'",[id])).rows[0].n,1);assert.equal(await snapshot(outside),outsideBefore);tests.push({test:"P06",status:"PASS"});
});
test("P07 expired cutoff does zero SQL; later-than-approved cutoff and wrong scopes reject",async()=>{
 configure("deletion",[doneId]);
 const expired=await cli({E4_CONTINUOUS_UNTIL:"2026-10-22T00:00:00Z",DATABASE_URL:"invalid-private-db",E4_LEDGER_DATABASE_URL:"invalid-private-ledger"});assert.equal(expired.code,0,expired.text);assert.match(expired.text,/EXPIRED/);assert.ok(!expired.text.includes("private-db"));
 const invalid=await cli({E4_CONTINUOUS_UNTIL:"2026-11-07T10:00:00Z"});assert.equal(invalid.code,1);assert.match(invalid.text,/REJECTED_CONFIGURATION/);
 const plan=configure("cleanup",[doneId]);await assert.rejects(runDeletionWorkerOnce({continuous:plan.slots[0],pendingOnly:true,deadlineAt:deadline()}));tests.push({test:"P07",status:"PASS"});
});
test("P08 ten fixed accounts and four explicit kinds rotate at most five slots per invocation",async()=>{
 const ids=Array.from({length:10},()=>randomUUID());configure("delivery",ids);
 for(const k of ["deletion","export","cleanup"]){process.env[`E4_CONTINUOUS_${k.toUpperCase()}_ENABLED`]="true";process.env[`E4_CONTINUOUS_${k.toUpperCase()}_ACCOUNT_IDS`]=JSON.stringify(ids);}
 const plan=continuousPlan()!;assert.equal(plan.slots.length,40);const own=join(dir,"fairness");await mkdir(own,{mode:0o700});const seen=new Set<string>();
 for(let n=0;n<8;n++){const r=await runContinuousCycle(plan,own,deadline(),async s=>{seen.add(s.task+s.accountId);return{status:"IDLE"};});assert.equal(r.outcomes.length,5);}
 assert.equal(seen.size,40);tests.push({test:"P08",status:"PASS"});
});
test("P09 bounded stale-artifact cleanup never removes current bytes or outside artifacts; unowned FK orphans reject",async()=>{
 const id=await seed(),other=await seed();for(const a of [id,other]){configure("export",[a]);await requestAccountExport(a,randomUUID());assert.equal((await runContinuousSlot(continuousPlan()!.slots[0],deadline())).status,"READY");}
 const job=(await admin.query("SELECT id,artifact_name FROM account_exports WHERE account_id=$1",[id])).rows[0];
 for(let i=0;i<105;i++)await admin.query("INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body) VALUES($1,$2,0,1,$3,$4)",[job.id,`${job.id}.${randomUUID()}.json`,createHash("sha256").update("x").digest("hex"),Buffer.from("x")]);
 const foreign=await snapshot(other);configure("cleanup",[id]);const s=continuousPlan()!.slots[0];const first=await cleanupContinuousExports(s,deadline());assert.equal(first.removed,100);const second=await cleanupContinuousExports(s,deadline());assert.equal(second.removed,5);
 assert.equal((await admin.query("SELECT count(*)::int AS n FROM private_export_chunks WHERE export_id=$1 AND artifact_name=$2",[job.id,job.artifact_name])).rows[0].n,1);assert.equal(await snapshot(other),foreign);
 const orphan=randomUUID();await assert.rejects(admin.query("INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body) VALUES($1,$2,0,1,$3,$4)",[orphan,`${orphan}.${randomUUID()}.json`,"f".repeat(64),Buffer.from("x")]));tests.push({test:"P09",status:"PASS"});
});
test("P10 original retired UUID cannot act on a newly registered same-email account",async()=>{
 const email=`recreated-${randomUUID()}@privacy.example.test`;const id=await seed(email);await confirmed(id);configure("deletion",[id]);assert.equal((await runContinuousSlot(continuousPlan()!.slots[0],deadline())).status,"COMPLETE");
 const newer=await seed(email),before=await snapshot(newer);assert.equal((await runContinuousSlot(continuousPlan()!.slots[0],deadline())).status,"IDLE");assert.equal(await snapshot(newer),before);tests.push({test:"P10",status:"PASS"});
});
test("P11 expiry units stop the actual coordinator timer/service and have a fixed UTC deadline",async()=>{
 const unit=await readFile("deploy/continuous-scheduler/cat-letters-background-expiry.service","utf8"),timer=await readFile("deploy/continuous-scheduler/cat-letters-background-expiry.timer","utf8");assert.match(unit,/User=root/);assert.match(unit,/disable --now cat-letters-background.timer/);assert.match(unit,/stop cat-letters-background.service/);assert.match(timer,/2026-11-06 10:00:00 UTC/);assert.match(timer,/Persistent=true/);tests.push({test:"P11",status:"PASS",linuxSystemdActuallyExecuted:false});
});
