import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import pg from "pg";
import { pool, transaction } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { lockCloudCat } from "../../src/server/cloud-repository";
import { initializeCloudCalendar } from "../../src/server/cloud-calendar";
import {
  claimCloudJob,
  runCloudWorkerOnce,
  runClaimedCloudJob,
  type CloudJobClaim,
} from "../../src/server/cloud-worker";
import handler from "../../netlify/functions/e4-worker.mjs";
import { HttpError } from "../../src/server/errors";

const ledger = new pg.Pool({
  connectionString: process.env.E4_LEDGER_DATABASE_URL,
});
const secret = "a".repeat(64);
let selected: string, otherFixture: string, personalSentinel: string;
let otherClaim: CloudJobClaim;
const denied = (error: unknown) =>
  error instanceof HttpError && error.status === 503;
const invoke = (query = "kind=cloud", body?: object) =>
  handler(
    new Request(`https://local.invalid/.netlify/functions/e4-worker?${query}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}` },
      body: body === undefined ? undefined : JSON.stringify(body),
    }),
  );
async function seed(domain: string) {
  const accountId = randomUUID(),
    participantId = randomUUID(),
    catId = randomUUID();
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    accountId,
    `${accountId}@${domain}`,
  ]);
  await pool.query("INSERT INTO participants(id,status) VALUES($1,'ACTIVE')", [
    participantId,
  ]);
  await pool.query(
    "INSERT INTO cat_profiles(id,account_id,participant_id,appearance_id,name) VALUES($1,$2,$3,'cat-01','范围合成猫')",
    [catId, accountId, participantId],
  );
  await transaction(async (db) => {
    const cat = await lockCloudCat(db, accountId);
    // Synthetic fixture only: no natural-time or real-user observation claim.
    await initializeCloudCalendar(db, cat, Date.now() - 20 * 60_000);
  });
  return accountId;
}
async function snapshot(id: string) {
  const result = [];
  for (const [table, order] of [
    ["accounts", "id"],
    ["cat_profiles", "id"],
    ["cloud_jobs", "id"],
    ["cloud_calendars", "cat_id"],
    ["cloud_calendar_nodes", "id"],
    ["cloud_letters", "id"],
    ["cloud_state", "cat_id"],
  ])
    result.push(
      (
        await pool.query(
          `SELECT * FROM ${table} WHERE ${table === "accounts" ? "id" : "account_id"}=$1 ORDER BY ${order}`,
          [id],
        )
      ).rows,
    );
  return JSON.stringify(result);
}
async function expiredExhausted(id: string) {
  await pool.query(
    "UPDATE cloud_jobs SET status='LEASED',attempts=5,lease_token=$2,lease_until=clock_timestamp()-interval '1 minute',next_run_at=clock_timestamp()-interval '1 minute' WHERE account_id=$1",
    [id, randomUUID()],
  );
}
before(async () => {
  for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
    const url = new URL(process.env[key]!);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(url.pathname, "/catletters_scoped_worker_test");
  }
  assert.equal(process.env.E4_SCHEDULED_RUN, "true");
  selected = await seed("example.invalid");
  otherFixture = await seed("example.invalid");
  // This is a disposable non-fixture-domain sentinel, never a personal account.
  personalSentinel = await seed("ordinary.example.test");
  process.env.E4_MANUAL_WORKER_ENABLED = "true";
  process.env.E4_MANUAL_WORKER_TOKEN = secret;
  process.env.E4_TEST_WORKER_ACCOUNT_ID = selected;
  await expiredExhausted(otherFixture);
  await expiredExhausted(personalSentinel);
});
after(async () => {
  await closeLifecycleProvider();
  await Promise.all([pool.end(), ledger.end()]);
});

test("W01 actual manual handler delivers only deployment fixture; outside exhausted jobs remain byte-identical", async () => {
  const outside = await Promise.all(
    [otherFixture, personalSentinel].map(snapshot),
  );
  const response = await invoke();
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.attempted, 1);
  assert.deepEqual(result.statuses, ["SETTLED"]);
  assert.equal(
    (
      await pool.query(
        "SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",
        [selected],
      )
    ).rows[0].n,
    1,
  );
  assert.deepEqual(
    await Promise.all([otherFixture, personalSentinel].map(snapshot)),
    outside,
  );
});

test("W02 exhausted-job update is limited to the selected fixture as well as normal claims", async () => {
  const outside = await Promise.all([selected, personalSentinel].map(snapshot));
  const result = await runCloudWorkerOnce(Date.now() + 25_000, {
    accountId: otherFixture,
  });
  assert.equal(result.status, "IDLE");
  assert.equal(
    (
      await pool.query("SELECT status FROM cloud_jobs WHERE account_id=$1", [
        otherFixture,
      ])
    ).rows[0].status,
    "FAILED",
  );
  assert.deepEqual(
    await Promise.all([selected, personalSentinel].map(snapshot)),
    outside,
  );
  await pool.query(
    "UPDATE cloud_jobs SET status='READY',attempts=0,lease_token=NULL,lease_until=NULL,next_run_at=clock_timestamp()-interval '1 minute',last_error=NULL WHERE account_id=$1",
    [otherFixture],
  );
});

test("W03 deployment ID must name an ACTIVE example.invalid account; wrong domain or absent ID makes no business change", async () => {
  const beforeState = await Promise.all(
    [selected, otherFixture, personalSentinel].map(snapshot),
  );
  try {
    for (const id of [personalSentinel, randomUUID()]) {
      process.env.E4_TEST_WORKER_ACCOUNT_ID = id;
      const result = await invoke();
      assert.equal(result.status, 503);
      assert.deepEqual(await result.json(), {
        kind: "cloud",
        status: "UNKNOWN",
        error: "check_durable_state",
      });
    }
  } finally {
    process.env.E4_TEST_WORKER_ACCOUNT_ID = selected;
  }
  assert.deepEqual(
    await Promise.all([selected, otherFixture, personalSentinel].map(snapshot)),
    beforeState,
  );
});

test("W04 request account/job/all/body overrides and privacy/cleanup cannot run work", async () => {
  const beforeState = await Promise.all(
    [selected, otherFixture, personalSentinel].map(snapshot),
  );
  for (const query of [
    `kind=cloud&accountId=${otherFixture}`,
    `kind=cloud&jobId=${randomUUID()}`,
    "kind=cloud&all=true",
  ])
    assert.equal((await invoke(query)).status, 400);
  assert.equal(
    (await invoke("kind=cloud", { accountId: otherFixture })).status,
    400,
  );
  for (const kind of ["privacy", "cleanup"])
    assert.equal((await invoke(`kind=${kind}`)).status, 403);
  assert.deepEqual(
    await Promise.all([selected, otherFixture, personalSentinel].map(snapshot)),
    beforeState,
  );
});

test("W05 an out-of-scope claimed lease is rejected before execution", async () => {
  otherClaim = (await claimCloudJob(Date.now() + 25_000, {
    accountId: otherFixture,
  }))!;
  assert.equal(otherClaim.accountId, otherFixture);
  const beforeState = await Promise.all(
    [selected, otherFixture, personalSentinel].map(snapshot),
  );
  await assert.rejects(
    runClaimedCloudJob(otherClaim, Date.now() + 25_000, {
      accountId: selected,
    }),
    denied,
  );
  assert.deepEqual(
    await Promise.all([selected, otherFixture, personalSentinel].map(snapshot)),
    beforeState,
  );
});

test("W06 domain change after claim refuses cat reads and failure writes; restoring fixture can complete the original lease once", async () => {
  await pool.query("UPDATE accounts SET email_normalized=$2 WHERE id=$1", [
    otherFixture,
    `${otherFixture}@changed.example.test`,
  ]);
  const beforeState = await Promise.all(
    [selected, otherFixture, personalSentinel].map(snapshot),
  );
  const original = pg.Client.prototype.query;
  const statements: string[] = [];
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    statements.push(typeof args[0] === "string" ? args[0] : args[0].text);
    return (original as Function).apply(this, args);
  } as typeof original;
  try {
    await assert.rejects(
      runClaimedCloudJob(otherClaim, Date.now() + 25_000, {
        accountId: otherFixture,
      }),
      denied,
    );
  } finally {
    pg.Client.prototype.query = original;
  }
  assert.equal(
    statements.some((q) =>
      /FROM cat_profiles|FROM participants|INSERT INTO cloud_state/.test(q),
    ),
    false,
  );
  assert.deepEqual(
    await Promise.all([selected, otherFixture, personalSentinel].map(snapshot)),
    beforeState,
  );
  await pool.query("UPDATE accounts SET email_normalized=$2 WHERE id=$1", [
    otherFixture,
    `${otherFixture}@example.invalid`,
  ]);
  assert.equal(
    (
      await runClaimedCloudJob(otherClaim, Date.now() + 25_000, {
        accountId: otherFixture,
      })
    ).status,
    "SETTLED",
  );
  assert.equal(
    (
      await pool.query(
        "SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1",
        [otherFixture],
      )
    ).rows[0].n,
    1,
  );
});

test("W07 closed independent restore gate remains 503 and leaves fixture and sentinels unchanged", async () => {
  const beforeState = await Promise.all(
    [selected, otherFixture, personalSentinel].map(snapshot),
  );
  await ledger.query(
    "UPDATE restore_gate SET status='CLOSED' WHERE singleton=true",
  );
  try {
    assert.equal((await invoke()).status, 503);
  } finally {
    await ledger.query(
      "UPDATE restore_gate SET status='READY' WHERE singleton=true",
    );
  }
  assert.deepEqual(
    await Promise.all([selected, otherFixture, personalSentinel].map(snapshot)),
    beforeState,
  );
});
