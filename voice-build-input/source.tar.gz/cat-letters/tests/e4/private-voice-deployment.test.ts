import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { configuredAccountCookies } from "../../src/server/account-cookie-config";
import { validatePrivateVoiceBase } from "../../src/server/private-voice-entry-config";
import { validatePrivateMount, privateVoiceCgroupPath, validatePrivateMemory, validateClosedProxyGate, validatePrivateProxyStage, privateVoiceMountAvailability, validatePrivateVoiceFreeCapacity, enforcePrivateVoiceLinux } from "../../scripts/private-voice-linux-guard";
import { privateVoiceStartupAction, privateVoiceStartupEnvironment, privateVoiceStartupRecovery } from "../../scripts/private-voice-startup";

const base = {
  APP_MODE: "INTERNAL", SAFETY_ADAPTER: "synthetic-v1", APP_ORIGIN: "https://cat-test.zyrobbie.site:8443",
  ACCOUNT_COOKIE_NAME: "cat_voice_test_session", DELETION_COOKIE_NAME: "cat_voice_test_deletion",
  COOKIE_SECURE: "true", NETLIFY: "false", E4_PRIVATE_ENTRY_STATE: "closed", OTP_ADAPTER: "disabled",
  DOTENV_CONFIG_PATH: "/dev/null", E4_SCHEDULED_RUN: "true",
  DATABASE_URL: "postgresql://cat_letters_app:synthetic-local-only-password@127.0.0.1:55441/cat_voice_business",
  E4_LEDGER_DATABASE_URL: "postgresql://cat_letters_ledger:synthetic-local-only-password@127.0.0.1:55442/cat_voice_ledger",
  OTP_HASH_SECRET: "synthetic-private-otp-secret-0123456789",
  E4_LEDGER_SECRET: "synthetic-private-ledger-secret-0123456789",
  E4_LIFECYCLE_ADAPTER: "postgres-v1", E4_LIFECYCLE_BOOTSTRAP: "false", E4_LIFECYCLE_RECOVERY: "false",
  E4_VOICE_ENABLED: "false", E4_VOICE_MODE: "disabled", E4_VOICE_ACCOUNT_IDS: "[]", E4_VOICE_CLEANUP_ENABLED: "false",
  E4_VOICE_STORAGE: "tmpfs-private-v1", E4_VOICE_PAYLOAD_DIRECTORY: "/run/cat-voice-private/payload",
  E4_VOICE_PROBE_DIRECTORY: "/run/cat-voice-private/probe",
};
const mount = "234 30 0:100 / /run/cat-voice-private rw,nosuid,nodev,noexec,relatime - tmpfs tmpfs rw,size=131072k,nr_inodes=4096,mode=700,uid=991,gid=991,noswap";

test("D01 existing cookie defaults remain unchanged and invalid/colliding names fail closed", () => {
  assert.deepEqual(configuredAccountCookies({}), { account: "cat_account_session", deletion: "cat_deletion_receipt" });
  assert.deepEqual(configuredAccountCookies(base), { account: "cat_voice_test_session", deletion: "cat_voice_test_deletion" });
  for (const name of ["", "a; Path=/", "a b", "中文", "cat_admin", "cat_session", "__Host-test", "a".repeat(65)])
    assert.throws(() => configuredAccountCookies({ ACCOUNT_COOKIE_NAME: name }));
  assert.throws(() => configuredAccountCookies({ ACCOUNT_COOKIE_NAME: "same", DELETION_COOKIE_NAME: "same" }));
  assert.throws(() => configuredAccountCookies({ ACCOUNT_COOKIE_NAME: "cat_deletion_receipt", DELETION_COOKIE_NAME: "other" }));
});

test("D02 closed base rejects wrong origin, old cookie names, hosted DB and accidental enabling", () => {
  assert.equal(validatePrivateVoiceBase(base).entry, "closed");
  for (const [key, value] of Object.entries({
    APP_ORIGIN: "https://cat-test.zyrobbie.site", ACCOUNT_COOKIE_NAME: "cat_account_session",
    COOKIE_SECURE: "false", NETLIFY: "true", OTP_ADAPTER: "synthetic-v1", E4_PRIVATE_ENTRY_STATE: "open",
    E4_VOICE_ENABLED: "true", E4_VOICE_MODE: "tencent-sentence-v1", E4_LIFECYCLE_BOOTSTRAP: "true",
    DATABASE_URL: base.DATABASE_URL.replace("127.0.0.1", "remote.example.invalid"),
    E4_LEDGER_DATABASE_URL: base.E4_LEDGER_DATABASE_URL.replace("55442", "55441"),
    OTP_HASH_SECRET: base.E4_LEDGER_SECRET,
  })) assert.throws(() => validatePrivateVoiceBase({ ...base, [key]: value }), key);
  for (const key of ["E4_VOICE_TENCENT_TOKEN", "E4_SYNTHETIC_MAILBOX_DIR", "E4_VOICE_REVIEW", "E4_LOCAL_ACCOUNT_CLIENT_DIRECTORY"])
    assert.throws(() => validatePrivateVoiceBase({ ...base, [key]: "" }), key);
});

test("D03 private mount rejects ordinary dirs, parent tmpfs, bind aliases and swap-enabled mount", () => {
  assert.doesNotThrow(() => validatePrivateMount(mount, "/run/cat-voice-private", 128 * 1024 * 1024));
  for (const value of ["", mount.replace("/run/cat-voice-private", "/run"), mount.replace("0:100 / ", "0:100 /alias "),
    mount.replace(",noswap", ""), mount.replace("- tmpfs ", "- ext4 "), mount.replace(",noexec", ""),
    mount.replace("size=131072k", "size=262144k"), mount.replace("size=131072k", "size=128M"), mount + "\n" + mount])
    assert.throws(() => validatePrivateMount(value, "/run/cat-voice-private", 128 * 1024 * 1024));
});

test("D04 only exact dedicated cgroup and finite bounded memory are accepted", () => {
  assert.equal(privateVoiceCgroupPath("0::/catvoice.slice/cat-voice-app.service\n"), "/sys/fs/cgroup/catvoice.slice/cat-voice-app.service");
  for (const value of ["0::/system.slice/cat-letters.service", "0::/catvoice.slice/../cat-voice-app.service",
    "0::/catvoice.slice/cat-voice-app.service/child", "1:memory:/catvoice.slice/cat-voice-app.service", "0::/catvoice.slice/cat-voice-app.service\n0::/other"])
    assert.throws(() => privateVoiceCgroupPath(value));
  assert.doesNotThrow(() => validatePrivateMemory("402653184\n", 384 * 1024 * 1024));
  for (const value of ["max", "0", "-1", "402653185", "123oops", "1e6"])
    assert.throws(() => validatePrivateMemory(value, 384 * 1024 * 1024));
});

test("D05 closed gate must apply to the whole server and local non-Linux guard refuses execution", () => {
  validateClosedProxyGate("# closed\nreturn 503;\n");
  for (const value of ["", "return 200;", "location / {return 503;}", "return 503;\nreturn 200;"])
    assert.throws(() => validateClosedProxyGate(value));
  if (process.platform !== "linux") assert.throws(() => enforcePrivateVoiceLinux("app"));
});

test("D06 proxy config cookie expressions whitelist only independent names and reject duplicate ambiguity", () => {
  const source = readFileSync("deploy/private-voice/linux/nginx.conf", "utf8");
  const matcher = (name: string, header: string) => {
    const block = source.match(new RegExp(`map \\$http_cookie \\$${name} \\{([\\s\\S]*?)\\n    \\}`))?.[1];
    assert(block);
    for (const row of block.matchAll(/"~([^"]+)" (?:"([^"]+)"|(1));/g)) {
      const match = header.match(new RegExp(row[1]));
      if (match) return row[3] ?? row[2].replace(/\$([a-z_]+)/g, (_, key) => match.groups?.[key] ?? "");
    }
    return name === "catvoice_duplicate_cookie" ? "0" : "";
  };
  const token = "a".repeat(64), receipt = "12345678-1234-4234-8234-123456789abc." + "b".repeat(64);
  const old = `cat_account_session=${"c".repeat(64)}; cat_deletion_receipt=${receipt}; cat_admin=old`;
  assert.equal(matcher("catvoice_account", old), "");
  assert.equal(matcher("catvoice_deletion", old), "");
  const both = `${old}; cat_voice_test_session=${token}; cat_voice_test_deletion=${receipt}`;
  assert.equal(matcher("catvoice_account", both) + matcher("catvoice_deletion", both),
    `cat_voice_test_session=${token};cat_voice_test_deletion=${receipt};`);
  assert.equal(matcher("catvoice_duplicate_cookie", both), "0");
  assert.equal(matcher("catvoice_duplicate_cookie", both + `; cat_voice_test_session=${token}`), "1");
  assert.equal(matcher("catvoice_duplicate_cookie", both + `; cat_voice_test_deletion=${receipt}`), "1");
  assert.match(source, /proxy_set_header X-Forwarded-Port 8443;/);
  assert.match(source, /proxy_http_version 1\.1;/);
  assert.match(source, /proxy_request_buffering off;/);
  assert.match(source, /proxy_buffering off;/);
  assert.match(source, /location \/ \{ return 404; \}/);
});

test("D07 long-lived key examples omit TOKEN assignment and all new service units enforce no swap/core", () => {
  assert.doesNotMatch(readFileSync("deploy/private-voice/voice.env.example", "utf8"), /^E4_VOICE_TENCENT_TOKEN=/m);
  assert.doesNotMatch(readFileSync("deploy/private-voice/linux/base.env.example", "utf8"), /^E4_VOICE_TENCENT_TOKEN=/m);
  for (const role of ["app", "proxy", "business", "ledger", "cleanup"]) {
    const source = readFileSync(`deploy/private-voice/linux/cat-voice-${role}.service`, "utf8");
    assert.match(source, /^Slice=catvoice\.slice$/m);
    assert.match(source, /^MemorySwapMax=0$/m);
    assert.match(source, /^LimitCORE=0$/m);
    assert.match(source, new RegExp(`private-voice-linux-guard.ts ${role}$`, "m"));
  }
  for (const name of ["private-tmpfs.mount.in", "proxy-tmpfs.mount.in"]) {
    const source = readFileSync(`deploy/private-voice/linux/${name}`, "utf8");
    assert.match(source, /^DirectoryMode=0700$/m);
    assert.match(source, /^Options=.*mode=0700,uid=@[A-Z_]+@,gid=@[A-Z_]+@,noswap,nodev,nosuid,noexec$/m);
  }
});

test("D08 staged configuration supports cleanup before opening and never publicly uses synthetic OTP", () => {
  const prepared = { ...base, E4_PRIVATE_ENTRY_STATE: "prepared", E4_VOICE_CLEANUP_ENABLED: "true",
    E4_VOICE_ACCOUNT_IDS: '["12345678-1234-4234-8234-123456789abc"]' };
  assert.equal(validatePrivateVoiceBase(prepared, true).cleanup, true);
  assert.throws(() => validatePrivateVoiceBase(base, true));
  const open = { ...prepared, E4_PRIVATE_ENTRY_STATE: "private-open", E4_PRIVATE_ENTRY_REVIEWED: "true",
    E4_VOICE_LINUX_STORAGE_ACCEPTED: "true", OTP_ADAPTER: "resend-v1", RESEND_API_KEY: "re_synthetic_config_only",
    OTP_FROM: "Private Test <test@example.invalid>" };
  assert.equal(validatePrivateVoiceBase(open).entry, "private-open");
  for (const [key, value] of Object.entries({ E4_PRIVATE_ENTRY_REVIEWED: "false", E4_VOICE_LINUX_STORAGE_ACCEPTED: "false",
    OTP_ADAPTER: "synthetic-v1", RESEND_API_KEY: "", OTP_FROM: "not-an-email" }))
    assert.throws(() => validatePrivateVoiceBase({ ...open, [key]: value }));
  const voice = { ...open, E4_VOICE_ENABLED: "true", E4_VOICE_MODE: "tencent-sentence-v1",
    E4_VOICE_TENCENT_ASR_APPROVED: "true", E4_VOICE_TENCENT_FREE_ONLY: "true",
    E4_VOICE_TENCENT_SECRET_ID: "synthetic_config_only", E4_VOICE_TENCENT_SECRET_KEY: "synthetic_config_only",
    E4_VOICE_BACKUP_POLICY: "exclude-ephemeral-v1" };
  assert.equal(validatePrivateVoiceBase(voice).voice, "enabled");
  assert.throws(() => validatePrivateVoiceBase({ ...voice, E4_VOICE_CLEANUP_ENABLED: "false" }));
  assert.throws(() => validatePrivateVoiceBase({ ...voice, E4_PRIVATE_ENTRY_STATE: "prepared" }));
  // Maintenance loads no mail/provider secret file, while still requiring scope and cleanup.
  assert.equal(validatePrivateVoiceBase({ ...voice, RESEND_API_KEY: undefined, OTP_FROM: undefined,
    E4_VOICE_TENCENT_SECRET_ID: undefined, E4_VOICE_TENCENT_SECRET_KEY: undefined }, true).cleanup, true);
});

test("D09 independent proxy stage and both gates must agree", () => {
  const closed = '{"entry":"closed","voice":"disabled"}';
  assert.equal(validatePrivateProxyStage(closed, "return 503;", "return 503;").entry, "closed");
  assert.equal(validatePrivateProxyStage('{"entry":"prepared","voice":"disabled"}', "return 503;", "return 503;").entry, "prepared");
  const open = '{"entry":"private-open","voice":"enabled"}';
  assert.equal(validatePrivateProxyStage(open, "# PRIVATE_E4_OPEN\n", "proxy_pass http://catvoice_app;").voice, "enabled");
  for (const [state, entry, voice] of [[closed, "# PRIVATE_E4_OPEN", "return 503;"],
    ['{"entry":"closed","voice":"enabled"}', "return 503;", "proxy_pass http://catvoice_app;"],
    [open, "# PRIVATE_E4_OPEN", "return 503;"], [open, "", "proxy_pass http://catvoice_app;"],
    ['{"entry":"private-open","voice":"enabled","extra":true}', "# PRIVATE_E4_OPEN", "proxy_pass http://catvoice_app;"]])
    assert.throws(() => validatePrivateProxyStage(state, entry, voice));
});

test("D10 startup recovers before listening and maintenance child receives no supplier/debug secrets", () => {
  assert.equal(privateVoiceStartupAction(base), "skip");
  const prepared = { ...base, E4_PRIVATE_ENTRY_STATE: "prepared", E4_VOICE_CLEANUP_ENABLED: "true",
    E4_VOICE_ACCOUNT_IDS: '["12345678-1234-4234-8234-123456789abc"]' };
  assert.equal(privateVoiceStartupAction(prepared), "cleanup");
  assert.throws(() => privateVoiceStartupAction({ ...prepared, E4_VOICE_CLEANUP_ENABLED: "false" }));
  const environment = privateVoiceStartupEnvironment({ ...prepared, RESEND_API_KEY: "synthetic-private-mail",
    E4_VOICE_TENCENT_SECRET_ID: "synthetic-private-id", E4_VOICE_TENCENT_SECRET_KEY: "synthetic-private-key",
    NODE_OPTIONS: "--report-on-fatalerror", NODE_PATH: "/untrusted", DOTENV_CONFIG_PATH: "/untrusted/.env", E4_VOICE_ENABLED: "true" });
  for (const key of ["RESEND_API_KEY", "E4_VOICE_TENCENT_SECRET_ID", "E4_VOICE_TENCENT_SECRET_KEY", "NODE_OPTIONS", "NODE_PATH"])
    assert.equal(environment[key], undefined);
  assert.equal(environment.DOTENV_CONFIG_PATH, "/dev/null");
  assert.equal(environment.E4_VOICE_ENABLED, "false");
  assert.equal(environment.DATABASE_URL, base.DATABASE_URL);
  const unit = readFileSync("deploy/private-voice/linux/cat-voice-app.service", "utf8");
  assert(unit.indexOf("private-voice-startup.ts") < unit.indexOf("ExecStart="));
});

test("D11 only app mount failures degrade; unsafe config/cgroup/core policy remains outside the downgrade", async () => {
  assert.equal(privateVoiceMountAvailability("app", () => { throw new Error("synthetic mount failure"); }), "unavailable");
  for (const role of ["proxy", "cleanup"] as const)
    assert.throws(() => privateVoiceMountAvailability(role, () => { throw new Error("synthetic mount failure"); }));
  assert.equal(privateVoiceMountAvailability("app", () => {}), "available");
  const guarded = (config: typeof base, cgroup: string, memory: string) => {
    validatePrivateVoiceBase(config);
    privateVoiceCgroupPath(cgroup);
    validatePrivateMemory(memory, 384 * 1024 * 1024);
    return privateVoiceMountAvailability("app", () => { throw new Error("synthetic mount failure"); });
  };
  assert.equal(guarded(base, "0::/catvoice.slice/cat-voice-app.service", "402653184"), "unavailable");
  assert.throws(() => guarded({ ...base, COOKIE_SECURE: "false" }, "0::/catvoice.slice/cat-voice-app.service", "402653184"));
  assert.throws(() => guarded(base, "0::/system.slice/other.service", "402653184"));
  assert.throws(() => guarded(base, "0::/catvoice.slice/cat-voice-app.service", "max"));
  assert.equal(await privateVoiceStartupRecovery(async () => 0), "complete");
  assert.equal(await privateVoiceStartupRecovery(async () => 1), "pending");
  assert.equal(await privateVoiceStartupRecovery(async () => { throw new Error(); }), "pending");
  const source = readFileSync("scripts/private-voice-linux-guard.ts", "utf8");
  assert(source.indexOf("Max core file size") < source.indexOf("storage = privateVoiceMountAvailability"));
  const unit = readFileSync("deploy/private-voice/linux/cat-voice-app.service", "utf8");
  assert.match(unit, /^Wants=run-cat\\x2dvoice\\x2dprivate.mount$/m);
  assert.doesNotMatch(unit, /^BindsTo=/m);
});

test("D12 cleanup can reclaim a full mount while unsafe mounts still fail and app/proxy capacity policy remains", () => {
  const verify = (role: "app" | "proxy" | "cleanup", blocks: number, inodes: number, info = mount) =>
    privateVoiceMountAvailability(role, () => {
      validatePrivateMount(info, "/run/cat-voice-private", 128 * 1024 * 1024);
      validatePrivateVoiceFreeCapacity(role, blocks, inodes);
    });
  for (const [blocks, inodes] of [[0, 1], [1, 0], [0, 0]]) {
    assert.equal(verify("cleanup", blocks, inodes), "available");
    assert.equal(verify("app", blocks, inodes), "unavailable");
    assert.throws(() => verify("proxy", blocks, inodes));
    assert.throws(() => verify("cleanup", blocks, inodes, mount.replace(",noswap", "")));
  }
  for (const role of ["app", "proxy", "cleanup"] as const)
    assert.equal(verify(role, 1, 1), "available");
});
