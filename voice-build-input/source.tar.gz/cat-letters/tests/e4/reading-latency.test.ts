import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { performance } from "node:perf_hooks";
import pg from "pg";
import { NextRequest } from "next/server";
import { pool } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { accountIdentity } from "../../src/server/account-auth";
import { adoptCat } from "../../src/server/account-service";
import { digest } from "../../src/server/auth";
import { LIGHT_DEMAND } from "../../src/content/supplemental";
import { GET, POST } from "../../src/app/api/e4/v1/[...path]/route";
import {
  sendCloudResponse,
  editCloudResponse,
  deleteCloudResponse,
} from "../../src/server/cloud-responses";
import { setTimeout as delay } from "node:timers/promises";

const baseline = process.env.READING_PHASE === "baseline";
const ledger = new pg.Pool({
  connectionString: process.env.E4_LEDGER_DATABASE_URL,
});
const originalQuery = pg.Client.prototype.query;
const originalConnect = pg.Pool.prototype.connect;
type Trace = {
  label: string;
  elapsedMs: number;
  calls: number;
  segments: Record<string, { calls: number; elapsedMs: number }>;
  poolAcquireMs: number;
};
const traces: Trace[] = [];
let active: {
  events: { segment: string; elapsedMs: number }[];
  poolAcquireMs: number;
} | null = null;
let accountId: string,
  catId: string,
  raw: string,
  raw2: string,
  foreignId: string,
  foreignRaw: string;
let historyId: string, unreadId: string;
const acquired: Record<string, number> = {};
let disconnectDuringDetail = false;
function segment(sql: string) {
  if (sql.includes("FROM ledger_identity")) return "ledgerSnapshot";
  if (sql.includes("FROM lifecycle_control")) return "businessWatermark";
  if (sql.includes("FROM account_sessions")) return "session";
  if (/cloud_calendar|cloud_jobs|clock_timestamp/.test(sql)) return "calendar";
  if (/FOR UPDATE|INSERT INTO cloud_state/.test(sql))
    return "ownerLocksOrWrite";
  if (/FROM cloud_letters|FROM cloud_responses|FROM cloud_trips/.test(sql))
    return "projectionOrDetail";
  return "transactionLockOrOther";
}
async function measure<T>(label: string, work: () => Promise<T>) {
  const capture = {
    events: [] as { segment: string; elapsedMs: number }[],
    poolAcquireMs: 0,
  };
  active = capture;
  const started = performance.now();
  try {
    return await work();
  } finally {
    active = null;
    const segments: Trace["segments"] = {};
    for (const event of capture.events) {
      const entry = (segments[event.segment] ??= { calls: 0, elapsedMs: 0 });
      entry.calls++;
      entry.elapsedMs += event.elapsedMs;
    }
    traces.push({
      label,
      elapsedMs: performance.now() - started,
      calls: capture.events.length,
      segments,
      poolAcquireMs: capture.poolAcquireMs,
    });
  }
}
function req(path: string, body?: object, token = raw, expected = accountId) {
  return new NextRequest(`${process.env.APP_ORIGIN}/api/e4/v1/${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      Origin: process.env.APP_ORIGIN!,
      Cookie: `cat_account_session=${token}`,
      "X-Catletters-Account": expected,
      "Content-Type": "application/json",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
async function fixture() {
  const id = randomUUID(),
    token = randomBytes(32).toString("hex");
  await pool.query("INSERT INTO accounts(id,email_normalized) VALUES($1,$2)", [
    id,
    `${id}@example.invalid`,
  ]);
  await pool.query(
    "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '7 days')",
    [digest(token), id],
  );
  const adopted = await adoptCat(id, {
    name: "阅读合成猫",
    appearanceId: "cat-02",
    key: randomUUID(),
  });
  return { id, token, catId: adopted.cat.id as string };
}
async function seedLetter(
  read = false,
  owner = { id: accountId, catId },
  title: string = LIGHT_DEMAND.title,
) {
  const id = `reading /?%:${randomUUID()}`;
  await pool.query(
    "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,origin,read_at) VALUES($1,$2,$3,'DEMAND',$4,'LEGACY',CASE WHEN $5 THEN now()-interval '1 minute' ELSE NULL END)",
    [
      id,
      owner.catId,
      owner.id,
      {
        title,
        body: LIGHT_DEMAND.body,
        catName: "阅读合成猫",
      },
      read,
    ],
  );
  return id;
}
before(async () => {
  for (const key of ["DATABASE_URL", "E4_LEDGER_DATABASE_URL"]) {
    const url = new URL(process.env[key]!);
    assert.equal(url.hostname, "127.0.0.1");
    assert.equal(url.pathname, "/catletters_reading_latency_test");
  }
  const main = await fixture(),
    other = await fixture();
  accountId = main.id;
  catId = main.catId;
  raw = main.token;
  foreignId = other.id;
  foreignRaw = other.token;
  raw2 = randomBytes(32).toString("hex");
  await pool.query(
    "INSERT INTO account_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '7 days')",
    [digest(raw2), accountId],
  );
  historyId = await seedLetter(true);
  unreadId = await seedLetter();
  pg.Client.prototype.query = function (this: pg.Client, ...args: any[]) {
    const capture = active,
      started = performance.now();
    const sql = typeof args[0] === "string" ? args[0] : args[0].text;
    if (disconnectDuringDetail && sql.includes("AS state_revision,l.*")) {
      disconnectDuringDetail = false;
      return ledger
        .query("SELECT pg_terminate_backend($1)", [acquired.ledger])
        .then(() => delay(25))
        .then(() => (originalQuery as Function).apply(this, args));
    }
    const result = (originalQuery as Function).apply(this, args);
    if (!capture || !result?.then) return result;
    return result.finally(() =>
      capture.events.push({
        segment: segment(sql),
        elapsedMs: performance.now() - started,
      }),
    );
  } as typeof originalQuery;
  pg.Pool.prototype.connect = function (this: pg.Pool, ...args: any[]) {
    const capture = active,
      started = performance.now();
    const result = (originalConnect as Function).apply(this, args);
    if (!result?.then) return result;
    return result.then((client: pg.PoolClient) => {
      const kind =
        Number(
          this.options.port ?? new URL(this.options.connectionString!).port,
        ) === Number(new URL(process.env.DATABASE_URL!).port)
          ? "business"
          : "ledger";
      acquired[kind] = (
        client as pg.PoolClient & { processID: number }
      ).processID;
      if (capture) capture.poolAcquireMs += performance.now() - started;
      return client;
    });
  } as typeof originalConnect;
});
after(async () => {
  pg.Client.prototype.query = originalQuery;
  pg.Pool.prototype.connect = originalConnect;
  await writeFile(
    join(process.env.E4_READING_EVIDENCE!, "query-timings.json"),
    JSON.stringify(
      {
        phase: process.env.READING_PHASE,
        timingScope: "real local PostgreSQL; not cloud timing",
        traces,
      },
      null,
      2,
    ) + "\n",
  );
  await closeLifecycleProvider();
  await Promise.all([pool.end(), ledger.end()]);
});
test("R00 actual guarded route round trips and local phase durations", async () => {
  await measure("session", () => accountIdentity(raw));
  const replies = await measure("legacy-three-requests", () =>
    Promise.all(
      ["state", "letters", "responses"].map((path) => GET(req(path))),
    ),
  );
  assert.ok(replies.every((reply) => reply.status === 200));
  await measure("legacy-state", () => GET(req("state")));
  await measure("legacy-letters", () => GET(req("letters")));
  await measure("legacy-responses", () => GET(req("responses")));
  if (!baseline) {
    const view = await measure("atomic-view", () => GET(req("view")));
    assert.equal(view.status, 200);
    const data = await view.json();
    assert.equal(data.world.stateRevision, data.mailbox.stateRevision);
    assert.equal(data.world.stateRevision, data.sent.stateRevision);
    assert.equal(JSON.stringify(data).includes(LIGHT_DEMAND.body), false);
  }
  const detail = await measure("history-detail", () =>
    GET(req(`letters/${encodeURIComponent(historyId)}/detail`)),
  );
  assert.equal(detail.status, 200);
  const history = await measure("history-via-post-read", () =>
    POST(req(`letters/${encodeURIComponent(historyId)}/read`, {})),
  );
  assert.equal(history.status, 200);
  assert.equal((await history.json()).firstRead, false);
  const first = await measure("first-unread-read", () =>
    POST(req(`letters/${encodeURIComponent(unreadId)}/read`, {})),
  );
  assert.equal(first.status, 200);
  assert.equal((await first.json()).firstRead, true);
  if (!baseline) {
    for (const [label, calls] of [
      ["atomic-view", 25],
      ["history-detail", 12],
      ["first-unread-read", 27],
    ] as const)
      assert.equal(traces.find((trace) => trace.label === label)?.calls, calls);
  }
  console.log(
    JSON.stringify(
      traces.map(({ label, calls, elapsedMs }) => ({
        label,
        calls,
        localElapsedMs: Number(elapsedMs.toFixed(2)),
      })),
    ),
  );
});

const optimized = { skip: baseline };
const letterPath = (id: string, action: string) =>
  `letters/${encodeURIComponent(id)}/${action}`;
async function one(sql: string, values: unknown[] = []) {
  return (await pool.query(sql, values)).rows[0];
}
async function persisted(id: string) {
  return one(
    "SELECT read_at FROM cloud_letters WHERE account_id=$1 AND id=$2",
    [accountId, id],
  );
}
async function stateSnapshot() {
  return (
    await one(
      `SELECT jsonb_build_object(
    'state',(SELECT to_jsonb(s) FROM cloud_state s WHERE account_id=$1),
    'calendar',(SELECT to_jsonb(c) FROM cloud_calendars c WHERE account_id=$1),
    'job',(SELECT to_jsonb(j) FROM cloud_jobs j WHERE account_id=$1),
    'nodes',(SELECT jsonb_agg(to_jsonb(n) ORDER BY node_order) FROM cloud_calendar_nodes n WHERE account_id=$1)) AS value`,
      [accountId],
    )
  ).value;
}
async function errorOnly(response: Response, status: number) {
  assert.equal(response.status, status);
  assert.deepEqual(Object.keys(await response.json()), ["error"]);
}

test(
  "R01 atomic view is private and context/ownership checks precede business changes",
  optimized,
  async () => {
    const id = await seedLetter();
    const before = await stateSnapshot();
    await errorOnly(await GET(req("view", undefined, raw, foreignId)), 401);
    assert.deepEqual(await stateSnapshot(), before);
    const response = await GET(req("view"));
    assert.equal(response.headers.get("cache-control"), "no-store");
    const data = await response.json();
    assert.equal(data.world.stateRevision, data.mailbox.stateRevision);
    assert.equal(data.world.stateRevision, data.sent.stateRevision);
    assert.equal(data.world.unread.id, id);
    assert.equal(
      /"(?:body|snapshot|image|illustration|contentId)"/.test(
        JSON.stringify(data),
      ),
      false,
    );
    assert.equal(
      data.mailbox.letters.find((l: { id: string }) => l.id === id).title,
      "有一封来信，还没打开",
    );
    await errorOnly(await GET(req(letterPath(id, "detail"))), 409);
    await errorOnly(
      await GET(
        req(letterPath(historyId, "detail"), undefined, foreignRaw, foreignId),
      ),
      404,
    );
    await errorOnly(
      await POST(req(letterPath(id, "read"), {}, foreignRaw, foreignId)),
      404,
    );
    assert.equal((await persisted(id)).read_at, null);
    await POST(req(letterPath(id, "read"), {}));
  },
);

test(
  "R02 two sessions commit exactly one first read and the same full result",
  optimized,
  async () => {
    const id = await seedLetter();
    const revision = (
      await one("SELECT revision FROM cloud_state WHERE account_id=$1", [
        accountId,
      ])
    ).revision;
    const results = await Promise.all(
      [raw, raw2].map(async (token) => {
        const response = await POST(req(letterPath(id, "read"), {}, token));
        assert.equal(response.status, 200);
        return response.json();
      }),
    );
    assert.equal(results.filter((result) => result.firstRead).length, 1);
    assert.equal(results[0].letter.readAt, results[1].letter.readAt);
    for (const result of results) {
      assert.equal(result.letter.snapshot.body, LIGHT_DEMAND.body);
      assert.equal(result.stateRevision, Number(revision) + 1);
    }
    assert.equal(
      (await persisted(id)).read_at.toISOString(),
      results[0].letter.readAt,
    );
  },
);

test(
  "R03 read failure rolls back settlement; success settles while the unread slot is occupied",
  optimized,
  async () => {
    const id = await seedLetter();
    const node = await one(
      "SELECT id,planned_at FROM cloud_calendar_nodes WHERE account_id=$1 AND kind='DEMAND' AND result_outcome IS NULL ORDER BY planned_at LIMIT 1",
      [accountId],
    );
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=GREATEST(0,ceil(extract(epoch FROM ($2::timestamptz-clock_timestamp()))*1000)::bigint)+1000 WHERE account_id=$1",
      [accountId, node.planned_at],
    );
    const before = await stateSnapshot();
    await pool.query(`CREATE FUNCTION synthetic_read_failure() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN IF OLD.read_at IS NULL AND NEW.read_at IS NOT NULL THEN RAISE EXCEPTION 'synthetic rollback'; END IF; RETURN NEW; END $$;
    CREATE TRIGGER synthetic_read_failure BEFORE UPDATE ON cloud_letters FOR EACH ROW EXECUTE FUNCTION synthetic_read_failure()`);
    try {
      await errorOnly(await POST(req(letterPath(id, "read"), {})), 503);
      assert.equal((await persisted(id)).read_at, null);
      assert.deepEqual(await stateSnapshot(), before);
    } finally {
      await pool.query(
        "DROP TRIGGER synthetic_read_failure ON cloud_letters; DROP FUNCTION synthetic_read_failure()",
      );
    }
    const response = await POST(req(letterPath(id, "read"), {}));
    assert.equal(response.status, 200);
    assert.equal((await response.json()).firstRead, true);
    const settled = await one(
      "SELECT result_outcome,result_reason,letter_id FROM cloud_calendar_nodes WHERE account_id=$1 AND id=$2",
      [accountId, node.id],
    );
    assert.equal(settled.result_outcome, "SKIPPED");
    assert.match(settled.result_reason, /未读/);
    assert.equal(settled.letter_id, null);
    assert.equal(
      (
        await one(
          "SELECT count(*)::int AS n FROM cloud_letters WHERE account_id=$1 AND read_at IS NULL",
          [accountId],
        )
      ).n,
      0,
    );
  },
);

test(
  "R04 every request rechecks revoked/expired sessions and unavailable accounts",
  optimized,
  async () => {
    const id = await seedLetter();
    async function denied() {
      await errorOnly(await GET(req("view")), 401);
      await errorOnly(await GET(req(letterPath(historyId, "detail"))), 401);
      await errorOnly(await POST(req(letterPath(id, "read"), {})), 401);
      assert.equal((await persisted(id)).read_at, null);
    }
    await pool.query(
      "UPDATE account_sessions SET revoked_at=now() WHERE token_hash=$1",
      [digest(raw)],
    );
    await denied();
    await pool.query(
      "UPDATE account_sessions SET revoked_at=NULL,expires_at=now()-interval '1 second' WHERE token_hash=$1",
      [digest(raw)],
    );
    await denied();
    await pool.query(
      "UPDATE account_sessions SET expires_at=now()+interval '7 days' WHERE token_hash=$1",
      [digest(raw)],
    );
    await pool.query("UPDATE accounts SET status='DELETING' WHERE id=$1", [
      accountId,
    ]);
    try {
      await denied();
    } finally {
      await pool.query("UPDATE accounts SET status='ACTIVE' WHERE id=$1", [
        accountId,
      ]);
    }
    assert.equal((await GET(req("view"))).status, 200);
    await POST(req(letterPath(id, "read"), {}));
  },
);

test(
  "R05 closed restore gate, watermark mismatch and damaged ledger all fail closed",
  optimized,
  async () => {
    const id = await seedLetter();
    const before = await stateSnapshot();
    async function denied() {
      await errorOnly(await GET(req("view")), 503);
      await errorOnly(await GET(req(letterPath(historyId, "detail"))), 503);
      await errorOnly(await POST(req(letterPath(id, "read"), {})), 503);
      assert.equal((await persisted(id)).read_at, null);
      assert.deepEqual(await stateSnapshot(), before);
    }
    await ledger.query(
      "UPDATE restore_gate SET status='CLOSED' WHERE singleton=true",
    );
    try {
      await denied();
    } finally {
      await ledger.query(
        "UPDATE restore_gate SET status='READY' WHERE singleton=true",
      );
    }
    await pool.query(
      "UPDATE lifecycle_control SET ledger_hash='synthetic mismatch' WHERE singleton=true",
    );
    try {
      await denied();
    } finally {
      await pool.query(
        "UPDATE lifecycle_control SET ledger_hash='' WHERE singleton=true",
      );
    }
    await ledger.query(
      "UPDATE ledger_head SET hash='synthetic damaged head' WHERE singleton=true",
    );
    try {
      await denied();
    } finally {
      await ledger.query("UPDATE ledger_head SET hash='' WHERE singleton=true");
    }
    assert.equal((await GET(req(letterPath(historyId, "detail")))).status, 200);
    await POST(req(letterPath(id, "read"), {}));
  },
);

test(
  "R06 history reads neither settle due nodes nor consume another unread letter",
  optimized,
  async () => {
    const id = await seedLetter();
    const next = await one(
      "SELECT planned_at FROM cloud_calendar_nodes WHERE account_id=$1 AND result_outcome IS NULL ORDER BY planned_at LIMIT 1",
      [accountId],
    );
    await pool.query(
      "UPDATE cloud_calendars SET offset_ms=GREATEST(0,ceil(extract(epoch FROM ($2::timestamptz-clock_timestamp()))*1000)::bigint)+1000 WHERE account_id=$1",
      [accountId, next.planned_at],
    );
    const before = await stateSnapshot();
    const response = await GET(req(letterPath(historyId, "detail")));
    assert.equal(response.status, 200);
    assert.equal(
      (await response.json()).letter.snapshot.body,
      LIGHT_DEMAND.body,
    );
    assert.deepEqual(await stateSnapshot(), before);
    assert.equal((await persisted(id)).read_at, null);
    await POST(req(letterPath(id, "read"), {}));
  },
);

test(
  "R07 both HTTP pools reuse after 11 idle seconds; ledger disconnect fails closed and reconnects",
  optimized,
  async () => {
    assert.equal(pool.options.idleTimeoutMillis, 60000);
    assert.equal((await GET(req(letterPath(historyId, "detail")))).status, 200);
    const before = { ...acquired };
    assert.ok(before.business && before.ledger);
    await delay(11000);
    assert.equal((await GET(req(letterPath(historyId, "detail")))).status, 200);
    assert.deepEqual(acquired, before);
    const state = await stateSnapshot();
    disconnectDuringDetail = true;
    await errorOnly(await GET(req(letterPath(historyId, "detail"))), 503);
    assert.deepEqual(await stateSnapshot(), state);
    assert.equal((await GET(req(letterPath(historyId, "detail")))).status, 200);
    assert.notEqual(acquired.ledger, before.ledger);
  },
);

test(
  "R08 history detail reflects committed response corrections and deletion without stale text",
  optimized,
  async () => {
    const sent = await sendCloudResponse(accountId, historyId, {
      text: "累了可以先休息。",
      expectedResponseId: null,
      key: randomUUID(),
    });
    const first = await (
      await GET(req(letterPath(historyId, "detail")))
    ).json();
    assert.equal(first.letter.response.text, "累了可以先休息。");
    await editCloudResponse(accountId, sent.responseId!, {
      text: "休息好了再慢慢走。",
      expectedRevision: 1,
      key: randomUUID(),
    });
    const edited = await (
      await GET(req(letterPath(historyId, "detail")))
    ).json();
    assert.equal(edited.letter.response.revision, 2);
    assert.equal(edited.letter.response.text, "休息好了再慢慢走。");
    await deleteCloudResponse(accountId, sent.responseId!, {
      expectedRevision: 2,
      key: randomUUID(),
    });
    const deleted = await (
      await GET(req(letterPath(historyId, "detail")))
    ).json();
    assert.equal(deleted.letter.response, null);
    assert.equal(deleted.letter.responseStatus, "DELETED");
    assert.equal(JSON.stringify(deleted).includes("休息好了再慢慢走。"), false);
  },
);

test(
  "R09 rendered mobile and desktop: atomic home, committed unread POST, history GET",
  { skip: baseline || !process.env.E4_READING_HTTP_ORIGIN },
  async () => {
    // Browser plugin is unavailable in this session; use installed Playwright.
    // Fresh browser contexts and sessions belong only to the disposable local DBs.
    const { chromium, expect } = await import("@playwright/test");
    const browser = await chromium.launch({ headless: true });
    const origin = process.env.E4_READING_HTTP_ORIGIN!;
    const screenshots = join(process.env.E4_READING_EVIDENCE!, "screenshots");
    await mkdir(screenshots, { recursive: true });
    const evidence: unknown[] = [];
    try {
      for (const viewport of [
        { width: 390, height: 844 },
        { width: 1280, height: 800 },
      ]) {
        const owner = await fixture(),
          id = await seedLetter(false, owner);
        const context = await browser.newContext({ viewport });
        try {
          await context.addCookies([
            {
              name: "cat_account_session",
              value: owner.token,
              url: origin,
              httpOnly: true,
              sameSite: "Lax",
              secure: false,
            },
          ]);
          const page = await context.newPage();
          const requests: { path: string; method: string }[] = [],
            errors: string[] = [];
          page.on("request", (request) => {
            const path = new URL(request.url()).pathname;
            if (path.startsWith("/api/e4/v1/"))
              requests.push({ path, method: request.method() });
          });
          page.on("pageerror", (error) => errors.push(error.message));
          page.on("console", (message) => {
            if (message.type() !== "error") return;
            if (
              message.location().url.startsWith(`${origin}/api/e4/privacy/`) &&
              /status of 401/.test(message.text())
            )
              return;
            errors.push(message.text());
          });
          await page.goto(`${origin}/account-app/`);
          await expect(page.locator(".e3-home-page")).toBeVisible();
          await expect(page.locator("main")).not.toContainText(
            LIGHT_DEMAND.body,
          );
          assert.equal(
            requests.filter((request) => request.path === "/api/e4/v1/view")
              .length,
            1,
          );
          assert.equal(
            requests.some((request) =>
              /\/(state|letters|responses)$/.test(request.path),
            ),
            false,
          );
          assert.equal(
            (
              await one(
                "SELECT read_at FROM cloud_letters WHERE account_id=$1 AND id=$2",
                [owner.id, id],
              )
            ).read_at,
            null,
          );
          await page.screenshot({
            path: join(screenshots, `${viewport.width}-home.png`),
            fullPage: true,
          });
          const committed = page.waitForResponse(
            (response) =>
              response.url().endsWith(`${encodeURIComponent(id)}/read`) &&
              response.request().method() === "POST",
          );
          await page
            .getByRole("button", { name: "看看来信", exact: true })
            .click();
          assert.equal((await committed).status(), 200);
          await expect(page.locator(".e3-story")).toHaveText(LIGHT_DEMAND.body);
          assert.ok(
            (
              await one(
                "SELECT read_at FROM cloud_letters WHERE account_id=$1 AND id=$2",
                [owner.id, id],
              )
            ).read_at,
          );
          await page
            .getByRole("button", { name: "← 来信盒", exact: true })
            .click();
          const before = requests.length;
          const restored = page.waitForResponse(
            (response) =>
              response.url().endsWith(`${encodeURIComponent(id)}/detail`) &&
              response.request().method() === "GET",
          );
          await page
            .locator(".e3-inbox-page button")
            .filter({ hasText: LIGHT_DEMAND.title })
            .click();
          assert.equal((await restored).status(), 200);
          await expect(page.locator(".e3-story")).toHaveText(LIGHT_DEMAND.body);
          const opened = requests.slice(before);
          assert.equal(
            opened.filter(
              (request) =>
                request.path.endsWith("/detail") && request.method === "GET",
            ).length,
            1,
          );
          assert.equal(
            opened.some((request) => request.method === "POST"),
            false,
          );
          assert.equal(
            await page.evaluate(
              () => document.documentElement.scrollWidth <= innerWidth,
            ),
            true,
          );
          assert.deepEqual(errors, []);
          await page.screenshot({
            path: join(screenshots, `${viewport.width}-history.png`),
            fullPage: true,
          });
          evidence.push({
            viewport,
            initialViewRequests: 1,
            legacyProjectionRequests: 0,
            firstRead: "committed POST before display",
            history: "GET detail without POST",
            consoleErrors: 0,
            requests,
          });
        } finally {
          await context.close();
        }
      }
    } finally {
      await browser.close();
    }
    await writeFile(
      join(process.env.E4_READING_EVIDENCE!, "browser.json"),
      JSON.stringify(
        {
          scope:
            "real rendered browser -> loopback HTTP -> two local PostgreSQL clusters",
          actualEmailSent: false,
          cloudExecuted: false,
          cases: evidence,
        },
        null,
        2,
      ) + "\n",
    );
  },
);

test(
  "R10 delayed old read success/error/finally cannot take over navigation or clear a new read",
  { skip: baseline || !process.env.E4_READING_HTTP_ORIGIN },
  async () => {
    const { chromium, expect } = await import("@playwright/test");
    const browser = await chromium.launch({ headless: true });
    const origin = process.env.E4_READING_HTTP_ORIGIN!;
    const results: unknown[] = [];
    function gate() {
      let resolve!: () => void;
      const promise = new Promise<void>((done) => {
        resolve = done;
      });
      return { resolve, promise };
    }
    try {
      for (const outcome of ["success", "error"] as const) {
        const owner = await fixture(),
          unread = await seedLetter(false, owner),
          history = await seedLetter(true, owner, "合成历史来信");
        const context = await browser.newContext({
          viewport: { width: 390, height: 844 },
        });
        const oldHeld = gate(),
          oldRelease = gate(),
          oldDone = gate(),
          newHeld = gate(),
          newRelease = gate();
        try {
          await context.addCookies([
            {
              name: "cat_account_session",
              value: owner.token,
              url: origin,
              httpOnly: true,
              sameSite: "Lax",
              secure: false,
            },
          ]);
          const page = await context.newPage();
          await page.route(
            `**/letters/${encodeURIComponent(unread)}/read`,
            async (route) => {
              const response = await route.fetch();
              assert.equal(response.status(), 200);
              oldHeld.resolve();
              await oldRelease.promise;
              if (outcome === "success") await route.fulfill({ response });
              else
                await route.fulfill({
                  status: 503,
                  contentType: "application/json",
                  body: JSON.stringify({ error: "合成延迟错误" }),
                });
              oldDone.resolve();
            },
          );
          await page.route(
            `**/letters/${encodeURIComponent(history)}/detail`,
            async (route) => {
              const response = await route.fetch();
              assert.equal(response.status(), 200);
              newHeld.resolve();
              await newRelease.promise;
              await route.fulfill({ response });
            },
          );
          await page.goto(`${origin}/account-app/`);
          await expect(page.locator(".e3-home-page")).toBeVisible();
          await page
            .getByRole("button", { name: "看看来信", exact: true })
            .click();
          await oldHeld.promise;
          await expect(
            page.getByRole("status").filter({ hasText: "正在打开来信" }),
          ).toBeVisible();
          await expect(page.locator(".e3-home-page")).toBeVisible();
          await page
            .getByRole("navigation", { name: "主要导航" })
            .getByRole("button", { name: "来信盒", exact: true })
            .click();
          await expect(page.locator(".e3-inbox-page")).toBeVisible();
          await expect(
            page.getByRole("status").filter({ hasText: "正在打开来信" }),
          ).toHaveCount(0);
          await page
            .locator(".e3-inbox-page button")
            .filter({ hasText: "合成历史来信" })
            .click();
          await newHeld.promise;
          oldRelease.resolve();
          await oldDone.promise;
          // Await a browser task after the old fetch resolves, then inspect the current page.
          await page.evaluate(
            () => new Promise<void>((done) => setTimeout(done, 50)),
          );
          await expect(page.locator(".e3-inbox-page")).toBeVisible();
          await expect(
            page.getByRole("status").filter({ hasText: "正在打开来信" }),
          ).toBeVisible();
          await expect(page.getByRole("alert")).toHaveCount(0);
          assert.ok(
            (
              await one(
                "SELECT read_at FROM cloud_letters WHERE account_id=$1 AND id=$2",
                [owner.id, unread],
              )
            ).read_at,
          );
          newRelease.resolve();
          await expect(page.locator(".e3-demand-title")).toHaveText(
            "合成历史来信",
          );
          await expect(
            page.getByRole("status").filter({ hasText: "正在打开来信" }),
          ).toHaveCount(0);
          await expect(page.getByRole("alert")).toHaveCount(0);
          results.push({
            oldOutcome: outcome,
            pendingFeedback: true,
            navigationAvailable: true,
            oldSuccessIgnored: outcome === "success",
            oldErrorIgnored: outcome === "error",
            oldFinallyPreservedNewLoading: true,
            serverReadNotReverted: true,
            selectedHistoryDisplayed: true,
          });
        } finally {
          oldRelease.resolve();
          newRelease.resolve();
          await context.close();
        }
      }
    } finally {
      await browser.close();
    }
    await writeFile(
      join(process.env.E4_READING_EVIDENCE!, "navigation-races.json"),
      JSON.stringify(
        {
          scope:
            "isolated real local HTTP/browser with controlled delayed responses and injected HTTP error",
          cases: results,
        },
        null,
        2,
      ) + "\n",
    );
  },
);
