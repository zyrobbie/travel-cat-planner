import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtemp, mkdir, rm, lstat, readdir, chmod, symlink, readFile, writeFile, unlink, utimes, link,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { pathToFileURL } from "node:url";
import {
  configuredVoicePayloadStore,
  VoicePayloadStoreError,
  validatePayloadLinuxEvidence,
  VOICE_PAYLOAD_AUDIO_MAX,
  VOICE_PAYLOAD_TEXT_MAX,
  type VoicePayloadStore,
} from "../../src/server/voice-payload-store";

const run = promisify(execFile);
const moduleUrl = pathToFileURL(resolve("src/server/voice-payload-store.ts")).href;
async function fixture(work: (env: Record<string, string>, root: string) => Promise<void>) {
  const root = await mkdtemp(join(tmpdir(), "cat-voice-payload-unit-"));
  const env = {
    APP_MODE: "INTERNAL", NODE_ENV: "test", E4_VOICE_STORAGE: "synthetic-files-v1",
    E4_VOICE_TEST_PAYLOAD_ROOT: root, E4_VOICE_PAYLOAD_DIRECTORY: join(root, "payload"),
    E4_VALIDATION_LOCAL_NONCE: randomUUID(),
  };
  try { await work(env, root); }
  finally { await rm(root, { recursive: true, force: true }); }
}
const reason = (expected: VoicePayloadStoreError["reason"]) => (error: unknown) =>
  error instanceof VoicePayloadStoreError && error.reason === expected;
async function published(store: VoicePayloadStore, kind: "audio" | "text" = "audio") {
  const stage = await store.stage(randomUUID(), kind, kind === "audio" ? Buffer.from("SYNTHETIC_AUDIO_ONLY") : "合成文字，不是真实录音。");
  return { stage, ref: await store.publish(stage) };
}
const subprocessEnv = (env: Record<string, string>): NodeJS.ProcessEnv => ({
  ...env, NODE_ENV: "test", PATH: process.env.PATH, TMPDIR: tmpdir(), LANG: "C.UTF-8", DOTENV_CONFIG_PATH: "/dev/null", TSX_DISABLE_CACHE: "1",
});

/** Child-only instrumentation around real fs syscalls; no production fault switch. */
async function killedAtFilesystemBoundary(env: Record<string, string>, phase: "stage-open" | "payload-link" | "epoch-link") {
  const jobId = randomUUID();
  const script = `
    import fs from 'node:fs';
    import {syncBuiltinESMExports} from 'node:module';
    const phase=${JSON.stringify(phase)};
    const stop=async()=>{await new Promise(resolve=>process.stdout.write(JSON.stringify({phase})+'\\n',resolve));process.kill(process.pid,'SIGKILL');await new Promise(()=>{});};
    const originalOpen=fs.promises.open;
    fs.promises.open=async(...args)=>{const handle=await originalOpen(...args);if(phase==='stage-open'&&String(args[0]).includes('/.stage_'))await stop();return handle;};
    const originalLink=fs.promises.link;
    fs.promises.link=async(...args)=>{await originalLink(...args);if((phase==='payload-link'&&String(args[1]).includes('/.payload_'))||(phase==='epoch-link'&&String(args[1]).endsWith('/.epoch')))await stop();};
    syncBuiltinESMExports();
    const {configuredVoicePayloadStore}=await import(${JSON.stringify(moduleUrl)});
    const store=await configuredVoicePayloadStore();
    const stage=await store.stage(${JSON.stringify(jobId)},'audio',Buffer.alloc(1024,7));
    await store.publish(stage);
    process.exitCode=9;
  `;
  let proof: unknown;
  await assert.rejects(run(process.execPath, ["--import", "tsx", "--input-type=module", "-e", script],
    { env: subprocessEnv(env), timeout: 20_000, maxBuffer: 8192 }), error => {
      const failure = error as Error & { signal?: string; stdout?: string | Buffer };
      assert.equal(failure.signal, "SIGKILL", "the child must die at the actual syscall boundary");
      proof = JSON.parse(failure.stdout!.toString());
      return true;
    });
  assert.deepEqual(proof, { phase });
  return jobId;
}

test("S01 explicit local fixture cannot become a production disk fallback", async () => {
  await assert.rejects(configuredVoicePayloadStore({}), reason("UNAVAILABLE"));
  await assert.rejects(configuredVoicePayloadStore({ E4_VOICE_STORAGE: "sql" }), reason("UNAVAILABLE"));
  await fixture(async env => {
    await assert.rejects(configuredVoicePayloadStore({ ...env, NODE_ENV: "production" }), reason("UNAVAILABLE"));
    await assert.rejects(configuredVoicePayloadStore({ ...env, APP_MODE: "PUBLIC" }), reason("UNAVAILABLE"));
    await assert.rejects(configuredVoicePayloadStore({ ...env, E4_VALIDATION_LOCAL_NONCE: "" }), reason("UNAVAILABLE"));
    await assert.rejects(configuredVoicePayloadStore({ ...env, E4_VOICE_PAYLOAD_DIRECTORY: "/tmp/payload" }), reason("UNAVAILABLE"));
    await assert.rejects(configuredVoicePayloadStore({ ...env, E4_VOICE_TEST_PAYLOAD_ROOT: "/tmp", E4_VOICE_PAYLOAD_DIRECTORY: "/tmp/payload" }), reason("UNAVAILABLE"));
  });
});

test("S02 atomic publication, private modes, unguessable generations and idempotent removal", async () => {
  await fixture(async env => {
    const store = await configuredVoicePayloadStore(env);
    await store.healthCheck();
    const stage = await store.stage(randomUUID(), "audio", Buffer.from("SYNTHETIC_AUDIO_ONLY"));
    assert.equal((await lstat(store.root)).mode & 0o777, 0o700);
    assert.equal((await lstat(join(store.root, stage.name))).mode & 0o777, 0o600);
    await assert.rejects(store.read(stage), reason("LOST"));
    assert.equal((await store.list())[0].staged, true);
    const ref = await store.publish(stage);
    assert.equal((await store.read(ref)).toString(), "SYNTHETIC_AUDIO_ONLY");
    assert.equal((await store.list()).length, 1);
    assert.equal((await store.list())[0].type, "payload");
    assert.deepEqual((await store.list())[0].ref, ref);
    assert.equal((await configuredVoicePayloadStore(env)).epoch, store.epoch);
    await assert.rejects(store.publish(stage), reason("LOST"));
    await store.discard(stage);
    assert.equal((await store.read(ref)).toString(), "SYNTHETIC_AUDIO_ONLY");
    await assert.rejects(store.read({ ...ref, bytes: ref.bytes + 1 }), reason("UNAVAILABLE"));
    await store.remove(ref);
    await store.remove(ref);
    assert.deepEqual(await store.list(), []);
  });
});

test("S03 byte bounds and kind validation reject before writing payload", async () => {
  await fixture(async env => {
    const store = await configuredVoicePayloadStore(env);
    await assert.rejects(store.stage(randomUUID(), "audio", Buffer.alloc(VOICE_PAYLOAD_AUDIO_MAX + 1)), reason("UNAVAILABLE"));
    await assert.rejects(store.stage(randomUUID(), "text", "字".repeat(Math.ceil(VOICE_PAYLOAD_TEXT_MAX / 3) + 1)), reason("UNAVAILABLE"));
    await assert.rejects(store.stage(randomUUID(), "audio", "SYNTHETIC"), reason("UNAVAILABLE"));
    await assert.rejects(store.stage("../../bad", "audio", Buffer.from("SYNTHETIC")), reason("UNAVAILABLE"));
    const { ref } = await published(store, "text");
    assert.equal((await store.read(ref)).toString(), "合成文字，不是真实录音。");
    await store.remove(ref);
    assert.deepEqual(await store.list(), []);
  });
});

test("S04 symlinks, loose modes and aliased parents cannot expose outside content", async () => {
  await fixture(async (env, root) => {
    const store = await configuredVoicePayloadStore(env);
    const { ref } = await published(store);
    const entry = (await store.list())[0], path = join(store.root, entry.name);
    await chmod(path, 0o644);
    await assert.rejects(store.read(ref), reason("UNAVAILABLE"));
    await chmod(path, 0o600);
    const outside = join(root, "outside-control");
    await writeFile(outside, "SYNTHETIC_CONTROL_UNCHANGED", { mode: 0o600 });
    await unlink(path);
    await symlink(outside, path);
    await assert.rejects(store.read(ref), reason("UNAVAILABLE"));
    await assert.rejects(store.remove(ref), reason("UNAVAILABLE"));
    const alias = (await store.list())[0];
    assert.equal(alias.type, "unknown");
    assert.equal(alias.ref, undefined);
    assert.equal(await store.removeEntry(alias, 0), true);
    assert.equal(await readFile(outside, "utf8"), "SYNTHETIC_CONTROL_UNCHANGED");
    await rm(store.root, { recursive: true });
    await mkdir(join(root, "actual"), { mode: 0o700 });
    await symlink(join(root, "actual"), store.root);
    await assert.rejects(configuredVoicePayloadStore(env), reason("UNAVAILABLE"));
    await unlink(store.root);
    const ancestorAlias = join(root, "alias");
    await symlink(join(root, "actual"), ancestorAlias);
    await assert.rejects(configuredVoicePayloadStore({ ...env,
      E4_VOICE_TEST_PAYLOAD_ROOT: ancestorAlias, E4_VOICE_PAYLOAD_DIRECTORY: join(ancestorAlias, "payload"),
    }), reason("UNAVAILABLE"));
  });
});

test("S05 loss/replacement changes epoch and makes old stores and refs unreadable", async () => {
  await fixture(async env => {
    const before = await configuredVoicePayloadStore(env);
    const { ref } = await published(before);
    await rm(before.root, { recursive: true });
    await mkdir(before.root, { mode: 0o700 });
    const after = await configuredVoicePayloadStore(env);
    assert.notEqual(after.epoch, before.epoch);
    await assert.rejects(before.healthCheck(), reason("LOST"));
    await assert.rejects(before.read(ref), reason("LOST"));
    await assert.rejects(after.read(ref), reason("LOST"));
    assert.deepEqual(await after.list(), []);
  });
});

test("S06 orphan cleanup respects age and inode snapshots and protects metadata", async () => {
  await fixture(async env => {
    const store = await configuredVoicePayloadStore(env);
    const stage = await store.stage(randomUUID(), "audio", Buffer.from("SYNTHETIC_STAGE"));
    let entry = (await store.list())[0];
    assert.equal(await store.removeEntry(entry), false);
    const old = new Date(Date.now() - 180_000);
    await utimes(join(store.root, stage.name), old, old);
    entry = (await store.list())[0];
    assert.equal(await store.removeEntry(entry), true);
    const { ref } = await published(store);
    entry = (await store.list())[0];
    await unlink(join(store.root, entry.name));
    await writeFile(join(store.root, entry.name), "NEW_SYNTHETIC_GENERATION", { mode: 0o600 });
    assert.equal(await store.removeEntry(entry, 0), false);
    assert.equal(await readFile(join(store.root, entry.name), "utf8"), "NEW_SYNTHETIC_GENERATION");
    const marker = { ...entry, name: ".epoch" };
    await assert.rejects(store.removeEntry(marker, 0), reason("UNAVAILABLE"));
    await assert.rejects(store.removeEntry({ ...entry, name: "../outside" }, 0), reason("UNAVAILABLE"));
    assert.equal((await store.list()).length, 1);
    await store.removeEntry((await store.list())[0], 0);
    assert.equal((await configuredVoicePayloadStore(env)).epoch, ref.epoch);
  });
});

test("S07 two real processes share one epoch and publish unique generations without overwrite", async () => {
  await fixture(async env => {
    const job = randomUUID();
    const script = `import {configuredVoicePayloadStore} from ${JSON.stringify(moduleUrl)}; const store=await configuredVoicePayloadStore();const stage=await store.stage(${JSON.stringify(job)},'audio',Buffer.alloc(256*1024,7)); const ref=await store.publish(stage); console.log(JSON.stringify(ref));`;
    const results = await Promise.all([0, 1].map(() => run(process.execPath,
      ["--import", "tsx", "--input-type=module", "-e", script],
      { env: subprocessEnv(env), timeout: 20_000, maxBuffer: 4096 })));
    const refs = results.map(r => JSON.parse(r.stdout.toString()));
    assert.equal(refs[0].epoch, refs[1].epoch);
    assert.notEqual(refs[0].version, refs[1].version);
    const store = await configuredVoicePayloadStore(env);
    const entries = await store.list();
    assert.equal(entries.length, 2);
    assert.ok(entries.every(e => e.type === "payload" && e.ref?.jobId === job));
    for (const ref of refs) assert.equal((await store.read(ref)).length, 256 * 1024);
  });
});

test("S08 actual child file-size exhaustion removes a partially written stage (not a Linux tmpfs ENOSPC proof)", async () => {
  await fixture(async env => {
    const script = `import {configuredVoicePayloadStore} from ${JSON.stringify(moduleUrl)};import {randomUUID} from 'node:crypto';const store=await configuredVoicePayloadStore();try {await store.stage(randomUUID(),'audio',Buffer.alloc(1024*1024,4));process.exitCode=2;}catch(e){console.log(JSON.stringify({reason:e.reason,remaining:(await store.list()).length}));if(e.reason!=='CAPACITY')process.exitCode=3;}`;
    const python = "import os,resource,signal,sys; signal.signal(signal.SIGXFSZ,signal.SIG_IGN); resource.setrlimit(resource.RLIMIT_FSIZE,(524288,524288)); os.execv(sys.argv[1],sys.argv[1:])";
    const result = await run("/usr/bin/python3", ["-c", python, process.execPath,
      "--import", "tsx", "--input-type=module", "-e", script],
      { env: subprocessEnv(env), timeout: 20_000, maxBuffer: 4096 });
    assert.deepEqual(JSON.parse(result.stdout.toString()), { reason: "CAPACITY", remaining: 0 });
  });
});

test("S09 bounded listings refuse truncation; unknown files have no readable payload ref", async () => {
  await fixture(async env => {
    const store = await configuredVoicePayloadStore(env);
    await published(store); await published(store); await published(store);
    await assert.rejects(store.list(2), reason("CAPACITY"));
    assert.equal((await store.list()).length, 3);
    await writeFile(join(store.root, "unknown-orphan"), "SYNTHETIC_UNKNOWN", { mode: 0o600 });
    const unknown = (await store.list()).find(e => e.name === "unknown-orphan")!;
    assert.equal(unknown.type, "unknown");
    assert.equal(unknown.ref, undefined);
    assert.equal(await store.removeEntry(unknown, 0), true);
  });
});

test("S10 synthetic nonce and epoch metadata cannot be replaced by aliases or another fixture", async () => {
  await fixture(async (env, root) => {
    const store = await configuredVoicePayloadStore(env);
    await assert.rejects(configuredVoicePayloadStore({ ...env, E4_VALIDATION_LOCAL_NONCE: randomUUID() }), reason("UNAVAILABLE"));
    const old = await readFile(join(store.root, ".epoch"));
    const control = join(root, "marker-control");
    await writeFile(control, old, { mode: 0o600 });
    await unlink(join(store.root, ".epoch"));
    await symlink(control, join(store.root, ".epoch"));
    await assert.rejects(store.healthCheck(), reason("UNAVAILABLE"));
    await assert.rejects(configuredVoicePayloadStore(env), reason("UNAVAILABLE"));
    assert.deepEqual(await readFile(control), old);
  });
});

test("S11 Linux evidence parser rejects swapping, loose mounts, dump settings and foreign cgroups", () => {
  const good = {
    platform: "linux", mountInfo: "100 23 0:72 / /run/cat-voice-private rw,nosuid,nodev,noexec,relatime - tmpfs tmpfs rw,size=131072k,nr_inodes=4096,mode=700,uid=991,gid=991,noswap\n",
    cgroup: "0::/catvoice.slice/cat-voice-app.service\n", swapMax: "0\n", sliceSwapMax: "0\n", memoryMax: "402653184\n",
    sliceMemoryMax: "805306368\n",
    limits: "Max core file size        0        0        bytes\n", execArgs: [] as string[],
  };
  validatePayloadLinuxEvidence(good);
  for (const change of [
    { platform: "darwin" }, { mountInfo: good.mountInfo.replace(",noswap", "") },
    { mountInfo: good.mountInfo.replace("/run/cat-voice-private", "/run") },
    { mountInfo: good.mountInfo.replace("131072k", "262144k") },
    { mountInfo: good.mountInfo.replace("nr_inodes=4096", "nr_inodes=8192") },
    { mountInfo: good.mountInfo.replace("nodev,", "") }, { swapMax: "max" }, { sliceSwapMax: "max" },
    { memoryMax: "max" }, { cgroup: "0::/system.slice/cat-letters.service\n" },
    { memoryMax: "805306368" }, { sliceMemoryMax: "max" }, { sliceMemoryMax: "1610612736" },
    { limits: "Max core file size        unlimited        unlimited        bytes\n" },
    { execArgs: ["--heapsnapshot-signal=SIGUSR2"] }, { nodeOptions: "--report-on-fatalerror" },
    { reportOnFatalError: true }, { reportOnSignal: true }, { reportOnUncaughtException: true },
  ]) assert.throws(() => validatePayloadLinuxEvidence({ ...good, ...change }), reason("UNAVAILABLE"));
});

test("S12 production tmpfs mode never accepts this macOS local directory fixture", async () => {
  await fixture(async env => {
    await assert.rejects(configuredVoicePayloadStore({ ...env, E4_VOICE_STORAGE: "tmpfs-private-v1" }), reason("UNAVAILABLE"));
    if (process.platform !== "linux") await assert.rejects(configuredVoicePayloadStore({
      E4_VOICE_STORAGE: "tmpfs-private-v1", E4_VOICE_PAYLOAD_DIRECTORY: "/run/cat-voice-private/payload",
    }), error => error instanceof VoicePayloadStoreError);
  });
});

test("S13 a missing private boundary is created only within the approved temporary fixture and can be rebuilt after loss", async () => {
  await fixture(async (env, root) => {
    const boundary = join(root, "voice-private");
    const actual = { ...env, E4_VOICE_TEST_PAYLOAD_ROOT: boundary, E4_VOICE_PAYLOAD_DIRECTORY: join(boundary, "payload") };
    const control = join(root, "business-control");
    await writeFile(control, "SYNTHETIC_SENT_BUSINESS_RECORD_KEEP", { mode: 0o600 });
    const before = await configuredVoicePayloadStore(actual);
    const { ref } = await published(before);
    assert.equal((await lstat(boundary)).mode & 0o777, 0o700);
    await rm(boundary, { recursive: true });
    const after = await configuredVoicePayloadStore(actual);
    assert.notEqual(after.epoch, before.epoch);
    await assert.rejects(after.read(ref), reason("LOST"));
    assert.equal(await readFile(control, "utf8"), "SYNTHETIC_SENT_BUSINESS_RECORD_KEEP");
    assert.deepEqual(await after.list(), []);
  });
});

test("S14 SIGKILL after actual stage open leaves zero bytes recognizable only for GC", async () => {
  await fixture(async env => {
    const jobId = await killedAtFilesystemBoundary(env, "stage-open");
    const store = await configuredVoicePayloadStore(env);
    const entries = await store.list();
    assert.equal(entries.length, 1);
    const entry = entries[0];
    assert.equal(entry.type, "stage");
    assert.equal(entry.staged, true);
    assert.equal(entry.ref?.jobId, jobId);
    assert.equal(entry.bytes, 0);
    await assert.rejects(store.read(entry.ref!), reason("UNAVAILABLE"));
    await assert.rejects(store.publish({ ...entry.ref!, name: entry.name, dev: entry.dev, ino: entry.ino }), reason("UNAVAILABLE"));
    assert.equal(await store.removeEntry(entry), false);
    const old = new Date(Date.now() - 180_000);
    await utimes(join(store.root, entry.name), old, old);
    assert.equal(await store.removeEntry((await store.list())[0]), true);
    assert.deepEqual(await store.list(), []);
    await store.healthCheck();
  });
});

test("S15 SIGKILL after actual payload link leaves two aliases that remain unreadable and are reclaimable", async () => {
  await fixture(async env => {
    const jobId = await killedAtFilesystemBoundary(env, "payload-link");
    const store = await configuredVoicePayloadStore(env);
    let entries = await store.list();
    assert.equal(entries.length, 2);
    assert.ok(entries.every(e => e.ref?.jobId === jobId && e.bytes === 1024));
    assert.equal(entries[0].ino, entries[1].ino);
    for (const entry of entries) assert.equal((await lstat(join(store.root, entry.name))).nlink, 2);
    const ready = entries.find(e => !e.staged)!;
    await assert.rejects(store.read(ready.ref!), reason("UNAVAILABLE"));
    const stage = entries.find(e => e.staged)!;
    await assert.rejects(store.publish({ ...stage.ref!, name: stage.name, dev: stage.dev, ino: stage.ino }), reason("UNAVAILABLE"));
    const old = new Date(Date.now() - 180_000);
    await utimes(join(store.root, stage.name), old, old);
    entries = await store.list();
    for (const entry of entries) assert.equal(await store.removeEntry(entry), true);
    assert.deepEqual(await store.list(), []);
    await store.healthCheck();
  });
});

test("S16 SIGKILL during epoch initialization leaves bounded metadata that GC can remove without changing epoch", async () => {
  await fixture(async env => {
    await killedAtFilesystemBoundary(env, "epoch-link");
    const store = await configuredVoicePayloadStore(env);
    const epoch = store.epoch;
    const entries = await store.list();
    assert.equal(entries.length, 1);
    const initialization = entries[0];
    assert.equal(initialization.type, "initialization");
    assert.equal(initialization.ref, undefined);
    assert.equal((await lstat(join(store.root, initialization.name))).nlink, 2);
    assert.equal(await store.removeEntry(initialization), false);
    const old = new Date(Date.now() - 180_000);
    await utimes(join(store.root, initialization.name), old, old);
    assert.equal(await store.removeEntry((await store.list())[0]), true);
    assert.deepEqual(await store.list(), []);
    assert.equal((await configuredVoicePayloadStore(env)).epoch, epoch);
    await store.healthCheck();
  });
});

test("S17 verify checks metadata without reading a 10MiB payload; instrumented control read is rejected", async () => {
  await fixture(async env => {
    const script = `
      import fs from 'node:fs';
      import {randomUUID} from 'node:crypto';
      import {syncBuiltinESMExports} from 'node:module';
      let payloadReads=0;
      const originalOpen=fs.promises.open;
      fs.promises.open=async(...args)=>{const handle=await originalOpen(...args);if(String(args[0]).includes('/.payload_')){handle.read=async()=>{payloadReads++;throw Error('SYNTHETIC_READ_DETECTOR');};handle.readFile=async()=>{payloadReads++;throw Error('SYNTHETIC_READ_DETECTOR');};handle.createReadStream=()=>{payloadReads++;throw Error('SYNTHETIC_READ_DETECTOR');};}return handle;};
      syncBuiltinESMExports();
      const {configuredVoicePayloadStore}=await import(${JSON.stringify(moduleUrl)});
      const store=await configuredVoicePayloadStore();
      const stage=await store.stage(randomUUID(),'audio',Buffer.alloc(10*1024*1024,7));
      const ref=await store.publish(stage);
      await store.verify(ref);
      const verifyReads=payloadReads;
      let controlReadBlocked=false;
      try{await store.read(ref);}catch{controlReadBlocked=payloadReads===1;}
      console.log(JSON.stringify({verifyReads,controlReadBlocked,payloadBytes:ref.bytes}));
    `;
    const result = await run(process.execPath, ["--import", "tsx", "--input-type=module", "-e", script],
      { env: subprocessEnv(env), timeout: 20_000, maxBuffer: 4096 });
    assert.deepEqual(JSON.parse(result.stdout.toString()), {
      verifyReads: 0, controlReadBlocked: true, payloadBytes: 10 * 1024 * 1024,
    });
  });
});

test("S18 verify rejects stale epoch, missing/zero files, symlinks, loose modes and multiple links", async () => {
  await fixture(async (env, root) => {
    const store = await configuredVoicePayloadStore(env);
    const { ref } = await published(store);
    const entry = (await store.list())[0], path = join(store.root, entry.name);
    assert.equal(await store.verify(ref), undefined);
    await assert.rejects(store.verify({ ...ref, epoch: randomUUID() }), reason("LOST"));
    await assert.rejects(store.verify({ ...ref, bytes: ref.bytes + 1 }), reason("UNAVAILABLE"));
    await chmod(path, 0o644);
    await assert.rejects(store.verify(ref), reason("UNAVAILABLE"));
    await chmod(path, 0o600);
    const second = join(root, "same-inode-control");
    await link(path, second);
    await assert.rejects(store.verify(ref), reason("UNAVAILABLE"));
    await unlink(second);
    assert.equal(await store.verify(ref), undefined);
    await writeFile(path, Buffer.alloc(0));
    await assert.rejects(store.verify(ref), reason("UNAVAILABLE"));
    await assert.rejects(store.verify({ ...ref, bytes: 0 }), reason("UNAVAILABLE"));
    await unlink(path);
    await assert.rejects(store.verify(ref), reason("LOST"));
    const outside = join(root, "outside-verify-control");
    await writeFile(outside, "SYNTHETIC_OUTSIDE_UNCHANGED", { mode: 0o600 });
    await symlink(outside, path);
    await assert.rejects(store.verify(ref), reason("UNAVAILABLE"));
    assert.equal(await readFile(outside, "utf8"), "SYNTHETIC_OUTSIDE_UNCHANGED");
  });
});
