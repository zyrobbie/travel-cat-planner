import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import type { Pool } from "pg";
import type { APIRequestContext } from "@playwright/test";
import { validateExportManifest } from "../../src/shared/export-download";

type Manifest = {
  status: string;
  artifact_name: string | null;
  artifact_hash: string | null;
  artifact_bytes: string | number | null;
};

export async function storedExport(db: Pool, id: string) {
  const manifest = (await db.query(
    "SELECT status,artifact_name,artifact_hash,artifact_bytes FROM account_exports WHERE id=$1",
    [id],
  )).rows[0] as Manifest | undefined;
  const rows = await db.query(
    "SELECT chunk_index,chunk_bytes,chunk_hash,body FROM private_export_chunks WHERE export_id=$1 ORDER BY chunk_index",
    [id],
  );
  rows.rows.forEach((row, index) => {
    assert.equal(row.chunk_index, index, "Private chunk order is not contiguous");
    assert.ok(Buffer.isBuffer(row.body), "Chunk payload must be bytea");
    assert.ok(row.body.length > 0 && row.body.length <= 2 * 1024 * 1024);
    assert.equal(row.body.length, row.chunk_bytes);
    assert.equal(createHash("sha256").update(row.body).digest("hex"), row.chunk_hash);
  });
  return { manifest, chunks: rows.rows.length,
    bytes: Buffer.concat(rows.rows.map(row => row.body as Buffer)) };
}

export async function assertCommittedExport(db: Pool, id: string) {
  const stored = await storedExport(db, id);
  assert.equal(stored.manifest?.status, "READY");
  assert.ok(stored.manifest.artifact_name?.startsWith(`${id}.`));
  assert.ok(stored.chunks > 0, "READY export must have committed private chunks");
  assert.equal(stored.bytes.length, Number(stored.manifest.artifact_bytes));
  assert.equal(createHash("sha256").update(stored.bytes).digest("hex"),
    stored.manifest.artifact_hash);
  return stored;
}

export async function assertReadyExport(db: Pool, owner: APIRequestContext, id: string) {
  const stored = await assertCommittedExport(db, id);
  const base = `/api/e4/privacy/exports/${id}`;
  const response = await owner.get(`${base}/download-manifest`);
  assert.equal(response.status(), 200, "Owner could not read export manifest");
  assert.match(response.headers()["cache-control"] ?? "", /no-store/);
  const manifest = validateExportManifest(await response.json());
  assert.equal(manifest.bytes, stored.bytes.length);
  assert.equal(manifest.sha256, stored.manifest!.artifact_hash);
  assert.equal(manifest.downloadVersion,
    createHash("sha256").update(stored.manifest!.artifact_name!).digest("hex"));
  assert.equal(manifest.chunks.length, stored.chunks);
  const wrongVersion = `${manifest.downloadVersion[0] === "0" ? "1" : "0"}${manifest.downloadVersion.slice(1)}`;
  assert.equal((await owner.get(`${base}/chunks/0?version=${wrongVersion}`)).status(), 409,
    "Stale download version unexpectedly read a private chunk");
  assert.notEqual((await owner.get(`${base}/download`)).status(), 200,
    "PostgreSQL export unexpectedly exposed the old direct download route");
  const chunks: Buffer[] = [];
  for (const part of manifest.chunks) {
    const chunk = await owner.get(`${base}/chunks/${part.index}?version=${manifest.downloadVersion}`);
    assert.equal(chunk.status(), 200, `Chunk ${part.index} was not downloadable`);
    assert.match(chunk.headers()["cache-control"] ?? "", /no-store/);
    assert.match(chunk.headers()["content-type"] ?? "", /octet-stream/);
    const bytes = Buffer.from(await chunk.body());
    assert.equal(bytes.length, part.bytes);
    assert.equal(createHash("sha256").update(bytes).digest("hex"), part.sha256);
    assert.equal(chunk.headers()["x-catletters-sha256"], part.sha256);
    chunks.push(bytes);
  }
  const downloaded = Buffer.concat(chunks);
  assert.deepEqual(downloaded, stored.bytes, "Download differs from committed chunks");
  return { manifest, payload: JSON.parse(downloaded.toString("utf8")) as Record<string, unknown> };
}
