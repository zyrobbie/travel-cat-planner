import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { request, type APIRequestContext } from "@playwright/test";
import { db, clients, dispose, origin, child, lifecycle,
  assertPurged, markerAbsent, snapshot } from "./helpers";
import { assertCommittedExport, assertReadyExport, storedExport } from "./independent-export";

const variant = process.env.E4_RESTORE_VARIANT!;
let fixture: any, a: APIRequestContext, b: APIRequestContext;
before(async () => {
  assert.equal((await db.query("SELECT current_database() AS name")).rows[0].name,
    "catletters_e4_lifecycle_restore_test");
  assert.ok(["old", "new"].includes(variant));
  fixture = JSON.parse(await readFile(process.env.E4_RESTORE_FIXTURE!, "utf8"));
  a = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin },
    storageState: { cookies: fixture.a.cookies, origins: [] } });
  b = await request.newContext({ baseURL: origin, extraHTTPHeaders: { Origin: origin },
    storageState: { cookies: fixture.b.cookies, origins: [] } });
  clients.push(a, b);
});
after(dispose);

test(`INDEPENDENT RESTORE ${variant}: physical business backup is blocked by the unrolled independent gate`, async () => {
  const before = await snapshot();
  const ids = [fixture.a.exportId, fixture.b.exportId, fixture.fresh.exportId];
  const beforeChunks = await Promise.all(ids.map(id => storedExport(db, id)));
  if (variant === "old") {
    await assertCommittedExport(db, fixture.a.exportId);
    await assertCommittedExport(db, fixture.b.exportId);
    assert.equal(beforeChunks[2].manifest, undefined);
  } else {
    assert.equal(beforeChunks[0].chunks, 0);
    assert.equal(beforeChunks[1].chunks, 0);
    await assertCommittedExport(db, fixture.fresh.exportId);
  }
  for (const path of ["/api/e4/account", "/api/e4/v1/state",
    `/api/e4/privacy/exports/${fixture.a.exportId}/download-manifest`,
    `/api/e4/privacy/exports/${fixture.b.exportId}/download-manifest`,
    `/api/e4/privacy/exports/${fixture.fresh.exportId}/download-manifest`])
    assert.equal((await a.get(path)).status(), 503);
  assert.equal((await b.get("/api/e4/account")).status(), 503);
  assert.notEqual((await child(["--import", "tsx", "scripts/cloud-worker.ts", "--once"])).code, 0);
  assert.notEqual((await child(["--import", "tsx", "scripts/lifecycle-worker.ts", "--once"])).code, 0);
  const afterRows = await snapshot();
  for (const table of ["cloud_letters", "cloud_response_revisions", "accounts"])
    assert.deepEqual(afterRows[table], before[table]);
  assert.deepEqual(await Promise.all(ids.map(id => storedExport(db, id))), beforeChunks,
    "Closed gate changed restored private chunks or export manifests");
  const response = await db.query(
    "SELECT text FROM cloud_response_revisions WHERE account_id=$1 AND response_id=$2 ORDER BY revision",
    [fixture.b.accountId, fixture.b.response],
  );
  assert.equal(response.rowCount, 2);
  assert.equal(response.rows.every(row => row.text !== null), variant === "old");
  const aStatus = (await db.query("SELECT status FROM accounts WHERE id=$1", [fixture.a.accountId])).rows[0]?.status;
  assert.equal(aStatus, variant === "old" ? "ACTIVE" : "DELETED");
});

test(`INDEPENDENT RESTORE ${variant}: failed replay stays closed and successful replay erases real rows`, async () => {
  if (variant === "old") {
    await db.query("CREATE FUNCTION e4_independent_restore_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'synthetic replay failure'; END $$");
    await db.query("CREATE TRIGGER e4_independent_restore_fail BEFORE DELETE ON cloud_letters FOR EACH ROW EXECUTE FUNCTION e4_independent_restore_fail()");
    try {
      assert.notEqual((await lifecycle("reconcile")).code, 0);
      assert.equal((await b.get("/api/e4/account")).status(), 503);
    } finally {
      await db.query("DROP TRIGGER e4_independent_restore_fail ON cloud_letters");
      await db.query("DROP FUNCTION e4_independent_restore_fail()");
    }
  }
  const recovery = await request.newContext({ baseURL: origin,
    extraHTTPHeaders: { Origin: origin },
    storageState: { cookies: fixture.a.recoveryCookies, origins: [] } });
  clients.push(recovery);
  const beforeRetry = await snapshot();
  assert.equal((await recovery.post("/api/e4/privacy/deletions/retry", {
    data: { requestId: fixture.a.requestId },
  })).status(), 503);
  assert.deepEqual(await snapshot(), beforeRetry);
  assert.equal((await lifecycle("reconcile")).code, 0);
  await assertPurged(fixture.a.accountId, fixture.a.participantId, fixture.a.email);
  await markerAbsent([fixture.a.marker, fixture.b.first, fixture.b.current]);
  const versions = await db.query(
    "SELECT text FROM cloud_response_revisions WHERE account_id=$1 AND response_id=$2 ORDER BY revision",
    [fixture.b.accountId, fixture.b.response],
  );
  assert.equal(versions.rowCount, 2);
  assert.ok(versions.rows.every(row => row.text === null));
  const erased = await Promise.all([fixture.a.exportId, fixture.b.exportId]
    .map(id => storedExport(db, id)));
  assert.ok(erased.every(value => value.chunks === 0),
    "Recovery left restored private chunks accessible");
  assert.equal(erased[0].manifest, undefined);
  assert.equal(erased[1].manifest?.status, "REVOKED");
  assert.equal((await b.get("/api/e4/account")).status(), 200);
  assert.ok([409, 410].includes(
    (await b.get(`/api/e4/privacy/exports/${fixture.b.exportId}/download-manifest`)).status()));
  assert.equal((await a.get("/api/e4/account")).status(), 401);
  assert.equal((await a.get(`/api/e4/privacy/exports/${fixture.a.exportId}/download-manifest`)).status(), 401);
  const fresh = (await db.query("SELECT id FROM accounts WHERE id=$1", [fixture.fresh.accountId])).rows[0];
  assert.equal(Boolean(fresh), variant === "new");
  if (variant === "new") {
    const freshOwner = await request.newContext({ baseURL: origin,
      extraHTTPHeaders: { Origin: origin },
      storageState: { cookies: fixture.fresh.cookies, origins: [] } });
    clients.push(freshOwner);
    const { payload } = await assertReadyExport(db, freshOwner, fixture.fresh.exportId);
    assert.equal((payload.account as { id: string }).id, fixture.fresh.accountId);
  } else assert.equal((await storedExport(db, fixture.fresh.exportId)).chunks, 0);
  const afterReplay = await snapshot();
  const chunksAfterReplay = await Promise.all(
    [fixture.a.exportId, fixture.b.exportId, fixture.fresh.exportId]
      .map(id => storedExport(db, id)));
  assert.equal((await lifecycle("reconcile")).code, 0);
  assert.deepEqual(await snapshot(), afterReplay);
  assert.deepEqual(await Promise.all(
    [fixture.a.exportId, fixture.b.exportId, fixture.fresh.exportId]
      .map(id => storedExport(db, id))), chunksAfterReplay);
});
