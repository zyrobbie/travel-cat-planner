import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { pool } from "../../src/server/db";
import { closeLifecycleProvider, independentLedger } from "../../src/server/lifecycle-provider";
import { reconcileLifecycle, runDeletionWorkerOnce } from "../../src/server/account-lifecycle";
import { db, assertDedicated, dispose, richFixture, json, prepare, confirm,
  status, assertPurged, markerAbsent, requestExport, job, tick, lifecycle } from "./helpers";
import { assertReadyExport, storedExport } from "./independent-export";

before(assertDedicated);
after(async () => { await closeLifecycleProvider(); await pool.end(); await dispose(); });

test("I01 real response text and complete account rows are erased through the independent ledger", async () => {
  const a = await richFixture();
  await json(a.client, "post", `/api/e4/v1/responses/${encodeURIComponent(a.response)}/delete`,
    { key: randomUUID(), expectedRevision: 2 });
  const revisions = await db.query(
    "SELECT text FROM cloud_response_revisions WHERE account_id=$1 AND response_id=$2 ORDER BY revision",
    [a.accountId, a.response],
  );
  assert.equal(revisions.rowCount, 2);
  assert.ok(revisions.rows.every(row => row.text === null));
  assert.equal((await db.query("SELECT status FROM cloud_responses WHERE id=$1", [a.response])).rows[0].status,
    "DELETED");
  const prepared = await prepare(a);
  await confirm(a, prepared.requestId);
  assert.equal((await status(a)).status, "PENDING");
  assert.equal((await runDeletionWorkerOnce()).status, "COMPLETE");
  assert.equal((await status(a)).status, "COMPLETE");
  await assertPurged(a.accountId, a.cat.participant_id, a.email);
  await markerAbsent([a.marker, a.email]);
});

test("I02 ledger-first freeze failure blocks ordinary traffic until actual operator replay", async () => {
  const a = await richFixture();
  const prepared = await prepare(a);
  await db.query(
    "CREATE FUNCTION e4_independent_freeze_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.status='DELETING' THEN RAISE EXCEPTION 'synthetic freeze failure'; END IF; RETURN NEW; END $$",
  );
  await db.query(
    "CREATE TRIGGER e4_independent_freeze_fail BEFORE UPDATE ON accounts FOR EACH ROW EXECUTE FUNCTION e4_independent_freeze_fail()",
  );
  try {
    const failed = await a.client.post("/api/e4/privacy/deletions/confirm", {
      data: { requestId: prepared.requestId, confirm: true },
    });
    assert.equal(failed.status(), 503);
    assert.equal((await a.client.get("/api/e4/account")).status(), 503);
    assert.equal((await status(a)).status, "PENDING");
  } finally {
    await db.query("DROP TRIGGER e4_independent_freeze_fail ON accounts");
    await db.query("DROP FUNCTION e4_independent_freeze_fail()");
  }
  const operationId = randomUUID();
  const gate = await independentLedger(pool).closeRestoreGate(operationId);
  process.env.E4_LIFECYCLE_RECOVERY = "true";
  try { await reconcileLifecycle(operationId, gate.epoch); }
  finally { delete process.env.E4_LIFECYCLE_RECOVERY; }
  await assertPurged(a.accountId, a.cat.participant_id, a.email);
  await markerAbsent([a.marker, a.email]);
});

test("I03 PostgreSQL manifest, chunks and owner download are revoked by response deletion and erased by account deletion", async () => {
  const a = await richFixture();
  // Force two real bytea chunks, so ordering and per-chunk hashes are exercised.
  await db.query(
    "INSERT INTO cloud_letters(id,cat_id,account_id,type,snapshot,read_at,origin) VALUES($1,$2,$3,'DEMAND',jsonb_build_object('title','large synthetic','body',repeat('x',2300000),'catName','synthetic'),now(),'LEGACY')",
    [`${a.cat.id}:fixture-large`, a.cat.id, a.accountId],
  );
  const old = await requestExport(a);
  await tick();
  assert.equal((await job(a, old.id)).status, "READY");
  const { payload: original, manifest: oldManifest } = await assertReadyExport(db, a.client, old.id);
  assert.ok(oldManifest.chunks.length >= 2, "Synthetic export did not cross a chunk boundary");
  const serialized = JSON.stringify(original);
  assert.ok(serialized.includes(a.first) && serialized.includes(a.current));
  assert.equal(original.format, "cat-letters-account-export");
  assert.equal((original.account as { id: string }).id, a.accountId);

  await json(a.client, "post", `/api/e4/v1/responses/${encodeURIComponent(a.response)}/delete`,
    { key: randomUUID(), expectedRevision: 2 });
  const revoked = await storedExport(db, old.id);
  assert.equal(revoked.manifest?.status, "REVOKED");
  assert.equal(revoked.chunks, 0, "Response deletion retained private chunks");
  for (const path of [
    `/api/e4/privacy/exports/${old.id}/download-manifest`,
    `/api/e4/privacy/exports/${old.id}/chunks/0?version=${oldManifest.downloadVersion}`,
  ]) assert.ok([409, 410].includes((await a.client.get(path)).status()));

  const fresh = await requestExport(a);
  await tick();
  const replacement = JSON.stringify((await assertReadyExport(db, a.client, fresh.id)).payload);
  assert.equal(replacement.includes(a.first), false);
  assert.equal(replacement.includes(a.current), false);
  const prepared = await prepare(a);
  await confirm(a, prepared.requestId);
  assert.equal((await runDeletionWorkerOnce()).status, "COMPLETE");
  await assertPurged(a.accountId, a.cat.participant_id, a.email);
  for (const id of [old.id, fresh.id]) {
    const gone = await storedExport(db, id);
    assert.equal(gone.chunks, 0, "Account deletion retained private chunks");
    assert.equal(gone.manifest, undefined);
    assert.equal((await a.client.get(`/api/e4/privacy/exports/${id}/download-manifest`)).status(), 401);
  }
});

test("I04 a failed READY publication rolls back PostgreSQL chunks and explicit retry publishes them", async () => {
  const a = await richFixture(), exported = await requestExport(a);
  await db.query(
    "CREATE FUNCTION e4_independent_export_fail() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.status='READY' THEN RAISE EXCEPTION 'synthetic publication failure'; END IF; RETURN NEW; END $$",
  );
  await db.query(
    "CREATE TRIGGER e4_independent_export_fail BEFORE UPDATE ON account_exports FOR EACH ROW EXECUTE FUNCTION e4_independent_export_fail()",
  );
  try { assert.notEqual((await lifecycle()).code, 0); }
  finally {
    await db.query("DROP TRIGGER e4_independent_export_fail ON account_exports");
    await db.query("DROP FUNCTION e4_independent_export_fail()");
  }
  const failed = await storedExport(db, exported.id);
  assert.equal(failed.manifest?.status, "FAILED");
  assert.equal(failed.chunks, 0, "Failed publication left committed private chunks");
  assert.notEqual((await a.client.get(`/api/e4/privacy/exports/${exported.id}/download-manifest`)).status(), 200);
  await json(a.client, "post", `/api/e4/privacy/exports/${exported.id}/retry`, {});
  await tick();
  assert.equal((await job(a, exported.id)).status, "READY");
  await assertReadyExport(db, a.client, exported.id);
});
