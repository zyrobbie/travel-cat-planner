import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { request } from "@playwright/test";
import { randomUUID } from "node:crypto";
import { pool } from "../../src/server/db";
import { closeLifecycleProvider } from "../../src/server/lifecycle-provider";
import { runDeletionWorkerOnce } from "../../src/server/account-lifecycle";
import { db, assertDedicated, dispose, richFixture, prepare, confirm, status,
  login, bind, clients, origin, json, requestExport, job, tick } from "./helpers";
import { assertReadyExport, storedExport } from "./independent-export";

await assertDedicated();
const path = process.env.E4_RESTORE_FIXTURE!;
try {
  if (process.argv[2] === "seed") {
    const a = await richFixture(), b = await richFixture();
    const aExport = await requestExport(a), bExport = await requestExport(b);
    await tick();
    await tick();
    assert.equal((await job(a, aExport.id)).status, "READY");
    assert.equal((await job(b, bExport.id)).status, "READY");
    assert.ok(JSON.stringify((await assertReadyExport(db, a.client, aExport.id)).payload).includes(a.marker));
    assert.ok(JSON.stringify((await assertReadyExport(db, b.client, bExport.id)).payload).includes(b.current));
    const document = {
      a: { accountId: a.accountId, email: a.email,
        participantId: a.cat.participant_id, marker: a.marker,
        exportId: aExport.id,
        cookies: (await a.client.storageState()).cookies },
      b: { accountId: b.accountId, response: b.response,
        marker: b.marker, first: b.first, current: b.current,
        exportId: bExport.id,
        cookies: (await b.client.storageState()).cookies },
    };
    await writeFile(path, JSON.stringify(document), { mode: 0o600, flag: "wx" });
    console.log("Independent restore fixture seeded; private content omitted");
  } else if (process.argv[2] === "delete") {
    const f = JSON.parse(await readFile(path, "utf8"));
    const aClient = await request.newContext({ baseURL: origin,
      extraHTTPHeaders: { Origin: origin }, storageState: { cookies: f.a.cookies, origins: [] } });
    const bClient = await request.newContext({ baseURL: origin,
      extraHTTPHeaders: { Origin: origin }, storageState: { cookies: f.b.cookies, origins: [] } });
    clients.push(aClient, bClient);
    await json(bClient, "post", `/api/e4/v1/responses/${encodeURIComponent(f.b.response)}/delete`,
      { key: randomUUID(), expectedRevision: 2 });
    assert.equal((await storedExport(db, f.b.exportId)).chunks, 0,
      "Response deletion retained the survivor export chunks");
    const a = { client: aClient, accountId: f.a.accountId, email: f.a.email, challengeId: "" };
    const prepared = await prepare(a);
    await confirm(a, prepared.requestId);
    assert.equal((await runDeletionWorkerOnce()).status, "COMPLETE");
    assert.equal((await status(a)).status, "COMPLETE");
    assert.equal((await storedExport(db, f.a.exportId)).chunks, 0,
      "Account deletion retained private export chunks");
    const fresh = await login(a.email), binding = await bind(fresh);
    const freshExport = await requestExport(fresh);
    await tick();
    await assertReadyExport(db, fresh.client, freshExport.id);
    f.a.requestId = prepared.requestId;
    f.a.recoveryCookies = (await aClient.storageState()).cookies;
    f.fresh = { accountId: fresh.accountId, catId: binding.cat.id,
      exportId: freshExport.id,
      cookies: (await fresh.client.storageState()).cookies };
    await writeFile(path, JSON.stringify(f), { mode: 0o600 });
    console.log("Independent deletion completed and same-email fresh account created; private content omitted");
  } else throw Error("Unknown restore fixture phase");
} finally {
  await closeLifecycleProvider();
  await pool.end();
  await dispose();
}
