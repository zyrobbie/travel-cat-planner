import test from "node:test";
import assert from "node:assert/strict";
import { createHash, createHmac } from "node:crypto";
import type { Pool, PoolClient } from "pg";
import { IndependentLedger, type Snapshot } from "../src/server/independent-ledger";

const secret = "synthetic-snapshot-test-secret-0123456789";
const ledgerId = "00000000-0000-4000-8000-000000000001";
const operationId = "00000000-0000-4000-8000-000000000002";
const keyHash = createHash("sha256").update(secret).digest("hex");

type ResultSet = { command: "SELECT"; rows: Record<string, string>[] };

function fixture(): ResultSet[] {
  const events = [];
  let previous = "";
  for (let sequence = 1; sequence <= 2; sequence++) {
    const unsigned = {
      kind: "DELETE_COMPLETE", requestId: `request-${sequence}`, accountId: `account-${sequence}`,
      sequence, previous, at: "2026-10-14T00:00:00.000Z",
    };
    const hash = createHmac("sha256", secret).update(JSON.stringify(unsigned)).digest("hex");
    events.push({ sequence: String(sequence), kind: unsigned.kind, request_id: unsigned.requestId,
      account_id: unsigned.accountId, previous_hash: previous, hash,
      event_json: JSON.stringify({ ...unsigned, hash }) });
    previous = hash;
  }
  return [
    { command: "SELECT", rows: [{ id: ledgerId, key_hash: keyHash }] },
    { command: "SELECT", rows: [{ sequence: "2", hash: previous }] },
    { command: "SELECT", rows: [{ status: "READY", epoch: "1", operation_id: operationId }] },
    { command: "SELECT", rows: events },
    { command: "SELECT", rows: [{ operation_id: operationId, epoch: "1" }] },
  ];
}

async function read(results: unknown) {
  const queries: unknown[][] = [];
  const client = { query: async (...args: unknown[]) => { queries.push(args); return results; } };
  const adapter = new IndependentLedger({} as Pool, {} as Pool, secret);
  // Exercise the isolated reader without opening sockets or loading application env.
  const snapshot = await (adapter as unknown as {
    snapshot(db: PoolClient): Promise<Snapshot>;
  }).snapshot(client as unknown as PoolClient);
  return { snapshot, queries };
}

test("one parameter-free query reads the full ordered snapshot without changing bigint rows", async () => {
  const results = fixture();
  const { snapshot, queries } = await read(results);
  assert.equal(queries.length, 1);
  assert.equal(queries[0].length, 1, "batch must remain a simple query without bound values");
  const sql = queries[0][0] as string;
  assert.equal(sql.split(";").filter(statement => statement.trim()).length, 5);
  assert.match(sql, /FROM ledger_events ORDER BY sequence/);
  assert.match(sql, /FROM restore_operations ORDER BY epoch/);
  assert.equal(snapshot.ledger.id, ledgerId);
  assert.equal(snapshot.ledger.sequence, 2);
  assert.deepEqual(snapshot.ledger.events.map(event => event.sequence), [1, 2]);
  assert.equal(snapshot.epoch, 1);
  assert.equal(snapshot.operationId, operationId);
  assert.equal(results[1].rows[0].sequence, "2");
  assert.equal(results[2].rows[0].epoch, "1");
});

test("missing or malformed result sets fail closed", async () => {
  for (const result of [fixture()[0], fixture().slice(0, 4), [...fixture(), fixture()[0]],
    [...fixture().slice(0, 4), { command: "SELECT", rows: null }]]) {
    await assert.rejects(read(result), /读取结果不完整/);
  }
});

test("missing identity, head, or gate rows fail closed", async () => {
  for (const index of [0, 1, 2]) {
    const result = fixture();
    result[index].rows = [];
    await assert.rejects(read(result), /不完整/);
  }
});

test("wrong secret and corrupt event JSON still fail closed", async () => {
  const wrongKey = fixture();
  wrongKey[0].rows[0].key_hash = "0".repeat(64);
  await assert.rejects(read(wrongKey), /密钥不匹配/);
  const broken = fixture();
  broken[3].rows[0].event_json = "broken-json";
  await assert.rejects(read(broken), /事件格式无效/);
});

test("HMAC, duplicate columns, event order, and chain completeness are still checked", async () => {
  const badSignature = fixture();
  const event = JSON.parse(badSignature[3].rows[0].event_json!);
  event.at = "2026-10-15T00:00:00.000Z";
  badSignature[3].rows[0].event_json = JSON.stringify(event);
  await assert.rejects(read(badSignature), /事件校验失败/);
  const badColumn = fixture();
  badColumn[3].rows[0].account_id = "different-account";
  await assert.rejects(read(badColumn), /事件校验失败/);
  const reversed = fixture();
  reversed[3].rows.reverse();
  await assert.rejects(read(reversed), /事件校验失败/);
  const missing = fixture();
  missing[3].rows.pop();
  await assert.rejects(read(missing), /水位不一致/);
});

test("unsafe bigint head and restore epoch values are rejected", async () => {
  const head = fixture();
  head[1].rows[0].sequence = "9007199254740993";
  await assert.rejects(read(head), /水位不一致/);
  const gate = fixture();
  gate[2].rows[0].epoch = "9007199254740993";
  await assert.rejects(read(gate), /恢复闸门无效/);
});

test("restore operation identity and contiguous epochs are still checked", async () => {
  const gap = fixture();
  gap[4].rows[0].epoch = "2";
  await assert.rejects(read(gap), /代次记录不一致/);
  const wrongOperation = fixture();
  wrongOperation[4].rows[0].operation_id = ledgerId;
  await assert.rejects(read(wrongOperation), /代次记录不一致/);
});
