import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { HttpError } from "../src/server/errors";
import { configuredOtpDelivery, eraseInMemoryOtpRecords, SyntheticMailbox, type OtpMessage } from "../src/server/otp-delivery";
import { createResendOtpDelivery } from "../src/server/resend-otp-delivery";

// Synthetic values only. Every Resend branch injects fetch; no network or DB.
const key = "re_unit_test_not_a_real_key";
const from = "有猫来信 <login@auth.example.test>";
const now = Date.parse("2026-10-12T03:00:00.000Z");
const message: OtpMessage = {
  challengeId: "51aa36b7-e4f9-49c2-aed8-a4ed757700e4",
  email: "synthetic@example.test",
  code: "001234",
  expiresAt: "2026-10-12T03:10:00.000Z",
};
const accepted = () => new Response(JSON.stringify({ id: "test-provider-receipt" }), { status: 200 });
const isSafeFailure = (error: unknown) => {
  assert.ok(error instanceof HttpError);
  assert.equal(error.status, 503);
  const printable = `${error.stack} ${JSON.stringify(error)}`;
  for (const secret of [key, message.email, message.code, "provider-secret-body"])
    assert.ok(!printable.includes(secret));
  assert.equal(error.cause, undefined);
  return true;
};

test("Resend request uses exact endpoint, one recipient, stable challenge key and no OTP subject", async () => {
  const requests: { url: unknown; init: RequestInit }[] = [];
  let clock = now;
  const adapter = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => clock,
    fetch: async (url, init) => { requests.push({ url, init: init! }); return accepted(); },
  });
  assert.equal(adapter.mode, "resend-v1");
  await adapter.send(message);
  clock += 2_000;
  await adapter.send({ ...message });
  assert.equal(requests.length, 2);
  const { url, init } = requests[0];
  assert.equal(url, "https://api.resend.com/emails");
  assert.equal(init.method, "POST");
  assert.equal(init.redirect, "error");
  assert.ok(init.signal instanceof AbortSignal);
  const headers = new Headers(init.headers);
  assert.equal(headers.get("authorization"), `Bearer ${key}`);
  assert.equal(headers.get("content-type"), "application/json");
  assert.equal(headers.get("idempotency-key"), `catletters-login/${message.challengeId}`);
  assert.equal(init.body, requests[1].init.body);
  assert.equal(headers.get("idempotency-key"), new Headers(requests[1].init.headers).get("idempotency-key"));
  const body = JSON.parse(String(init.body));
  assert.deepEqual(body.to, [message.email]);
  assert.equal(body.from, from);
  assert.equal(body.subject, "有猫来信 · 登录验证码");
  assert.ok(!body.subject.includes(message.code));
  assert.match(body.text, /001234/);
  assert.match(body.text, /2026\/10\/12 11:10:00（北京时间）/);
  assert.match(body.text, /不是你的操作/);
  assert.deepEqual(Object.keys(body).sort(), ["from", "subject", "text", "to"]);
});

test("different challenges use different idempotency keys", async () => {
  const keys: string[] = [];
  const adapter = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now,
    fetch: async (_, init) => { keys.push(new Headers(init?.headers).get("idempotency-key")!); return accepted(); },
  });
  await adapter.send(message);
  await adapter.send({ ...message, challengeId: "07d4c431-eb78-480e-8fcf-6d35322ca9e1" });
  assert.notEqual(keys[0], keys[1]);
});

test("configuration is explicit and refuses missing, injected or public-only credentials", () => {
  for (const config of [
    {}, { apiKey: key }, { from }, { apiKey: "invalid", from },
    { apiKey: `${key}\r\nInjected: yes`, from },
    { apiKey: key, from: "One <one@example.test>, Two <two@example.test>" },
    { apiKey: key, from: "login@example.test\r\nBcc: other@example.test" },
    { apiKey: key, from: "not-an-address" },
  ]) assert.throws(() => createResendOtpDelivery(config), isSafeFailure);
  for (const timeoutMs of [0, -1, 15_001, Number.NaN, Infinity, 1.5])
    assert.throws(() => createResendOtpDelivery({ apiKey: key, from }, { timeoutMs }), isSafeFailure);
  assert.throws(() => configuredOtpDelivery({
    APP_MODE: "INTERNAL", OTP_ADAPTER: "resend-v1",
    NEXT_PUBLIC_RESEND_API_KEY: key, VITE_RESEND_API_KEY: key, OTP_FROM: from,
  }), isSafeFailure);
});

test("browser context refuses constructing a credential-bearing sender", () => {
  Object.defineProperty(globalThis, "window", { configurable: true, value: {} });
  try { assert.throws(() => createResendOtpDelivery({ apiKey: key, from }), isSafeFailure); }
  finally { Reflect.deleteProperty(globalThis, "window"); }
});

test("configured delivery requires INTERNAL for both adapters and rejects unknown adapters", async () => {
  for (const mode of [undefined, "PUBLIC", "internal"])
    for (const adapter of ["synthetic-v1", "resend-v1"])
      assert.throws(() => configuredOtpDelivery({
        APP_MODE: mode, OTP_ADAPTER: adapter, RESEND_API_KEY: key, OTP_FROM: from,
      }), isSafeFailure);
  assert.throws(() => configuredOtpDelivery({ APP_MODE: "INTERNAL", OTP_ADAPTER: "unknown" }), isSafeFailure);
  let requests = 0;
  const adapter = configuredOtpDelivery({
    APP_MODE: "INTERNAL", OTP_ADAPTER: "resend-v1", RESEND_API_KEY: key, OTP_FROM: from,
  }, { now: () => now, fetch: async () => { requests++; return accepted(); } });
  await adapter.send(message);
  assert.equal(requests, 1);
  assert.equal(adapter.mode, "resend-v1");
});

test("invalid or expired messages do not make a network request", async () => {
  let requests = 0;
  const adapter = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now, fetch: async () => { requests++; return accepted(); },
  });
  for (const update of [
    { code: "abc123" }, { code: "12345" }, { code: "<12345>" },
    { email: "one@example.test,other@example.test" },
    { challengeId: "invalid\r\nheader" }, { expiresAt: "invalid" },
    { expiresAt: new Date(now).toISOString() }, { expiresAt: new Date(now - 1).toISOString() },
  ]) await assert.rejects(adapter.send({ ...message, ...update }), isSafeFailure);
  assert.equal(requests, 0);
});

test("non-2xx results fail safely with one attempt and no provider body exposed", async () => {
  for (const status of [302, 400, 401, 403, 409, 422, 429, 500, 503]) {
    let requests = 0;
    const adapter = createResendOtpDelivery({ apiKey: key, from }, {
      now: () => now,
      fetch: async () => {
        requests++;
        return new Response(`provider-secret-body ${message.email} ${message.code} ${key}`, { status });
      },
    });
    await assert.rejects(adapter.send(message), isSafeFailure);
    assert.equal(requests, 1);
  }
});

test("network errors do not expose causes, credentials or recipients and never auto-retry", async (t) => {
  const logs: unknown[] = [];
  for (const level of ["error", "warn", "log"] as const) t.mock.method(console, level, (...args: unknown[]) => { logs.push(args); });
  let requests = 0;
  const adapter = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now,
    fetch: async () => { requests++; throw Error(`provider-secret-body ${message.email} ${message.code} ${key}`); },
  });
  await assert.rejects(adapter.send(message), isSafeFailure);
  assert.equal(requests, 1);
  assert.deepEqual(logs, []);
});

test("timeout aborts the request and remains bounded even if injected transport ignores abort", async () => {
  let signal: AbortSignal | null | undefined;
  let requests = 0;
  const adapter = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now, timeoutMs: 20,
    fetch: async (_, init) => { requests++; signal = init?.signal; return new Promise<Response>(() => {}); },
  });
  const started = performance.now();
  await assert.rejects(adapter.send(message), isSafeFailure);
  assert.ok(performance.now() - started < 1_000);
  assert.equal(signal?.aborted, true);
  assert.equal(requests, 1);
});

test("timeout covers body consumption; malformed success receipts fail closed", async () => {
  const bodies = [null, {}, { id: "" }, { id: 7 }, { id: "a".repeat(257) }];
  for (const receipt of bodies) {
    const adapter = createResendOtpDelivery({ apiKey: key, from }, {
      now: () => now, fetch: async () => new Response(JSON.stringify(receipt)),
    });
    await assert.rejects(adapter.send(message), isSafeFailure);
  }
  const slow = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now, timeoutMs: 20,
    fetch: async () => new Response(new ReadableStream({ start() {} })),
  });
  await assert.rejects(slow.send(message), isSafeFailure);
  const invalidJson = createResendOtpDelivery({ apiKey: key, from }, {
    now: () => now, fetch: async () => new Response("provider-secret-body"),
  });
  await assert.rejects(invalidJson.send(message), isSafeFailure);
});

test("existing synthetic in-memory behavior stays isolated, copied and erasable", async () => {
  const standalone = new SyntheticMailbox();
  const input = { ...message };
  await standalone.send(input);
  input.code = "999999";
  assert.equal(standalone.messages.get(message.challengeId)?.code, message.code);
  const adapter = configuredOtpDelivery({ APP_MODE: "INTERNAL", OTP_ADAPTER: "synthetic-v1" }, {
    fetch: async () => { throw Error("Synthetic must not call fetch"); },
  }) as SyntheticMailbox;
  assert.equal(adapter.mode, "synthetic-v1");
  await adapter.send(message);
  assert.deepEqual(adapter.messages.get(message.challengeId), message);
  eraseInMemoryOtpRecords([message.challengeId]);
  assert.equal(adapter.messages.size, 0);
  assert.equal(standalone.messages.size, 1);
});

test("existing synthetic private-file behavior preserves exclusive writes and permissions", async () => {
  const directory = await mkdtemp(join(tmpdir(), "cat-otp-adapter-test-"));
  try {
    const adapter = configuredOtpDelivery({
      APP_MODE: "INTERNAL", OTP_ADAPTER: "synthetic-v1", E4_SYNTHETIC_MAILBOX_DIR: directory,
    });
    assert.equal(adapter.mode, "synthetic-v1");
    await adapter.send(message);
    const path = join(directory, `${message.challengeId}.json`);
    assert.deepEqual(JSON.parse(await readFile(path, "utf8")), message);
    assert.equal((await stat(path)).mode & 0o777, 0o600);
    await assert.rejects(adapter.send(message), { code: "EEXIST" });
    assert.throws(() => configuredOtpDelivery({
      APP_MODE: "INTERNAL", OTP_ADAPTER: "synthetic-v1", E4_SYNTHETIC_MAILBOX_DIR: "relative/path",
    }), /must be absolute/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});
