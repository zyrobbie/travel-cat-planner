import { X509Certificate } from "node:crypto";
import type { PoolConfig } from "pg";

const conflictingParameters = new Set([
  "host", "ssl", "sslmode", "sslrootcert", "sslcert", "sslkey", "sslnegotiation",
]);
const localHosts = new Set(["localhost", "127.0.0.1", "[::1]"]);

/** Keep the URL's host and the TLS identity checked by node-postgres aligned. */
export function postgresTlsConfig(connectionString: string | undefined): Pick<PoolConfig, "ssl"> {
  // Next collects route modules during build without runtime database secrets.
  // Pool construction opens no socket; the E4 runtime validates both URLs.
  if (!connectionString) return {};
  let url: URL;
  try { url = new URL(connectionString); }
  catch { throw new Error("PostgreSQL connection URL is invalid."); }
  if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname)
    throw new Error("PostgreSQL connection URL must name a host.");
  if ([...url.searchParams.keys()].some(key => conflictingParameters.has(key.toLowerCase())))
    throw new Error("PostgreSQL URL contains parameters that can override the verified TLS configuration.");

  // Local PostgreSQL fixtures use plain TCP. A hosted runtime always requires
  // verified TLS, even if it was accidentally configured with a local URL.
  if (localHosts.has(url.hostname) && process.env.NETLIFY !== "true") return {};

  const value = process.env.E4_PG_CA_PEM;
  if (!value) throw new Error("PostgreSQL CA certificate is not configured.");
  const ca = value.replace(/\\n/g, "\n").trim() + "\n";
  try { new X509Certificate(ca); }
  catch { throw new Error("PostgreSQL CA certificate is invalid."); }
  // pg passes this object to Node TLS and supplies the URL hostname as SNI.
  // rejectUnauthorized also enforces the default hostname identity check.
  return { ssl: { ca, rejectUnauthorized: true } };
}
