import { ensure } from "./errors";

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const validationEmail = (id: string) =>
  `e4-lifecycle-${id}@example.invalid`;

/** Trusted operator environment only. No HTTP route accepts these options. */
export function validationScope() {
  const env = process.env;
  ensure(
    env.APP_MODE === "INTERNAL" &&
      env.E4_CLOUD_LIFECYCLE_VALIDATION_ENABLED === "true",
    503,
    "受控生命周期验证未启用。",
  );
  ensure(
    env.E4_LIFECYCLE_ADAPTER === "postgres-v1" &&
      env.E4_EXPORT_STORAGE === "postgres" &&
      env.E4_LIFECYCLE_BOOTSTRAP !== "true" &&
      env.E4_LIFECYCLE_RECOVERY !== "true",
    503,
    "受控验证必须使用正常两库守护及私有 PostgreSQL 导出。",
  );
  for (const [key, role] of [
    ["DATABASE_URL", "cat_letters_app"],
    ["E4_LEDGER_DATABASE_URL", "cat_letters_ledger"],
  ]) {
    let user = "";
    let connection: URL | undefined;
    try {
      connection = new URL(env[key] ?? "");
      user = decodeURIComponent(connection.username);
    } catch {}
    ensure(
      user === role || user.startsWith(role + "."),
      503,
      "验证只能连接既有受限运行角色。",
    );
    ensure(
      connection &&
        (["127.0.0.1", "localhost", "[::1]"].includes(connection.hostname) ||
          connection.port === "" ||
          connection.port === "5432"),
      503,
      "云连接必须使用 direct/session 5432，不能使用 transaction pool。",
    );
  }
  const accountId = env.E4_CLOUD_LIFECYCLE_VALIDATION_ACCOUNT_ID?.toLowerCase();
  const until = env.E4_CLOUD_LIFECYCLE_VALIDATION_UNTIL;
  ensure(
    accountId &&
      uuid.test(accountId) &&
      until &&
      /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(until),
    503,
    "固定合成账号或验证截止时间无效。",
  );
  const untilAt = Date.parse(until);
  ensure(
    Number.isSafeInteger(untilAt) &&
      untilAt > Date.now() &&
      untilAt <= Date.now() + 3_600_000,
    503,
    "验证窗口已到期或超过一小时。",
  );
  return { accountId, email: validationEmail(accountId), untilAt };
}

export function validationDeadline(startedAt = Date.now()) {
  // Local operator CLI, not a Scheduled Function. Its single call is bounded
  // to 60s; the application's existing 25s scheduled runner is unchanged.
  return Math.min(startedAt + 60_000, validationScope().untilAt);
}

export function validationOrigin() {
  const u = new URL(process.env.APP_ORIGIN ?? "");
  ensure(
    u.origin === (process.env.APP_ORIGIN ?? "") &&
      !u.username &&
      !u.password &&
      (u.protocol === "https:" ||
        (u.protocol === "http:" &&
          u.hostname === "127.0.0.1" &&
          process.env.NETLIFY !== "true")),
    503,
    "验证地址必须是明确的 HTTPS origin 或本机隔离地址。",
  );
  return u.origin;
}

export function validationControlId() {
  const id =
    process.env.E4_CLOUD_LIFECYCLE_VALIDATION_CONTROL_ID?.toLowerCase();
  ensure(
    id && uuid.test(id) && id !== validationScope().accountId,
    503,
    "固定对照合成账号无效。",
  );
  return id;
}
