import { runCloudWorkerOnce, type CloudWorkerScope } from "./cloud-worker";
import { runDeletionWorkerOnce } from "./account-lifecycle";
import { cleanupAccountExportsBounded, runExportWorkerOnce } from "./account-export";
import { configuredExportStorage } from "./export-storage";
import { lifecycleAdapterMode } from "./lifecycle-provider";
import { assertInternal } from "./safety";
import { ensure } from "./errors";
import { remainingMs, requireWindow } from "./scheduler-budget";

const CALL_MS = 25_000;
const CLAIM_STOP_MS = 20_000;
const MIN_START_MS = 7_000;

function start(invocationDeadlineAt?: number) {
  assertInternal();
  ensure(
    process.env.E4_SCHEDULED_RUN === "true" &&
      lifecycleAdapterMode() === "postgres-v1" &&
      configuredExportStorage().kind === "postgres",
    503,
    "定时候选必须使用受限连接池、独立账本及 PostgreSQL 私有导出。",
  );
  const startedAt = Date.now();
  ensure(
    invocationDeadlineAt === undefined ||
      Number.isSafeInteger(invocationDeadlineAt),
    503,
    "调度调用截止时间无效。",
  );
  return {
    startedAt,
    deadlineAt: Math.min(startedAt + CALL_MS, invocationDeadlineAt ?? Infinity),
  };
}

/** Internal caller budget only; never populated from an HTTP payload. */
export type CloudTickOptions = {
  invocationDeadlineAt?: number;
  maxJobs?: number;
};

/** Shared bounded runner for the manual worker and scoped scheduled function. */
export async function cloudTick(
  scope?: CloudWorkerScope,
  options: CloudTickOptions = {},
) {
  const maxJobs = options.maxJobs ?? 5;
  ensure(
    Number.isInteger(maxJobs) && maxJobs >= 1 && maxJobs <= 5,
    503,
    "调度任务上限无效。",
  );
  const { startedAt, deadlineAt } = start(options.invocationDeadlineAt);
  const outcomes = [];
  for (let i = 0; i < maxJobs && Date.now() - startedAt < CLAIM_STOP_MS; i++) {
    if (remainingMs(deadlineAt) <= MIN_START_MS) break;
    const outcome = await runCloudWorkerOnce(deadlineAt, scope);
    if (outcome.status === "IDLE") break;
    outcomes.push(outcome);
  }
  return {
    kind: "cloud",
    attempted: outcomes.length,
    outcomes,
    elapsedMs: Date.now() - startedAt,
  };
}

/** One heavy task per call. Automatic deletion selects PENDING only;
 * explicit retry controls FAILED deletions so they cannot starve exports. */
export async function privacyTick() {
  const { startedAt, deadlineAt } = start();
  requireWindow(deadlineAt, MIN_START_MS);
  const deletion = await runDeletionWorkerOnce({ deadlineAt, pendingOnly: true });
  if (deletion.status !== "IDLE")
    return { kind: "privacy", task: "deletion", outcome: deletion,
      elapsedMs: Date.now() - startedAt };
  // Disabled until a full near-32MiB product export proves a 25s margin.
  if (process.env.E4_SCHEDULED_EXPORTS_ENABLED !== "true")
    return { kind: "privacy", task: "export", outcome: { status: "DISABLED" },
      elapsedMs: Date.now() - startedAt };
  requireWindow(deadlineAt, MIN_START_MS);
  const outcome = await runExportWorkerOnce(deadlineAt);
  return { kind: "privacy", task: "export", outcome,
    elapsedMs: Date.now() - startedAt };
}

export async function privacyCleanupTick() {
  const { startedAt, deadlineAt } = start();
  const outcome = await cleanupAccountExportsBounded(deadlineAt, 100);
  return { kind: "cleanup", outcome, elapsedMs: Date.now() - startedAt };
}
