import { z } from "zod";
import { HttpError } from "./errors";
import type { OtpDelivery, OtpMessage } from "./otp-delivery";

export type ResendOtpConfig = { apiKey?: string; from?: string };
export type ResendOtpDependencies = {
  fetch?: typeof globalThis.fetch;
  now?: () => number;
  timeoutMs?: number;
};

const unavailable = () => new HttpError(503, "验证码服务尚未配置。");
const failed = () => new HttpError(503, "验证码未能就绪，请稍后重新请求。");

/** Server-only credentials. Never use NEXT_PUBLIC_* or VITE_* for these values. */
export function createResendOtpDelivery(
  config: ResendOtpConfig,
  dependencies: ResendOtpDependencies = {},
): OtpDelivery {
  const apiKey = config.apiKey?.trim();
  const from = config.from?.trim();
  const address = from?.match(/^[^<>\r\n]+ <([^<>\r\n]+)>$/)?.[1] ?? from;
  const timeoutMs = dependencies.timeoutMs ?? 10_000;
  if (
    typeof window !== "undefined" ||
    !apiKey || !/^re_[A-Za-z0-9_-]+$/.test(apiKey) ||
    !from || /[\r\n]/.test(from) ||
    !z.email().max(254).safeParse(address).success ||
    !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 15_000
  ) throw unavailable();

  const sendFetch = dependencies.fetch ?? globalThis.fetch;
  const now = dependencies.now ?? Date.now;
  return {
    mode: "resend-v1",
    async send(message: OtpMessage) {
      const expiresAt = Date.parse(message.expiresAt);
      if (
        !z.uuid().safeParse(message.challengeId).success ||
        !z.email().max(254).safeParse(message.email).success ||
        !/^\d{6}$/.test(message.code) ||
        !Number.isFinite(expiresAt) || expiresAt <= now()
      ) throw failed();

      // This value is stable across attempts for the same challenge. Do not use
      // a relative countdown: it would change the payload for the same key.
      const deadline = new Intl.DateTimeFormat("zh-CN", {
        timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
      }).format(expiresAt);
      const controller = new AbortController();
      let timer: ReturnType<typeof setTimeout> | undefined;
      try {
        const timeout = new Promise<never>((_, reject) => {
          timer = setTimeout(() => {
            controller.abort();
            reject(failed());
          }, timeoutMs);
        });
        await Promise.race([
          (async () => {
            const response = await sendFetch("https://api.resend.com/emails", {
              method: "POST",
              redirect: "error",
              signal: controller.signal,
              headers: {
                Authorization: `Bearer ${apiKey}`,
                "Content-Type": "application/json",
                "Idempotency-Key": `catletters-login/${message.challengeId}`,
              },
              body: JSON.stringify({
                from,
                to: [message.email],
                subject: "有猫来信 · 登录验证码",
                text: [
                  "你正在登录有猫来信。",
                  `登录验证码：${message.code}`,
                  `请于 ${deadline}（北京时间）前完成验证。请勿将验证码转告他人。`,
                  "如果这不是你的操作，请忽略这封邮件。",
                ].join("\n\n"),
              }),
            });
            if (!response.ok) throw failed();
            const receipt: unknown = await response.json();
            if (!receipt || typeof receipt !== "object" || !("id" in receipt) ||
              typeof receipt.id !== "string" || !receipt.id.trim() || receipt.id.length > 256)
              throw failed();
            // A receipt means provider acceptance, not delivery to the inbox.
          })(),
          timeout,
        ]);
      } catch {
        // Never propagate provider bodies/errors: they may contain addresses,
        // OTPs or credentials. The caller revokes challenges on unknown outcomes.
        throw failed();
      } finally {
        if (timer !== undefined) clearTimeout(timer);
        controller.abort();
      }
    },
  };
}
