import { CONTINUOUS_MAX_SLOTS, type ContinuousScope, type continuousPlan } from "./continuous-scope";
import { readCursor, writeCursor } from "./continuous-state";
type Plan=NonNullable<ReturnType<typeof continuousPlan>>;

/** Caller holds the OS flock. Advancing before work avoids a crashing slot
 * starving later accounts; the job's durable lease remains the work authority. */
export async function runContinuousCycle(plan:Plan,dir:string,deadlineAt:number,
  run:(scope:ContinuousScope,deadlineAt:number)=>Promise<{status:string}>) {
  const cursor=await readCursor(dir,plan.digest,plan.slots.length);
  const outcomes:{task:string;status:string}[]=[];
  for(let i=0;i<Math.min(CONTINUOUS_MAX_SLOTS,plan.slots.length)&&deadlineAt-Date.now()>7000;i++) {
    const scope=plan.slots[cursor.next];
    cursor.next=(cursor.next+1)%plan.slots.length;
    await writeCursor(dir,cursor);
    try {outcomes.push({task:scope.task,status:(await run(scope,deadlineAt)).status});}
    catch {outcomes.push({task:scope.task,status:"UNKNOWN_CHECK_DURABLE_STATE"});break;}
  }
  const failed=outcomes.some(o=>["FAILED","RETRY","UNKNOWN_CHECK_DURABLE_STATE"].includes(o.status));
  return {status:failed?"ATTENTION":outcomes.length?"OK":"BUDGET_EXHAUSTED",outcomes,failed};
}
