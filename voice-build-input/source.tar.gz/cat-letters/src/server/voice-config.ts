import { stat, access, lstat, mkdir } from "node:fs/promises";
import { constants } from "node:fs";
import { isAbsolute } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { voiceDirectory } from "./voice-directory";
import { ensure } from "./errors";
import {
  VOICE_MAX_BYTES,
  VOICE_MAX_MS,
  VOICE_MIMES,
  type VoiceCapabilities,
} from "../shared/voice";
export function voiceScope(accountId: string) {
  ensure(
    process.env.APP_MODE === "INTERNAL" &&
      process.env.E4_VOICE_ENABLED === "true" &&
      process.env.E4_VOICE_BACKUP_POLICY === "exclude-ephemeral-v1",
    503,
    "语音暂不可用，你可以继续打字。",
  );
  let ids: unknown;
  try {
    ids = JSON.parse(process.env.E4_VOICE_ACCOUNT_IDS ?? "null");
  } catch {}
  ensure(
    Array.isArray(ids) &&
      ids.length > 0 &&
      ids.length <= 10 &&
      ids.every(
        (x) =>
          typeof x === "string" &&
          /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(
            x,
          ),
      ) &&
      new Set(ids).size === ids.length &&
      ids.includes(accountId),
    503,
    "语音暂不可用，你可以继续打字。",
  );
}
let checkedTools = { key: "", until: 0 };
const run = promisify(execFile);
export async function voiceCapabilities(
  accountId: string,
): Promise<VoiceCapabilities> {
  const base = {
    available: false,
    reason: process.env.E4_VOICE_ENABLED === "true" ? "unavailable" as const : "disabled" as const,
    mode: "disabled",
    maxMs: VOICE_MAX_MS,
    maxBytes: VOICE_MAX_BYTES,
    mimes: VOICE_MIMES,
  };
  try {
    voiceScope(accountId);
    let key = "";
    const paths = [process.env.E4_VOICE_FFPROBE, process.env.E4_VOICE_FFMPEG];
    for (const path of paths) {
      ensure(path && isAbsolute(path), 503, "语音格式校验未配置。");
      await access(path, constants.X_OK);
      const st = await stat(path);
      ensure(st.isFile(), 503, "语音校验不可用。");
      key += `${path}:${st.mtimeMs};`;
    }
    if (checkedTools.key !== key || checkedTools.until < Date.now()) {
      for (let i = 0; i < paths.length; i++) {
        const result = await run(paths[i]!, ["-version"], {
          env: { LANG: "C", PATH: "/usr/bin:/bin", NODE_ENV: "production" },
          timeout: 2000,
          maxBuffer: 16384,
        });
        ensure(
          result.stdout.startsWith(
            i === 0 ? "ffprobe version " : "ffmpeg version ",
          ),
          503,
          "语音工具不可用。",
        );
      }
      checkedTools = { key, until: Date.now() + 60_000 };
    }
    await voiceDirectory();
    const { configuredVoicePayloadStore } = await import("./voice-payload-store");
    await (await configuredVoicePayloadStore()).healthCheck();
    const { configuredVoiceProvider } = await import("./voice-provider");
    const p = configuredVoiceProvider();
    return {
      ...base,
      available: true,
      mode: p.mode,
      ...(p.mode === "tencent-sentence-v1"
        ? {
            privacyNotice:
              "录音将交给腾讯云转成文字。服务商的转写文本可能保留7天，应用的临时音频清理不代表服务商副本已删除。仅使用免费额度，服务不可用时仍可打字。",
          }
        : {}),
    };
  } catch {
    return base;
  }
}
