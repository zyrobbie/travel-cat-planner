import type { PoolClient } from "pg";
import {
  lockCloudCat,
  cloudStateView,
  cloudLettersView,
} from "./cloud-repository";
import { cloudResponsesView } from "./cloud-sources";
import { settleCloudCalendar } from "./cloud-calendar";

/** Account/session and lifecycle guard are held by the caller for this request. */
export async function cloudAccountView(db: PoolClient, accountId: string) {
  const cat = await lockCloudCat(db, accountId);
  await settleCloudCalendar(db, cat);
  const world = await cloudStateView(db, cat);
  const mailbox = await cloudLettersView(db, cat);
  const sent = await cloudResponsesView(db, cat);
  return { world, mailbox, sent };
}
