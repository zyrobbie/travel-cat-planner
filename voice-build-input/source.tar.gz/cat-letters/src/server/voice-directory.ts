import { lstat, mkdir, realpath, access } from "node:fs/promises";
import { constants } from "node:fs";
import { resolve, isAbsolute, dirname, basename } from "node:path";
import { ensure } from "./errors";
const privatePath = (p: string) =>
  !p
    .split(/[\\/]/)
    .some((x) =>
      [
        "public",
        "dist",
        "pages-dist",
        "assets",
        "static",
        ".git",
        ".next",
        "node_modules",
        "ui-components-v1",
        "ui-daily-core-v1",
      ].includes(x.toLowerCase()),
    );
/** Resolve aliases before creating anything; never allow static or repo internals. */
export async function voiceDirectory(options: { forCleanup?: boolean } = {}) {
  const configured = process.env.E4_VOICE_PROBE_DIRECTORY;
  ensure(configured && isAbsolute(configured), 503, "语音临时目录未配置。");
  const normalized = resolve(configured);
  ensure(privatePath(normalized), 503, "语音临时目录配置无效。");
  // Validate the real storage boundary before creating or writing a probe file.
  const { configuredVoicePayloadStore } = await import("./voice-payload-store");
  const store = await configuredVoicePayloadStore();
  if (options.forCleanup) await store.list();
  else await store.healthCheck();
  const expected = process.env.E4_VOICE_STORAGE === "tmpfs-private-v1"
    ? "/run/cat-voice-private/probe"
    : resolve(process.env.E4_VOICE_TEST_PAYLOAD_ROOT ?? "", "probe");
  ensure(normalized === expected, 503, "语音临时目录必须与私有存储共同隔离。");
  let ancestor = normalized;
  const missing: string[] = [];
  for (;;) {
    try {
      await lstat(ancestor);
      break;
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
      missing.unshift(basename(ancestor));
      ancestor = dirname(ancestor);
    }
  }
  const path = resolve(await realpath(ancestor), ...missing);
  ensure(privatePath(path), 503, "语音临时目录配置无效。");
  if (missing.length === 0)
    ensure(
      !(await lstat(normalized)).isSymbolicLink(),
      503,
      "语音临时目录不可使用符号链接。",
    );
  // A full mount must still permit deletion. Cleanup never creates directories.
  if (options.forCleanup && missing.length > 0) return path;
  await mkdir(path, { recursive: true, mode: 0o700 });
  const st = await lstat(path);
  ensure(
    st.isDirectory() &&
      !st.isSymbolicLink() &&
      (st.mode & 0o077) === 0 &&
      st.uid === process.getuid?.(),
    503,
    "语音临时目录不可用。",
  );
  await access(path, constants.W_OK);
  return path;
}
