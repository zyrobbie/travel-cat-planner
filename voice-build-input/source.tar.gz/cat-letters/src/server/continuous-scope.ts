import { createHash } from "node:crypto";
import { ensure } from "./errors";

export type ContinuousTask = "delivery" | "export" | "deletion" | "cleanup";
export type ContinuousScope = Readonly<{ task: ContinuousTask; accountId: string }>;
const issued = new WeakSet<ContinuousScope>();
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const CONTINUOUS_BUDGET_MS = 25_000;
export const CONTINUOUS_MAX_SLOTS = 5;
export const CONTINUOUS_LATEST_UNTIL = Date.parse("2026-11-06T10:00:00Z");
const tasks: ContinuousTask[] = ["delivery", "deletion", "export", "cleanup"];

function flag(name: string) {
  const value = process.env[name];
  ensure(value === undefined || value === "false" || value === "true", 503, "INVALID_CONTINUOUS_FLAG");
  return value === "true";
}
function ids(task: ContinuousTask) {
  if (!flag(`E4_CONTINUOUS_${task.toUpperCase()}_ENABLED`)) return [];
  let value: unknown;
  try { value = JSON.parse(process.env[`E4_CONTINUOUS_${task.toUpperCase()}_ACCOUNT_IDS`] ?? "null"); }
  catch { value = null; }
  ensure(Array.isArray(value) && value.length >= 1 && value.length <= 10 &&
    value.every((id: unknown) => typeof id === "string" && uuid.test(id)) &&
    new Set(value).size === value.length, 503, "INVALID_FIXED_ACCOUNT_SCOPE");
  return (value as string[]).slice().sort();
}
export function continuousUntil() {
  const until=process.env.E4_CONTINUOUS_UNTIL??"";
  const at=Date.parse(until);
  ensure(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(until)&&
    Number.isSafeInteger(at)&&at<=CONTINUOUS_LATEST_UNTIL,503,"INVALID_CONTINUOUS_CUTOFF");
  return at;
}
export function continuousStatus() {
  return !flag("E4_CONTINUOUS_ENABLED")?"DISABLED":continuousUntil()<=Date.now()?"EXPIRED":"ENABLED";
}
function guards() {
  const env = process.env;
  ensure(env.APP_MODE === "INTERNAL" && env.SAFETY_ADAPTER === "synthetic-v1" &&
    env.NETLIFY !== "true" && env.E4_LIFECYCLE_ADAPTER === "postgres-v1" &&
    env.E4_EXPORT_STORAGE === "postgres" && env.E4_LIFECYCLE_BOOTSTRAP !== "true" &&
    env.E4_LIFECYCLE_RECOVERY !== "true", 503, "INVALID_CONTINUOUS_RUNTIME");
  for (const [key,role] of [["DATABASE_URL","cat_letters_app"],["E4_LEDGER_DATABASE_URL","cat_letters_ledger"]]) {
    let u: URL | undefined;
    try { u = new URL(env[key] ?? ""); } catch {}
    const user = u ? decodeURIComponent(u.username) : "";
    ensure(u && ["postgres:","postgresql:"].includes(u.protocol) &&
      (user === role || user.startsWith(role+".")) &&
      (["127.0.0.1","localhost","[::1]"].includes(u.hostname) || u.port === "" || u.port === "5432"),
      503, "RESTRICTED_SESSION_CONNECTION_REQUIRED");
  }
}

/** Environment is loaded by systemd from root-managed files. No request/CLI
 * arguments can add accounts. Capabilities cannot be recreated from JSON. */
export function continuousPlan() {
  if (continuousStatus()!=="ENABLED") return null;
  guards();
  const lists = tasks.map(ids);
  const union = [...new Set(lists.flat())].sort();
  ensure(union.length >= 1 && union.length <= 10, 503, "INVALID_CONTINUOUS_TOTAL_SCOPE");
  const slots: ContinuousScope[] = [];
  for (const accountId of union) for (let i=0;i<tasks.length;i++) if(lists[i].includes(accountId)) {
    const scope = Object.freeze({task:tasks[i],accountId});
    issued.add(scope); slots.push(scope);
  }
  return Object.freeze({ slots: Object.freeze(slots),untilAt:continuousUntil(),digest:createHash("sha256").update(JSON.stringify({slots,untilAt:continuousUntil()})).digest("hex") });
}

export function assertContinuousScope(scope: ContinuousScope, task: ContinuousTask, accountId = scope?.accountId) {
  ensure(scope && issued.has(scope) && scope.task === task && scope.accountId === accountId &&
    continuousStatus()==="ENABLED", 503, "UNAUTHORIZED_CONTINUOUS_SCOPE");
  guards();
  ensure(ids(task).includes(accountId), 503, "CONTINUOUS_SCOPE_REVOKED");
}
