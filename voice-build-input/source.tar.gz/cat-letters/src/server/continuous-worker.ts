import { randomUUID } from "node:crypto";
import pg, { type PoolClient } from "pg";
import { pool, transaction } from "./db";
import { independentLedger } from "./lifecycle-provider";
import { runCloudWorkerOnce } from "./cloud-worker";
import { runClaimedAccountExport, type ExportClaim } from "./account-export";
import { runDeletionWorkerOnce } from "./account-lifecycle";
import { assertContinuousScope, continuousUntil, CONTINUOUS_BUDGET_MS, type ContinuousScope } from "./continuous-scope";
import { ensure } from "./errors";
import { armConnectionDeadline, requireWindow } from "./scheduler-budget";
import { postgresTlsConfig } from "./postgres-tls";

const roleSql = `SELECT current_user AS role,r.rolsuper,r.rolbypassrls,r.rolcreatedb,r.rolcreaterole,r.rolreplication,
 has_schema_privilege(current_user,'public','CREATE') AS schema_create,
 EXISTS(SELECT 1 FROM pg_class WHERE relowner=current_user::regrole AND relnamespace='public'::regnamespace) AS owns_tables
 FROM pg_roles r WHERE rolname=current_user`;
async function restricted(db: pg.Client | PoolClient, expected: string) {
  const row=(await db.query(roleSql)).rows[0];
  ensure(row && row.role===expected && Object.entries(row).every(([k,v])=>k==="role"||v===false),503,"UNSAFE_CONTINUOUS_DATABASE_ROLE");
}
/** Read-only, no account enumeration, no grant/migration/restore operation. */
export async function preflightContinuous(deadlineAt: number) {
  requireWindow(deadlineAt,7000);
  // Role metadata has no account payloads and needs no business transaction.
  // Actual job reads/writes still perform the complete original dual-DB guard.
  const business=await pool.connect();
  let lost=false;
  const onBusinessError=()=>{lost=true;};
  business.on("error",onBusinessError);
  const cancelBusiness=armConnectionDeadline(business,deadlineAt,()=>{lost=true;});
  try {await restricted(business,"cat_letters_app");ensure(!lost,503,"BUSINESS_PREFLIGHT_CONNECTION_LOST");}
  catch(e){lost=true;throw e;}finally{cancelBusiness();business.removeListener("error",onBusinessError);business.release(lost);}
  const url=process.env.E4_LEDGER_DATABASE_URL;
  const client=new pg.Client({connectionString:url,...postgresTlsConfig(url),connectionTimeoutMillis:3000});
  let ledgerLost=false;const onLedgerError=()=>{ledgerLost=true;};client.on("error",onLedgerError);
  const disarm=armConnectionDeadline(client as PoolClient,deadlineAt,()=>{ledgerLost=true;});
  try {
    await client.connect(); await restricted(client,"cat_letters_ledger");
    const r=(await client.query(`SELECT has_table_privilege(current_user,'ledger_events','UPDATE,DELETE') AS rewrite,
      has_table_privilege(current_user,'restore_gate','UPDATE') AS gate,
      has_table_privilege(current_user,'restore_operations','INSERT') AS restore`)).rows[0];
    ensure(Object.values(r).every(v=>v===false),503,"UNSAFE_CONTINUOUS_LEDGER_GRANTS");
    ensure(!ledgerLost,503,"LEDGER_PREFLIGHT_CONNECTION_LOST");
  } finally { disarm();await client.end().catch(()=>{});client.removeListener("error",onLedgerError); }
}

async function active(db:PoolClient,scope:ContinuousScope) {
  assertContinuousScope(scope,scope.task);
  return !!(await db.query("SELECT id FROM accounts WHERE id=$1 AND status='ACTIVE' FOR UPDATE",[scope.accountId])).rows[0];
}
export async function claimContinuousExport(scope:ContinuousScope,deadlineAt:number):Promise<ExportClaim|null> {
  assertContinuousScope(scope,"export");deadlineAt=Math.min(deadlineAt,continuousUntil());requireWindow(deadlineAt,7000);
  return transaction(async db=>{
    if(!await active(db,scope))return null;
    await db.query(`WITH exhausted AS (SELECT id FROM account_exports WHERE account_id=$1 AND status='BUILDING'
      AND lease_until<=clock_timestamp() AND attempts>=5 FOR UPDATE SKIP LOCKED)
      UPDATE account_exports e SET status='FAILED',lease_token=NULL,lease_until=NULL,last_error='RETRIES_EXHAUSTED'
      FROM exhausted x WHERE e.id=x.id AND e.account_id=$1`,[scope.accountId]);
    const r=await db.query(`SELECT id FROM account_exports WHERE account_id=$1 AND attempts<5
      AND (status='QUEUED' OR (status='BUILDING' AND lease_until<=clock_timestamp()))
      ORDER BY created_at,id FOR UPDATE SKIP LOCKED LIMIT 1`,[scope.accountId]);
    if(!r.rows[0])return null;
    const leaseToken=randomUUID();
    await db.query(`UPDATE account_exports SET status='BUILDING',lease_token=$3,
      lease_until=clock_timestamp()+interval '60 seconds',attempts=attempts+1,last_error=NULL
      WHERE id=$1 AND account_id=$2`,[r.rows[0].id,scope.accountId,leaseToken]);
    return {id:r.rows[0].id,accountId:scope.accountId,leaseToken};
  },{deadlineAt});
}

/** Same export cleanup rules as bounded cleanup, every selector UUID scoped.
 * No global rate-limit sweep; at most 100 selected rows/chunks per call. */
export async function cleanupContinuousExports(scope:ContinuousScope,deadlineAt:number) {
  assertContinuousScope(scope,"cleanup");deadlineAt=Math.min(deadlineAt,continuousUntil());requireWindow(deadlineAt,7000);
  return independentLedger(pool).withExclusive(op=>op.businessTx(async db=>{
    assertContinuousScope(scope,"cleanup");
    await db.query("SELECT id FROM accounts WHERE id=$1 FOR UPDATE",[scope.accountId]);
    let left=100;
    const expired=await db.query(`WITH selected AS (SELECT id FROM account_exports
      WHERE account_id=$1 AND status='READY' AND expires_at<=clock_timestamp()
      ORDER BY created_at,id LIMIT $2 FOR UPDATE SKIP LOCKED)
      UPDATE account_exports e SET status='EXPIRED',lease_token=NULL,lease_until=NULL
      FROM selected s WHERE e.id=s.id AND e.account_id=$1 RETURNING e.id`,[scope.accountId,left]);
    left-=expired.rowCount??0;
    const revoked=left>0?await db.query(`WITH selected AS (SELECT e.id FROM account_exports e
      WHERE e.account_id=$1 AND e.status='READY' AND NOT EXISTS(
        SELECT 1 FROM accounts a LEFT JOIN cat_profiles c ON c.account_id=a.id
        LEFT JOIN cloud_state s ON s.cat_id=c.id AND s.account_id=a.id
        WHERE a.id=$1 AND a.status='ACTIVE' AND e.cat_id IS NOT DISTINCT FROM c.id
        AND e.captured_revision IS NOT DISTINCT FROM s.revision)
      ORDER BY e.created_at,e.id LIMIT $2 FOR UPDATE OF e SKIP LOCKED)
      UPDATE account_exports e SET status='REVOKED' FROM selected s
      WHERE e.id=s.id AND e.account_id=$1 RETURNING e.id`,[scope.accountId,left]):null;
    left-=revoked?.rowCount??0;
    const chunks=left>0?await db.query(`WITH selected AS (
      SELECT p.export_id,p.artifact_name,p.chunk_index FROM private_export_chunks p
      JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1
      AND NOT (e.status='READY' AND e.artifact_name=p.artifact_name)
      AND NOT (e.status='BUILDING' AND e.lease_until>clock_timestamp())
      ORDER BY p.export_id,p.artifact_name,p.chunk_index LIMIT $2 FOR UPDATE OF p SKIP LOCKED)
      DELETE FROM private_export_chunks p USING selected s
      WHERE p.export_id=s.export_id AND p.artifact_name=s.artifact_name
      AND p.chunk_index=s.chunk_index RETURNING p.export_id`,[scope.accountId,left]):null;
    return {status:"CLEANED",selected:100-left+(chunks?.rowCount??0),expired:expired.rowCount??0,
      revoked:revoked?.rowCount??0,removed:chunks?.rowCount??0,rateLimits:0};
  }),deadlineAt);
}
export async function runContinuousSlot(scope:ContinuousScope,deadlineAt:number):Promise<{status:string}> {
  assertContinuousScope(scope,scope.task);
  deadlineAt=Math.min(deadlineAt,Date.now()+CONTINUOUS_BUDGET_MS,continuousUntil());
  if(scope.task==="delivery")return runCloudWorkerOnce(deadlineAt,{accountId:scope.accountId,allowBudgetRecovery:true,continuous:scope});
  if(scope.task==="cleanup")return cleanupContinuousExports(scope,deadlineAt);
  if(scope.task==="deletion")return runDeletionWorkerOnce({deadlineAt,pendingOnly:true,continuous:scope});
  const claim=await claimContinuousExport(scope,deadlineAt);
  return claim?runClaimedAccountExport(claim,deadlineAt):{status:"IDLE"};
}
