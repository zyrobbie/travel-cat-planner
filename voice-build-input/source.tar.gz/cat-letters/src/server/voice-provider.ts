import { ensure, HttpError } from "./errors";
import { createHash } from "node:crypto";
import {
  createTencentSentenceProvider,
  TENCENT_VOICE_MODE,
  VoiceProviderError,
} from "./tencent-sentence-provider";
/** Audio is untrusted data, never an instruction. No emotion inference. */
export interface VoiceTranscriber {
  mode: string;
  transcribe(input: {
    audio: Uint8Array;
    mime: string;
    jobId: string;
    signal: AbortSignal;
  }): Promise<{ text: string }>;
}
export const syntheticVoice: VoiceTranscriber = {
  mode: "synthetic-v1",
  async transcribe({ signal }) {
    if (signal.aborted) throw Error("VOICE_ABORTED");
    return { text: "这是合成转写演示，请改成你想说的话。" };
  },
};
// Runtime configuration is explicit deployment intent, never proof of remote
// billing or IAM settings. Operator evidence is checked separately at deployment.
function tencentConfigurationKey() {
  ensure(
    process.env.APP_MODE === "INTERNAL" &&
      process.env.E4_VOICE_ENABLED === "true" &&
      process.env.E4_VOICE_MODE === TENCENT_VOICE_MODE &&
      process.env.E4_VOICE_TENCENT_ASR_APPROVED === "true" &&
      process.env.E4_VOICE_TENCENT_FREE_ONLY === "true" &&
      process.env.E4_VOICE_TENCENT_SECRET_ID &&
      process.env.E4_VOICE_TENCENT_SECRET_KEY,
    503,
    "免费语音服务尚未启用，你可以继续打字。",
  );
  // Used only in process to bind a provider and failure latch to credentials.
  // Never persisted, returned or logged. No evidence file or clock dependency.
  return createHash("sha256")
    .update(
      JSON.stringify([
        process.env.E4_VOICE_TENCENT_SECRET_ID,
        process.env.E4_VOICE_TENCENT_SECRET_KEY,
        process.env.E4_VOICE_TENCENT_TOKEN ?? "",
      ]),
    )
    .digest("hex");
}
// A genuine quota/auth error closes this configuration until an operator fixes
// the service and restarts it, or explicitly replaces its credentials.
let disabledTencentConfiguration: string | null = null;
export function configuredVoiceProvider(): VoiceTranscriber {
  if (process.env.E4_VOICE_MODE === TENCENT_VOICE_MODE) {
    const configuration = tencentConfigurationKey();
    ensure(
      configuration !== disabledTencentConfiguration,
      503,
      "免费语音服务暂不可用，你可以继续打字。",
    );
    const provider = createTencentSentenceProvider();
    return {
      mode: provider.mode,
      async transcribe(input) {
        // Explicit disable/reconfiguration must also stop an already-created
        // provider. This does not read an operator receipt or probe billing.
        ensure(
          tencentConfigurationKey() === configuration &&
            configuration !== disabledTencentConfiguration,
          503,
          "免费语音服务配置已变化或暂不可用，你可以继续打字。",
        );
        try {
          return await provider.transcribe(input);
        } catch (e) {
          const code = e instanceof VoiceProviderError ? e.code : "NETWORK";
          if (code === "QUOTA_OR_LIMIT" || code === "AUTH_FAILED")
            disabledTencentConfiguration = configuration;
          if (code === "TIMEOUT")
            throw new HttpError(504, "转写超时，请重试或继续打字。");
          if (code === "CANCELLED")
            throw new HttpError(409, "录音处理已中止。");
          if (code === "INVALID_AUDIO")
            throw new HttpError(
              400,
              "录音格式不受支持，请重新录音或继续打字。",
            );
          if (code === "QUOTA_OR_LIMIT")
            throw new HttpError(503, "免费语音额度暂不可用，你可以继续打字。");
          throw new HttpError(503, "语音转写暂不可用，你可以继续打字。");
        }
      },
    };
  }
  ensure(
    process.env.E4_VOICE_MODE === "synthetic-v1",
    503,
    "语音服务尚未配置，你可以继续打字。",
  );
  return syntheticVoice;
}
