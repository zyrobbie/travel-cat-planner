import { createHash } from "node:crypto";
import {
  closeSync,
  existsSync,
  fsyncSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  unlinkSync,
} from "node:fs";
import { join } from "node:path";
import { ensure } from "./errors";
import type { PoolClient } from "pg";
import { assertInternal } from "./safety";
import { lifecycleDirectory, writePrivateAtomic } from "./lifecycle-ledger";
import {
  EXPORT_CHUNK_BYTES,
  EXPORT_MAX_BYTES,
  validateExportManifest,
  type ExportDownloadManifest,
} from "../shared/export-download";

const artifactPattern = /^[a-f0-9-]{36}\.[a-f0-9-]{36}\.json$/;
export const exportSha = (bytes: Uint8Array | string) =>
  createHash("sha256").update(bytes).digest("hex");
export function validateArtifact(name: string) {
  ensure(artifactPattern.test(name), 503, "私有文件标识无效。");
  return name;
}
export function buildExportManifest(
  name: string,
  bytes: Buffer,
): ExportDownloadManifest {
  validateArtifact(name);
  ensure(
    bytes.length > 0 && bytes.length <= EXPORT_MAX_BYTES,
    503,
    "导出超过本轮处理范围。",
  );
  return {
    format: "cat-letters-export-download",
    version: 1,
    downloadVersion: exportSha(name),
    filename: `cat-letters-${name.slice(0, 36)}.json`,
    bytes: bytes.length,
    sha256: exportSha(bytes),
    chunkBytes: EXPORT_CHUNK_BYTES,
    chunks: Array.from(
      { length: Math.ceil(bytes.length / EXPORT_CHUNK_BYTES) },
      (_, index) => {
        const part = bytes.subarray(
          index * EXPORT_CHUNK_BYTES,
          (index + 1) * EXPORT_CHUNK_BYTES,
        );
        return { index, bytes: part.length, sha256: exportSha(part) };
      },
    ),
  };
}
function verifyManifest(name: string, data: unknown) {
  const manifest = validateExportManifest(data);
  ensure(
    manifest.downloadVersion === exportSha(validateArtifact(name)) &&
      manifest.filename === `cat-letters-${name.slice(0, 36)}.json`,
    503,
    "导出文件校验失败。",
  );
  return manifest;
}
function verifyChunk(
  manifest: ExportDownloadManifest,
  index: number,
  bytes: Buffer,
) {
  const part = manifest.chunks[index];
  ensure(
    part && bytes.length === part.bytes && exportSha(bytes) === part.sha256,
    503,
    "导出文件校验失败。",
  );
  return bytes;
}
export interface ExportStorage {
  readonly kind: "file" | "postgres";
  write(name: string, bytes: Buffer, db?: PoolClient): Promise<void>;
  manifest(name: string, db?: PoolClient): Promise<ExportDownloadManifest>;
  chunk(
    name: string,
    index: number,
    manifest: ExportDownloadManifest,
    db?: PoolClient,
  ): Promise<Buffer>;
  remove(name: string, db?: PoolClient): Promise<void>;
  removeJob(id: string, db?: PoolClient): Promise<void>;
  cleanup(
    keep: (name: string) => boolean,
    db?: PoolClient,
  ): Promise<{ cleaned: number }>;
}
function exportDirectory() {
  const dir = join(lifecycleDirectory(), "exports");
  if (!existsSync(dir)) mkdirSync(dir, { mode: 0o700 });
  ensure(
    lstatSync(dir).isDirectory() && !lstatSync(dir).isSymbolicLink(),
    503,
    "私有导出目录不安全。",
  );
  return dir;
}
function syncDirectory(dir: string) {
  const fd = openSync(dir, "r");
  try {
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}
function localRead(name: string) {
  const path = join(exportDirectory(), validateArtifact(name));
  ensure(
    existsSync(path) &&
      lstatSync(path).isFile() &&
      !lstatSync(path).isSymbolicLink() &&
      lstatSync(path).size <= EXPORT_MAX_BYTES,
    503,
    "导出文件暂不可用。",
  );
  return readFileSync(path);
}
async function localDelete(match: (name: string) => boolean) {
  const dir = exportDirectory();
  let cleaned = 0;
  for (const file of readdirSync(dir))
    if (match(file)) {
      unlinkSync(join(dir, file));
      cleaned++;
    }
  syncDirectory(dir);
  return { cleaned };
}
export const fileExportStorage: ExportStorage = {
  kind: "file",
  async write(name, bytes) {
    buildExportManifest(name, bytes);
    const path = join(exportDirectory(), name);
    ensure(!existsSync(path), 503, "导出文件标识已存在。");
    writePrivateAtomic(path, bytes);
  },
  async manifest(name) {
    return buildExportManifest(name, localRead(name));
  },
  async chunk(name, index, manifest) {
    const bytes = localRead(name);
    ensure(
      bytes.length === manifest.bytes && exportSha(bytes) === manifest.sha256,
      503,
      "导出文件校验失败。",
    );
    return verifyChunk(
      manifest,
      index,
      bytes.subarray(
        index * EXPORT_CHUNK_BYTES,
        (index + 1) * EXPORT_CHUNK_BYTES,
      ),
    );
  },
  async remove(name) {
    validateArtifact(name);
    await localDelete(
      (file) =>
        file === name ||
        (file.startsWith(`${name}.`) &&
          /^[a-f0-9-]{36}\.tmp$/.test(file.slice(name.length + 1))),
    );
  },
  async removeJob(id) {
    ensure(/^[a-f0-9-]{36}$/.test(id), 503, "私有文件标识无效。");
    await localDelete(
      (file) =>
        file.startsWith(`${id}.`) &&
        /^[a-f0-9-]{36}\.json(?:\.[a-f0-9-]{36}\.tmp)?$/.test(
          file.slice(id.length + 1),
        ),
    );
  },
  async cleanup(keep) {
    return localDelete((file) => {
      const name = file.match(
        /^([a-f0-9-]{36}\.[a-f0-9-]{36}\.json)(?:\.[a-f0-9-]{36}\.tmp)?$/,
      )?.[1];
      return !!name && !keep(file);
    });
  },
};

/** PostgreSQL adapter never opens a pool: use the caller's existing transaction. */
function connection(db?: PoolClient) {
  ensure(db, 503, "私有导出需要当前数据库事务。");
  return db;
}
export const postgresExportStorage: ExportStorage = {
  kind: "postgres",
  async write(name, bytes, client) {
    const db = connection(client),
      manifest = buildExportManifest(name, bytes);
    const {
      rows: [budget],
    } = await db.query(
      "SELECT payload_budget_bytes FROM private_export_budget WHERE singleton=true FOR UPDATE",
    );
    ensure(
      budget && Number(budget.payload_budget_bytes) >= EXPORT_MAX_BYTES,
      503,
      "私有导出容量未配置。",
    );
    // Replacement and quota check share the same transaction as publication.
    // A failed capacity check rolls this deletion back, retaining previous bytes.
    await db.query("DELETE FROM private_export_chunks WHERE export_id=$1", [
      name.slice(0, 36),
    ]);
    const {
      rows: [usage],
    } = await db.query(
      "SELECT COALESCE(sum(chunk_bytes),0)::bigint AS bytes FROM private_export_chunks",
    );
    ensure(
      Number(usage.bytes) + bytes.length <= Number(budget.payload_budget_bytes),
      507,
      "导出暂存空间已满，已有文件仍保留。请稍后重试。",
    );
    // Same guarded publication transaction and quota lock. At most 16 chunks;
    // one parameterized INSERT avoids 16 network round trips for a large export.
    const values:unknown[]=[];
    const rows=manifest.chunks.map(part=>{
      const start=values.length;
      values.push(name.slice(0,36),name,part.index,part.bytes,part.sha256,
        bytes.subarray(part.index*EXPORT_CHUNK_BYTES,(part.index+1)*EXPORT_CHUNK_BYTES));
      return `(${Array.from({length:6},(_,i)=>`$${start+i+1}`).join(",")})`;
    });
    await db.query("INSERT INTO private_export_chunks(export_id,artifact_name,chunk_index,chunk_bytes,chunk_hash,body) VALUES"+rows.join(","),values);
  },
  async manifest(name, client) {
    validateArtifact(name);
    const db = connection(client);
    const {
      rows: [job],
    } = await db.query(
      "SELECT artifact_bytes,artifact_hash FROM account_exports WHERE id=$1 AND artifact_name=$2",
      [name.slice(0, 36), name],
    );
    ensure(job, 503, "导出文件暂不可用。");
    const { rows } = await db.query(
      "SELECT chunk_index,chunk_bytes,chunk_hash FROM private_export_chunks WHERE export_id=$1 AND artifact_name=$2 ORDER BY chunk_index",
      [name.slice(0, 36), name],
    );
    return verifyManifest(name, {
      format: "cat-letters-export-download",
      version: 1,
      downloadVersion: exportSha(name),
      filename: `cat-letters-${name.slice(0, 36)}.json`,
      bytes: Number(job.artifact_bytes),
      sha256: job.artifact_hash,
      chunkBytes: EXPORT_CHUNK_BYTES,
      chunks: rows.map((r) => ({
        index: r.chunk_index,
        bytes: r.chunk_bytes,
        sha256: r.chunk_hash,
      })),
    });
  },
  async chunk(name, index, manifest, client) {
    validateArtifact(name);
    verifyManifest(name, manifest);
    ensure(
      Number.isInteger(index) && index >= 0 && index < manifest.chunks.length,
      400,
      "导出分块无效。",
    );
    const {
      rows: [part],
    } = await connection(client).query(
      "SELECT body FROM private_export_chunks WHERE export_id=$1 AND artifact_name=$2 AND chunk_index=$3",
      [name.slice(0, 36), name, index],
    );
    ensure(part, 503, "导出分块暂不可用。");
    return verifyChunk(manifest, index, part.body);
  },
  async remove(name, client) {
    validateArtifact(name);
    await connection(client).query(
      "DELETE FROM private_export_chunks WHERE export_id=$1 AND artifact_name=$2",
      [name.slice(0, 36), name],
    );
  },
  async removeJob(id, client) {
    ensure(/^[a-f0-9-]{36}$/.test(id), 503, "私有文件标识无效。");
    await connection(client).query(
      "DELETE FROM private_export_chunks WHERE export_id=$1",
      [id],
    );
  },
  async cleanup(_keep, client) {
    const result = await connection(client).query(
      "DELETE FROM private_export_chunks p USING account_exports e WHERE e.id=p.export_id AND NOT (e.status='READY' AND e.artifact_name=p.artifact_name) AND NOT (e.status='BUILDING' AND e.lease_until>clock_timestamp())",
    );
    return { cleaned: result.rowCount ?? 0 };
  },
};
export function configuredExportStorage(): ExportStorage {
  assertInternal();
  const adapter = process.env.E4_EXPORT_STORAGE ?? "file";
  ensure(
    process.env.NETLIFY !== "true" || adapter === "postgres",
    503,
    "云端私有导出必须配置持久化存储。",
  );
  ensure(
    adapter === "file" || adapter === "postgres",
    503,
    "私有导出存储未配置。",
  );
  return adapter === "postgres" ? postgresExportStorage : fileExportStorage;
}
