import { HttpError } from "./errors";

export const DEFAULT_ACCOUNT_COOKIE = "cat_account_session";
export const DEFAULT_DELETION_COOKIE = "cat_deletion_receipt";

/** Deployment settings are read when the server modules start; changes require restart. */
export function configuredAccountCookies(
  env: Readonly<Record<string, string | undefined>> = process.env,
) {
  const account = env.ACCOUNT_COOKIE_NAME ?? DEFAULT_ACCOUNT_COOKIE;
  const deletion = env.DELETION_COOKIE_NAME ?? DEFAULT_DELETION_COOKIE;
  // Deliberately accept a small safe subset, without browser prefix/path surprises.
  const valid = (name: string) => /^[a-z][a-z0-9_]{0,63}$/.test(name);
  if (!valid(account) || !valid(deletion) || account === deletion ||
      account === DEFAULT_DELETION_COOKIE || deletion === DEFAULT_ACCOUNT_COOKIE ||
      [account, deletion].some(name => ["cat_session", "cat_admin"].includes(name)))
    throw new HttpError(503, "账号 Cookie 配置无效。");
  return Object.freeze({ account, deletion });
}
