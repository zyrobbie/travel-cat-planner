import { spawn } from "node:child_process";
import { performance } from "node:perf_hooks";
import {
  mkdtemp,
  writeFile,
  rm,
  lstat,
  mkdir,
  readdir,
} from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { ensure, HttpError } from "./errors";
import { VOICE_MAX_BYTES, VOICE_MAX_MS } from "../shared/voice";
import { voiceDirectory } from "./voice-directory";
type ProbeBudget = { deadline: number; bytes: number };
type AudioProof = { ms: number; aacEndSample?: number };
function readProbe(
  binary: string,
  file: string,
  root: string,
  entries: string,
  budget: ProbeBudget,
  signal?: AbortSignal,
): Promise<string> {
  return new Promise<string>((yes, no) => {
    const child = spawn(
      binary,
      [
        "-v",
        "error",
        "-protocol_whitelist",
        "file,pipe",
        "-max_alloc",
        "16777216",
        "-show_entries",
        entries,
        "-of",
        "json",
        file,
      ],
      {
        env: {
          LANG: "C",
          PATH: "/usr/bin:/bin",
          NODE_ENV: "production",
          TMPDIR: root,
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
    let text = "",
      failed = false;
    const stop = () => {
      failed = true;
      child.kill("SIGKILL");
    };
    const timer = setTimeout(stop, Math.max(1, budget.deadline - performance.now()));
    signal?.addEventListener("abort", stop, { once: true });
    child.stdout.on("data", (b) => {
      budget.bytes += b.length;
      if (budget.bytes > 1024 * 1024) stop();
      else text += b;
    });
    child.stderr.on("data", () => {});
    child.once("error", () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", stop);
      no(new HttpError(503, "录音校验暂不可用，你可以继续打字。"));
    });
    child.once("close", (code) => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", stop);
      code === 0 && !failed
        ? yes(text)
        : no(new HttpError(400, "录音无法读取或校验超时，请继续打字。"));
    });
    if (signal?.aborted) stop();
  });
}

/** Validate AAC presentation against every decoded frame, never a duration tag alone.
 * FFmpeg 6.1 MOV may omit a packet duration and may leave a partial final
 * AAC frame untrimmed. Only that container-declared final-frame padding can
 * be removed; all other decoded samples and timestamp gaps count in full.
 */
async function proveAac(
  parsed: any,
  binary: string,
  file: string,
  root: string,
  budget: ProbeBudget,
  signal?: AbortSignal,
): Promise<AudioProof> {
  const stream = parsed.streams[0],
    rate = Number(stream.sample_rate);
  const valid = (condition: unknown) =>
    ensure(condition, 400, "录音时间信息无效。");
  valid(
    Number.isSafeInteger(rate) &&
      rate > 0 &&
      rate <= 192000 &&
      stream.time_base === `1/${rate}` &&
      stream.start_pts === 0,
  );
  const packets = new Map<number, any>();
  for (const p of parsed.packets) {
    valid(
      Number.isSafeInteger(p.pts) &&
        p.stream_index === stream.index &&
        !packets.has(p.pts) &&
        (p.duration === undefined ||
          (Number.isSafeInteger(p.duration) &&
            p.duration > 0 &&
            p.duration <= 4096)),
    );
    if (p.pts < 0) {
      // The decoder must demonstrably discard the declared priming packet.
      valid(
        packets.size === 0 &&
          p.pts >= -4096 &&
          p.duration === -p.pts &&
          p.side_data_list?.some(
            (s: any) =>
              s.side_data_type === "Skip Samples" && s.skip_samples === -p.pts,
          ),
      );
    }
    packets.set(p.pts, p);
  }
  let frames: any;
  try {
    frames = JSON.parse(
      await readProbe(
        binary,
        file,
        root,
        "frame=pts,nb_samples",
        budget,
        signal,
      ),
    ).frames;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(400, "录音无法读取。");
  }
  valid(Array.isArray(frames) && frames.length > 0);
  let samples = 0,
    padding = 0;
  for (let i = 0; i < frames.length; i++) {
    const f = frames[i],
      p = packets.get(f.pts);
    valid(
      Number.isSafeInteger(f.pts) &&
        f.pts === samples &&
        Number.isSafeInteger(f.nb_samples) &&
        f.nb_samples > 0 &&
        f.nb_samples <= 4096 &&
        p,
    );
    if (p.duration !== undefined && p.duration !== f.nb_samples) {
      // Decoded samples beyond a proven partial LAST packet are AAC padding.
      // A shorter/contradictory stream duration, earlier partial packet or extra
      // decoded frame cannot authorize truncation.
      valid(
        i === frames.length - 1 &&
          p.duration < f.nb_samples &&
          Number.isSafeInteger(stream.duration_ts) &&
          stream.duration_ts === f.pts + p.duration,
      );
      padding = f.nb_samples - p.duration;
    }
    samples += f.nb_samples;
    packets.delete(f.pts);
  }
  valid([...packets.keys()].every((pts) => pts < 0));
  const validSamples = samples - padding;
  ensure(
    validSamples > 0 && validSamples * 1000 <= VOICE_MAX_MS * rate,
    400,
    "录音超过60秒，请缩短后再试，也可以继续打字。",
  );
  return {
    ms: Math.ceil((validSamples * 1000) / rate),
    ...(padding ? { aacEndSample: validSamples } : {}),
  };
}

export async function inspectVoiceAudio(
  audio: Buffer,
  mime: string,
  signal?: AbortSignal,
) {
  return (await proveVoiceAudio(audio, mime, signal)).ms;
}
async function proveVoiceAudio(
  audio: Buffer,
  mime: string,
  signal?: AbortSignal,
): Promise<AudioProof> {
  ensure(
    audio.length > 0 && audio.length <= VOICE_MAX_BYTES,
    413,
    "录音大小超过限制，你可以继续打字。",
  );
  const magic =
    mime === "audio/webm"
      ? audio.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]))
      : mime === "audio/ogg"
        ? audio.subarray(0, 4).toString() === "OggS"
        : mime === "audio/mp4"
          ? audio.subarray(4, 8).toString() === "ftyp"
          : mime === "audio/wav" &&
            audio.subarray(0, 4).toString() === "RIFF" &&
            audio.subarray(8, 12).toString() === "WAVE";
  ensure(magic, 400, "录音格式不正确，请重新录音或继续打字。");
  const binary = process.env.E4_VOICE_FFPROBE;
  ensure(binary && isAbsolute(binary), 503, "语音格式校验未配置。");
  const root = await voiceDirectory();
  const dir = await mkdtemp(join(root, "probe-")),
    file = join(dir, "audio");
  try {
    await writeFile(file, audio, { mode: 0o600, flag: "wx" });
    const budget = { deadline: performance.now() + 5000, bytes: 0 };
    const result = await readProbe(
      binary,
      file,
      root,
      "stream=index,codec_type,codec_name,sample_rate,time_base,start_pts,duration_ts:packet=stream_index,pts,duration,pts_time,duration_time:packet_side_data=side_data_type,skip_samples",
      budget,
      signal,
    );
    let parsed: any;
    try {
      parsed = JSON.parse(result);
    } catch {
      throw new HttpError(400, "录音无法读取。");
    }
    ensure(
      Array.isArray(parsed.streams) &&
        parsed.streams.length === 1 &&
        parsed.streams[0].codec_type === "audio" &&
        ["opus", "aac", "pcm_s16le", "pcm_s24le", "pcm_f32le"].includes(
          parsed.streams[0].codec_name,
        ),
      400,
      "录音音轨不受支持。",
    );
    ensure(
      Array.isArray(parsed.packets) && parsed.packets.length > 0,
      400,
      "录音没有可用声音数据。",
    );
    if (mime === "audio/mp4" && parsed.streams[0].codec_name === "aac")
      return await proveAac(parsed, binary, file, root, budget, signal);
    let first = Infinity,
      last = -Infinity;
    for (const p of parsed.packets) {
      const at = Number(p.pts_time),
        duration = Number(p.duration_time);
      ensure(
        Number.isFinite(at) &&
          Number.isFinite(duration) &&
          duration >= 0 &&
          duration <= 10,
        400,
        "录音时间信息无效。",
      );
      first = Math.min(first, at);
      last = Math.max(last, at + duration);
    }
    const ms = Math.round((last - first) * 1000);
    if (
      ms > VOICE_MAX_MS &&
      ms <= VOICE_MAX_MS + 100 &&
      ["opus", "aac"].includes(parsed.streams[0].codec_name)
    ) {
      // Encoder priming/padding is not speech. Decode without truncating and cap
      // the actual sample count; a genuinely >60s signal still fails.
      const decoded = await decodeVoiceAudio(audio, signal);
      return { ms: Math.ceil((decoded.length - 44) / 32) };
    }
    ensure(
      ms > 0 && ms <= VOICE_MAX_MS,
      400,
      "录音超过60秒，请缩短后再试，也可以继续打字。",
    );
    return { ms };
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/** Fixed PCM output, never relabel browser WebM as WAV. No automatic truncation. */
export async function normalizeVoiceAudio(
  audio: Buffer,
  mime: string,
  signal?: AbortSignal,
): Promise<Buffer> {
  const proof = await proveVoiceAudio(audio, mime, signal);
  return decodeVoiceAudio(audio, signal, proof.aacEndSample);
}
async function decodeVoiceAudio(
  audio: Buffer,
  signal?: AbortSignal,
  aacEndSample?: number,
): Promise<Buffer> {
  const binary = process.env.E4_VOICE_FFMPEG;
  ensure(binary && isAbsolute(binary), 503, "语音转换尚未配置。");
  const root = await voiceDirectory();
  const dir = await mkdtemp(join(root, "convert-")),
    file = join(dir, "audio");
  try {
    await writeFile(file, audio, { mode: 0o600, flag: "wx" });
    const pcm = await new Promise<Buffer>((yes, no) => {
      const child = spawn(
        binary,
        [
          "-nostdin",
          "-v",
          "error",
          "-protocol_whitelist",
          "file,pipe",
          "-max_alloc",
          "16777216",
          "-probesize",
          "1048576",
          "-analyzeduration",
          "5000000",
          "-threads",
          "1",
          "-filter_threads",
          "1",
          "-i",
          file,
          "-map",
          "0:a:0",
          "-vn",
          "-sn",
          "-dn",
          ...(aacEndSample === undefined
            ? []
            : ["-af", `atrim=end_sample=${aacEndSample}`]),
          "-ac",
          "1",
          "-ar",
          "16000",
          "-c:a",
          "pcm_s16le",
          "-f",
          "s16le",
          "pipe:1",
        ],
        {
          env: {
            LANG: "C",
            PATH: "/usr/bin:/bin",
            NODE_ENV: "production",
            TMPDIR: root,
          },
          stdio: ["ignore", "pipe", "pipe"],
        },
      );
      const chunks: Buffer[] = [];
      let size = 0,
        failed = false;
      const stop = () => {
        failed = true;
        child.kill("SIGKILL");
      };
      const timer = setTimeout(stop, 10000);
      signal?.addEventListener("abort", stop, { once: true });
      child.stdout.on("data", (b) => {
        size += b.length;
        if (size > 1_920_000) stop();
        else chunks.push(b);
      });
      child.stderr.on("data", () => {});
      child.once("error", () => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        no(new HttpError(503, "录音转换不可用，你可以继续打字。"));
      });
      child.once("close", (code) => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        code === 0 && !failed && size > 0
          ? yes(Buffer.concat(chunks))
          : no(new HttpError(400, "录音转换失败或超限，你可以继续打字。"));
      });
      if (signal?.aborted) stop();
    });
    const header = Buffer.alloc(44);
    header.write("RIFF");
    header.writeUInt32LE(pcm.length + 36, 4);
    header.write("WAVEfmt ", 8);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(16000, 24);
    header.writeUInt32LE(32000, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write("data", 36);
    header.writeUInt32LE(pcm.length, 40);
    const wav = Buffer.concat([header, pcm]);
    ensure(
      wav.toString("base64").length <= 3_000_000,
      413,
      "转换后的录音超过服务限制。",
    );
    return wav;
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/** Crash remnants only; active conversions have a <=10s wall clock bound. */
export async function cleanupVoiceFiles() {
  const root = await voiceDirectory({ forCleanup: true });
  let cleaned = 0;
  const entries = await readdir(root, { withFileTypes: true }).catch(
    (error) => {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw error;
    },
  );
  ensure(entries.length <= 1000, 503, "语音临时目录需要人工检查。");
  for (const e of entries.slice(0, 100)) {
    if (!/^(probe|convert)-[a-zA-Z0-9]+$/.test(e.name)) continue;
    const path = join(root, e.name),
      s = await lstat(path);
    if (
      s.isDirectory() &&
      !s.isSymbolicLink() &&
      s.mtimeMs < Date.now() - 60_000
    ) {
      await rm(path, { recursive: true, force: true });
      cleaned++;
    }
  }
  return cleaned;
}
