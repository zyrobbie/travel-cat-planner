import { spawn } from "node:child_process";
import {
  mkdtemp,
  writeFile,
  rm,
  lstat,
  mkdir,
  readdir,
} from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { ensure, HttpError } from "./errors";
import { VOICE_MAX_BYTES, VOICE_MAX_MS } from "../shared/voice";
import { voiceDirectory } from "./voice-directory";
export async function inspectVoiceAudio(
  audio: Buffer,
  mime: string,
  signal?: AbortSignal,
) {
  ensure(
    audio.length > 0 && audio.length <= VOICE_MAX_BYTES,
    413,
    "录音大小超过限制，你可以继续打字。",
  );
  const magic =
    mime === "audio/webm"
      ? audio.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]))
      : mime === "audio/ogg"
        ? audio.subarray(0, 4).toString() === "OggS"
        : mime === "audio/mp4"
          ? audio.subarray(4, 8).toString() === "ftyp"
          : mime === "audio/wav" &&
            audio.subarray(0, 4).toString() === "RIFF" &&
            audio.subarray(8, 12).toString() === "WAVE";
  ensure(magic, 400, "录音格式不正确，请重新录音或继续打字。");
  const binary = process.env.E4_VOICE_FFPROBE;
  ensure(binary && isAbsolute(binary), 503, "语音格式校验未配置。");
  const root = await voiceDirectory();
  const dir = await mkdtemp(join(root, "probe-")),
    file = join(dir, "audio");
  try {
    await writeFile(file, audio, { mode: 0o600, flag: "wx" });
    const result = await new Promise<string>((yes, no) => {
      const child = spawn(
        binary,
        [
          "-v",
          "error",
          "-protocol_whitelist",
          "file,pipe",
          "-max_alloc",
          "16777216",
          "-show_entries",
          "stream=codec_type,codec_name:packet=pts_time,duration_time",
          "-of",
          "json",
          file,
        ],
        {
          env: { LANG: "C", PATH: "/usr/bin:/bin", NODE_ENV: "production", TMPDIR: root },
          stdio: ["ignore", "pipe", "pipe"],
        },
      );
      let text = "",
        failed = false;
      const stop = () => {
        failed = true;
        child.kill("SIGKILL");
      };
      const timer = setTimeout(stop, 5000);
      signal?.addEventListener("abort", stop, { once: true });
      child.stdout.on("data", (b) => {
        text += b;
        if (Buffer.byteLength(text) > 1024 * 1024) stop();
      });
      child.stderr.on("data", () => {});
      child.once("error", () => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        no(new HttpError(503, "录音校验暂不可用，你可以继续打字。"));
      });
      child.once("close", (code) => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        code === 0 && !failed
          ? yes(text)
          : no(new HttpError(400, "录音无法读取或校验超时，请继续打字。"));
      });
      if (signal?.aborted) stop();
    });
    let parsed: any;
    try {
      parsed = JSON.parse(result);
    } catch {
      throw new HttpError(400, "录音无法读取。");
    }
    ensure(
      Array.isArray(parsed.streams) &&
        parsed.streams.length === 1 &&
        parsed.streams[0].codec_type === "audio" &&
        ["opus", "aac", "pcm_s16le", "pcm_s24le", "pcm_f32le"].includes(
          parsed.streams[0].codec_name,
        ),
      400,
      "录音音轨不受支持。",
    );
    ensure(
      Array.isArray(parsed.packets) && parsed.packets.length > 0,
      400,
      "录音没有可用声音数据。",
    );
    let first = Infinity,
      last = -Infinity;
    for (const p of parsed.packets) {
      const at = Number(p.pts_time),
        duration = Number(p.duration_time);
      ensure(
        Number.isFinite(at) &&
          Number.isFinite(duration) &&
          duration >= 0 &&
          duration <= 10,
        400,
        "录音时间信息无效。",
      );
      first = Math.min(first, at);
      last = Math.max(last, at + duration);
    }
    const ms = Math.round((last - first) * 1000);
    if (
      ms > VOICE_MAX_MS &&
      ms <= VOICE_MAX_MS + 100 &&
      ["opus", "aac"].includes(parsed.streams[0].codec_name)
    ) {
      // Encoder priming/padding is not speech. Decode without truncating and cap
      // the actual sample count; a genuinely >60s signal still fails.
      const decoded = await decodeVoiceAudio(audio, signal);
      return Math.ceil((decoded.length - 44) / 32);
    }
    ensure(
      ms > 0 && ms <= VOICE_MAX_MS,
      400,
      "录音超过60秒，请缩短后再试，也可以继续打字。",
    );
    return ms;
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/** Fixed PCM output, never relabel browser WebM as WAV. No automatic truncation. */
export async function normalizeVoiceAudio(
  audio: Buffer,
  mime: string,
  signal?: AbortSignal,
): Promise<Buffer> {
  await inspectVoiceAudio(audio, mime, signal);
  return decodeVoiceAudio(audio, signal);
}
async function decodeVoiceAudio(
  audio: Buffer,
  signal?: AbortSignal,
): Promise<Buffer> {
  const binary = process.env.E4_VOICE_FFMPEG;
  ensure(binary && isAbsolute(binary), 503, "语音转换尚未配置。");
  const root = await voiceDirectory();
  const dir = await mkdtemp(join(root, "convert-")),
    file = join(dir, "audio");
  try {
    await writeFile(file, audio, { mode: 0o600, flag: "wx" });
    const pcm = await new Promise<Buffer>((yes, no) => {
      const child = spawn(
        binary,
        [
          "-nostdin",
          "-v",
          "error",
          "-protocol_whitelist",
          "file,pipe",
          "-max_alloc",
          "16777216",
          "-probesize",
          "1048576",
          "-analyzeduration",
          "5000000",
          "-threads",
          "1",
          "-filter_threads",
          "1",
          "-i",
          file,
          "-map",
          "0:a:0",
          "-vn",
          "-sn",
          "-dn",
          "-ac",
          "1",
          "-ar",
          "16000",
          "-c:a",
          "pcm_s16le",
          "-f",
          "s16le",
          "pipe:1",
        ],
        {
          env: { LANG: "C", PATH: "/usr/bin:/bin", NODE_ENV: "production", TMPDIR: root },
          stdio: ["ignore", "pipe", "pipe"],
        },
      );
      const chunks: Buffer[] = [];
      let size = 0,
        failed = false;
      const stop = () => {
        failed = true;
        child.kill("SIGKILL");
      };
      const timer = setTimeout(stop, 10000);
      signal?.addEventListener("abort", stop, { once: true });
      child.stdout.on("data", (b) => {
        size += b.length;
        if (size > 1_920_000) stop();
        else chunks.push(b);
      });
      child.stderr.on("data", () => {});
      child.once("error", () => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        no(new HttpError(503, "录音转换不可用，你可以继续打字。"));
      });
      child.once("close", (code) => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", stop);
        code === 0 && !failed && size > 0
          ? yes(Buffer.concat(chunks))
          : no(new HttpError(400, "录音转换失败或超限，你可以继续打字。"));
      });
      if (signal?.aborted) stop();
    });
    const header = Buffer.alloc(44);
    header.write("RIFF");
    header.writeUInt32LE(pcm.length + 36, 4);
    header.write("WAVEfmt ", 8);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(1, 22);
    header.writeUInt32LE(16000, 24);
    header.writeUInt32LE(32000, 28);
    header.writeUInt16LE(2, 32);
    header.writeUInt16LE(16, 34);
    header.write("data", 36);
    header.writeUInt32LE(pcm.length, 40);
    const wav = Buffer.concat([header, pcm]);
    ensure(
      wav.toString("base64").length <= 3_000_000,
      413,
      "转换后的录音超过服务限制。",
    );
    return wav;
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/** Crash remnants only; active conversions have a <=10s wall clock bound. */
export async function cleanupVoiceFiles() {
  const root = await voiceDirectory({ forCleanup: true });
  let cleaned = 0;
  const entries = await readdir(root, { withFileTypes: true }).catch(error => {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw error;
  });
  ensure(entries.length <= 1000, 503, "语音临时目录需要人工检查。");
  for (const e of entries.slice(0, 100)) {
    if (!/^(probe|convert)-[a-zA-Z0-9]+$/.test(e.name)) continue;
    const path = join(root, e.name),
      s = await lstat(path);
    if (
      s.isDirectory() &&
      !s.isSymbolicLink() &&
      s.mtimeMs < Date.now() - 60_000
    ) {
      await rm(path, { recursive: true, force: true });
      cleaned++;
    }
  }
  return cleaned;
}
