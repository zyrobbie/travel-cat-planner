import { createHash, createHmac, randomUUID } from "node:crypto";
import type { Pool, PoolClient, QueryResult } from "pg";
import { ensure } from "./errors";
import type { Ledger, LedgerEvent, LedgerPayload } from "./lifecycle-ledger";
import { armConnectionDeadline, commitWithinBudget, requireWindow,
  SchedulerDeadlineExceeded, setTransactionLimits, type DeadlineAt } from "./scheduler-budget";

const LOCK = 82101008;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const signed = (secret: string, value: unknown) =>
  createHmac("sha256", secret).update(JSON.stringify(value)).digest("hex");
async function sessionLock(db: PoolClient, shared: boolean, deadlineAt: DeadlineAt) {
  const suffix = shared ? "_shared" : "";
  if (deadlineAt === undefined) {
    await db.query(`SELECT pg_advisory_lock${suffix}($1)`, [LOCK]);
    return;
  }
  const lockDeadline = Math.min(deadlineAt, Date.now() + 1000);
  while (Date.now() < lockDeadline) {
    requireWindow(deadlineAt);
    const result = await db.query(`SELECT pg_try_advisory_lock${suffix}($1) AS locked`, [LOCK]);
    if (result.rows[0]?.locked === true) return;
    await new Promise(resolve => setTimeout(resolve, Math.min(50, Math.max(1, lockDeadline - Date.now()))));
  }
  throw new SchedulerDeadlineExceeded();
}
const hex64 = (value: unknown) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
function validatePayload(payload: LedgerPayload) {
  ensure(typeof payload.requestId === "string" && typeof payload.accountId === "string",
    503, "独立恢复账本记录身份无效。");
  if (payload.kind === "DELETE_REQUESTED") {
    ensure(hex64(payload.receiptHash) && [payload.participantIds, payload.catIds,
      payload.otpIds, payload.exportIds, payload.sourceHashes].every(Array.isArray),
      503, "独立恢复账本注销记录无效。");
  } else if (payload.kind === "RESPONSE_DELETED") {
    ensure(Array.isArray(payload.exportIds) && Number.isSafeInteger(payload.throughRevision) &&
      payload.throughRevision > 0 && Number.isSafeInteger(payload.stateRevision) &&
      payload.stateRevision >= 0 && hex64(payload.payloadHash),
      503, "独立恢复账本回应删除记录无效。");
  } else if (payload.kind === "DELETE_CANCELLED") {
    ensure(hex64(payload.receiptHash), 503, "独立恢复账本取消记录无效。");
  } else ensure(payload.kind === "DELETE_COMPLETE", 503, "独立恢复账本事件类型无效。");
}

export type Snapshot = { ledger: Ledger; gate: "READY" | "CLOSED"; epoch: number; operationId: string | null };
type TxMode = "normal" | "reconcile";
type Recovery = { operationId: string; epoch: number };
export type Operation = {
  read(): Promise<Snapshot>;
  append(payload: LedgerPayload): Promise<Ledger>;
  businessTx<T>(fn: (db: PoolClient, ledger: Ledger) => Promise<T>, mode?: TxMode): Promise<T>;
  prefixReadTx<T>(fn: (db: PoolClient, ledger: Ledger) => Promise<T>): Promise<T>;
};
export type SharedOperation = {
  businessTx<T>(fn: (db: PoolClient, ledger: Ledger) => Promise<T>): Promise<T>;
  assertLive(): Promise<void>;
};

/**
 * Both pools must point to physically independent PostgreSQL projects.
 * Business locks are always acquired before ledger locks.
 */
export class IndependentLedger {
  constructor(
    private readonly businessPool: Pool,
    private readonly ledgerPool: Pool,
    private readonly secret: string,
  ) {
    ensure(secret.length >= 32, 503, "恢复账本尚未配置。");
    ensure(businessPool !== ledgerPool, 503, "恢复账本必须使用独立连接池。");
  }

  private async snapshot(db: PoolClient): Promise<Snapshot> {
    // Fixed SQL without parameters uses pg's simple-query protocol: one round trip,
    // five native result sets. Keep bigint fields as pg strings, not JSON numbers.
    const results: unknown = await db.query(`
      SELECT id,key_hash FROM ledger_identity WHERE singleton=true;
      SELECT sequence,hash FROM ledger_head WHERE singleton=true;
      SELECT status,epoch,operation_id FROM restore_gate WHERE singleton=true;
      SELECT sequence,kind,request_id,account_id,previous_hash,hash,event_json FROM ledger_events ORDER BY sequence;
      SELECT operation_id,epoch FROM restore_operations ORDER BY epoch;
    `);
    ensure(Array.isArray(results) && results.length === 5 &&
      results.every(result => result?.command === "SELECT" && Array.isArray(result.rows)),
      503, "独立恢复账本读取结果不完整，服务已暂停。");
    const [identity, head, gate, events, operations] = results as QueryResult[];
    ensure(identity.rows.length === 1 && head.rows.length === 1 && gate.rows.length === 1,
      503, "独立恢复账本不完整，服务已暂停。");
    ensure(identity.rows[0].key_hash === hash(this.secret), 503, "独立恢复账本密钥不匹配。");
    let previous = "";
    const parsed: LedgerEvent[] = [];
    for (const row of events.rows) {
      let event: LedgerEvent;
      try { event = JSON.parse(row.event_json) as LedgerEvent; }
      catch { ensure(false, 503, "独立恢复账本事件格式无效。"); throw new Error("unreachable"); }
      const { hash: signature, ...unsigned } = event;
      ensure(event.sequence === parsed.length + 1 && Number(row.sequence) === event.sequence &&
        event.previous === previous && signature === signed(this.secret, unsigned) &&
        row.kind === event.kind && row.request_id === event.requestId &&
        row.account_id === event.accountId && row.previous_hash === event.previous && row.hash === signature,
      503, "独立恢复账本事件校验失败。");
      validatePayload(event);
      previous = signature;
      parsed.push(event);
    }
    const sequence = Number(head.rows[0].sequence);
    ensure(Number.isSafeInteger(sequence) && sequence === parsed.length && head.rows[0].hash === previous,
      503, "独立恢复账本水位不一致。");
    const epoch = Number(gate.rows[0].epoch);
    ensure(Number.isSafeInteger(epoch) && epoch >= 0 &&
      ["READY", "CLOSED"].includes(gate.rows[0].status), 503, "独立恢复闸门无效。");
    ensure((epoch === 0 && gate.rows[0].operation_id === null) ||
      (epoch > 0 && typeof gate.rows[0].operation_id === "string"),
      503, "独立恢复操作身份无效。");
    ensure(operations.rows.length === epoch &&
      operations.rows.every((row, index) => Number(row.epoch) === index + 1) &&
      (epoch === 0 || operations.rows.at(-1).operation_id === gate.rows[0].operation_id),
      503, "独立恢复操作代次记录不一致。");
    return {
      ledger: { id: identity.rows[0].id, sequence, hash: previous, events: parsed },
      gate: gate.rows[0].status,
      epoch,
      operationId: gate.rows[0].operation_id,
    };
  }

  private async businessPrefix(db: PoolClient, snapshot: Snapshot, exact: boolean) {
    const r = await db.query("SELECT status,ledger_id,ledger_sequence,ledger_hash,restore_epoch FROM lifecycle_control WHERE singleton=true");
    const row = r.rows[0];
    const sequence = Number(row?.ledger_sequence);
    const prefixHash = sequence === 0 ? "" : snapshot.ledger.events[sequence - 1]?.hash;
    ensure(row && row.ledger_id === snapshot.ledger.id && Number.isSafeInteger(sequence) &&
      sequence >= 0 && sequence <= snapshot.ledger.sequence && row.ledger_hash === prefixHash,
      503, "业务库与独立账本身份或水位不一致。");
    ensure(Number.isSafeInteger(Number(row.restore_epoch)) && Number(row.restore_epoch) <= snapshot.epoch,
      503, "业务库恢复代次无效。");
    if (exact) ensure(row.status === "READY" && snapshot.gate === "READY" &&
      Number(row.restore_epoch) === snapshot.epoch &&
      sequence === snapshot.ledger.sequence && row.ledger_hash === snapshot.ledger.hash,
      503, "数据恢复尚未核验，服务已暂停。");
  }

  private async pair<T>(exclusive: boolean,
    fn: (business: PoolClient, ledger: PoolClient, live: () => Promise<void>) => Promise<T>,
    deadlineAt?: number): Promise<T> {
    // Both pool waits are capped at 3s in scheduled mode. Do not start a scope
    // that cannot finish acquiring and safely releasing both connections.
    requireWindow(deadlineAt, deadlineAt === undefined ? 0 : 7000);
    const business = await this.businessPool.connect();
    let ledger: PoolClient | undefined;
    let businessLocked = false, ledgerLocked = false, lost = false, businessLost = false;
    let businessUnlockFailed = false, ledgerUnlockFailed = false;
    let failed = false;
    let cancelBusiness = () => {}, cancelLedger = () => {};
    const onError = () => { lost = true; };
    const onBusinessError = () => { businessLost = true; };
    const suffix = exclusive ? "" : "_shared";
    try {
      business.on("error", onBusinessError);
      cancelBusiness = armConnectionDeadline(business, deadlineAt, () => { businessLost = true; });
      if (deadlineAt !== undefined) {
        await business.query("SET statement_timeout = '5s'");
        await business.query("SET lock_timeout = '1s'");
      }
      await sessionLock(business, !exclusive, deadlineAt);
      businessLocked = true;
      requireWindow(deadlineAt, deadlineAt === undefined ? 0 : 7000);
      ledger = await this.ledgerPool.connect();
      ledger.on("error", onError);
      cancelLedger = armConnectionDeadline(ledger, deadlineAt, () => { lost = true; });
      if (deadlineAt !== undefined) {
        await ledger.query("SET statement_timeout = '5s'");
        await ledger.query("SET lock_timeout = '1s'");
      }
      await sessionLock(ledger, !exclusive, deadlineAt);
      ledgerLocked = true;
      const live = async () => {
        requireWindow(deadlineAt);
        ensure(!lost && !businessLost, 503, "生命周期连接已断开。");
        await ledger!.query("SELECT 1");
        requireWindow(deadlineAt);
        ensure(!lost && !businessLost, 503, "生命周期连接已断开。");
      };
      const result = await fn(business, ledger, live);
      await live();
      return result;
    } catch (error) {
      failed = true;
      throw error;
    } finally {
      if (ledger) {
        if (ledgerLocked && !lost) await ledger.query(`SELECT pg_advisory_unlock${suffix}($1)`, [LOCK]).catch(() => { ledgerUnlockFailed = true; });
        if (deadlineAt !== undefined && !lost && !ledgerUnlockFailed)
          await ledger.query("RESET statement_timeout; RESET lock_timeout").catch(() => { ledgerUnlockFailed = true; });
        cancelLedger();
        ledger.removeListener("error", onError);
        ledger.release(lost || ledgerUnlockFailed || (deadlineAt !== undefined && failed));
      }
      if (businessLocked && !businessLost) await business.query(`SELECT pg_advisory_unlock${suffix}($1)`, [LOCK]).catch(() => { businessUnlockFailed = true; });
      if (deadlineAt !== undefined && !businessLost && !businessUnlockFailed)
        await business.query("RESET statement_timeout; RESET lock_timeout").catch(() => { businessUnlockFailed = true; });
      cancelBusiness();
      business.removeListener("error", onBusinessError);
      business.release(businessLost || businessUnlockFailed || (deadlineAt !== undefined && failed));
    }
  }

  private async businessTx<T>(business: PoolClient, ledger: PoolClient, live: () => Promise<void>,
    fn: (db: PoolClient, current: Ledger) => Promise<T>, mode: TxMode,
    recovery?: Recovery, deadlineAt?: number): Promise<T> {
    await business.query("BEGIN");
    try {
      await setTransactionLimits(business, deadlineAt);
      const snapshot = await this.snapshot(ledger);
      if (recovery) ensure(snapshot.gate === "CLOSED" &&
        snapshot.operationId === recovery.operationId && snapshot.epoch === recovery.epoch,
        503, "恢复操作身份或代次已改变。");
      await this.businessPrefix(business, snapshot, mode === "normal");
      const result = await fn(business, snapshot.ledger);
      await live();
      await commitWithinBudget(business, deadlineAt);
      return result;
    } catch (error) {
      await business.query("ROLLBACK").catch(() => {});
      throw error;
    }
  }

  async readBusinessTx<T>(fn: (db: PoolClient, ledger: Ledger) => Promise<T>, deadlineAt?: number): Promise<T> {
    return this.pair(false, (business, ledger, live) =>
      this.businessTx(business, ledger, live, fn, "normal", undefined, deadlineAt), deadlineAt);
  }

  async withShared<T>(fn: (operation: SharedOperation) => Promise<T>, deadlineAt?: number): Promise<T> {
    return this.pair(false, async (business, ledger, live) => {
      let active = true;
      let pending: Promise<unknown> | undefined;
      const tasks: Promise<unknown>[] = [];
      const track = <U>(start: () => Promise<U>): Promise<U> => {
        let task: Promise<U>;
        try {
          ensure(active && !pending, 503, "共享生命周期操作已结束或正在执行。");
          task = start();
        } catch (error) { task = Promise.reject(error); }
        pending = task;
        tasks.push(task);
        void task.catch(() => {});
        void task.then(() => { if (pending === task) pending = undefined; },
          () => { if (pending === task) pending = undefined; });
        return task;
      };
      const operation: SharedOperation = {
        businessTx: (work) => track(() => this.businessTx(business, ledger, live, work, "normal", undefined, deadlineAt)),
        assertLive: () => track(live),
      };
      let result!: T, failed = false, failure: unknown;
      try { result = await fn(operation); }
      catch (error) { failed = true; failure = error; }
      active = false;
      const completed = await Promise.allSettled(tasks);
      if (failed) throw failure;
      const rejected = completed.find((item): item is PromiseRejectedResult => item.status === "rejected");
      if (rejected) throw rejected.reason;
      return result;
    }, deadlineAt);
  }

  async withExclusive<T>(fn: (operation: Operation) => Promise<T>, deadlineAt?: number): Promise<T> {
    return this.runExclusive(fn, undefined, deadlineAt);
  }

  /** Only an explicit operator recovery may append while the gate is closed. */
  async withRecovery<T>(operationId: string, epoch: number,
    fn: (operation: Operation) => Promise<T>): Promise<T> {
    ensure(process.env.E4_LIFECYCLE_RECOVERY === "true", 503, "未允许恢复对账事务。");
    return this.runExclusive(fn, { operationId, epoch });
  }

  private async runExclusive<T>(fn: (operation: Operation) => Promise<T>, recovery?: Recovery,
    deadlineAt?: number): Promise<T> {
    return this.pair(true, async (business, ledger, live) => {
      if (recovery) {
        const initial = await this.snapshot(ledger);
        ensure(initial.gate === "CLOSED" && initial.operationId === recovery.operationId &&
          initial.epoch === recovery.epoch, 503, "恢复操作身份或代次已改变。");
      }
      let active = true;
      let appended = false;
      const pending = new Set<Promise<unknown>>();
      const tasks: Promise<unknown>[] = [];
      const check = () => ensure(active, 503, "生命周期操作已结束。");
      const track = <T>(start: () => Promise<T>): Promise<T> => {
        let task: Promise<T>;
        try {
          check();
          ensure(pending.size === 0, 503, "生命周期操作不能并发执行。");
          task = start();
        } catch (error) {
          task = Promise.reject(error);
        }
        pending.add(task);
        tasks.push(task);
        // The caller may forget await; keep the lock until that task settles.
        void task.catch(() => {});
        void task.then(() => pending.delete(task), () => pending.delete(task));
        return task;
      };
      const operation: Operation = {
        read: () => track(() => this.snapshot(ledger)),
        prefixReadTx: (work) => track(async () => {
          await business.query("BEGIN READ ONLY");
          try {
            await setTransactionLimits(business, deadlineAt);
            const snapshot = await this.snapshot(ledger);
            ensure(snapshot.gate === "READY" && !recovery,
              503, "数据恢复期间不能查询注销进度。");
            await this.businessPrefix(business, snapshot, false);
            const result = await work(business, snapshot.ledger);
            await live();
            await commitWithinBudget(business, deadlineAt);
            return result;
          } catch (error) {
            await business.query("ROLLBACK").catch(() => {});
            throw error;
          }
        }),
        append: (payload) => track(async () => {
          const before = await this.snapshot(ledger);
          if (recovery) ensure(before.gate === "CLOSED" &&
            before.operationId === recovery.operationId && before.epoch === recovery.epoch,
            503, "恢复操作身份或代次已改变。");
          await this.businessPrefix(business, before, !recovery);
          const result = await this.append(ledger, live, payload, recovery, deadlineAt);
          appended = true;
          return result;
        }),
        businessTx: (work, mode = "normal") => track(() => {
          ensure(mode === "normal" || appended || recovery,
            503, "未允许恢复对账事务。");
          return this.businessTx(business, ledger, live, work, mode, recovery, deadlineAt);
        }),
      };
      let result!: T;
      let callbackFailed = false;
      let callbackError: unknown;
      try { result = await fn(operation); }
      catch (error) { callbackFailed = true; callbackError = error; }
      active = false;
      const completed = await Promise.allSettled(tasks);
      if (callbackFailed) throw callbackError;
      const failed = completed.find((item): item is PromiseRejectedResult => item.status === "rejected");
      if (failed) throw failed.reason;
      return result;
    }, deadlineAt);
  }

  private async append(db: PoolClient, live: () => Promise<void>, payload: LedgerPayload,
    recovery?: Recovery, deadlineAt?: number): Promise<Ledger> {
    validatePayload(payload);
    await db.query("BEGIN");
    try {
      await setTransactionLimits(db, deadlineAt);
      await db.query("SELECT sequence FROM ledger_head WHERE singleton=true FOR UPDATE");
      const snapshot = await this.snapshot(db);
      if (recovery) ensure(snapshot.gate === "CLOSED" &&
        snapshot.operationId === recovery.operationId && snapshot.epoch === recovery.epoch,
        503, "恢复操作身份或代次已改变。");
      else ensure(snapshot.gate === "READY", 503, "独立恢复闸门已关闭。");
      const prior = snapshot.ledger.events.find(e => e.kind === payload.kind &&
        e.requestId === payload.requestId && e.accountId === payload.accountId);
      if (prior) {
        for (const [key, value] of Object.entries(payload))
          ensure(JSON.stringify((prior as unknown as Record<string, unknown>)[key]) === JSON.stringify(value),
            409, "账本幂等键对应的内容不一致。");
        await commitWithinBudget(db, deadlineAt);
        return snapshot.ledger;
      }
      const unsigned = { ...payload, sequence: snapshot.ledger.sequence + 1,
        previous: snapshot.ledger.hash, at: new Date().toISOString() };
      const event = { ...unsigned, hash: signed(this.secret, unsigned) } as LedgerEvent;
      await db.query(
        "INSERT INTO ledger_events(sequence,kind,request_id,account_id,previous_hash,hash,event_json) VALUES($1,$2,$3,$4,$5,$6,$7)",
        [event.sequence, event.kind, event.requestId, event.accountId, event.previous, event.hash, JSON.stringify(event)],
      );
      await db.query("UPDATE ledger_head SET sequence=$1,hash=$2 WHERE singleton=true",
        [event.sequence, event.hash]);
      await live();
      await commitWithinBudget(db, deadlineAt);
      return { ...snapshot.ledger, sequence: event.sequence, hash: event.hash,
        events: [...snapshot.ledger.events, event] };
    } catch (error) {
      await db.query("ROLLBACK").catch(() => {});
      throw error;
    }
  }

  /** Bootstrap is an explicit operator action, never an ordinary request fallback. */
  async bootstrap(): Promise<Ledger> {
    ensure(process.env.E4_LIFECYCLE_BOOTSTRAP === "true", 503, "未允许初始化独立账本。");
    return this.pair(true, async (business, ledger, live) => {
      const control = await business.query("SELECT ledger_id FROM lifecycle_control WHERE singleton=true");
      ensure(control.rows.length === 1, 503, "业务库生命周期控制行缺失。");
      // System content catalogs may be seeded; every table carrying user state must be empty.
      for (const table of [
        "participants", "invites", "sessions", "trips", "letters", "responses",
        "safety_cases", "audit_events", "rate_limits", "admin_requests",
        "accounts", "email_challenges", "account_sessions", "cat_profiles",
        "account_requests", "legacy_bindings", "account_deletions", "account_rate_limits",
        "cloud_state", "cloud_trips", "cloud_letters", "cloud_responses",
        "cloud_response_revisions", "cloud_reviews", "cloud_letter_sources",
        "cloud_review_sources", "cloud_requests", "cloud_calendars",
        "cloud_calendar_nodes", "cloud_jobs", "cloud_review_requests",
        "legacy_binding_requests", "legacy_binding_cancellations",
        "deletion_preparations", "erased_legacy_sources", "account_exports",
      ] as const) {
        const occupied = await business.query(`SELECT 1 FROM ${table} LIMIT 1`);
        ensure(occupied.rowCount === 0, 503, "业务库已有用户数据，禁止初始化空账本。");
      }
      const rows = [
        await ledger.query("SELECT 1 FROM ledger_identity"),
        await ledger.query("SELECT 1 FROM ledger_head"),
        await ledger.query("SELECT 1 FROM restore_gate"),
        await ledger.query("SELECT 1 FROM ledger_events"),
        await ledger.query("SELECT 1 FROM restore_operations"),
      ];
      if (rows.every(r => r.rowCount === 0)) {
        ensure(!control.rows[0].ledger_id, 503, "业务库已绑定账本，禁止重建。");
        await ledger.query("BEGIN");
        try {
          const id = randomUUID();
          await ledger.query("INSERT INTO ledger_identity(singleton,id,key_hash) VALUES(true,$1,$2)", [id, hash(this.secret)]);
          await ledger.query("INSERT INTO ledger_head(singleton) VALUES(true)");
          await ledger.query("INSERT INTO restore_gate(singleton,status) VALUES(true,'CLOSED')");
          await live();
          await ledger.query("COMMIT");
        } catch (error) {
          await ledger.query("ROLLBACK").catch(() => {});
          throw error;
        }
      }
      const initialized = await this.snapshot(ledger);
      ensure(initialized.ledger.sequence === 0 && initialized.gate === "CLOSED" &&
        initialized.epoch === 0 &&
        (!control.rows[0].ledger_id || control.rows[0].ledger_id === initialized.ledger.id),
        503, "业务库已绑定其他账本，禁止重建。");
      const bound = await business.query(
        "UPDATE lifecycle_control SET ledger_id=$1,status='CLOSED' WHERE singleton=true AND (ledger_id IS NULL OR ledger_id=$1)",
        [initialized.ledger.id],
      );
      ensure(bound.rowCount === 1, 503, "业务库账本身份绑定失败。");
      return initialized.ledger;
    });
  }

  /** Close independent gate only after the business lock has drained in-flight work. */
  async closeRestoreGate(operationId: string): Promise<Snapshot> {
    ensure(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(operationId),
      503, "恢复操作身份无效。");
    return this.pair(true, async (business, ledger, live) => {
      const snapshot = await this.snapshot(ledger);
      ensure(snapshot.operationId !== operationId || snapshot.gate === "CLOSED",
        503, "恢复操作已结束，禁止重新关闭闸门。");
      const retry = snapshot.operationId === operationId;
      await ledger.query("BEGIN");
      try {
        if (!retry) {
          const reused = await ledger.query("SELECT 1 FROM restore_operations WHERE operation_id=$1", [operationId]);
          ensure(reused.rowCount === 0, 503, "恢复操作身份已使用，不能重新发起。");
          await ledger.query("INSERT INTO restore_operations(operation_id,epoch) VALUES($1,$2)",
            [operationId, snapshot.epoch + 1]);
          const updated = await ledger.query("UPDATE restore_gate SET status='CLOSED',epoch=epoch+1,operation_id=$1,closed_at=clock_timestamp() WHERE singleton=true", [operationId]);
          ensure(updated.rowCount === 1, 503, "独立恢复闸门不存在。");
        }
        await live();
        await ledger.query("COMMIT");
      } catch (error) {
        await ledger.query("ROLLBACK").catch(() => {});
        throw error;
      }
      await business.query("UPDATE lifecycle_control SET status='CLOSED' WHERE singleton=true");
      return { ...snapshot, gate: "CLOSED", epoch: snapshot.epoch + (retry ? 0 : 1), operationId };
    });
  }

  /** A retried operator command may report a recovery already opened by this operation. */
  async completedRecovery(operationId: string, expectedEpoch: number): Promise<Ledger | null> {
    return this.pair(true, async (business, ledger, live) => {
      const snapshot = await this.snapshot(ledger);
      if (snapshot.gate !== "READY" || snapshot.operationId !== operationId ||
          snapshot.epoch !== expectedEpoch) return null;
      await this.businessPrefix(business, snapshot, true);
      await live();
      return snapshot.ledger;
    });
  }

  /** Called only after explicit replay and a committed exact READY watermark. */
  async openRestoreGate(operationId: string, expectedEpoch: number): Promise<void> {
    await this.pair(true, async (business, ledger, live) => {
      const snapshot = await this.snapshot(ledger);
      ensure(snapshot.gate === "CLOSED" && snapshot.operationId === operationId &&
        snapshot.epoch === expectedEpoch, 503, "恢复操作身份或代次已改变。");
      await this.businessPrefix(business, snapshot, false);
      const row = (await business.query("SELECT status,ledger_sequence,ledger_hash,restore_epoch FROM lifecycle_control WHERE singleton=true")).rows[0];
      ensure(row.status === "READY" && Number(row.ledger_sequence) === snapshot.ledger.sequence &&
        row.ledger_hash === snapshot.ledger.hash && Number(row.restore_epoch) === snapshot.epoch,
        503, "业务库未完成恢复对账，闸门保持关闭。");
      await ledger.query("BEGIN");
      try {
        const updated = await ledger.query("UPDATE restore_gate SET status='READY' WHERE singleton=true AND status='CLOSED' AND operation_id=$1 AND epoch=$2",
          [operationId, expectedEpoch]);
        ensure(updated.rowCount === 1, 503, "独立恢复闸门状态已改变。");
        await live();
        await ledger.query("COMMIT");
      } catch (error) {
        await ledger.query("ROLLBACK").catch(() => {});
        throw error;
      }
    });
  }
}
