import { configuredAccountCookies } from "./account-cookie-config";
import { createResendOtpDelivery } from "./resend-otp-delivery";

type Environment = Readonly<Record<string, string | undefined>>;
const fail = (): never => { throw new Error("PRIVATE_VOICE_BASE_CONFIG_INVALID"); };

export type PrivateVoiceEntryStage = "closed" | "prepared" | "private-open";

/** No network/DB/file access. Operator review flags are intent, not Linux/vendor proof. */
export function validatePrivateVoiceBase(env: Environment, maintenance = false) {
  const cookies = configuredAccountCookies(env);
  if (cookies.account !== "cat_voice_test_session" ||
      cookies.deletion !== "cat_voice_test_deletion")
    fail();
  let origin: URL;
  try { origin = new URL(env.APP_ORIGIN ?? ""); } catch { return fail(); }
  if (origin.protocol !== "https:" || origin.port !== "8443" ||
      origin.hostname !== "cat-test.zyrobbie.site" || origin.origin !== env.APP_ORIGIN)
    fail();
  if (env.APP_MODE !== "INTERNAL" || env.SAFETY_ADAPTER !== "synthetic-v1" ||
      env.COOKIE_SECURE !== "true" || env.NETLIFY !== "false" ||
      env.DOTENV_CONFIG_PATH !== "/dev/null" || env.E4_SCHEDULED_RUN !== "true" ||
      env.E4_LIFECYCLE_ADAPTER !== "postgres-v1" ||
      env.E4_LIFECYCLE_BOOTSTRAP !== "false" || env.E4_LIFECYCLE_RECOVERY !== "false")
    fail();
  for (const [key, port, name, role] of [
    ["DATABASE_URL", "55441", "cat_voice_business", "cat_letters_app"],
    ["E4_LEDGER_DATABASE_URL", "55442", "cat_voice_ledger", "cat_letters_ledger"],
  ]) {
    let db: URL;
    try { db = new URL(env[key] ?? ""); } catch { return fail(); }
    if (db.protocol !== "postgresql:" || db.hostname !== "127.0.0.1" ||
        db.port !== port || db.pathname !== `/${name}` || db.username !== role ||
        !db.password || /REPLACE|CHANGEME/.test(db.password) || db.search || db.hash)
      fail();
  }
  for (const key of ["OTP_HASH_SECRET", "E4_LEDGER_SECRET"]) {
    const value = env[key];
    if (!value || value.length < 32 || /REPLACE|CHANGEME/.test(value)) fail();
  }
  if (env.OTP_HASH_SECRET === env.E4_LEDGER_SECRET) fail();
  const entry = env.E4_PRIVATE_ENTRY_STATE as PrivateVoiceEntryStage;
  if (!["closed", "prepared", "private-open"].includes(entry) ||
      !["false", "true"].includes(env.E4_VOICE_ENABLED ?? "") ||
      !["false", "true"].includes(env.E4_VOICE_CLEANUP_ENABLED ?? "") ||
      !["disabled", "resend-v1"].includes(env.OTP_ADAPTER ?? "") ||
      env.E4_VOICE_STORAGE !== "tmpfs-private-v1" ||
      env.E4_VOICE_PAYLOAD_DIRECTORY !== "/run/cat-voice-private/payload" ||
      env.E4_VOICE_PROBE_DIRECTORY !== "/run/cat-voice-private/probe") fail();
  let accounts: unknown;
  try { accounts = JSON.parse(env.E4_VOICE_ACCOUNT_IDS ?? ""); } catch { return fail(); }
  const accountIds = Array.isArray(accounts) ? accounts : fail();
  if (accountIds.length > 10 || new Set(accountIds).size !== accountIds.length ||
      accountIds.some(id => typeof id !== "string" || !/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(id))) fail();
  const voice = env.E4_VOICE_ENABLED === "true";
  const cleanup = env.E4_VOICE_CLEANUP_ENABLED === "true";
  if ((entry !== "private-open" && voice) || (maintenance && !cleanup) ||
      ((entry !== "closed" || cleanup) && accountIds.length === 0) ||
      (voice && (!cleanup || env.E4_VOICE_MODE !== "tencent-sentence-v1")) ||
      (!voice && env.E4_VOICE_MODE !== "disabled")) fail();
  if (entry === "private-open" && !maintenance) {
    if (env.E4_PRIVATE_ENTRY_REVIEWED !== "true" || env.E4_VOICE_LINUX_STORAGE_ACCEPTED !== "true" ||
        env.OTP_ADAPTER !== "resend-v1") fail();
    // Constructor validation performs no send. There is no synthetic OTP fallback.
    createResendOtpDelivery({ apiKey: env.RESEND_API_KEY, from: env.OTP_FROM });
    if (voice && (env.E4_VOICE_TENCENT_ASR_APPROVED !== "true" ||
        env.E4_VOICE_TENCENT_FREE_ONLY !== "true" ||
        !env.E4_VOICE_TENCENT_SECRET_ID?.trim() || !env.E4_VOICE_TENCENT_SECRET_KEY?.trim() ||
        env.E4_VOICE_BACKUP_POLICY !== "exclude-ephemeral-v1")) fail();
  }
  if (env.E4_VOICE_TENCENT_TOKEN !== undefined && !env.E4_VOICE_TENCENT_TOKEN.trim()) fail();
  // Test-only entry points never become a deployment adapter, even in closed mode.
  for (const key of Object.keys(env)) {
    if (key.startsWith("E4_SYNTHETIC_") || key.startsWith("E4_VOICE_REVIEW") ||
        key === "E4_LOCAL_ACCOUNT_CLIENT_DIRECTORY")
      fail();
  }
  return { entry, voice: voice ? "enabled" : "disabled", cleanup, origin: origin.origin, cookies } as const;
}
