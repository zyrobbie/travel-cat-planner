import pg from "pg";
import type { Pool } from "pg";
import { ensure } from "./errors";
import { IndependentLedger } from "./independent-ledger";
import { postgresTlsConfig } from "./postgres-tls";

export type LifecycleAdapterMode = "file-v1" | "postgres-v1";
let ledgerPool: Pool | undefined;
let adapter: IndependentLedger | undefined;

export function lifecycleAdapterMode(): LifecycleAdapterMode {
  const configured = process.env.E4_LIFECYCLE_ADAPTER;
  ensure(configured === undefined || configured === "file-v1" || configured === "postgres-v1",
    503, "生命周期适配器配置无效。");
  ensure(process.env.NETLIFY !== "true" || configured === "postgres-v1",
    503, "Netlify 必须显式配置独立 PostgreSQL 生命周期适配器。");
  return configured ?? "file-v1";
}

export function independentLedger(businessPool: Pool): IndependentLedger {
  ensure(lifecycleAdapterMode() === "postgres-v1", 503, "未启用独立恢复账本。");
  const url = process.env.E4_LEDGER_DATABASE_URL;
  const businessUrl = process.env.DATABASE_URL;
  const secret = process.env.E4_LEDGER_SECRET;
  ensure(url && businessUrl && secret && secret.length >= 32 && url !== businessUrl,
    503, "独立恢复账本连接尚未正确配置。");
  if (!ledgerPool) {
    ledgerPool = new pg.Pool({
      connectionString: url,
      ...postgresTlsConfig(url),
      max: process.env.E4_SCHEDULED_RUN === "true" ? 2 : 4,
      idleTimeoutMillis: process.env.E4_SCHEDULED_RUN === "true" ? 5000 : 60000,
      connectionTimeoutMillis: process.env.E4_SCHEDULED_RUN === "true" ? 3000 : 5000,
    });
    ledgerPool.on("error", () => console.warn("Ledger PostgreSQL idle connection removed."));
  }
  if (!adapter) adapter = new IndependentLedger(businessPool, ledgerPool, secret);
  return adapter;
}

export async function closeLifecycleProvider() {
  if (ledgerPool) await ledgerPool.end();
  ledgerPool = undefined;
  adapter = undefined;
}
