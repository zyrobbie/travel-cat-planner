import { createHash } from "node:crypto";
import { lstatSync, readFileSync, realpathSync } from "node:fs";
import { basename, dirname, isAbsolute, join, resolve } from "node:path";
import { z } from "zod";
import { ensure, HttpError } from "./errors";
import { createTencentSentenceProvider } from "./tencent-sentence-provider";

const unavailable = "免费语音服务尚未就绪，你可以继续打字。";
const hex = z.string().regex(/^[a-f0-9]{64}$/);
export const tencentReadinessSchema = z.strictObject({
  version: z.literal(1),
  provider: z.literal("tencent-sentence-v1"),
  accountFingerprint: hex,
  credentialFingerprint: hex,
  userDecision: z.literal("FREE_ONLY"),
  postpaid: z.literal("DISABLED"),
  dataOptimization: z.literal("DISABLED"),
  permissionScope: z.literal("asr:SentenceRecognition"),
  freeRemainingCalls: z.number().int().min(1).max(5000),
  verifiedAt: z.iso.datetime(),
  expiresAt: z.iso.datetime(),
  month: z.string().regex(/^\d{4}-\d{2}$/),
  evidence: z
    .array(
      z.strictObject({
        file: z
          .string()
          .regex(/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,79}\.(png|json|txt)$/),
        sha256: hex,
      }),
    )
    .min(1)
    .max(5),
});
const safePath = (p: string) =>
  !p
    .split(/[\\/]/)
    .some((x) =>
      [
        "public",
        "dist",
        "pages-dist",
        "assets",
        "static",
        ".git",
        ".next",
        "node_modules",
      ].includes(x.toLowerCase()),
    );
function privateFile(path: string, max: number) {
  const st = lstatSync(path);
  ensure(
    st.isFile() &&
      !st.isSymbolicLink() &&
      (st.mode & 0o077) === 0 &&
      st.uid === process.getuid?.() &&
      st.size > 0 &&
      st.size <= max,
    503,
    unavailable,
  );
  return readFileSync(path);
}
/** Deployment-only operator evidence check, NOT a remote settings query.
 * Never imported by the runtime voice factory or consulted by user requests.
 * Receipt freshness is a predeployment check, not a recurring service lease. */
export function verifyTencentDeploymentEvidence(
  env: Readonly<Record<string, string | undefined>> = process.env,
  now = Date.now(),
) {
  try {
    // Validate the proposed server credential/configuration without any I/O.
    createTencentSentenceProvider(env);
    ensure(
      env.APP_MODE === "INTERNAL" &&
        env.E4_VOICE_ENABLED === "true" &&
        env.E4_VOICE_MODE === "tencent-sentence-v1" &&
        env.E4_VOICE_TENCENT_ASR_APPROVED === "true" &&
        env.E4_VOICE_TENCENT_FREE_ONLY === "true",
      503,
      unavailable,
    );
    const configured = env.E4_VOICE_TENCENT_READINESS_FILE;
    ensure(
      configured && isAbsolute(configured) && safePath(resolve(configured)),
      503,
      unavailable,
    );
    const parent = dirname(resolve(configured)),
      st = lstatSync(parent),
      real = realpathSync(parent);
    const application = realpathSync(process.cwd());
    ensure(
      real !== application && !real.startsWith(application + "/"),
      503,
      unavailable,
    );
    ensure(
      st.isDirectory() &&
        !st.isSymbolicLink() &&
        (st.mode & 0o077) === 0 &&
        st.uid === process.getuid?.() &&
        safePath(real),
      503,
      unavailable,
    );
    const bytes = privateFile(join(real, basename(configured)), 16384),
      receipt = tencentReadinessSchema.parse(
        JSON.parse(bytes.toString("utf8")),
      );
    const verified = Date.parse(receipt.verifiedAt),
      expires = Date.parse(receipt.expiresAt);
    const month = new Date(now + 8 * 60 * 60 * 1000).toISOString().slice(0, 7);
    ensure(
      verified <= now &&
        verified > now - 24 * 60 * 60 * 1000 &&
        expires > now &&
        expires > verified &&
        expires <= verified + 24 * 60 * 60 * 1000 &&
        receipt.month === month &&
        new Set(receipt.evidence.map((e) => e.file)).size ===
          receipt.evidence.length,
      503,
      unavailable,
    );
    ensure(
      env.E4_VOICE_TENCENT_SECRET_ID &&
        receipt.credentialFingerprint ===
          createHash("sha256")
            .update(env.E4_VOICE_TENCENT_SECRET_ID)
            .digest("hex"),
      503,
      unavailable,
    );
    for (const item of receipt.evidence) {
      const evidence = privateFile(join(real, item.file), 10 * 1024 * 1024);
      ensure(
        createHash("sha256").update(evidence).digest("hex") === item.sha256,
        503,
        unavailable,
      );
    }
    return {
      receiptSha256: createHash("sha256").update(bytes).digest("hex"),
      expiresAt: receipt.expiresAt,
    };
  } catch {
    throw new HttpError(503, unavailable);
  }
}
