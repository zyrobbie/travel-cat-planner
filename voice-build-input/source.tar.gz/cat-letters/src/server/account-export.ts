import { createHash, randomUUID } from "node:crypto";
import {
  closeSync,
  existsSync,
  fsyncSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  unlinkSync,
} from "node:fs";
import { join } from "node:path";
import type { PoolClient } from "pg";
import { z } from "zod";
import { pool, transaction } from "./db";
import { independentLedger, lifecycleAdapterMode } from "./lifecycle-provider";
import { lockActiveAccount } from "./account-service";
import { ensure, HttpError } from "./errors";
import { assertInternal } from "./safety";
import { digest } from "./auth";
import { requireWindow } from "./scheduler-budget";
import { configuredExportStorage, exportSha } from "./export-storage";
import {
  EXPORT_MAX_BYTES,
  type ExportDownloadManifest,
} from "../shared/export-download";
import {
  deletePrivateFile,
  guardedLifecycleTx,
  lifecycleDirectory,
  withLifecycleLock,
  withLifecycleReadLock,
} from "./lifecycle-ledger";

export type ExportJob = {
  id: string;
  status: "QUEUED" | "BUILDING" | "READY" | "FAILED" | "EXPIRED" | "REVOKED";
  createdAt: string;
  expiresAt: string | null;
  filename: string | null;
  error: string | null;
};
export type ExportClaim = { id: string; accountId: string; leaseToken: string };
const sha = (b: Buffer) => createHash("sha256").update(b).digest("hex");
const date = (v: Date | string | null) =>
  v ? new Date(v).toISOString() : null;
const filename = (id: string) => `cat-letters-${id}.json`;
const project = (r: Record<string, unknown>): ExportJob => ({
  id: String(r.id),
  status: r.status as ExportJob["status"],
  createdAt: date(r.created_at as Date)!,
  expiresAt: date(r.expires_at as Date),
  filename: r.status === "READY" ? filename(String(r.id)) : null,
  error:
    r.last_error === "EXPORT_STORAGE_FULL"
      ? "导出暂存空间已满，已有文件仍保留。请稍后重试。"
      : r.last_error
        ? "导出未完成，请重试。"
        : null,
});
function exportDirectory() {
  const path = join(lifecycleDirectory(), "exports");
  if (!existsSync(path)) mkdirSync(path, { mode: 0o700 });
  ensure(
    lstatSync(path).isDirectory() && !lstatSync(path).isSymbolicLink(),
    503,
    "私有导出目录不安全。",
  );
  return path;
}
async function snapshotVersion(db: PoolClient, accountId: string) {
  const r = await db.query(
    "SELECT c.id,s.revision FROM cat_profiles c LEFT JOIN cloud_state s ON s.cat_id=c.id AND s.account_id=c.account_id WHERE c.account_id=$1 FOR UPDATE OF c",
    [accountId],
  );
  return {
    catId: r.rows[0]?.id ?? null,
    revision: r.rows[0]?.revision ?? null,
  };
}
async function invalidateOld(db: PoolClient, accountId: string) {
  const version = await snapshotVersion(db, accountId);
  await db.query(
    "UPDATE account_exports SET status=CASE WHEN expires_at<=clock_timestamp() THEN 'EXPIRED' ELSE 'REVOKED' END,lease_token=NULL,lease_until=NULL WHERE account_id=$1 AND status='READY' AND (expires_at<=clock_timestamp() OR cat_id IS DISTINCT FROM $2::uuid OR captured_revision IS DISTINCT FROM $3::bigint)",
    [accountId, version.catId, version.revision],
  );
  return version;
}
export async function requestAccountExport(accountId: string, key: string) {
  assertInternal();
  z.uuid().parse(key);
  return transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    await invalidateOld(db, accountId);
    const existing = await db.query(
      "SELECT * FROM account_exports WHERE account_id=$1 AND request_key=$2",
      [accountId, key],
    );
    if (existing.rows[0]) return { job: project(existing.rows[0]) };
    const busy = await db.query(
      "SELECT count(*)::int AS n FROM account_exports WHERE account_id=$1 AND status IN ('QUEUED','BUILDING')",
      [accountId],
    );
    ensure(busy.rows[0].n < 2, 429, "已有导出正在处理，请稍后再试。");
    const id = randomUUID();
    const r = await db.query(
      "INSERT INTO account_exports(id,account_id,request_key,status) VALUES($1,$2,$3,'QUEUED') RETURNING *",
      [id, accountId, key],
    );
    return { job: project(r.rows[0]) };
  });
}
export async function listAccountExports(accountId: string) {
  return transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    await invalidateOld(db, accountId);
    return {
      exports: (
        await db.query(
          "SELECT * FROM account_exports WHERE account_id=$1 ORDER BY created_at DESC LIMIT 20",
          [accountId],
        )
      ).rows.map(project),
    };
  });
}
export async function accountExportStatus(accountId: string, id: string) {
  z.uuid().parse(id);
  return transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    await invalidateOld(db, accountId);
    const r = await db.query(
      "SELECT * FROM account_exports WHERE account_id=$1 AND id=$2",
      [accountId, id],
    );
    ensure(r.rows[0], 404, "没有找到这份导出。");
    return { job: project(r.rows[0]) };
  });
}
export async function retryAccountExport(accountId: string, id: string) {
  z.uuid().parse(id);
  return transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    await invalidateOld(db, accountId);
    const r = await db.query(
      "SELECT * FROM account_exports WHERE account_id=$1 AND id=$2 FOR UPDATE",
      [accountId, id],
    );
    ensure(r.rows[0], 404, "没有找到这份导出。");
    if (["FAILED", "REVOKED", "EXPIRED"].includes(r.rows[0].status)) {
      const n = await db.query(
        "UPDATE account_exports SET status='QUEUED',lease_token=NULL,lease_until=NULL,attempts=0,last_error=NULL,expires_at=NULL,captured_revision=NULL,cat_id=NULL WHERE account_id=$1 AND id=$2 RETURNING *",
        [accountId, id],
      );
      return { job: project(n.rows[0]) };
    }
    return { job: project(r.rows[0]) };
  });
}
export async function claimAccountExport(
  options: { leaseSeconds?: number; deadlineAt?: number } = {},
): Promise<ExportClaim | null> {
  assertInternal();
  requireWindow(options.deadlineAt, options.deadlineAt === undefined ? 0 : 7000);
  const seconds = options.leaseSeconds ?? 60;
  ensure(
    Number.isInteger(seconds) && seconds >= 1 && seconds <= 300,
    400,
    "导出租约无效。",
  );
  return transaction(async (db) => {
    await db.query(
      `WITH exhausted AS (
        SELECT id FROM account_exports WHERE status='BUILDING'
          AND lease_until<=clock_timestamp() AND attempts>=5
        ORDER BY lease_until,id LIMIT 100 FOR UPDATE SKIP LOCKED
      ) UPDATE account_exports e SET status='FAILED',lease_token=NULL,lease_until=NULL,
        last_error='RETRIES_EXHAUSTED' FROM exhausted x WHERE e.id=x.id`,
    );
    const r = await db.query(
      "SELECT e.* FROM account_exports e JOIN accounts a ON a.id=e.account_id AND a.status='ACTIVE' WHERE e.attempts<5 AND (e.status='QUEUED' OR (e.status='BUILDING' AND e.lease_until<=clock_timestamp())) ORDER BY e.created_at FOR UPDATE OF e SKIP LOCKED LIMIT 1",
    );
    if (!r.rows[0]) return null;
    const leaseToken = randomUUID();
    await db.query(
      "UPDATE account_exports SET status='BUILDING',lease_token=$2,lease_until=clock_timestamp()+$3*interval '1 second',attempts=attempts+1,last_error=NULL WHERE id=$1",
      [r.rows[0].id, leaseToken, seconds],
    );
    return { id: r.rows[0].id, accountId: r.rows[0].account_id, leaseToken };
  }, { deadlineAt: options.deadlineAt });
}
/** Deliberate white-list: no sessions, OTPs, command payloads, drafts or private review authority. */
async function collectExport(db: PoolClient, accountId: string) {
  const account = await lockActiveAccount(db, accountId),
    version = await snapshotVersion(db, accountId);
  // UUID is validated before using the simple-query multi-result protocol.
  // Native pg row parsers retain the exact prior date/bigint/JSON representation.
  // Every SELECT remains explicitly account scoped and under the same locks.
  const fixedId=z.uuid().parse(accountId);
  const selects=[
    "SELECT id,appearance_id,appearance_version,name,adopted_at FROM cat_profiles WHERE account_id=$1",
    "SELECT id,type,snapshot,trip_id,story_id,calendar_node_id,delivered_at,planned_at,effective_at,read_at,skipped_at,origin FROM cloud_letters WHERE account_id=$1 ORDER BY delivered_at,id",
    "SELECT id,letter_id,current_revision,status,created_at,deleted_at,origin FROM cloud_responses WHERE account_id=$1 ORDER BY id",
    "SELECT r.response_id,r.revision,CASE WHEN p.status='DELETED' THEN NULL ELSE r.text END AS text,r.at FROM cloud_response_revisions r JOIN cloud_responses p ON (p.account_id,p.cat_id,p.id)=(r.account_id,r.cat_id,r.response_id) WHERE r.account_id=$1 ORDER BY r.response_id,r.revision",
    "SELECT letter_id,source_order,response_id,revision,claim,start_offset,end_offset,assessment FROM cloud_letter_sources WHERE account_id=$1 ORDER BY letter_id,source_order",
    "SELECT id,scene,status,started_at,ended_at,planned_start_at,planned_end_at,origin FROM cloud_trips WHERE account_id=$1 ORDER BY id",
    "SELECT version,initialized_at,base_at,offset_ms,last_effective_at,processed_count,node_count FROM cloud_calendars WHERE account_id=$1",
    "SELECT id,planned_at,node_order,kind,trip_id,scene,content_id,origin,result_outcome,result_reason,written_at,effective_at,letter_id FROM cloud_calendar_nodes WHERE account_id=$1 ORDER BY node_order",
    "SELECT logical_cat_id FROM legacy_bindings WHERE account_id=$1",
    "SELECT l.id,l.content_id,l.type,l.snapshot,l.trip_id,l.delivered_at,l.read_at,l.skipped_at,l.simulation FROM letters l JOIN cat_profiles c ON c.participant_id=l.participant_id WHERE c.account_id=$1 ORDER BY l.delivered_at,l.id",
    "SELECT r.id,r.letter_id,r.text,r.created_at FROM responses r JOIN cat_profiles c ON c.participant_id=r.participant_id WHERE c.account_id=$1 ORDER BY r.created_at,r.id",
    "SELECT t.id,t.started_at,t.ended_at,t.simulation FROM trips t JOIN cat_profiles c ON c.participant_id=t.participant_id WHERE c.account_id=$1 ORDER BY t.started_at,t.id"
];
  const sql=selects.map(query=>query.replaceAll('$1',`'${fixedId}'::uuid`)).join(';');
  const results:unknown=await db.query(sql);
  ensure(Array.isArray(results)&&results.length===selects.length&&
    results.every(r=>r?.command==='SELECT'&&Array.isArray(r.rows)),503,'EXPORT_SNAPSHOT_RESULTS_INCOMPLETE');
  const rows=new Map(selects.map((query,i)=>[query,(results as {rows:any[]}[])[i].rows]));
  const q = async (query:string) => {const found=rows.get(query);ensure(found,503,'EXPORT_SNAPSHOT_QUERY_MISMATCH');return found;};
  const cat =
    (
      await q(
        "SELECT id,appearance_id,appearance_version,name,adopted_at FROM cat_profiles WHERE account_id=$1",
      )
    )[0] ?? null;
  const letters = await q(
    "SELECT id,type,snapshot,trip_id,story_id,calendar_node_id,delivered_at,planned_at,effective_at,read_at,skipped_at,origin FROM cloud_letters WHERE account_id=$1 ORDER BY delivered_at,id",
  );
  const responses = await q(
    "SELECT id,letter_id,current_revision,status,created_at,deleted_at,origin FROM cloud_responses WHERE account_id=$1 ORDER BY id",
  );
  const revisions = await q(
    "SELECT r.response_id,r.revision,CASE WHEN p.status='DELETED' THEN NULL ELSE r.text END AS text,r.at FROM cloud_response_revisions r JOIN cloud_responses p ON (p.account_id,p.cat_id,p.id)=(r.account_id,r.cat_id,r.response_id) WHERE r.account_id=$1 ORDER BY r.response_id,r.revision",
  );
  const sources = await q(
    "SELECT letter_id,source_order,response_id,revision,claim,start_offset,end_offset,assessment FROM cloud_letter_sources WHERE account_id=$1 ORDER BY letter_id,source_order",
  );
  const trips = await q(
    "SELECT id,scene,status,started_at,ended_at,planned_start_at,planned_end_at,origin FROM cloud_trips WHERE account_id=$1 ORDER BY id",
  );
  const calendar =
    (
      await q(
        "SELECT version,initialized_at,base_at,offset_ms,last_effective_at,processed_count,node_count FROM cloud_calendars WHERE account_id=$1",
      )
    )[0] ?? null;
  const nodes = await q(
    "SELECT id,planned_at,node_order,kind,trip_id,scene,content_id,origin,result_outcome,result_reason,written_at,effective_at,letter_id FROM cloud_calendar_nodes WHERE account_id=$1 ORDER BY node_order",
  );
  const logical =
    (
      await q("SELECT logical_cat_id FROM legacy_bindings WHERE account_id=$1")
    )[0]?.logical_cat_id ??
    cat?.id ??
    null;
  const legacyHistory = {
    letters: await q(
      "SELECT l.id,l.content_id,l.type,l.snapshot,l.trip_id,l.delivered_at,l.read_at,l.skipped_at,l.simulation FROM letters l JOIN cat_profiles c ON c.participant_id=l.participant_id WHERE c.account_id=$1 ORDER BY l.delivered_at,l.id",
    ),
    responses: await q(
      "SELECT r.id,r.letter_id,r.text,r.created_at FROM responses r JOIN cat_profiles c ON c.participant_id=r.participant_id WHERE c.account_id=$1 ORDER BY r.created_at,r.id",
    ),
    trips: await q(
      "SELECT t.id,t.started_at,t.ended_at,t.simulation FROM trips t JOIN cat_profiles c ON c.participant_id=t.participant_id WHERE c.account_id=$1 ORDER BY t.started_at,t.id",
    ),
  };
  return {
    version,
    data: {
      format: "cat-letters-account-export",
      version: 1,
      exportedAt: new Date().toISOString(),
      account: {
        id: account.id,
        email: account.email_normalized,
        createdAt: account.created_at,
      },
      cat: cat ? { ...cat, logicalId: logical } : null,
      stateRevision:
        version.revision === null ? null : Number(version.revision),
      letters,
      responses,
      responseRevisions: revisions,
      letterSources: sources,
      trips,
      calendar: calendar ? { ...calendar, nodes } : null,
      legacyHistory,
      omitted: ["本机草稿", "验证码与登录凭证", "内部操作记录"],
    },
  };
}
export async function runClaimedAccountExport(claim: ExportClaim, deadlineAt?: number) {
  assertInternal();
  const run = async (
    tx: <T>(fn: (db: PoolClient) => Promise<T>) => Promise<T>,
  ) => {
    const artifact = `${claim.id}.${randomUUID()}.json`;
    const storage = configuredExportStorage();
    try {
      requireWindow(deadlineAt);
      const snapshot = await tx(async (db) => {
        await lockActiveAccount(db, claim.accountId);
        const r = await db.query(
          "SELECT * FROM account_exports WHERE id=$1 AND account_id=$2 AND status='BUILDING' AND lease_token=$3 AND lease_until>clock_timestamp() FOR UPDATE",
          [claim.id, claim.accountId, claim.leaseToken],
        );
        if (!r.rows[0]) return null;
        return collectExport(db, claim.accountId);
      });
      if (!snapshot) return { status: "STALE" };
      requireWindow(deadlineAt);
      const bytes = Buffer.from(JSON.stringify(snapshot.data, null, 2));
      ensure(
        bytes.byteLength <= EXPORT_MAX_BYTES,
        503,
        "导出超过本轮处理范围。",
      );
      if (storage.kind === "file") await storage.write(artifact, bytes);
      requireWindow(deadlineAt);
      const result = await tx(async (db) => {
        await lockActiveAccount(db, claim.accountId);
        const now = await snapshotVersion(db, claim.accountId);
        const same =
          now.catId === snapshot.version.catId &&
          now.revision === snapshot.version.revision;
        const live = await db.query(
          "SELECT id FROM account_exports WHERE id=$1 AND account_id=$2 AND status='BUILDING' AND lease_token=$3 AND lease_until>clock_timestamp() FOR UPDATE",
          [claim.id, claim.accountId, claim.leaseToken],
        );
        if (!live.rows[0]) return { status: "STALE" };
        if (storage.kind === "postgres" && same)
          await storage.write(artifact, bytes, db);
        const r = await db.query(
          "UPDATE account_exports SET status=$4,cat_id=$5,captured_revision=$6,expires_at=clock_timestamp()+interval '24 hours',artifact_hash=$7,artifact_bytes=$8,artifact_name=$9,lease_token=NULL,lease_until=NULL WHERE id=$1 AND account_id=$2 AND status='BUILDING' AND lease_token=$3 AND lease_until>clock_timestamp() RETURNING *",
          [
            claim.id,
            claim.accountId,
            claim.leaseToken,
            same ? "READY" : "REVOKED",
            snapshot.version.catId,
            snapshot.version.revision,
            sha(bytes),
            bytes.byteLength,
            artifact,
          ],
        );
        // Never commit chunks if the publication lease expired during INSERT.
        if (storage.kind === "postgres")
          ensure(r.rows[0], 409, "导出租约已失效，请重试。");
        return r.rows[0]
          ? { status: r.rows[0].status, job: project(r.rows[0]) }
          : { status: "STALE" };
      });
      if (result.status !== "READY" && storage.kind === "file")
        await deletePrivateFile(artifact);
      return result;
    } catch (error) {
      let cleanupFailed = false;
      try {
        if (storage.kind === "file") await deletePrivateFile(artifact);
      } catch {
        cleanupFailed = true;
      }
      await tx(async (db) => {
        await lockActiveAccount(db, claim.accountId);
        await db.query(
          "UPDATE account_exports SET status='FAILED',lease_token=NULL,lease_until=NULL,last_error=$4 WHERE id=$1 AND account_id=$2 AND lease_token=$3",
          [
            claim.id,
            claim.accountId,
            claim.leaseToken,
            cleanupFailed
              ? "EXPORT_FILE_CLEANUP_FAILED"
              : error instanceof HttpError && error.status === 507
                ? "EXPORT_STORAGE_FULL"
                : "EXPORT_FAILED",
          ],
        );
      }).catch(() => {});
      throw error;
    }
  };
  if (lifecycleAdapterMode() === "postgres-v1")
    return independentLedger(pool).withShared((op) =>
      run((fn) => op.businessTx(fn)),
      deadlineAt,
    );
  return withLifecycleReadLock((connection) =>
    run((fn) => guardedLifecycleTx(connection, fn)),
  );
}
export async function downloadAccountExport(accountId: string, id: string) {
  ensure(
    configuredExportStorage().kind === "file",
    409,
    "请刷新页面后使用分块下载。私有文件不会直接公开。",
  );
  z.uuid().parse(id);
  const result = await transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    const v = await snapshotVersion(db, accountId);
    const r = await db.query(
      "SELECT *,expires_at>clock_timestamp() AS valid FROM account_exports WHERE id=$1 AND account_id=$2 FOR UPDATE",
      [id, accountId],
    );
    const job = r.rows[0];
    ensure(job, 404, "没有找到这份导出。");
    ensure(
      job.status === "READY",
      409,
      "这份导出尚未就绪或已失效，请重新导出。",
    );
    ensure(job.valid, 410, "这份导出已过期，请重新导出。");
    ensure(
      job.cat_id === v.catId && job.captured_revision === v.revision,
      409,
      "记录已经改变，请重新导出当前内容。",
    );
    try {
      ensure(
        typeof job.artifact_name === "string" &&
          job.artifact_name.startsWith(`${id}.`) &&
          /^[a-f0-9-]{36}\.[a-f0-9-]{36}\.json$/.test(job.artifact_name),
        503,
        "导出文件校验失败。",
      );
      const path = join(exportDirectory(), job.artifact_name);
      ensure(
        existsSync(path) && !lstatSync(path).isSymbolicLink(),
        503,
        "导出文件暂不可用，请重试。",
      );
      const bytes = readFileSync(path);
      ensure(
        bytes.byteLength === Number(job.artifact_bytes) &&
          sha(bytes) === job.artifact_hash,
        503,
        "导出文件校验失败。",
      );
      return { failed: false as const, bytes, filename: filename(id) };
    } catch {
      await db.query(
        "UPDATE account_exports SET status='FAILED',last_error='EXPORT_FILE_UNAVAILABLE',lease_token=NULL,lease_until=NULL WHERE id=$1 AND account_id=$2",
        [id, accountId],
      );
      // Commit the recoverable task status before returning the download error.
      return { failed: true as const };
    }
  });
  ensure(!result.failed, 503, "导出文件暂不可用，请重试准备。");
  return { bytes: result.bytes, filename: result.filename };
}
export async function cleanupAccountExports() {
  const clean = async (
    tx: <T>(fn: (db: PoolClient) => Promise<T>) => Promise<T>,
  ) => {
    const jobs = await tx(async (db) => {
      // Rate-limit keys have no payloads and are temporary; do not erase a new same-email account's live bucket.
      await db.query(
        "DELETE FROM account_rate_limits WHERE window_at<clock_timestamp()-interval '24 hours'",
      );
      await db.query(
        "DELETE FROM rate_limits WHERE window_at<clock_timestamp()-interval '24 hours'",
      );
      await db.query(
        "UPDATE account_exports SET status='EXPIRED',lease_token=NULL,lease_until=NULL WHERE status='READY' AND expires_at<=clock_timestamp()",
      );
      await db.query(
        "UPDATE account_exports e SET status='REVOKED' WHERE e.status='READY' AND NOT EXISTS(SELECT 1 FROM accounts a LEFT JOIN cat_profiles c ON c.account_id=a.id LEFT JOIN cloud_state s ON s.cat_id=c.id AND s.account_id=a.id WHERE a.id=e.account_id AND a.status='ACTIVE' AND e.cat_id IS NOT DISTINCT FROM c.id AND e.captured_revision IS NOT DISTINCT FROM s.revision)",
      );
      return (
        await db.query(
          "SELECT id,status,artifact_name,lease_until>clock_timestamp() AS lease_valid FROM account_exports",
        )
      ).rows;
    });
    const byId = new Map(jobs.map((r) => [r.id, r]));
    const storage = configuredExportStorage();
    const keep = (name: string) => {
      const job = byId.get(name.slice(0, 36));
      return (
        (job?.status === "READY" && name === job.artifact_name) ||
        (job?.status === "BUILDING" && job.lease_valid === true)
      );
    };
    return storage.kind === "postgres"
      ? tx((db) => storage.cleanup(keep, db))
      : storage.cleanup(keep);
  };
  if (lifecycleAdapterMode() === "postgres-v1")
    return independentLedger(pool).withExclusive((op) =>
      clean((fn) => op.businessTx(fn)),
    );
  return withLifecycleLock((connection) =>
    clean((fn) => guardedLifecycleTx(connection, fn)),
  );
}

/** One scheduled cleanup transaction; at most `limit` selected rows in total. */
export async function cleanupAccountExportsBounded(deadlineAt: number, limit = 100) {
  assertInternal();
  ensure(configuredExportStorage().kind === "postgres" && lifecycleAdapterMode() === "postgres-v1",
    503, "定时清理需要独立账本和 PostgreSQL 私有导出。");
  ensure(Number.isInteger(limit) && limit > 0 && limit <= 100, 400, "清理批量无效。");
  requireWindow(deadlineAt, 7000);
  return independentLedger(pool).withExclusive(op => op.businessTx(async db => {
    let left = limit;
    const expired = await db.query(
      `WITH selected AS (
        SELECT id FROM account_exports WHERE status='READY' AND expires_at<=clock_timestamp()
        ORDER BY created_at,id LIMIT $1 FOR UPDATE SKIP LOCKED
      ) UPDATE account_exports e SET status='EXPIRED',lease_token=NULL,lease_until=NULL
        FROM selected s WHERE e.id=s.id RETURNING e.id`, [left]);
    left -= expired.rowCount ?? 0;
    const revoked = left > 0 ? await db.query(
      `WITH selected AS (
        SELECT e.id FROM account_exports e WHERE e.status='READY' AND NOT EXISTS(
          SELECT 1 FROM accounts a LEFT JOIN cat_profiles c ON c.account_id=a.id
          LEFT JOIN cloud_state s ON s.cat_id=c.id AND s.account_id=a.id
          WHERE a.id=e.account_id AND a.status='ACTIVE'
            AND e.cat_id IS NOT DISTINCT FROM c.id
            AND e.captured_revision IS NOT DISTINCT FROM s.revision)
        ORDER BY e.created_at,e.id LIMIT $1 FOR UPDATE OF e SKIP LOCKED
      ) UPDATE account_exports e SET status='REVOKED'
        FROM selected s WHERE e.id=s.id RETURNING e.id`, [left]) : null;
    left -= revoked?.rowCount ?? 0;
    const accountRates = left > 0 ? await db.query(
      `WITH selected AS (
        SELECT key FROM account_rate_limits WHERE window_at<clock_timestamp()-interval '24 hours'
        ORDER BY window_at,key LIMIT $1 FOR UPDATE SKIP LOCKED
      ) DELETE FROM account_rate_limits r USING selected s WHERE r.key=s.key RETURNING r.key`, [left]) : null;
    left -= accountRates?.rowCount ?? 0;
    const rates = left > 0 ? await db.query(
      `WITH selected AS (
        SELECT key FROM rate_limits WHERE window_at<clock_timestamp()-interval '24 hours'
        ORDER BY window_at,key LIMIT $1 FOR UPDATE SKIP LOCKED
      ) DELETE FROM rate_limits r USING selected s WHERE r.key=s.key RETURNING r.key`, [left]) : null;
    left -= rates?.rowCount ?? 0;
    const chunks = left > 0 ? await db.query(
      `WITH selected AS (
        SELECT p.export_id,p.artifact_name,p.chunk_index FROM private_export_chunks p
        JOIN account_exports e ON e.id=p.export_id
        WHERE NOT (e.status='READY' AND e.artifact_name=p.artifact_name)
          AND NOT (e.status='BUILDING' AND e.lease_until>clock_timestamp())
        ORDER BY p.export_id,p.artifact_name,p.chunk_index
        LIMIT $1 FOR UPDATE OF p SKIP LOCKED
      ) DELETE FROM private_export_chunks p USING selected s
        WHERE p.export_id=s.export_id AND p.artifact_name=s.artifact_name
          AND p.chunk_index=s.chunk_index RETURNING p.export_id`, [left]) : null;
    left -= chunks?.rowCount ?? 0;
    return { status: "CLEANED" as const, selected: limit - left,
      expired: expired.rowCount ?? 0, revoked: revoked?.rowCount ?? 0,
      rateLimits: (accountRates?.rowCount ?? 0) + (rates?.rowCount ?? 0),
      orphanChunks: chunks?.rowCount ?? 0 };
  }), deadlineAt);
}

export async function runExportWorkerOnce(deadlineAt?: number) {
  const claim = await claimAccountExport({ deadlineAt });
  return claim ? runClaimedAccountExport(claim, deadlineAt) : { status: "IDLE" };
}

/** Session lock is held until the chunk is read; logout/deletion cannot revoke mid-read. */
async function checkDownloadSession(
  db: PoolClient,
  accountId: string,
  raw: string | undefined,
) {
  ensure(raw && /^[a-f0-9]{64}$/.test(raw), 401, "请重新登录。");
  const r = await db.query(
    "SELECT token_hash FROM account_sessions WHERE token_hash=$1 AND account_id=$2 AND revoked_at IS NULL AND expires_at>clock_timestamp() FOR SHARE",
    [digest(raw), accountId],
  );
  ensure(r.rows[0], 401, "会话已过期，请重新登录。");
}
async function readDownloadPart<T>(
  accountId: string,
  id: string,
  raw: string | undefined,
  version: string | undefined,
  read: (
    name: string,
    manifest: ExportDownloadManifest,
    db: PoolClient,
  ) => Promise<T>,
): Promise<T> {
  z.uuid().parse(id);
  const result = await transaction(async (db) => {
    await lockActiveAccount(db, accountId);
    await checkDownloadSession(db, accountId, raw);
    const current = await snapshotVersion(db, accountId);
    const {
      rows: [job],
    } = await db.query(
      "SELECT *,expires_at>clock_timestamp() AS valid FROM account_exports WHERE id=$1 AND account_id=$2 FOR UPDATE",
      [id, accountId],
    );
    ensure(job, 404, "没有找到这份导出。");
    ensure(
      job.status === "READY",
      409,
      "这份导出尚未就绪或已失效，请重新导出。",
    );
    ensure(job.valid, 410, "这份导出已过期，请重新导出。");
    ensure(
      job.cat_id === current.catId &&
        job.captured_revision === current.revision,
      409,
      "记录已经改变，请重新导出当前内容。",
    );
    ensure(
      version === undefined || version === exportSha(job.artifact_name),
      409,
      "导出内容已经改变，请重新下载。",
    );
    let value: T;
    try {
      const manifest = await configuredExportStorage().manifest(
        job.artifact_name,
        db,
      );
      ensure(
        manifest.bytes === Number(job.artifact_bytes) &&
          manifest.sha256 === job.artifact_hash,
        503,
        "导出文件校验失败。",
      );
      value = await read(job.artifact_name, manifest, db);
    } catch (error) {
      if (error instanceof HttpError && error.status < 500) throw error;
      await db.query(
        "UPDATE account_exports SET status='FAILED',last_error='EXPORT_FILE_UNAVAILABLE',lease_token=NULL,lease_until=NULL WHERE id=$1 AND account_id=$2",
        [id, accountId],
      );
      return { failed: true as const };
    }
    // Long storage reads must not extend an expired session or artifact's authority.
    await checkDownloadSession(db, accountId, raw);
    const {
      rows: [still],
    } = await db.query(
      "SELECT expires_at>clock_timestamp() AS valid FROM account_exports WHERE id=$1",
      [id],
    );
    ensure(still?.valid, 410, "这份导出已过期，请重新导出。");
    return { failed: false as const, value };
  });
  ensure(!result.failed, 503, "导出文件暂不可用，请重试准备。");
  return result.value;
}
export async function accountExportManifest(
  accountId: string,
  id: string,
  raw: string | undefined,
) {
  return readDownloadPart(
    accountId,
    id,
    raw,
    undefined,
    async (_name, manifest) => manifest,
  );
}
export async function accountExportChunk(
  accountId: string,
  id: string,
  raw: string | undefined,
  index: number,
  version: string,
) {
  ensure(
    Number.isInteger(index) &&
      index >= 0 &&
      index < 16 &&
      /^[a-f0-9]{64}$/.test(version),
    400,
    "导出分块请求无效。",
  );
  return readDownloadPart(
    accountId,
    id,
    raw,
    version,
    async (name, manifest, db) => {
      ensure(index < manifest.chunks.length, 400, "导出分块请求无效。");
      const bytes = await configuredExportStorage().chunk(
        name,
        index,
        manifest,
        db,
      );
      return { bytes, sha256: manifest.chunks[index].sha256 };
    },
  );
}
