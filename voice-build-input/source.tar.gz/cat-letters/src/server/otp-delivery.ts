import { mkdir, writeFile } from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { HttpError } from "./errors";
import { createResendOtpDelivery, type ResendOtpDependencies } from "./resend-otp-delivery";

export type OtpMessage = {
  challengeId: string;
  email: string;
  code: string;
  expiresAt: string;
};
export interface OtpDelivery {
  readonly mode?: "synthetic-v1" | "resend-v1";
  send(message: OtpMessage): Promise<void>;
}

/** A test dependency, never exposed through a route or ordinary application log. */
export class SyntheticMailbox implements OtpDelivery {
  readonly mode = "synthetic-v1" as const;
  readonly messages = new Map<string, OtpMessage>();
  async send(message: OtpMessage) {
    this.messages.set(message.challengeId, { ...message });
  }
}

const memoryMailbox = new SyntheticMailbox();
/** Only the configured in-process adapter is server data; injected test mailboxes belong to tests. */
export function eraseInMemoryOtpRecords(ids:readonly string[]) {
  for(const id of ids)memoryMailbox.messages.delete(id);
}

/** Active OTP transport metadata; distinct from the app's safety adapter. */
export function configuredOtpMode(
  env: Readonly<Record<string, string | undefined>> = process.env,
): "synthetic-v1" | "resend-v1" {
  if (env.APP_MODE !== "INTERNAL" ||
    !["synthetic-v1", "resend-v1"].includes(env.OTP_ADAPTER ?? "")) {
    throw new HttpError(503, "验证码服务尚未配置。");
  }
  return env.OTP_ADAPTER as "synthetic-v1" | "resend-v1";
}

export function configuredOtpDelivery(
  env: Readonly<Record<string, string | undefined>> = process.env,
  dependencies: ResendOtpDependencies = {},
): OtpDelivery {
  const mode = configuredOtpMode(env);
  if (mode === "resend-v1") {
    return createResendOtpDelivery({ apiKey: env.RESEND_API_KEY, from: env.OTP_FROM }, dependencies);
  }
  const directory = env.E4_SYNTHETIC_MAILBOX_DIR;
  if (!directory) return memoryMailbox;
  if (!isAbsolute(directory))
    throw new Error("Synthetic mailbox must be absolute");
  return {
    mode: "synthetic-v1",
    async send(message) {
      // Only the isolated test harness supplies this private, temporary directory.
      await mkdir(directory, { recursive: true, mode: 0o700 });
      await writeFile(
        join(directory, `${message.challengeId}.json`),
        JSON.stringify(message),
        { mode: 0o600, flag: "wx" },
      );
    },
  };
}
