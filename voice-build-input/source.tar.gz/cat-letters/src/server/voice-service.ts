import { createHash, randomUUID } from "node:crypto";
import type { PoolClient } from "pg";
import { z } from "zod";
import { withAccountIdentity } from "./account-auth";
import { lockActiveAccount } from "./account-service";
import { digest } from "./auth";
import { transaction } from "./db";
import { ensure, HttpError } from "./errors";
import { voiceScope, voiceCapabilities } from "./voice-config";
import { inspectVoiceAudio, normalizeVoiceAudio } from "./voice-probe";
import {
  configuredVoiceProvider,
  type VoiceTranscriber,
} from "./voice-provider";
import { VOICE_MAX_BYTES, VOICE_MIMES, type VoiceJob } from "../shared/voice";
import { validResponseText } from "../shared/response-text";
import { configuredVoicePayloadStore, type PayloadRef } from "./voice-payload-store";
import { cleanupVoiceFiles } from "./voice-probe";

export type VoiceIdentity = {
  token: string | undefined;
  account: string | null;
};
type Row = {
  id: string;
  account_id: string;
  session_hash: string;
  cat_id: string;
  letter_id: string;
  request_key: string;
  audio_hash: string;
  expected_bytes: number;
  mime_type: string;
  status: VoiceJob["status"];
  provider_mode: string;
  expires_at: Date;
  lease_token: string | null;
  lease_until: Date | null;
  attempts: number;
  last_error: string | null;
  payload_epoch: string | null;
  audio_version: string | null;
  audio_bytes: string | number;
  text_version: string | null;
  text_bytes: number;
  reserved_bytes: string | number;
};
const terminal = (s: string) =>
  ["CONFIRMED", "CANCELLED", "EXPIRED"].includes(s);
const uuid = (id: string) => z.uuid().parse(id);
const view = (r: Row, text?: string): VoiceJob => ({
  id: r.id,
  status: r.status,
  expiresAt: r.expires_at.toISOString(),
  mode: r.provider_mode,
  error: r.last_error,
  ...(text === undefined ? {} : { text }),
});
async function guarded<T>(
  identity: VoiceIdentity,
  fn: (db: PoolClient, id: string, session: string) => Promise<T>,
) {
  return withAccountIdentity(identity.token, async (db, id) => {
    ensure(identity.account === id, 401, "登录账号已变化，请重新载入。");
    await lockActiveAccount(db, id);
    const session = digest(identity.token!);
    const s = await db.query(
      "SELECT token_hash FROM account_sessions WHERE token_hash=$1 AND account_id=$2 AND revoked_at IS NULL AND expires_at>clock_timestamp() FOR SHARE",
      [session, id],
    );
    ensure(s.rowCount, 401, "会话已过期，请重新登录。");
    return fn(db, id, session);
  });
}
async function job(
  db: PoolClient,
  id: string,
  account: string,
  session: string,
): Promise<Row> {
  const r = (
    await db.query(
      "SELECT * FROM private_voice_jobs WHERE id=$1 AND account_id=$2 AND session_hash=$3 FOR UPDATE",
      [uuid(id), account, session],
    )
  ).rows[0] as Row | undefined;
  ensure(r, 404, "没有找到这段录音。");
  if (!terminal(r.status) && r.expires_at.getTime() <= Date.now()) {
    await db.query(
      "UPDATE private_voice_jobs SET status='EXPIRED',lease_token=NULL,lease_until=NULL,last_error='EXPIRED' WHERE id=$1",
      [r.id],
    );
    r.status = "EXPIRED";
    r.lease_token = null;
    r.lease_until = null;
    r.last_error = "EXPIRED";
  }
  return r;
}
const budget = async (db: PoolClient, requireHealthy = true) => {
  const r = (
    await db.query(
      "SELECT * FROM private_voice_budget WHERE singleton FOR UPDATE",
    )
  ).rows[0];
  ensure(r, 503, "语音暂不可用，你可以继续打字。");
  if (requireHealthy) ensure(
    r.cleanup_epoch === (await configuredVoicePayloadStore()).epoch &&
    Number(r.cleanup_failures) < 3 &&
    Date.now() - new Date(r.last_cleanup_at).getTime() <= 180_000 &&
    new Date(r.last_cleanup_at).getTime() <= Date.now() + 30_000,
    503, "语音清理暂不可用，你可以继续打字。",
  );
  return Number(r.max_bytes);
};
const ref = (r: Row, kind: "audio" | "text"): PayloadRef | null => {
  const version = kind === "audio" ? r.audio_version : r.text_version;
  const bytes = Number(kind === "audio" ? r.audio_bytes : r.text_bytes);
  return version && r.payload_epoch && bytes > 0
    ? { jobId: r.id, kind, version, epoch: r.payload_epoch, bytes } : null;
};
async function markLost(db: PoolClient, r: Row) {
  await db.query("UPDATE private_voice_jobs SET status='FAILED',last_error='AUDIO_LOST',lease_token=NULL,lease_until=NULL WHERE id=$1", [r.id]);
  r.status = "FAILED"; r.last_error = "AUDIO_LOST";
  r.audio_version = null; r.text_version = null; r.payload_epoch = null;
  r.audio_bytes = 0; r.text_bytes = 0; r.reserved_bytes = 0;
}
async function cleanupFailed() {
  await transaction(db => db.query("UPDATE private_voice_budget SET cleanup_failures=LEAST(cleanup_failures+1,1000000),last_cleanup_error='FILE_CLEANUP_FAILED' WHERE singleton"));
}
async function removeRefs(refs: (PayloadRef | null)[]) {
  const material = refs.filter((r): r is PayloadRef => r !== null);
  if (!material.length) return;
  try {
    const store = await configuredVoicePayloadStore();
    for (const r of material) await store.remove(r);
  } catch { await cleanupFailed().catch(() => {}); }
}
/** COMMIT can succeed while its acknowledgement is lost. Never delete a
 * published generation until a fresh locked read proves it is unreferenced. */
async function compensatePublished(published: PayloadRef) {
  try {
    await transaction(async db => {
      const row = (await db.query("SELECT * FROM private_voice_jobs WHERE id=$1 FOR UPDATE", [published.jobId])).rows[0] as Row | undefined;
      const current = row && ref(row, published.kind);
      if (current?.epoch === published.epoch && current.version === published.version) return;
      await (await configuredVoicePayloadStore()).remove(published);
    }, { deadlineAt: Date.now() + 15_000 });
  } catch { await cleanupFailed().catch(() => {}); }
}
/** Metadata reservations serialize concurrent claims; filesystem usage also
 * charges orphan/old generations until deletion actually succeeds. */
async function reserveCapacity(db: PoolClient, want: number, excludeId?: string) {
  const max = await budget(db), store = await configuredVoicePayloadStore();
  await store.healthCheck();
  const q = (await db.query(
    `SELECT COALESCE(sum(audio_bytes+text_bytes),0)::bigint AS stored,
      COALESCE(sum(reserved_bytes) FILTER(WHERE lease_until>clock_timestamp() AND id<>COALESCE($1::uuid,'00000000-0000-0000-0000-000000000000'::uuid)),0)::bigint AS pending
     FROM private_voice_jobs`, [excludeId ?? null],
  )).rows[0];
  const actual = (await store.list()).reduce((n, e) => n + e.bytes, 0);
  ensure(Math.max(Number(q.stored), actual) + Number(q.pending) + want <= max,
    429, "语音暂时繁忙，请稍后再试。");
}
export async function availableVoice(identity: VoiceIdentity) {
  return guarded(identity, async (db, id) => {
    const caps = await voiceCapabilities(id);
    if (!caps.available) return caps;
    try {
      await db.query("SELECT 1 FROM private_voice_jobs LIMIT 0");
      await db.query("SELECT audio_version,reserved_bytes FROM private_voice_jobs LIMIT 0");
      await budget(db);
    } catch {
      return { ...caps, available: false, mode: "disabled", reason: "unavailable" as const };
    }
    return caps;
  });
}
export const voiceInput = z.strictObject({
  letterId: z.string().min(1).max(256),
  key: z.uuid(),
  hash: z.string().regex(/^[a-f0-9]{64}$/),
  bytes: z.number().int().min(1).max(VOICE_MAX_BYTES),
  mime: z.enum(VOICE_MIMES),
});
export async function createVoice(
  identity: VoiceIdentity,
  input: z.infer<typeof voiceInput>,
) {
  const v = voiceInput.parse(input);
  return guarded(identity, async (db, id, session) => {
    voiceScope(id);
    const caps = await voiceCapabilities(id);
    ensure(caps.available, 503, "语音服务暂不可用，你可以继续打字。");
    const old = (
      await db.query(
        "SELECT * FROM private_voice_jobs WHERE account_id=$1 AND session_hash=$2 AND request_key=$3 FOR UPDATE",
        [id, session, v.key],
      )
    ).rows[0] as Row | undefined;
    if (old) {
      ensure(
        old.letter_id === v.letterId &&
          old.audio_hash === v.hash &&
          old.expected_bytes === v.bytes &&
          old.mime_type === v.mime,
        409,
        "重复请求与原录音不一致。",
      );
      return view(await job(db, old.id, id, session));
    }
    const letter = (
      await db.query(
        "SELECT l.cat_id FROM cloud_letters l JOIN cat_profiles c ON c.id=l.cat_id AND c.account_id=l.account_id WHERE l.account_id=$1 AND l.id=$2 AND l.type='DEMAND' AND l.read_at IS NOT NULL",
        [id, v.letterId],
      )
    ).rows[0];
    ensure(letter, 404, "这封来信当前不能使用语音回应。");
    const limits = (
      await db.query(
        "SELECT count(*) FILTER(WHERE created_at>clock_timestamp()-interval '1 minute')::int AS minute,count(*) FILTER(WHERE created_at>clock_timestamp()-interval '1 hour')::int AS hourly,count(*) FILTER(WHERE expires_at>clock_timestamp() AND status NOT IN ('CONFIRMED','CANCELLED','EXPIRED') AND last_error IS DISTINCT FROM 'AUDIO_LOST')::int AS active FROM private_voice_jobs WHERE account_id=$1",
        [id],
      )
    ).rows[0];
    ensure(
      limits.minute < 3 && limits.hourly < 20 && limits.active < 2,
      429,
      "录音操作太频繁，请稍后再试，也可以继续打字。",
    );
    await reserveCapacity(db, 0);
    const total = (
      await db.query(
        "SELECT count(*)::int AS n FROM private_voice_jobs WHERE created_at>clock_timestamp()-interval '1 minute'",
      )
    ).rows[0].n;
    ensure(total < 30, 429, "语音暂时繁忙，你可以继续打字。");
    const r = (
      await db.query(
        "INSERT INTO private_voice_jobs(id,account_id,session_hash,cat_id,letter_id,request_key,audio_hash,expected_bytes,mime_type,provider_mode) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *",
        [
          randomUUID(),
          id,
          session,
          letter.cat_id,
          v.letterId,
          v.key,
          v.hash,
          v.bytes,
          v.mime,
          caps.mode,
        ],
      )
    ).rows[0] as Row;
    return view(r);
  });
}
export async function readVoice(identity: VoiceIdentity, id: string) {
  return guarded(identity, async (db, account, session) => {
    const r = await job(db, id, account, session);
    if (r.status === "READY") {
      try {
        const pointer = ref(r, "text");
        ensure(pointer, 409, "临时录音已失效。");
        const text = (await (await configuredVoicePayloadStore()).read(pointer)).toString("utf8");
        ensure(text.length > 0 && validResponseText(text), 409, "临时录音已失效。");
        return view(r, text);
      } catch { await markLost(db, r); }
    }
    return view(r);
  });
}
export async function finishVoice(
  identity: VoiceIdentity,
  id: string,
  action: "confirm" | "cancel",
) {
  const ended = await guarded(identity, async (db, account, session) => {
    const r = await job(db, id, account, session);
    if (terminal(r.status)) return { value: view(r), refs: [] as (PayloadRef | null)[] };
    ensure(
      action === "cancel" || r.status === "READY",
      409,
      "转写尚未就绪，不能确认。",
    );
    r.status = action === "confirm" ? "CONFIRMED" : "CANCELLED";
    r.last_error = null;
    await db.query(
      "UPDATE private_voice_jobs SET status=$2,lease_token=NULL,lease_until=NULL,last_error=NULL WHERE id=$1",
      [id, r.status],
    );
    return { value: view(r), refs: [ref(r, "audio"), ref(r, "text")] };
  });
  await removeRefs(ended.refs);
  // A committed terminal row revokes access; only an actual file check/delete
  // may acknowledge physical cleanup. A failure is queued for the timer.
  let complete = false;
  try {
    const store = await configuredVoicePayloadStore();
    for (const e of await store.list()) if (e.ref?.jobId === id) await store.removeEntry(e, 0);
    complete = !(await store.list()).some(e => e.ref?.jobId === id);
  } catch { await cleanupFailed().catch(() => {}); }
  return { ...ended.value, cleanup: complete ? "complete" as const : "pending" as const };
}
export async function claimVoiceUpload(identity: VoiceIdentity, id: string) {
  const claimed = await guarded(identity, async (db, account, session) => {
    voiceScope(account);
    const r = await job(db, id, account, session);
    ensure(r.last_error !== "AUDIO_LOST", 409, "临时录音已丢失，请重新录音。");
    ensure(
      ["CREATED", "FAILED", "UPLOADING"].includes(r.status),
      409,
      "这段录音不能重复上传。",
    );
    ensure(
      r.status !== "UPLOADING" || r.lease_until!.getTime() < Date.now(),
      409,
      "录音正在上传，请稍候。",
    );
    const reserved = r.expected_bytes * 2;
    await reserveCapacity(db, reserved, r.id);
    const q = (
      await db.query(
        "SELECT count(*) FILTER(WHERE status='UPLOADING' AND lease_until>clock_timestamp())::int AS running FROM private_voice_jobs",
      )
    ).rows[0];
    ensure(
      q.running < 2,
      429,
      "语音暂时繁忙，请稍后再试。",
    );
    const previous = [ref(r, "audio"), ref(r, "text")];
    r.lease_token = randomUUID();
    r.status = "UPLOADING";
    await db.query(
      "UPDATE private_voice_jobs SET status='UPLOADING',lease_token=$2,lease_until=clock_timestamp()+interval '30 seconds',last_error=NULL,payload_epoch=NULL,audio_version=NULL,audio_bytes=0,text_version=NULL,text_bytes=0,reserved_bytes=$3 WHERE id=$1",
      [id, r.lease_token, reserved],
    );
    return {
      lease: r.lease_token,
      bytes: r.expected_bytes,
      mime: r.mime_type,
      hash: r.audio_hash,
      previous,
    };
  });
  await removeRefs(claimed.previous);
  const { previous, ...publicClaim } = claimed;
  return publicClaim;
}
export async function failVoiceLease(
  identity: VoiceIdentity,
  id: string,
  lease: string,
  error: string,
) {
  return guarded(identity, async (db, account, session) => {
    const r = await job(db, id, account, session);
    if (r.lease_token === lease)
      await db.query(
        "UPDATE private_voice_jobs SET status='FAILED',lease_token=NULL,lease_until=NULL,last_error=$2 WHERE id=$1",
        [id, error],
      );
  });
}
export async function storeVoiceUpload(
  identity: VoiceIdentity,
  id: string,
  lease: string,
  audio: Buffer,
  signal?: AbortSignal,
) {
  const expected = await guarded(identity, async (db, account, session) => {
    voiceScope(account);
    const r = await job(db, id, account, session);
    ensure(
      r.status === "UPLOADING" &&
        r.lease_token === lease &&
        r.lease_until!.getTime() > Date.now(),
      409,
      "这次录音已取消或失效。",
    );
    return { bytes: r.expected_bytes, mime: r.mime_type, hash: r.audio_hash };
  });
  ensure(
    audio.length === expected.bytes &&
      createHash("sha256").update(audio).digest("hex") === expected.hash,
    400,
    "录音上传不完整，请重新录音。",
  );
  const ms = await inspectVoiceAudio(audio, expected.mime, signal);
  const store = await configuredVoicePayloadStore();
  const staged = await store.stage(id, "audio", audio);
  let published: PayloadRef | undefined;
  try {
    return await guarded(identity, async (db, account, session) => {
      voiceScope(account);
      const r = await job(db, id, account, session);
      ensure(!signal?.aborted && r.status === "UPLOADING" && r.lease_token === lease &&
        r.lease_until!.getTime() > Date.now(), 409, "这次录音已取消或失效。");
      await budget(db);
      published = await store.publish(staged);
      await db.query(
        "UPDATE private_voice_jobs SET status='UPLOADED',duration_ms=$2,lease_token=NULL,lease_until=NULL,last_error=NULL,payload_epoch=$3,audio_version=$4,audio_bytes=$5 WHERE id=$1",
        [id, ms, published.epoch, published.version, published.bytes],
      );
      r.status = "UPLOADED"; r.last_error = null;
      return view(r);
    });
  } catch (e) {
    if (published) await compensatePublished(published);
    throw e;
  } finally { await store.discard(staged).catch(() => cleanupFailed().catch(() => {})); }
}
export async function transcribeVoice(
  identity: VoiceIdentity,
  id: string,
  provider?: VoiceTranscriber,
  signal?: AbortSignal,
) {
  const claim = await guarded(identity, async (db, account, session) => {
    voiceScope(account);
    const r = await job(db, id, account, session);
    if (
      terminal(r.status) ||
      r.status === "READY" ||
      (r.status === "TRANSCRIBING" && r.lease_until!.getTime() > Date.now())
    )
      return { existing: view(r) };
    ensure(
      ["UPLOADED", "FAILED", "TRANSCRIBING"].includes(r.status) &&
        r.attempts < 3,
      409,
      "这段录音无法继续转写，请重新录音或打字。",
    );
    const adapter = provider ?? configuredVoiceProvider();
    ensure(
      adapter.mode === r.provider_mode,
      409,
      "语音服务已变化，请重新录音。",
    );
    await reserveCapacity(db, Number(r.audio_bytes) + 1_920_044 + 128_000, r.id);
    const count = (
      await db.query(
        "SELECT count(*)::int AS n FROM private_voice_jobs WHERE status='TRANSCRIBING' AND lease_until>clock_timestamp()",
      )
    ).rows[0].n;
    ensure(count < 2, 429, "语音暂时繁忙，请稍后重试。");
    let audio: Buffer;
    try {
      const pointer = ref(r, "audio");
      ensure(pointer, 409, "临时录音已失效。");
      audio = await (await configuredVoicePayloadStore()).read(pointer);
    } catch {
      await markLost(db, r);
      return { existing: view(r) };
    }
    const lease = randomUUID();
    await db.query(
      "UPDATE private_voice_jobs SET status='TRANSCRIBING',lease_token=$2,lease_until=clock_timestamp()+interval '45 seconds',attempts=attempts+1,last_error=NULL,reserved_bytes=$3 WHERE id=$1",
      [id, lease, Number(r.audio_bytes) + 1_920_044 + 128_000],
    );
    return {
      lease,
      audio,
      mime: r.mime_type,
      adapter,
    };
  });
  if (claim.existing)
    return claim.existing.status === "READY"
      ? readVoice(identity, id)
      : claim.existing;
  const abort = new AbortController();
  const cancelled = () => abort.abort();
  signal?.addEventListener("abort", cancelled, { once: true });
  if (signal?.aborted) abort.abort();
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const work = async () => {
      const audio = await normalizeVoiceAudio(
        claim.audio!,
        claim.mime!,
        abort.signal,
      );
      const result = await claim.adapter!.transcribe({
        audio,
        mime: "audio/wav",
        jobId: id,
        signal: abort.signal,
      });
      ensure(
        typeof result.text === "string" &&
          result.text.trim().length > 0 &&
          validResponseText(result.text) &&
          !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(result.text),
        502,
        "没有得到可用文字，请重新录音或打字。",
      );
      return result.text.trim();
    };
    const text = await Promise.race([
      work(),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          reject(new HttpError(504, "转写超时，请重试或继续打字。"));
          abort.abort();
        }, 30_000);
        abort.signal.addEventListener(
          "abort",
          () => reject(new HttpError(409, "录音处理已中止。")),
          { once: true },
        );
      }),
    ]);
    const store = await configuredVoicePayloadStore();
    const staged = await store.stage(id, "text", text);
    let published: PayloadRef | undefined;
    try {
      return await guarded(identity, async (db, account, session) => {
        const r = await job(db, id, account, session);
        ensure(!abort.signal.aborted && r.status === "TRANSCRIBING" &&
          r.lease_token === claim.lease && r.lease_until!.getTime() > Date.now() &&
          r.payload_epoch === store.epoch, 409, "这次录音已取消或失效。");
        await budget(db);
        published = await store.publish(staged);
        await db.query(
          "UPDATE private_voice_jobs SET status='READY',lease_token=NULL,lease_until=NULL,last_error=NULL,text_version=$2,text_bytes=$3 WHERE id=$1",
          [id, published.version, published.bytes],
        );
        r.status = "READY"; r.last_error = null;
        return view(r, text);
      });
    } catch (e) {
      if (published) await compensatePublished(published);
      throw e;
    } finally { await store.discard(staged).catch(() => cleanupFailed().catch(() => {})); }
  } catch (e) {
    await failVoiceLease(
      identity,
      id,
      claim.lease!,
      "TRANSCRIPTION_FAILED",
    ).catch(() => {});
    if (e instanceof HttpError) throw e;
    throw new HttpError(503, "转写暂时失败，你可以重试或继续打字。");
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", cancelled);
    abort.abort();
  }
}
/** Separate bounded cleanup; does not change the natural-observation worker. */
export async function cleanupPrivateVoice(accountIds: string[]) {
  ensure(
    accountIds.length > 0 && accountIds.length <= 10,
    503,
    "语音清理范围无效。",
  );
  accountIds.forEach(uuid);
  try {
    const store = await configuredVoicePayloadStore();
    const entries = await store.list();
    const cleaned = await transaction(async (db) => {
    const rows = (
      await db.query(
        `SELECT j.*, (s.token_hash IS NOT NULL AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() AND a.status='ACTIVE') AS authorized
         FROM private_voice_jobs j LEFT JOIN account_sessions s ON s.token_hash=j.session_hash JOIN accounts a ON a.id=j.account_id
         WHERE j.account_id=ANY($1::uuid[]) AND (j.expires_at<=clock_timestamp() OR j.status IN ('UPLOADING','UPLOADED','TRANSCRIBING','READY') OR
           (j.status='FAILED' AND (j.audio_version IS NOT NULL OR j.reserved_bytes>0)) OR
           (j.status NOT IN ('CONFIRMED','CANCELLED','EXPIRED') AND (s.revoked_at IS NOT NULL OR s.expires_at<=clock_timestamp() OR a.status<>'ACTIVE')))
         ORDER BY j.expires_at,j.id LIMIT 100 FOR UPDATE OF j SKIP LOCKED`,
        [accountIds],
      )
    ).rows;
    let changed = 0;
    for (const r of rows) {
      if (new Date(r.expires_at).getTime() <= Date.now() || !r.authorized) {
        await db.query("UPDATE private_voice_jobs SET status='EXPIRED',lease_token=NULL,lease_until=NULL,last_error='EXPIRED' WHERE id=$1", [r.id]);
        changed++;
      } else {
        let missing = false;
        if (["UPLOADED", "TRANSCRIBING", "READY"].includes(r.status)) {
          // Publication may have committed after the initial orphan snapshot.
          // Verify the CURRENT pointer while holding this task's row lock.
          for (const pointer of [ref(r, "audio"), ...(r.status === "READY" ? [ref(r, "text")] : [])]) {
            try {
              ensure(pointer && pointer.epoch === store.epoch, 409, "临时录音已失效。");
              await store.verify(pointer);
            } catch { missing = true; break; }
          }
        }
        if (missing) { await markLost(db, r); changed++; }
        else if (["UPLOADING", "TRANSCRIBING"].includes(r.status) && new Date(r.lease_until).getTime() <= Date.now()) {
          await db.query("UPDATE private_voice_jobs SET status='FAILED',lease_token=NULL,lease_until=NULL,last_error='LEASE_EXPIRED' WHERE id=$1", [r.id]);
          changed++;
        }
      }
    }
    await db.query(
      "DELETE FROM private_voice_jobs WHERE id=ANY($1::uuid[]) AND expires_at<=clock_timestamp()",
      [rows.map((r) => r.id)],
    );
    return changed;
    });
    let files = 0;
    for (const entry of entries) {
      if (files >= 100) break;
      if (entry.type === "initialization") {
        files += Number(await store.removeEntry(entry));
        continue;
      }
      ensure(entry.ref, 503, "私有目录需要检查。");
      files += await transaction(async db => {
        const rows = await db.query(
          `SELECT j.*, (s.token_hash IS NOT NULL AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() AND a.status='ACTIVE') AS authorized
           FROM private_voice_jobs j LEFT JOIN account_sessions s ON s.token_hash=j.session_hash JOIN accounts a ON a.id=j.account_id
           WHERE j.id=$1 FOR UPDATE OF j SKIP LOCKED`, [entry.ref!.jobId],
        );
        const r = rows.rows[0];
        if (!r) {
          // A row held by a publisher is different from a deleted/crashed job.
          if ((await db.query("SELECT 1 FROM private_voice_jobs WHERE id=$1", [entry.ref!.jobId])).rowCount) return 0;
          return Number(await store.removeEntry(entry));
        }
        if (!accountIds.includes(r.account_id)) return 0;
        const pointer = ref(r, entry.ref!.kind);
        const authorized = r.authorized && new Date(r.expires_at).getTime() > Date.now() && !terminal(r.status);
        if (authorized && !entry.staged && pointer?.version === entry.ref!.version && pointer.epoch === store.epoch) return 0;
        if (authorized && entry.staged && r.lease_token && new Date(r.lease_until).getTime() > Date.now()) return 0;
        return Number(await store.removeEntry(entry, terminal(r.status) || r.last_error === "AUDIO_LOST" ? 0 : 120_000));
      });
    }
    const probeFiles = await cleanupVoiceFiles();
    const remaining = await store.list();
    const success = await transaction(async db => (await db.query(
      "UPDATE private_voice_budget SET cleanup_failures=0,last_cleanup_at=clock_timestamp(),cleanup_epoch=$1,last_cleanup_error=NULL WHERE singleton RETURNING last_cleanup_at", [store.epoch],
    )).rows[0].last_cleanup_at as Date);
    return { cleaned, files, probeFiles, payloadBytes: remaining.reduce((n, e) => n + e.bytes, 0),
      oldestAgeMs: Math.max(0, ...remaining.map(e => Date.now() - e.mtimeMs)), lastSuccess: success.toISOString() };
  } catch (e) {
    await cleanupFailed().catch(() => {});
    throw e;
  }
}

/** Post-commit best effort. Triggers already revoked all pointer access. */
async function purgeEndedVoice(where: "session_hash" | "account_id", value: string) {
  if (!process.env.E4_VOICE_STORAGE) return;
  try {
    const ids = await transaction(async db => (await db.query(
      `SELECT id FROM private_voice_jobs WHERE ${where}=$1 AND status IN ('CONFIRMED','CANCELLED','EXPIRED') ORDER BY created_at DESC LIMIT 100`, [value],
    )).rows.map(r => r.id as string));
    const store = await configuredVoicePayloadStore();
    for (const e of await store.list()) if (e.ref && ids.includes(e.ref.jobId)) await store.removeEntry(e, 0);
  } catch { await cleanupFailed().catch(() => {}); }
}
export const purgeVoiceSessionFiles = (sessionHash: string) => purgeEndedVoice("session_hash", sessionHash);
export const purgeVoiceAccountFiles = (accountId: string) => purgeEndedVoice("account_id", accountId);
