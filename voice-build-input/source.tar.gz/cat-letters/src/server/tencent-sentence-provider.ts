import { createHash, createHmac } from "node:crypto";

/** Server-only candidate. This module performs no I/O until transcribe(). */
export interface VoiceTranscriber {
  mode: string;
  transcribe(input: {
    audio: Uint8Array;
    mime: string;
    jobId: string;
    signal: AbortSignal;
  }): Promise<{ text: string }>;
}
export const TENCENT_VOICE_MODE = "tencent-sentence-v1";
const ENDPOINT = "https://asr.tencentcloudapi.com/";
const HOST = "asr.tencentcloudapi.com";
const ACTION = "SentenceRecognition";
const CONTENT_TYPE = "application/json; charset=utf-8";
const SIGNED_HEADERS = "content-type;host;x-tc-action";
const MAX_PCM_BYTES = 60 * 16_000 * 2;
const MAX_BASE64_BYTES = 3_000_000;
const MAX_RESPONSE_BYTES = 64 * 1024;
const MAX_TIMEOUT_MS = 12_000;

export type VoiceProviderCode =
  | "NOT_CONFIGURED"
  | "INVALID_AUDIO"
  | "CANCELLED"
  | "TIMEOUT"
  | "NETWORK"
  | "SERVICE_UNAVAILABLE"
  | "QUOTA_OR_LIMIT"
  | "AUTH_FAILED"
  | "INVALID_RESPONSE"
  | "NO_TEXT";
export class VoiceProviderError extends Error {
  readonly code: VoiceProviderCode;
  constructor(code: VoiceProviderCode) {
    super(`VOICE_PROVIDER_${code}`);
    this.name = "VoiceProviderError";
    this.code = code;
  }
}
function fail(code: VoiceProviderCode): never {
  throw new VoiceProviderError(code);
}

type Credentials = { secretId: string; secretKey: string; token?: string };
type Environment = Readonly<Record<string, string | undefined>>;
export type OfflineDependencies = {
  fetch?: typeof globalThis.fetch;
  now?: () => number;
  /** Tests may shorten the deadline, never increase its production maximum. */
  timeoutMs?: number;
};
function configuredCredentials(env: Environment): Credentials {
  if (typeof window !== "undefined") fail("NOT_CONFIGURED");
  if (
    env.APP_MODE !== "INTERNAL" ||
    env.E4_VOICE_ENABLED !== "true" ||
    env.E4_VOICE_MODE !== TENCENT_VOICE_MODE ||
    env.E4_VOICE_TENCENT_ASR_APPROVED !== "true"
  )
    fail("NOT_CONFIGURED");
  const secretId = env.E4_VOICE_TENCENT_SECRET_ID;
  const secretKey = env.E4_VOICE_TENCENT_SECRET_KEY;
  const token = env.E4_VOICE_TENCENT_TOKEN;
  if (
    !secretId ||
    !/^[A-Za-z0-9]{10,128}$/.test(secretId) ||
    !secretKey ||
    !/^[A-Za-z0-9]{10,128}$/.test(secretKey) ||
    (token !== undefined && !/^[\x21-\x7e]{1,4096}$/.test(token))
  )
    fail("NOT_CONFIGURED");
  return { secretId, secretKey, token };
}

/** Only our canonical 44-byte-header PCM WAV is accepted, not arbitrary uploads. */
export function assertNormalizedWav(audio: Uint8Array, mime: string): Buffer {
  if (
    mime !== "audio/wav" ||
    audio.byteLength < 46 ||
    audio.byteLength > MAX_PCM_BYTES + 44
  )
    fail("INVALID_AUDIO");
  const b = Buffer.from(audio);
  const pcmBytes = b.length - 44;
  if (
    b.toString("ascii", 0, 4) !== "RIFF" ||
    b.readUInt32LE(4) !== b.length - 8 ||
    b.toString("ascii", 8, 16) !== "WAVEfmt " ||
    b.readUInt32LE(16) !== 16 ||
    b.readUInt16LE(20) !== 1 ||
    b.readUInt16LE(22) !== 1 ||
    b.readUInt32LE(24) !== 16_000 ||
    b.readUInt32LE(28) !== 32_000 ||
    b.readUInt16LE(32) !== 2 ||
    b.readUInt16LE(34) !== 16 ||
    b.toString("ascii", 36, 40) !== "data" ||
    b.readUInt32LE(40) !== pcmBytes ||
    pcmBytes % 2 !== 0 ||
    4 * Math.ceil(b.length / 3) > MAX_BASE64_BYTES
  )
    fail("INVALID_AUDIO");
  return b;
}

/** Pure TC3 signing; generic inputs allow verification against Tencent's published CVM example. */
export function tc3Signature(input: {
  body: string;
  host: string;
  service: string;
  action: string;
  timestamp: number;
  secretId: string;
  secretKey: string;
}): {
  authorization: string;
  canonicalHash: string;
  bodyHash: string;
  date: string;
} {
  const hash = (s: string) =>
    createHash("sha256").update(s, "utf8").digest("hex");
  const hmac = (key: string | Buffer, s: string) =>
    createHmac("sha256", key).update(s, "utf8").digest();
  const date = new Date(input.timestamp * 1000).toISOString().slice(0, 10);
  const bodyHash = hash(input.body);
  const canonical = [
    "POST",
    "/",
    "",
    `content-type:${CONTENT_TYPE}\nhost:${input.host.toLowerCase()}\nx-tc-action:${input.action.toLowerCase()}\n`,
    SIGNED_HEADERS,
    bodyHash,
  ].join("\n");
  const canonicalHash = hash(canonical);
  const scope = `${date}/${input.service}/tc3_request`;
  const message = [
    "TC3-HMAC-SHA256",
    String(input.timestamp),
    scope,
    canonicalHash,
  ].join("\n");
  const signingKey = hmac(
    hmac(hmac(`TC3${input.secretKey}`, date), input.service),
    "tc3_request",
  );
  const signature = hmac(signingKey, message).toString("hex");
  return {
    authorization: `TC3-HMAC-SHA256 Credential=${input.secretId}/${scope}, SignedHeaders=${SIGNED_HEADERS}, Signature=${signature}`,
    canonicalHash,
    bodyHash,
    date,
  };
}

async function boundedJson(
  response: Response,
  signal: AbortSignal,
): Promise<unknown> {
  const length = response.headers.get("content-length");
  if (
    length !== null &&
    (!/^\d+$/.test(length) || Number(length) > MAX_RESPONSE_BYTES)
  )
    fail("INVALID_RESPONSE");
  if (!response.body) fail("INVALID_RESPONSE");
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  const cancel = () => {
    void reader.cancel().catch(() => {});
  };
  signal.addEventListener("abort", cancel, { once: true });
  try {
    if (signal.aborted) fail("CANCELLED");
    while (true) {
      const part = await reader.read();
      if (signal.aborted) fail("CANCELLED");
      if (part.done) break;
      size += part.value.byteLength;
      if (size > MAX_RESPONSE_BYTES) fail("INVALID_RESPONSE");
      chunks.push(part.value);
    }
    try {
      return JSON.parse(
        new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks)),
      );
    } catch {
      fail("INVALID_RESPONSE");
    }
  } finally {
    signal.removeEventListener("abort", cancel);
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
function resultText(body: unknown): string {
  if (
    !body ||
    typeof body !== "object" ||
    !("Response" in body) ||
    !body.Response ||
    typeof body.Response !== "object"
  )
    fail("INVALID_RESPONSE");
  const response = body.Response as Record<string, unknown>;
  if (response.Error) {
    const error = response.Error;
    const code =
      typeof error === "object" &&
      error !== null &&
      "Code" in error &&
      typeof error.Code === "string"
        ? error.Code
        : "";
    if (/^(AuthFailure|UnauthorizedOperation)(\.|$)/.test(code))
      fail("AUTH_FAILED");
    if (
      /^(LimitExceeded|RequestLimitExceeded|ResourceUnavailable)(\.|$)/.test(
        code,
      ) ||
      /^FailedOperation\.(UserHasNoAmount|UserHasNoFreeAmount|ServiceIsolate)$/.test(
        code,
      )
    )
      fail("QUOTA_OR_LIMIT");
    fail("SERVICE_UNAVAILABLE");
  }
  const text = response.Result;
  if (typeof text !== "string") fail("INVALID_RESPONSE");
  if (text.trim().length === 0) fail("NO_TEXT");
  if (
    text.length > 16_000 ||
    /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(text)
  )
    fail("INVALID_RESPONSE");
  return text; // No rewriting, negation filtering, truncation or HTML interpretation.
}

/** Returns a disabled error unless the operator explicitly approved this provider. */
export function createTencentSentenceProvider(
  env: Environment = process.env,
  dependencies: OfflineDependencies = {},
): VoiceTranscriber {
  const credentials = configuredCredentials(env);
  const request = dependencies.fetch ?? globalThis.fetch;
  const now = dependencies.now ?? Date.now;
  const timeoutMs = dependencies.timeoutMs ?? MAX_TIMEOUT_MS;
  if (
    !Number.isSafeInteger(timeoutMs) ||
    timeoutMs <= 0 ||
    timeoutMs > MAX_TIMEOUT_MS
  )
    fail("NOT_CONFIGURED");
  return {
    mode: TENCENT_VOICE_MODE,
    async transcribe({ audio, mime, signal }) {
      if (signal.aborted) fail("CANCELLED");
      const wav = assertNormalizedWav(audio, mime);
      const body = JSON.stringify({
        EngSerViceType: "16k_zh",
        SourceType: 1,
        VoiceFormat: "wav",
        Data: wav.toString("base64"),
        DataLen: wav.length,
        WordInfo: 0,
        FilterDirty: 0,
        FilterModal: 0,
        FilterPunc: 0,
        ConvertNumMode: 0,
      });
      const timestamp = Math.floor(now() / 1000);
      if (
        !Number.isSafeInteger(timestamp) ||
        timestamp <= 0 ||
        timestamp > 253_402_300_799
      )
        fail("NOT_CONFIGURED");
      const signed = tc3Signature({
        body,
        host: HOST,
        service: "asr",
        action: ACTION,
        timestamp,
        ...credentials,
      });
      const headers: Record<string, string> = {
        "content-type": CONTENT_TYPE,
        host: HOST,
        "x-tc-action": ACTION,
        "x-tc-timestamp": String(timestamp),
        "x-tc-version": "2019-06-14",
        authorization: signed.authorization,
      };
      if (credentials.token) headers["x-tc-token"] = credentials.token;
      const controller = new AbortController();
      let interruption: "TIMEOUT" | "CANCELLED" | undefined;
      let rejectInterrupted!: (error: VoiceProviderError) => void;
      const interrupted = new Promise<never>((_, reject) => {
        rejectInterrupted = reject;
      });
      const stop = (code: "TIMEOUT" | "CANCELLED") => {
        if (interruption) return;
        interruption = code;
        rejectInterrupted(new VoiceProviderError(code));
        controller.abort();
      };
      const cancel = () => stop("CANCELLED");
      signal.addEventListener("abort", cancel, { once: true });
      const timer = setTimeout(() => stop("TIMEOUT"), timeoutMs);
      try {
        if (signal.aborted) {
          cancel();
          await interrupted;
        }
        const operation = async () => {
          const response = await request(ENDPOINT, {
            method: "POST",
            headers,
            body,
            signal: controller.signal,
            redirect: "error",
            cache: "no-store",
            credentials: "omit",
          });
          if (response.redirected) fail("INVALID_RESPONSE");
          if (!response.ok) {
            void response.body?.cancel().catch(() => {});
            if (response.status === 429) fail("QUOTA_OR_LIMIT");
            if (response.status === 401 || response.status === 403)
              fail("AUTH_FAILED");
            fail("SERVICE_UNAVAILABLE");
          }
          const result = await boundedJson(response, controller.signal);
          if (controller.signal.aborted) fail(interruption ?? "CANCELLED");
          return { text: resultText(result) };
        };
        return await Promise.race([operation(), interrupted]);
      } catch (error) {
        if (interruption) fail(interruption);
        if (error instanceof VoiceProviderError) throw error;
        fail("NETWORK"); // Never expose response bodies, upstream errors or credentials.
      } finally {
        clearTimeout(timer);
        signal.removeEventListener("abort", cancel);
        controller.abort();
      }
    },
  };
}
