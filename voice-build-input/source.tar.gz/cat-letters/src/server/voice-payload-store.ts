import { constants, type Stats } from "node:fs";
import {
  lstat, mkdir, open, link, unlink, opendir, readFile, realpath, statfs,
} from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { basename, isAbsolute, join, relative, resolve } from "node:path";
import { tmpdir } from "node:os";
import { HttpError } from "./errors";

export const VOICE_PAYLOAD_AUDIO_MAX = 10 * 1024 * 1024;
export const VOICE_PAYLOAD_TEXT_MAX = 128_000;
export const VOICE_PAYLOAD_FILE_LIMIT = 4096;
const MOUNT = "/run/cat-voice-private";
const MOUNT_MAX = 128 * 1024 * 1024;
const UUID = "[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}";
const uuid = new RegExp(`^${UUID}$`);
const filePattern = new RegExp(`^\\.(stage|payload)_(${UUID})_(${UUID})_(audio|text)_(${UUID})$`);
const initializationPattern = new RegExp(`^\\.epoch\\.init-(${UUID})$`);
const MARKER = ".epoch";
const TEST_MARKER = ".synthetic-only";
type Environment = Readonly<Record<string, string | undefined>>;
type Identity = { dev: number; ino: number; uid: number };
export type VoicePayloadKind = "audio" | "text";
export type PayloadRef = {
  jobId: string;
  kind: VoicePayloadKind;
  version: string;
  epoch: string;
  bytes: number;
};
export type PayloadStage = PayloadRef & {
  name: string;
  dev: number;
  ino: number;
};
export type PayloadEntry = {
  name: string;
  type: "payload" | "stage" | "initialization" | "unknown";
  staged: boolean;
  ref?: PayloadRef;
  mtimeMs: number;
  bytes: number;
  dev: number;
  ino: number;
};
export type Stage = PayloadStage;
export type Entry = PayloadEntry;
export type VoicePayloadStore = {
  readonly epoch: string;
  readonly root: string;
  healthCheck(): Promise<void>;
  stage(jobId: string, kind: VoicePayloadKind, data: Buffer | string): Promise<PayloadStage>;
  publish(stage: PayloadStage): Promise<PayloadRef>;
  discard(stage: PayloadStage): Promise<void>;
  verify(ref: PayloadRef): Promise<void>;
  read(ref: PayloadRef): Promise<Buffer>;
  remove(ref: PayloadRef): Promise<void>;
  list(limit?: number): Promise<PayloadEntry[]>;
  removeEntry(entry: PayloadEntry, minimumAgeMs?: number): Promise<boolean>;
};
export class VoicePayloadStoreError extends HttpError {
  constructor(public readonly reason: "UNAVAILABLE" | "LOST" | "CAPACITY" | "CONFLICT") {
    super(reason === "CONFLICT" ? 409 : 503,
      reason === "LOST" ? "临时录音已失效，请重新录音。" : "语音临时存储不可用，你可以继续打字。");
  }
}
function fail(reason: VoicePayloadStoreError["reason"] = "UNAVAILABLE"): never {
  throw new VoicePayloadStoreError(reason);
}
const osCode = (error: unknown) => (error as NodeJS.ErrnoException)?.code;
const sanitize = (error: unknown): never => {
  if (error instanceof VoicePayloadStoreError) throw error;
  if (["ENOSPC", "EDQUOT", "EFBIG", "EMFILE", "ENFILE"].includes(osCode(error) ?? "")) fail("CAPACITY");
  if (osCode(error) === "ENOENT") fail("LOST");
  if (osCode(error) === "EEXIST") fail("CONFLICT");
  fail();
};
const maximum = (kind: VoicePayloadKind) => kind === "audio" ? VOICE_PAYLOAD_AUDIO_MAX : VOICE_PAYLOAD_TEXT_MAX;
function validRef(ref: PayloadRef) {
  if (!ref || !uuid.test(ref.jobId) || !uuid.test(ref.version) || !uuid.test(ref.epoch) ||
      !["audio", "text"].includes(ref.kind) || !Number.isSafeInteger(ref.bytes) ||
      ref.bytes < 1 || ref.bytes > maximum(ref.kind)) fail();
}
function nameFor(ref: PayloadRef, staged: boolean) {
  validRef(ref);
  return `.${staged ? "stage" : "payload"}_${ref.epoch}_${ref.jobId}_${ref.kind}_${ref.version}`;
}
function sameRoot(a: Identity, b: Identity) {
  return a.dev === b.dev && a.ino === b.ino && a.uid === b.uid;
}
function privateDirectory(st: Stats) {
  if (!st.isDirectory() || st.isSymbolicLink() || (st.mode & 0o777) !== 0o700 ||
      st.uid !== process.geteuid?.()) fail();
}
function privateFile(st: Stats, bytes?: number, maximumLinks = 1) {
  if (!st.isFile() || st.uid !== process.geteuid?.() || (st.mode & 0o777) !== 0o600 ||
      st.nlink < 1 || st.nlink > maximumLinks || (bytes !== undefined && st.size !== bytes)) fail();
}
async function boundedRead(path: string, limit: number, expected?: number, metadata = false) {
  const handle = await open(/* turbopackIgnore: true */ path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const st = await handle.stat();
    privateFile(st, expected, metadata ? 2 : 1);
    if (st.size < 1 || st.size > limit) fail();
    const data = Buffer.alloc(st.size);
    let offset = 0;
    while (offset < data.length) {
      const { bytesRead } = await handle.read(data, offset, data.length - offset, offset);
      if (!bytesRead) fail("LOST");
      offset += bytesRead;
    }
    // Reject mutation through another open descriptor before returning content.
    const after = await handle.stat();
    if (after.size !== st.size || after.mtimeMs !== st.mtimeMs || after.ctimeMs !== st.ctimeMs) fail("LOST");
    return data;
  } finally { await handle.close(); }
}

/** Pure host-evidence validation; fixtures exercise rejection, not a Linux mount proof. */
export function validatePayloadLinuxEvidence(input: {
  platform: string; mountInfo: string; cgroup: string; swapMax: string;
  sliceSwapMax: string; memoryMax: string; sliceMemoryMax: string;
  limits: string; execArgs: readonly string[]; nodeOptions?: string;
  reportOnFatalError?: boolean; reportOnSignal?: boolean; reportOnUncaughtException?: boolean;
}) {
  if (input.platform !== "linux") fail();
  const lines = input.mountInfo.split("\n").filter(line => line.split(" ")[4] === MOUNT);
  if (lines.length !== 1) fail();
  const [left, right] = lines[0].split(" - ");
  if (!right) fail();
  const [type, , superFlags] = right.split(" ");
  const flags = new Set([...left.split(" ")[5].split(","), ...superFlags.split(",")]);
  const size = [...flags].find(flag => flag.startsWith("size="))?.slice(5);
  const inodes = [...flags].find(flag => flag.startsWith("nr_inodes="))?.slice(10);
  if (type !== "tmpfs" || !["rw", "noswap", "nodev", "nosuid", "noexec"].every(flag => flags.has(flag)) ||
      !size || !/^\d+k?$/.test(size) || !inodes || !/^\d+$/.test(inodes)) fail();
  const bytes = Number(size.replace(/k$/, "")) * (size.endsWith("k") ? 1024 : 1);
  if (bytes < 1 || bytes > MOUNT_MAX || Number(inodes) < 1 || Number(inodes) > VOICE_PAYLOAD_FILE_LIMIT) fail();
  if (!/^0::\/catvoice\.slice\/cat-voice-(?:app|cleanup)\.service\n?$/.test(input.cgroup) ||
      input.swapMax.trim() !== "0" || input.sliceSwapMax.trim() !== "0" ||
      !/^\d+$/.test(input.memoryMax.trim()) || Number(input.memoryMax.trim()) < 1 || Number(input.memoryMax.trim()) > 384 * 1024 * 1024 ||
      !/^\d+$/.test(input.sliceMemoryMax.trim()) || Number(input.sliceMemoryMax.trim()) < 1 || Number(input.sliceMemoryMax.trim()) > 768 * 1024 * 1024 ||
      input.reportOnFatalError || input.reportOnSignal || input.reportOnUncaughtException ||
      !/^Max core file size\s+0\s+0\s+bytes$/m.test(input.limits)) fail();
  const args = [...input.execArgs, input.nodeOptions ?? ""].join(" ");
  if (/--(?:heap(?:snapshot|prof)|report(?:-|\b)|diagnostic-dir|inspect)/.test(args)) fail();
}

async function noAliases(path: string, boundary: string) {
  const rel = relative(boundary, path);
  if (!rel || rel.startsWith("..") || isAbsolute(rel)) fail();
  let cursor = boundary;
  const parts = rel.split("/");
  for (let i = 0; i < parts.length; i++) {
    cursor = join(cursor, parts[i]);
    try {
      const st = await lstat(/* turbopackIgnore: true */ cursor);
      if (st.isSymbolicLink() || !st.isDirectory()) fail();
      // The root and each service-controlled parent must be private.
      privateDirectory(st);
    } catch (error) {
      if (osCode(error) !== "ENOENT" || i !== parts.length - 1) throw error;
    }
  }
}
async function configuration(env: Environment) {
  const mode = env.E4_VOICE_STORAGE;
  if (mode === "tmpfs-private-v1") {
    if (env.E4_VOICE_PAYLOAD_DIRECTORY !== `${MOUNT}/payload` ||
        Object.keys(env).some(k => k.startsWith("E4_VOICE_TEST_PAYLOAD"))) fail();
    return { root: `${MOUNT}/payload`, boundary: MOUNT, mode, nonce: "" } as const;
  }
  if (mode !== "synthetic-files-v1" || env.APP_MODE !== "INTERNAL" ||
      env.NODE_ENV === "production" || !uuid.test(env.E4_VALIDATION_LOCAL_NONCE ?? "")) fail();
  const configured = env.E4_VOICE_TEST_PAYLOAD_ROOT;
  if (!configured || !isAbsolute(configured) ||
      env.E4_VOICE_PAYLOAD_DIRECTORY !== join(configured, "payload")) fail();
  const temporary = resolve(tmpdir());
  const canonicalTemporary = await realpath(/* turbopackIgnore: true */ temporary);
  let boundary = resolve(configured);
  if (boundary.startsWith(temporary + "/")) boundary = join(canonicalTemporary, relative(temporary, boundary));
  const rel = relative(canonicalTemporary, boundary);
  if (rel.startsWith("..") || isAbsolute(rel) ||
      !/^cat-(?:private-voice|voice-payload)-[^/]+\//.test(rel + "/")) fail();
  await noAliases(boundary, canonicalTemporary);
  // The test runner names this private boundary before any payload exists.
  // Only its final component may be missing; noAliases has checked every
  // ancestor within the approved temporary fixture before this creation.
  try { await mkdir(/* turbopackIgnore: true */ boundary, { mode: 0o700 }); }
  catch (error) { if (osCode(error) !== "EEXIST") throw error; }
  privateDirectory(await lstat(/* turbopackIgnore: true */ boundary));
  return { root: join(boundary, "payload"), boundary, mode, nonce: env.E4_VALIDATION_LOCAL_NONCE! } as const;
}

/** No SQL backend or general disk fallback exists. Synthetic files are a named local test fixture only. */
export async function configuredVoicePayloadStore(
  env: Environment = process.env,
): Promise<VoicePayloadStore> {
  try {
    const config = await configuration(env);
    async function hostCheck() {
      privateDirectory(await lstat(/* turbopackIgnore: true */ config.boundary));
      if (config.mode === "tmpfs-private-v1") {
        if (process.platform !== "linux") fail();
        const cgroup = await readFile(/* turbopackIgnore: true */ "/proc/self/cgroup", "utf8");
        if (!/^0::\/catvoice\.slice\/cat-voice-(?:app|cleanup)\.service\n?$/.test(cgroup)) fail();
        const current = `/sys/fs/cgroup${cgroup.trim().slice(3)}`;
        validatePayloadLinuxEvidence({
          platform: process.platform, cgroup,
          mountInfo: await readFile(/* turbopackIgnore: true */ "/proc/self/mountinfo", "utf8"),
          swapMax: await readFile(/* turbopackIgnore: true */ `${current}/memory.swap.max`, "utf8"),
          sliceSwapMax: await readFile(/* turbopackIgnore: true */ "/sys/fs/cgroup/catvoice.slice/memory.swap.max", "utf8"),
          memoryMax: await readFile(/* turbopackIgnore: true */ `${current}/memory.max`, "utf8"),
          sliceMemoryMax: await readFile(/* turbopackIgnore: true */ "/sys/fs/cgroup/catvoice.slice/memory.max", "utf8"),
          limits: await readFile(/* turbopackIgnore: true */ "/proc/self/limits", "utf8"),
          execArgs: process.execArgv, nodeOptions: process.env.NODE_OPTIONS,
          reportOnFatalError: process.report.reportOnFatalError,
          reportOnSignal: process.report.reportOnSignal,
          reportOnUncaughtException: process.report.reportOnUncaughtException,
        });
        const fs = await statfs(/* turbopackIgnore: true */ config.boundary);
        if (fs.type !== 0x01021994 || fs.bsize * fs.blocks > MOUNT_MAX) fail();
      } else {
        await noAliases(config.boundary, await realpath(/* turbopackIgnore: true */ tmpdir()));
      }
      await noAliases(config.root, config.boundary);
    }
    await hostCheck();
    try { await mkdir(/* turbopackIgnore: true */ config.root, { mode: 0o700 }); }
    catch (error) { if (osCode(error) !== "EEXIST") throw error; }
    const identity = await lstat(/* turbopackIgnore: true */ config.root);
    privateDirectory(identity);
    if (identity.dev !== (await lstat(/* turbopackIgnore: true */ config.boundary)).dev) fail();

    // Use a descriptor-pinned directory on Linux. A concurrent rename/symlink
    // cannot redirect payload I/O to a disk path between checks and open().
    async function directory<T>(work: (path: string) => Promise<T>, expectedEpoch?: string): Promise<T> {
      await hostCheck();
      const handle = await open(/* turbopackIgnore: true */ config.root, constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW);
      try {
        const st = await handle.stat();
        privateDirectory(st);
        if (!sameRoot(identity, st)) fail("LOST");
        const path = process.platform === "linux" ? `/proc/self/fd/${handle.fd}` : config.root;
        if (expectedEpoch && (await boundedRead(join(path, MARKER), 64, undefined, true)).toString("ascii") !== `${expectedEpoch}\n`)
          fail("LOST");
        const result = await work(path);
        if (!sameRoot(identity, await lstat(/* turbopackIgnore: true */ config.root))) fail("LOST");
        return result;
      } finally { await handle.close(); }
    }
    async function initializeMarker(name: string, value: string) {
      return directory(async path => {
        try { return await boundedRead(join(path, name), 128, undefined, true); }
        catch (error) { if (osCode(error) !== "ENOENT") throw error; }
        const temporary = `.epoch.init-${randomUUID()}`;
        const file = await open(/* turbopackIgnore: true */ join(path, temporary), constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
        try { await file.writeFile(value, "ascii"); await file.sync(); }
        finally { await file.close(); }
        try { await link(/* turbopackIgnore: true */ join(path, temporary), /* turbopackIgnore: true */ join(path, name)); }
        catch (error) { if (osCode(error) !== "EEXIST") throw error; }
        finally { await unlink(/* turbopackIgnore: true */ join(path, temporary)).catch(() => {}); }
        return boundedRead(join(path, name), 128, undefined, true);
      });
    }
    if (config.mode === "synthetic-files-v1") {
      const marker = await initializeMarker(TEST_MARKER, `SYNTHETIC_ONLY:${config.nonce}\n`);
      if (marker.toString("ascii") !== `SYNTHETIC_ONLY:${config.nonce}\n`) fail();
    }
    const epoch = (await initializeMarker(MARKER, `${randomUUID()}\n`)).toString("ascii").trim();
    if (!uuid.test(epoch)) fail();
    async function active<T>(work: (path: string) => Promise<T>) {
      try { return await directory(work, epoch); }
      catch (error) { return sanitize(error); }
    }
    function current(ref: PayloadRef) {
      validRef(ref);
      if (ref.epoch !== epoch) fail("LOST");
    }
    function stageName(stage: PayloadStage) {
      current(stage);
      if (stage.name !== nameFor(stage, true) || !Number.isSafeInteger(stage.dev) || !Number.isSafeInteger(stage.ino)) fail();
      return stage.name;
    }
    async function removeChecked(path: string, name: string, expected?: Pick<PayloadEntry, "dev" | "ino" | "bytes" | "mtimeMs">) {
      let st: Stats;
      try { st = await lstat(/* turbopackIgnore: true */ join(path, name)); }
      catch (error) { if (osCode(error) === "ENOENT") return false; throw error; }
      if (expected && (st.dev !== expected.dev || st.ino !== expected.ino || st.size !== expected.bytes || st.mtimeMs !== expected.mtimeMs)) return false;
      // unlink never follows a symlink. Unknown aliases may be safely removed
      // by compensation cleanup, but public read/publish/remove reject them.
      if ((!st.isFile() && !st.isSymbolicLink()) || st.uid !== process.geteuid?.()) fail();
      await unlink(/* turbopackIgnore: true */ join(path, name));
      return true;
    }
    const store: VoicePayloadStore = {
      epoch, root: config.root,
      async healthCheck() {
        await active(async () => {
          const fs = await statfs(/* turbopackIgnore: true */ config.root);
          if (fs.bavail < 2 || fs.ffree < 2) fail("CAPACITY");
        });
      },
      async stage(jobId, kind, data) {
        if (!uuid.test(jobId) || !["audio", "text"].includes(kind) ||
            (kind === "audio" && !Buffer.isBuffer(data)) || (kind === "text" && typeof data !== "string")) fail();
        const bytes = typeof data === "string" ? Buffer.from(data, "utf8") : data;
        const ref: PayloadRef = { jobId, kind, version: randomUUID(), epoch, bytes: bytes.length };
        validRef(ref);
        return active(async path => {
          const fs = await statfs(/* turbopackIgnore: true */ config.root);
          if (fs.bavail * fs.bsize < Math.ceil(bytes.length / fs.bsize) * fs.bsize + fs.bsize || fs.ffree < 2) fail("CAPACITY");
          const name = nameFor(ref, true);
          const file = await open(/* turbopackIgnore: true */ join(path, name), constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
          try {
            let offset = 0;
            while (offset < bytes.length) {
              const { bytesWritten } = await file.write(bytes, offset, bytes.length - offset, offset);
              if (!bytesWritten) fail("CAPACITY");
              offset += bytesWritten;
            }
            await file.sync();
            const st = await file.stat();
            privateFile(st, bytes.length);
            return { ...ref, name, dev: st.dev, ino: st.ino };
          } catch (error) {
            await unlink(/* turbopackIgnore: true */ join(path, name)).catch(() => {});
            throw error;
          } finally { await file.close(); }
        });
      },
      async publish(stage) {
        const name = stageName(stage);
        return active(async path => {
          const source = join(path, name), target = join(path, nameFor(stage, false));
          const handle = await open(/* turbopackIgnore: true */ source, constants.O_RDONLY | constants.O_NOFOLLOW);
          let published = false;
          try {
            const st = await handle.stat();
            privateFile(st, stage.bytes);
            if (st.dev !== stage.dev || st.ino !== stage.ino) fail("CONFLICT");
            // link is atomic and will never overwrite an existing generation.
            await link(/* turbopackIgnore: true */ source, /* turbopackIgnore: true */ target);
            published = true;
            await unlink(/* turbopackIgnore: true */ source);
            const result = await lstat(/* turbopackIgnore: true */ target);
            privateFile(result, stage.bytes);
            if (result.dev !== stage.dev || result.ino !== stage.ino) fail("CONFLICT");
            return { jobId: stage.jobId, kind: stage.kind, version: stage.version, epoch, bytes: stage.bytes };
          } catch (error) {
            if (published) {
              const st = await lstat(/* turbopackIgnore: true */ target).catch(() => null);
              if (st?.dev === stage.dev && st.ino === stage.ino) await unlink(/* turbopackIgnore: true */ target).catch(() => {});
            }
            throw error;
          } finally { await handle.close(); }
        });
      },
      async discard(stage) {
        const name = stageName(stage);
        await active(async path => {
          const st = await lstat(/* turbopackIgnore: true */ join(path, name)).catch(error => { if (osCode(error) === "ENOENT") return null; throw error; });
          if (!st) return;
          if (st.dev !== stage.dev || st.ino !== stage.ino) fail("CONFLICT");
          privateFile(st, stage.bytes);
          await unlink(/* turbopackIgnore: true */ join(path, name));
        });
      },
      async verify(ref) {
        current(ref);
        await active(async path => {
          const handle = await open(/* turbopackIgnore: true */ join(path, nameFor(ref, false)), constants.O_RDONLY | constants.O_NOFOLLOW);
          try { privateFile(await handle.stat(), ref.bytes); }
          finally { await handle.close(); }
        });
      },
      async read(ref) {
        current(ref);
        return active(path => boundedRead(join(path, nameFor(ref, false)), maximum(ref.kind), ref.bytes));
      },
      async remove(ref) {
        current(ref);
        await active(async path => {
          const name = nameFor(ref, false);
          const st = await lstat(/* turbopackIgnore: true */ join(path, name)).catch(error => { if (osCode(error) === "ENOENT") return null; throw error; });
          if (!st) return;
          privateFile(st, ref.bytes);
          await unlink(/* turbopackIgnore: true */ join(path, name));
        });
      },
      async list(limit = VOICE_PAYLOAD_FILE_LIMIT) {
        if (!Number.isInteger(limit) || limit < 1 || limit > VOICE_PAYLOAD_FILE_LIMIT) fail();
        return active(async path => {
          const directory = await opendir(/* turbopackIgnore: true */ path);
          const entries: PayloadEntry[] = [];
          let examined = 0;
          for await (const entry of directory) {
            if (++examined > VOICE_PAYLOAD_FILE_LIMIT) fail("CAPACITY");
            if ([MARKER, TEST_MARKER].includes(entry.name)) continue;
            if (entries.length >= limit) fail("CAPACITY");
            const st = await lstat(/* turbopackIgnore: true */ join(path, entry.name)).catch(error => { if (osCode(error) === "ENOENT") return null; throw error; });
            if (!st) continue;
            const match = filePattern.exec(entry.name);
            const safeOwnedFile = st.isFile() && st.uid === process.geteuid?.() &&
              (st.mode & 0o777) === 0o600 && st.nlink >= 1 && st.nlink <= 2;
            // An interrupted open->write can leave size zero; an interrupted
            // link->unlink can leave two aliases of the same inode. They remain
            // recognizable for GC, while read/publish still require bytes>=1
            // and a single link. An Entry.ref is therefore GC metadata, not
            // evidence that its payload is complete or readable.
            const ref = match && safeOwnedFile && st.size >= 0 && st.size <= maximum(match[4] as VoicePayloadKind)
              ? { epoch: match[2], jobId: match[3], kind: match[4] as VoicePayloadKind, version: match[5], bytes: st.size }
              : undefined;
            const initialization = initializationPattern.test(entry.name) && safeOwnedFile && st.size <= 128;
            entries.push({
              name: entry.name, type: ref ? match![1] as "stage" | "payload" : initialization ? "initialization" : "unknown",
              staged: !!ref && match![1] === "stage", ...(ref ? { ref } : {}),
              mtimeMs: st.mtimeMs, bytes: st.size, dev: st.dev, ino: st.ino,
            });
          }
          return entries.sort((a, b) => a.mtimeMs - b.mtimeMs || a.name.localeCompare(b.name));
        });
      },
      async removeEntry(entry, minimumAgeMs = 120_000) {
        if (!entry || !entry.name || basename(entry.name) !== entry.name || /[\\/\u0000]/.test(entry.name) ||
            [MARKER, TEST_MARKER, ".", ".."].includes(entry.name) ||
            !Number.isFinite(minimumAgeMs) || minimumAgeMs < 0 || minimumAgeMs > 24 * 60 * 60_000) fail();
        // Default grace exceeds all leases. A caller may choose zero only after
        // checking a terminal/revoked task under its PG lock; this module cannot
        // know task authority and never treats a directory listing as authority.
        if (!Number.isFinite(entry.mtimeMs) ||
            (minimumAgeMs > 0 && entry.mtimeMs > Date.now() - minimumAgeMs)) return false;
        return active(path => removeChecked(path, entry.name, entry));
      },
    };
    return store;
  } catch (error) { return sanitize(error); }
}
