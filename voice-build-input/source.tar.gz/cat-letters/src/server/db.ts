import "dotenv/config";
import pg from "pg";
import { postgresTlsConfig } from "./postgres-tls";
const globalDb = globalThis as unknown as { catPool?: pg.Pool };
export const pool =
  globalDb.catPool ??
  new pg.Pool({
    connectionString: process.env.DATABASE_URL,
    ...postgresTlsConfig(process.env.DATABASE_URL),
    max: process.env.E4_SCHEDULED_RUN === "true" ? 2 : 8,
    idleTimeoutMillis: process.env.E4_SCHEDULED_RUN === "true" ? 5000 : 60000,
    connectionTimeoutMillis: process.env.E4_SCHEDULED_RUN === "true" ? 3000 : 5000,
  });
// pg-pool emits errors from idle clients on the pool, after callers have
// released them. Never log the Error object: it may contain connection data.
pool.on("error", () => console.warn("Business PostgreSQL idle connection removed."));
if (process.env.NODE_ENV !== "production") globalDb.catPool = pool;
export async function transaction<T>(
  fn: (db: pg.PoolClient) => Promise<T>,
  options: { trustedMigration?: boolean; deadlineAt?: number } = {},
): Promise<T> {
  if (!options.trustedMigration) {
    const { lifecycleAdapterMode, independentLedger } = await import("./lifecycle-provider");
    if (lifecycleAdapterMode() === "postgres-v1")
      return independentLedger(pool).readBusinessTx(async (db) => fn(db), options.deadlineAt);
  }
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    if (!options.trustedMigration) {
      const { guardLifecycleTransaction } = await import("./lifecycle-ledger");
      await guardLifecycleTransaction(db);
    }
    const result = await fn(db);
    await db.query("COMMIT");
    return result;
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
}
