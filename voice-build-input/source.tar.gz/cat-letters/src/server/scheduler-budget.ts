import type { PoolClient } from "pg";

/** A single invocation deadline, shared by every claim and business scope. */
export type DeadlineAt = number | undefined;

export class SchedulerDeadlineExceeded extends Error {
  readonly code = "SCHEDULER_DEADLINE";
  constructor() {
    super("本轮调度时间已用尽，未完成的工作将按持久状态处理。");
  }
}

export function remainingMs(deadlineAt: DeadlineAt) {
  return deadlineAt === undefined ? Number.POSITIVE_INFINITY : deadlineAt - Date.now();
}

export function requireWindow(deadlineAt: DeadlineAt, minimumMs = 0) {
  if (remainingMs(deadlineAt) <= minimumMs) throw new SchedulerDeadlineExceeded();
}

/** Close the client socket at the deadline; the durable outcome of an in-flight
 * COMMIT can still be unknown and must be checked on the next invocation. */
export function armConnectionDeadline(
  db: PoolClient,
  deadlineAt: DeadlineAt,
  onExpire: () => void,
) {
  if (deadlineAt === undefined) return () => {};
  requireWindow(deadlineAt);
  const timer = setTimeout(() => {
    onExpire();
    void db.end().catch(() => {});
  }, Math.max(1, remainingMs(deadlineAt)));
  return () => clearTimeout(timer);
}

/** All values are internal integer milliseconds, never user SQL input. */
export async function setTransactionLimits(db: PoolClient, deadlineAt: DeadlineAt) {
  if (deadlineAt === undefined) return;
  requireWindow(deadlineAt);
  const statementMs = Math.max(1, Math.min(5000, Math.floor(remainingMs(deadlineAt))));
  const lockMs = Math.max(1, Math.min(1000, statementMs));
  await db.query(`SET LOCAL statement_timeout = '${statementMs}ms'`);
  await db.query(`SET LOCAL lock_timeout = '${lockMs}ms'`);
  await db.query("SET LOCAL idle_in_transaction_session_timeout = '5s'");
}

/** Force deferred work under a 2s statement limit and leave a 3s window for
 * COMMIT. A lost COMMIT reply still requires a durable-state check. */
export async function commitWithinBudget(db: PoolClient, deadlineAt: DeadlineAt) {
  if (deadlineAt === undefined) {
    await db.query("COMMIT");
    return;
  }
  requireWindow(deadlineAt, 3000);
  // PostgreSQL does not reliably enforce statement_timeout during deferred
  // COMMIT triggers. Force those triggers while a normal SQL statement is
  // still cancellable, before deciding whether there is room to commit.
  await db.query("SET statement_timeout = '2s'");
  requireWindow(deadlineAt, 3000);
  await db.query("SET CONSTRAINTS ALL IMMEDIATE");
  requireWindow(deadlineAt, 3000);
  await db.query("COMMIT");
  requireWindow(deadlineAt);
}
