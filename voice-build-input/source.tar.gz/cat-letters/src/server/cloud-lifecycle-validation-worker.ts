import { randomUUID } from "node:crypto";
import { readFile, lstat } from "node:fs/promises";
import { isAbsolute } from "node:path";
import pg, { type PoolClient } from "pg";
import { pool, transaction } from "./db";
import { independentLedger } from "./lifecycle-provider";
import { runClaimedAccountExport, type ExportClaim } from "./account-export";
import { ensure } from "./errors";
import { digest, sameSecret } from "./auth";
import { requireWindow, armConnectionDeadline } from "./scheduler-budget";
import { postgresTlsConfig } from "./postgres-tls";
import {
  validationScope,
  validationDeadline,
} from "./cloud-lifecycle-validation-scope";

async function activeFixture(db: PoolClient) {
  const scope = validationScope();
  await restrictedRole(db);
  const r = await db.query(
    "SELECT id FROM accounts WHERE id=$1 AND email_normalized=$2 AND status='ACTIVE' FOR UPDATE",
    [scope.accountId, scope.email],
  );
  ensure(r.rows[0], 503, "固定账号不是本轮专用 ACTIVE 合成账号。");
  return scope;
}

/** Same durable export lease rules; every selection/update is UUID scoped. */
export async function claimValidationExport(
  deadlineAt = validationDeadline(),
): Promise<ExportClaim | null> {
  validationScope();
  requireWindow(deadlineAt, 7000);
  return transaction(
    async (db) => {
      const { accountId } = await activeFixture(db);
      await db.query(
        `WITH exhausted AS (
      SELECT id FROM account_exports WHERE account_id=$1 AND status='BUILDING'
        AND lease_until<=clock_timestamp() AND attempts>=5 FOR UPDATE SKIP LOCKED
      ) UPDATE account_exports e SET status='FAILED',lease_token=NULL,lease_until=NULL,last_error='RETRIES_EXHAUSTED'
      FROM exhausted x WHERE e.id=x.id AND e.account_id=$1`,
        [accountId],
      );
      const r = await db.query(
        `SELECT id FROM account_exports WHERE account_id=$1 AND attempts<5
      AND (status='QUEUED' OR (status='BUILDING' AND lease_until<=clock_timestamp()))
      ORDER BY created_at,id FOR UPDATE SKIP LOCKED LIMIT 1`,
        [accountId],
      );
      if (!r.rows[0]) return null;
      const leaseToken = randomUUID();
      await db.query(
        `UPDATE account_exports SET status='BUILDING',lease_token=$3,
      lease_until=clock_timestamp()+interval '60 seconds',attempts=attempts+1,last_error=NULL
      WHERE id=$1 AND account_id=$2`,
        [r.rows[0].id, accountId, leaseToken],
      );
      return { id: r.rows[0].id, accountId, leaseToken };
    },
    { deadlineAt },
  );
}

export async function runValidationExport(deadlineAt = validationDeadline()) {
  const claim = await claimValidationExport(deadlineAt);
  return claim
    ? runClaimedAccountExport(claim, deadlineAt)
    : { status: "IDLE" };
}

/** No global rate-limit sweep, orphan scan, deletion worker, or restore entry. */
export async function cleanupValidationExports(
  deadlineAt = validationDeadline(),
) {
  validationScope();
  requireWindow(deadlineAt, 7000);
  return independentLedger(pool).withExclusive(
    (op) =>
      op.businessTx(async (db) => {
        const { accountId } = await activeFixture(db);
        const expired = await db.query(
          `UPDATE account_exports SET status='EXPIRED',lease_token=NULL,lease_until=NULL
      WHERE account_id=$1 AND status='READY' AND expires_at<=clock_timestamp() RETURNING id`,
          [accountId],
        );
        const revoked = await db.query(
          `UPDATE account_exports e SET status='REVOKED'
      WHERE e.account_id=$1 AND e.status='READY' AND NOT EXISTS (
        SELECT 1 FROM accounts a LEFT JOIN cat_profiles c ON c.account_id=a.id
        LEFT JOIN cloud_state s ON s.account_id=a.id AND s.cat_id=c.id
        WHERE a.id=$1 AND a.status='ACTIVE' AND e.cat_id IS NOT DISTINCT FROM c.id
          AND e.captured_revision IS NOT DISTINCT FROM s.revision) RETURNING e.id`,
          [accountId],
        );
        const removed = await db.query(
          `DELETE FROM private_export_chunks p USING account_exports e
      WHERE e.account_id=$1 AND e.id=p.export_id
        AND NOT (e.status='READY' AND e.artifact_name=p.artifact_name)
        AND NOT (e.status='BUILDING' AND e.lease_until>clock_timestamp()) RETURNING p.export_id`,
          [accountId],
        );
        return {
          status: "CLEANED",
          expired: expired.rowCount ?? 0,
          revoked: revoked.rowCount ?? 0,
          removed: removed.rowCount ?? 0,
          rateLimits: 0,
        };
      }),
    deadlineAt,
  );
}

export async function observeValidationAccount(
  deadlineAt = validationDeadline(),
) {
  const scope = validationScope();
  return independentLedger(pool).withShared(
    (op) =>
      op.businessTx(async (db, ledger) => {
        const a = await db.query(
          "SELECT id,status,email_normalized FROM accounts WHERE id=$1",
          [scope.accountId],
        );
        ensure(
          a.rows[0] &&
            (a.rows[0].email_normalized === scope.email ||
              (a.rows[0].status === "DELETED" &&
                a.rows[0].email_normalized ===
                  `deleted+${scope.accountId}@invalid.invalid`)),
          503,
          "固定合成账号不匹配。",
        );
        if (a.rows[0].status === "DELETED") {
          // An anonymized UUID alone no longer proves the original email. Require
          // the private fixture capability and its HMAC-verified ledger intent.
          const path = process.env.E4_CLOUD_LIFECYCLE_VALIDATION_STATE;
          ensure(
            path && isAbsolute(path),
            503,
            "已注销账号需要本轮私有恢复凭证。",
          );
          const st = await lstat(path);
          ensure(
            st.isFile() && !st.isSymbolicLink() && (st.mode & 0o077) === 0,
            503,
            "私有验证状态不安全。",
          );
          const state = JSON.parse(await readFile(path, "utf8"));
          const parts =
            typeof state.receipt === "string" ? state.receipt.split(".") : [];
          const intent = ledger.events.find(
            (e) =>
              e.kind === "DELETE_REQUESTED" &&
              e.accountId === scope.accountId &&
              e.requestId === parts[0],
          );
          ensure(
            state.accountId === scope.accountId &&
              state.seeded === true &&
              parts.length === 2 &&
              /^[a-f0-9]{64}$/.test(parts[1]) &&
              intent?.kind === "DELETE_REQUESTED" &&
              sameSecret(intent.receiptHash, digest(parts[1])),
            503,
            "私有凭证不属于本轮注销账号。",
          );
        }
        const counts = await db.query(
          `SELECT
      (SELECT count(*)::int FROM cat_profiles WHERE account_id=$1) AS cats,
      (SELECT count(*)::int FROM cloud_letters WHERE account_id=$1) AS letters,
      (SELECT count(*)::int FROM cloud_responses WHERE account_id=$1) AS responses,
      (SELECT count(*)::int FROM account_sessions WHERE account_id=$1 AND revoked_at IS NULL) AS live_sessions,
      (SELECT count(*)::int FROM private_export_chunks p JOIN account_exports e ON e.id=p.export_id WHERE e.account_id=$1) AS chunks`,
          [scope.accountId],
        );
        const jobs = await db.query(
          "SELECT id,status,attempts,artifact_bytes,lease_until FROM account_exports WHERE account_id=$1 ORDER BY created_at,id",
          [scope.accountId],
        );
        const deletion = await db.query(
          "SELECT request_id,status,phase,attempts,receipt_closed FROM account_deletions WHERE account_id=$1",
          [scope.accountId],
        );
        return {
          status: a.rows[0].status,
          counts: counts.rows[0],
          exports: jobs.rows,
          deletion: deletion.rows[0] ?? null,
        };
      }),
    deadlineAt,
  );
}

const roleSql = `SELECT current_user AS role,r.rolsuper,r.rolbypassrls,r.rolcreatedb,r.rolcreaterole,r.rolreplication,
  has_schema_privilege(current_user,'public','CREATE') AS schema_create,
  EXISTS(SELECT 1 FROM pg_class WHERE relowner=current_user::regrole AND relnamespace='public'::regnamespace) AS owns_tables
  FROM pg_roles r WHERE rolname=current_user`;
async function restrictedRole(db: pg.PoolClient | pg.Client) {
  const row = (await db.query(roleSql)).rows[0];
  ensure(
    row &&
      !row.rolsuper &&
      !row.rolbypassrls &&
      !row.rolcreatedb &&
      !row.rolcreaterole &&
      !row.rolreplication &&
      !row.schema_create &&
      !row.owns_tables,
    503,
    "必须使用无 DDL/所有权/特权的运行角色。",
  );
  return row;
}

/** Read-only permission probes. Does not grant privileges or repair a gate. */
export async function preflightValidation(deadlineAt = validationDeadline()) {
  const scope = validationScope();
  const business = await transaction(
    async (db) => {
      const role = await restrictedRole(db);
      const r = await db.query(`SELECT
      (has_table_privilege(current_user,'account_exports','SELECT') AND has_table_privilege(current_user,'account_exports','INSERT') AND has_table_privilege(current_user,'account_exports','DELETE')) AS exports,
      has_column_privilege(current_user,'account_exports','status','UPDATE') AS export_status,
      (has_table_privilege(current_user,'private_export_chunks','SELECT') AND has_table_privilege(current_user,'private_export_chunks','INSERT') AND has_table_privilege(current_user,'private_export_chunks','DELETE')) AS chunks,
      has_column_privilege(current_user,'private_export_budget','singleton','UPDATE') AS budget_lock,
      has_table_privilege(current_user,'schema_migrations','SELECT') AS migrations,
      has_table_privilege(current_user,'accounts','DELETE') AS account_delete,
      has_table_privilege(current_user,'cloud_letters','TRUNCATE') AS truncate_letters`);
      const p = r.rows[0];
      ensure(
        p.exports &&
          p.export_status &&
          p.chunks &&
          p.budget_lock &&
          !p.migrations &&
          !p.account_delete &&
          !p.truncate_letters,
        503,
        "业务运行角色权限不符合既有受限配置。",
      );
      ensure(
        (
          await db.query(
            "SELECT payload_budget_bytes FROM private_export_budget WHERE singleton=true",
          )
        ).rowCount === 1,
        503,
        "私有导出预算对运行角色不可见。",
      );
      const present = await db.query(
        "SELECT id FROM accounts WHERE id=$1 AND email_normalized=$2 AND status='ACTIVE'",
        [scope.accountId, scope.email],
      );
      return { role, permissions: p, fixturePresent: present.rowCount === 1 };
    },
    { deadlineAt },
  );
  const url = process.env.E4_LEDGER_DATABASE_URL;
  const client = new pg.Client({
    connectionString: url,
    ...postgresTlsConfig(url),
    connectionTimeoutMillis: 3000,
  });
  const disarm = armConnectionDeadline(
    client as PoolClient,
    deadlineAt,
    () => {},
  );
  try {
    await client.connect();
    const role = await restrictedRole(client);
    const permissions = (
      await client.query(`SELECT
      (has_table_privilege(current_user,'ledger_events','SELECT') AND has_table_privilege(current_user,'ledger_events','INSERT')) AS events,
      has_column_privilege(current_user,'ledger_head','hash','UPDATE') AS head,
      has_table_privilege(current_user,'ledger_events','UPDATE,DELETE') AS rewrite_events,
      has_table_privilege(current_user,'restore_gate','UPDATE') AS open_gate,
      has_table_privilege(current_user,'restore_operations','INSERT') AS restore_operation`)
    ).rows[0];
    ensure(
      permissions.events &&
        permissions.head &&
        !permissions.rewrite_events &&
        !permissions.open_gate &&
        !permissions.restore_operation,
      503,
      "账本运行角色不能改写历史或操纵恢复闸门。",
    );
    return {
      status: "READY",
      business,
      ledger: { role, permissions },
      fullGuardPassed: true,
      scopeConfigured: true,
    };
  } finally {
    disarm();
    await client.end().catch(() => {});
  }
}
