import { randomUUID } from "node:crypto";
import { lstat, open, readFile, rename, unlink } from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import { ensure } from "./errors";

export type Cursor = {digest:string;next:number};
export async function cursorDirectory() {
  const dir=process.env.E4_CONTINUOUS_STATE_DIRECTORY;
  ensure(dir && isAbsolute(dir),503,"PRIVATE_CONTINUOUS_STATE_REQUIRED");
  const s=await lstat(dir);
  ensure(s.isDirectory()&&!s.isSymbolicLink()&&(s.mode&0o077)===0&&s.uid===process.getuid?.(),503,"UNSAFE_CONTINUOUS_STATE_DIRECTORY");
  return dir;
}
export async function readCursor(dir:string,digest:string,count:number):Promise<Cursor> {
  let data:string;
  try {
    const s=await lstat(join(dir,"cursor.json"));
    ensure(s.isFile()&&!s.isSymbolicLink()&&(s.mode&0o077)===0&&s.size<=1024,503,"UNSAFE_CONTINUOUS_CURSOR");
    data=await readFile(join(dir,"cursor.json"),"utf8");
  } catch(e) {if((e as NodeJS.ErrnoException).code==="ENOENT")return {digest,next:0};throw e;}
  const value=JSON.parse(data);
  ensure(value&&/^[a-f0-9]{64}$/.test(value.digest)&&Number.isInteger(value.next)&&value.next>=0&&value.next<40,503,"INVALID_CONTINUOUS_CURSOR");
  return value.digest===digest?{digest,next:value.next%count}:{digest,next:0};
}
export async function writeCursor(dir:string,value:Cursor) {
  const temp=join(dir,`.cursor-${randomUUID()}.tmp`);
  try {
    const handle=await open(temp,"wx",0o600);
    try {await handle.writeFile(JSON.stringify(value)+"\n");await handle.sync();}finally{await handle.close();}
    await rename(temp,join(dir,"cursor.json"));
    const parent=await open(dir,"r");try{await parent.sync();}finally{await parent.close();}
  } finally {await unlink(temp).catch(()=>{});}
}
