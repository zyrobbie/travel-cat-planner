import type { PoolClient } from "pg";
import { z } from "zod";
import { transaction } from "./db";
import { lockActiveAccount } from "./account-service";
import { ensure } from "./errors";

export const cloudId = z.string().min(1).max(1024);
export const cloudOperation = z.enum([
  "SEND_RESPONSE",
  "EDIT_RESPONSE",
  "DELETE_RESPONSE",
]);
export type CloudOperation = z.infer<typeof cloudOperation>;
export interface CloudCat {
  accountId: string;
  catId: string;
  participantId: string;
  logicalCatId?: string;
  name: string;
  appearanceId: string;
  safety: "CLEAR" | "INTERCEPTED";
  stateRevision: number;
}

/** Every business read and mutation uses account -> cat -> state lock order.
 * A successful identity lookup alone is insufficient if account deletion races it.
 */
export async function lockCloudCat(
  db: PoolClient,
  accountId: string,
): Promise<CloudCat> {
  await lockActiveAccount(db, accountId);
  const c = await db.query(
    "SELECT * FROM cat_profiles WHERE account_id=$1 FOR UPDATE",
    [accountId],
  );
  ensure(c.rows[0], 409, "请先领养一只小猫。");
  const row = c.rows[0];
  const p = await db.query(
    "SELECT safety_state FROM participants WHERE id=$1 FOR UPDATE",
    [row.participant_id],
  );
  await db.query(
    "INSERT INTO cloud_state(cat_id,account_id) VALUES($1,$2) ON CONFLICT(cat_id) DO NOTHING",
    [row.id, accountId],
  );
  const state = await db.query(
    "SELECT revision FROM cloud_state WHERE cat_id=$1 AND account_id=$2 FOR UPDATE",
    [row.id, accountId],
  );
  const binding = await db.query(
    "SELECT source_experience_id FROM legacy_bindings WHERE cat_id=$1 AND account_id=$2",
    [row.id, accountId],
  );
  return {
    accountId,
    catId: row.id,
    participantId: row.participant_id,
    logicalCatId: binding.rows[0]?.source_experience_id,
    name: row.name,
    appearanceId: row.appearance_id,
    safety: p.rows[0].safety_state,
    stateRevision: Number(state.rows[0].revision),
  };
}

export function withCloudCat<T>(
  accountId: string,
  fn: (db: PoolClient, cat: CloudCat) => Promise<T>,
) {
  return transaction(async (db) => fn(db, await lockCloudCat(db, accountId)));
}

// Settlement is explicit: read/skip must settle before releasing the unread slot,
// while edit/delete can invalidate pending sources before a worker acquires the cat.
async function settleBeforeRead(db: PoolClient, cat: CloudCat) {
  const { settleCloudCalendar } = await import("./cloud-calendar");
  await settleCloudCalendar(db, cat);
}

export async function bumpCloudRevision(db: PoolClient, cat: CloudCat) {
  const r = await db.query(
    "UPDATE cloud_state SET revision=revision+1 WHERE cat_id=$1 AND account_id=$2 AND revision < 9007199254740991 RETURNING revision",
    [cat.catId, cat.accountId],
  );
  ensure(r.rows[0], 409, "记录版本已达安全上限，操作未保存，请联系维护者。");
  cat.stateRevision = Number(r.rows[0].revision);
  await db.query("UPDATE account_exports SET status='REVOKED' WHERE account_id=$1 AND status='READY'",[cat.accountId]);
  return cat.stateRevision;
}

export async function ownedCloudLetter(
  db: PoolClient,
  cat: CloudCat,
  id: string,
) {
  const r = await db.query(
    "SELECT * FROM cloud_letters WHERE cat_id=$1 AND account_id=$2 AND id=$3",
    [cat.catId, cat.accountId, id],
  );
  ensure(r.rows[0], 404, "没有找到这封信。");
  return r.rows[0];
}
export async function ownedCloudResponse(
  db: PoolClient,
  cat: CloudCat,
  id: string,
) {
  const r = await db.query(
    "SELECT * FROM cloud_responses WHERE cat_id=$1 AND account_id=$2 AND id=$3",
    [cat.catId, cat.accountId, id],
  );
  ensure(r.rows[0], 404, "没有找到这条回应。");
  return r.rows[0];
}

export async function cloudState(accountId: string) {
  return withCloudCat(accountId, async (db, cat) => {
    await settleBeforeRead(db, cat);
    return cloudStateView(db, cat);
  });
}

/** Caller holds the guarded transaction and account/cat/state locks. */
export async function cloudStateView(db: PoolClient, cat: CloudCat) {
  const result = await db.query(
    `SELECT t.id AS trip_id,t.scene,l.id AS letter_id,l.type,l.delivered_at
       FROM (SELECT 1) base
       LEFT JOIN LATERAL (
         SELECT id,scene FROM cloud_trips WHERE cat_id=$1 AND account_id=$2 AND status='ACTIVE' LIMIT 1
       ) t ON true
       LEFT JOIN LATERAL (
         SELECT id,type,delivered_at FROM cloud_letters WHERE cat_id=$1 AND account_id=$2 AND read_at IS NULL
         ORDER BY delivered_at,id LIMIT 1
       ) l ON true`,
    [cat.catId, cat.accountId],
  );
  const row = result.rows[0];
  return {
    cat: {
      id: cat.catId,
      logicalId: cat.logicalCatId ?? cat.catId,
      name: cat.name,
      appearanceId: cat.appearanceId,
    },
    world: {
      status: row.trip_id ? "TRAVEL" : "HOME",
      tripId: row.trip_id ?? null,
      scene: row.scene ?? null,
    },
    unread: row.letter_id
      ? { id: row.letter_id, type: row.type, deliveredAt: row.delivered_at }
      : null,
    stateRevision: cat.stateRevision,
    safety: cat.safety,
  };
}

export async function listCloudLetters(accountId: string) {
  return withCloudCat(accountId, async (db, cat) => {
    await settleBeforeRead(db, cat);
    return cloudLettersView(db, cat);
  });
}

/** Metadata only: unopened copy and artwork never enter this projection. */
export async function cloudLettersView(db: PoolClient, cat: CloudCat) {
  const r = await db.query(
    `SELECT l.id,l.type,l.delivered_at,l.read_at,l.skipped_at,
      CASE WHEN l.read_at IS NOT NULL THEN l.snapshot->>'title' ELSE '有一封来信，还没打开' END AS title,
      r.id AS response_id,r.status AS response_status
      FROM cloud_letters l LEFT JOIN cloud_responses r
        ON (r.cat_id,r.account_id,r.letter_id)=(l.cat_id,l.account_id,l.id)
      WHERE l.cat_id=$1 AND l.account_id=$2 ORDER BY l.delivered_at DESC,l.id`,
    [cat.catId, cat.accountId],
  );
  return {
    letters: r.rows.map((l) => ({
      id: l.id,
      type: l.type,
      deliveredAt: l.delivered_at,
      readAt: l.read_at,
      skippedAt: l.skipped_at,
      hasResponse: l.response_status === "ACTIVE",
      title: l.title,
      responseId: l.response_id,
      responseStatus: l.response_status,
    })),
    stateRevision: cat.stateRevision,
  };
}

export async function readCloudLetter(accountId: string, letterId: string) {
  cloudId.parse(letterId);
  return transaction((db) => readCloudLetterInTx(db, accountId, letterId));
}

/** Caller owns the complete guard; settlement precedes releasing the unread slot. */
export async function readCloudLetterInTx(
  db: PoolClient,
  accountId: string,
  letterId: string,
) {
  cloudId.parse(letterId);
  const cat = await lockCloudCat(db, accountId);
  await settleBeforeRead(db, cat);
  let l = await ownedCloudLetter(db, cat, letterId);
  const firstRead = l.read_at === null;
  if (firstRead) {
    const r = await db.query(
      "UPDATE cloud_letters SET read_at=now() WHERE cat_id=$1 AND account_id=$2 AND id=$3 RETURNING *",
      [cat.catId, cat.accountId, letterId],
    );
    l = r.rows[0];
    await bumpCloudRevision(db, cat);
  }
  return cloudLetterView(db, cat, l, firstRead);
}

/** Restore an already-read view without consuming an unread letter. */
export async function readCloudLetterDetail(
  accountId: string,
  letterId: string,
) {
  cloudId.parse(letterId);
  return transaction((db) =>
    readCloudLetterDetailInTx(db, accountId, letterId),
  );
}

/** A single statement gives an already-read letter/response/revision snapshot.
 * No calendar settlement, write or cached authorization is used for this view. */
export async function readCloudLetterDetailInTx(
  db: PoolClient,
  accountId: string,
  letterId: string,
) {
  cloudId.parse(letterId);
  const result = await db.query(
    `SELECT a.status AS account_status,c.id AS owned_cat_id,s.revision AS state_revision,l.*,
       reply.id AS response_id,reply.status AS response_status,reply.current_revision,
       reply.text AS response_text,reply.at AS response_at
     FROM accounts a
     LEFT JOIN cat_profiles c ON c.account_id=a.id
     LEFT JOIN cloud_state s ON (s.account_id,s.cat_id)=(a.id,c.id)
     LEFT JOIN cloud_letters l ON (l.account_id,l.cat_id,l.id)=(a.id,c.id,$2)
     LEFT JOIN LATERAL (
       SELECT r.id,r.status,r.current_revision,v.text,v.at FROM cloud_responses r
       JOIN cloud_response_revisions v
         ON (v.account_id,v.cat_id,v.response_id,v.revision)=(r.account_id,r.cat_id,r.id,r.current_revision)
       WHERE r.account_id=a.id AND r.cat_id=c.id AND r.letter_id=l.id
     ) reply ON true
     WHERE a.id=$1`,
    [accountId, letterId],
  );
  const letter = result.rows[0];
  ensure(letter?.account_status === "ACTIVE", 401, "账号当前不可用。");
  ensure(letter.owned_cat_id, 409, "请先领养一只小猫。");
  const revision = Number(letter.state_revision);
  ensure(
    letter.state_revision !== null &&
      Number.isSafeInteger(revision) &&
      revision >= 0,
    503,
    "账号记录尚未就绪。",
  );
  ensure(letter.id, 404, "没有找到这封来信。");
  ensure(letter.read_at !== null, 409, "请先打开这封来信。");
  const response = letter.response_id
    ? {
        id: letter.response_id,
        status: letter.response_status,
        current_revision: letter.current_revision,
        text: letter.response_text,
        at: letter.response_at,
      }
    : undefined;
  return cloudLetterProjection(
    { stateRevision: revision },
    letter,
    response,
    false,
  );
}

async function cloudLetterView(
  db: PoolClient,
  cat: CloudCat,
  l: Awaited<ReturnType<typeof ownedCloudLetter>>,
  firstRead: boolean,
) {
  const r = await db.query(
    `SELECT r.id,r.status,r.current_revision,v.text,v.at FROM cloud_responses r
      JOIN cloud_response_revisions v ON (v.account_id,v.cat_id,v.response_id,v.revision)=(r.account_id,r.cat_id,r.id,r.current_revision)
      WHERE r.cat_id=$1 AND r.account_id=$2 AND r.letter_id=$3`,
    [cat.catId, cat.accountId, l.id],
  );
  const response = r.rows[0];
  return cloudLetterProjection(cat, l, response, firstRead);
}

function cloudLetterProjection(
  cat: Pick<CloudCat, "stateRevision">,
  l: Awaited<ReturnType<typeof ownedCloudLetter>>,
  response:
    | {
        id: string;
        status: string;
        current_revision: number;
        text: string | null;
        at: Date | null;
      }
    | undefined,
  firstRead: boolean,
) {
  return {
    letter: {
      id: l.id,
      type: l.type,
      snapshot: l.snapshot,
      deliveredAt: l.delivered_at,
      plannedAt: l.planned_at,
      effectiveAt: l.effective_at,
      readAt: l.read_at,
      skippedAt: l.skipped_at,
      tripId: l.trip_id,
      storyId: l.story_id,
      response:
        response?.status === "ACTIVE"
          ? {
              id: response.id,
              revision: response.current_revision,
              text: response.text,
              at: response.at,
            }
          : null,
      responseStatus: response?.status ?? null,
    },
    firstRead,
    stateRevision: cat.stateRevision,
  };
}

export async function skipCloudLetter(accountId: string, letterId: string) {
  cloudId.parse(letterId);
  return withCloudCat(accountId, async (db, cat) => {
    await settleBeforeRead(db, cat);
    const l = await ownedCloudLetter(db, cat, letterId);
    ensure(l.type === "DEMAND", 409, "这封信不需要回应。");
    if (!l.skipped_at || !l.read_at) {
      await db.query(
        "UPDATE cloud_letters SET skipped_at=COALESCE(skipped_at,now()),read_at=COALESCE(read_at,now()) WHERE cat_id=$1 AND account_id=$2 AND id=$3",
        [cat.catId, cat.accountId, letterId],
      );
      await bumpCloudRevision(db, cat);
    }
    return { ok: true, stateRevision: cat.stateRevision };
  });
}

export async function cloudRequestResult(
  accountId: string,
  operation: string,
  key: string,
) {
  cloudOperation.parse(operation);
  z.uuid().parse(key);
  return withCloudCat(accountId, async (db, cat) => {
    const r = await db.query(
      "SELECT result FROM cloud_requests WHERE account_id=$1 AND cat_id=$2 AND operation=$3 AND key=$4",
      [accountId, cat.catId, operation, key],
    );
    return r.rows[0]?.result ?? { pending: true };
  });
}
