export const EXPORT_CHUNK_BYTES = 2 * 1024 * 1024;
export const EXPORT_MAX_BYTES = 32 * 1024 * 1024;
export type ExportDownloadManifest = {
  format: "cat-letters-export-download";
  version: 1;
  downloadVersion: string;
  filename: string;
  bytes: number;
  sha256: string;
  chunkBytes: number;
  chunks: { index: number; bytes: number; sha256: string }[];
};
const hash = /^[a-f0-9]{64}$/;
/** Validate before allocating memory or fetching any artifact fragments. */
export function validateExportManifest(value: unknown): ExportDownloadManifest {
  const v = value as ExportDownloadManifest;
  if (
    !v ||
    v.format !== "cat-letters-export-download" ||
    v.version !== 1 ||
    typeof v.downloadVersion !== "string" ||
    !hash.test(v.downloadVersion) ||
    typeof v.filename !== "string" ||
    !/^cat-letters-[a-f0-9-]{36}\.json$/.test(v.filename) ||
    !Number.isSafeInteger(v.bytes) ||
    v.bytes < 1 ||
    v.bytes > EXPORT_MAX_BYTES ||
    typeof v.sha256 !== "string" ||
    !hash.test(v.sha256) ||
    v.chunkBytes !== EXPORT_CHUNK_BYTES ||
    !Array.isArray(v.chunks) ||
    v.chunks.length !== Math.ceil(v.bytes / EXPORT_CHUNK_BYTES) ||
    v.chunks.some(
      (c, index) =>
        !c ||
        c.index !== index ||
        c.bytes !==
          Math.min(EXPORT_CHUNK_BYTES, v.bytes - index * EXPORT_CHUNK_BYTES) ||
        typeof c.sha256 !== "string" ||
        !hash.test(c.sha256),
    )
  )
    throw new Error("导出文件说明校验失败，请重新准备。");
  return v;
}
