export const VOICE_MAX_MS = 60_000;
export const VOICE_MAX_BYTES = 10 * 1024 * 1024;
export const VOICE_TTL_MS = 24 * 60 * 60 * 1000;
export const VOICE_MIMES = [
  "audio/webm",
  "audio/ogg",
  "audio/mp4",
  "audio/wav",
] as const;
export type VoiceStatus =
  | "CREATED"
  | "UPLOADING"
  | "UPLOADED"
  | "TRANSCRIBING"
  | "READY"
  | "FAILED"
  | "CONFIRMED"
  | "CANCELLED"
  | "EXPIRED";
export type VoiceJob = {
  id: string;
  status: VoiceStatus;
  expiresAt: string;
  mode: string;
  error: string | null;
  text?: string;
  cleanup?: "complete" | "pending";
};
export type VoiceCapabilities = {
  privacyNotice?: string;
  available: boolean;
  reason?: "disabled" | "unavailable";
  mode: string;
  maxMs: number;
  maxBytes: number;
  mimes: readonly string[];
};
export type VoiceApi = {
  capabilities: () => Promise<VoiceCapabilities>;
  create: (
    letterId: string,
    key: string,
    hash: string,
    bytes: number,
    mime: string,
  ) => Promise<VoiceJob>;
  upload: (id: string, blob: Blob) => Promise<VoiceJob>;
  transcribe: (id: string) => Promise<VoiceJob>;
  status: (id: string) => Promise<VoiceJob>;
  finish: (id: string, action: "confirm" | "cancel") => Promise<VoiceJob>;
};
