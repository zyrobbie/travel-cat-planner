/** One counter for account replies, edits, voice review and local drafts.
 * Offsets in source evidence remain UTF-16 offsets, never grapheme indices. */
export const RESPONSE_MAX_GRAPHEMES = 2000;
export const RESPONSE_MAX_UNITS = 64000;
export const RESPONSE_MAX_BYTES = 128000;
const segmenter = new Intl.Segmenter("zh", { granularity: "grapheme" });
export function countResponseText(value: string) {
  let n = 0;
  for (const _ of segmenter.segment(value)) n++;
  return n;
}
/** Drafts may exceed 2000 graphemes so correction never silently truncates. */
export function validDraftText(value: string) {
  let wellFormed = true;
  for (let i = 0; i < value.length && wellFormed; i++) {
    const c = value.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff) {
      const next = value.charCodeAt(++i);
      wellFormed = next >= 0xdc00 && next <= 0xdfff;
    } else if (c >= 0xdc00 && c <= 0xdfff) wellFormed = false;
  }
  return (
    value.length <= RESPONSE_MAX_UNITS &&
    new TextEncoder().encode(value).byteLength <= RESPONSE_MAX_BYTES &&
    !value.includes("\0") &&
    wellFormed
  );
}
export function validResponseText(value: string) {
  return (
    value.length > 0 &&
    validDraftText(value) &&
    countResponseText(value) <= RESPONSE_MAX_GRAPHEMES
  );
}
