import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { assertInternal } from "@/server/safety";
import { assertLifecycleReady } from "@/server/lifecycle-ledger";
import { lifecycleAdapterMode } from "@/server/lifecycle-provider";
import { originCheck } from "@/server/auth";
import { assertAccountContext } from "@/server/account-context";
import { configuredOtpMode } from "@/server/otp-delivery";
import { HttpError, ensure } from "@/server/errors";
import {
  ACCOUNT_COOKIE,
  SESSION_SECONDS,
  accountIdentity,
  accountSession,
  accountCookieSecure,
  logoutAccount,
  requestCode,
  verifyCode,
} from "@/server/account-auth";
import {
  adoptCat,
  adoptionResult,
} from "@/server/account-service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function json(body: unknown, status = 200) {
  return NextResponse.json(body, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}

async function handler(req: NextRequest) {
  try {
    assertInternal();
    // Check adapter configuration without opening a database scope. Every
    // operation below still uses guarded transactions for its actual work.
    lifecycleAdapterMode();
    const secure = accountCookieSecure();
    const path = req.nextUrl.pathname.slice("/api/e4/".length);
    const write = req.method === "POST";
    if (write) originCheck(req);
    let body: unknown = {};
    if (write) {
      const raw = await req.text();
      ensure(Buffer.byteLength(raw) <= 4096, 413, "输入过长。");
      body = JSON.parse(raw || "{}");
    }
    if (path === "auth/request-code" && write) {
      // Conservative global bucket until a trusted deployment proxy is chosen.
      const input = z.strictObject({ email: z.string() }).parse(body);
      return json(await requestCode(input.email, undefined, { globalRateLimit: true }));
    }
    if (path === "auth/verify-code" && write) {
      const input = z
        .strictObject({
          challengeId: z.uuid(),
          email: z.string(),
          code: z.string(),
        })
        .parse(body);
      const otpMode = configuredOtpMode();
      const login = await verifyCode(
        input.challengeId,
        input.email,
        input.code,
        { globalRateLimit: true },
      );
      const response = json({
        ok: true,
        accountId: login.accountId,
        account: login.account,
        // Legacy `mode` describes the currently configured OTP transport.
        // It is not a delivery receipt or a claim about the safety classifier.
        mode: otpMode,
        safetyAdapter: "synthetic-v1",
      });
      response.cookies.set(ACCOUNT_COOKIE, login.rawToken, {
        httpOnly: true,
        sameSite: "strict",
        path: "/",
        secure,
        maxAge: SESSION_SECONDS,
      });
      return response;
    }
    if (path === "auth/logout" && write) {
      // With no cookie this branch performs no guarded DB operation, so retain
      // its lifecycle readiness check before clearing the browser cookie.
      if (!req.cookies.get(ACCOUNT_COOKIE)?.value &&
          !req.headers.has("x-catletters-account")) await assertLifecycleReady();
      if (req.headers.has("x-catletters-account"))
        assertAccountContext(
          req,
          await accountIdentity(req.cookies.get(ACCOUNT_COOKIE)?.value),
        );
      await logoutAccount(req.cookies.get(ACCOUNT_COOKIE)?.value);
      const response = json({ ok: true });
      response.cookies.set(ACCOUNT_COOKIE, "", {
        httpOnly: true,
        sameSite: "strict",
        path: "/",
        maxAge: 0,
        secure,
      });
      return response;
    }
    if (path === "account" && !write) {
      const account = await accountSession(req.cookies.get(ACCOUNT_COOKIE)?.value);
      assertAccountContext(req, account.id);
      return json(account);
    }
    const accountId = await accountIdentity(
      req.cookies.get(ACCOUNT_COOKIE)?.value,
    );
    assertAccountContext(req, accountId);
    if (path === "cat/adopt" && write)
      return json(await adoptCat(accountId, body));
    const result = path.match(/^requests\/([^/]+)$/);
    if (result && !write)
      return json(await adoptionResult(accountId, result[1]));
    throw new HttpError(404, "没有此接口。");
  } catch (error) {
    const status =
      error instanceof HttpError
        ? error.status
        : error instanceof z.ZodError || error instanceof SyntaxError
          ? 400
          : 503;
    return json(
      {
        error:
          error instanceof HttpError
            ? error.message
            : status === 400
              ? "输入格式不正确。"
              : "服务暂不可用，请稍后再试。",
      },
      status,
    );
  }
}

export const GET = handler;
export const POST = handler;
