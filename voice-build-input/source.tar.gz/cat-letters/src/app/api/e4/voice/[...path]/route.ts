import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { ACCOUNT_COOKIE } from "@/server/account-auth";
import { originCheck } from "@/server/auth";
import { assertInternal } from "@/server/safety";
import { HttpError, ensure } from "@/server/errors";
import {
  availableVoice,
  createVoice,
  readVoice,
  finishVoice,
  claimVoiceUpload,
  storeVoiceUpload,
  failVoiceLease,
  transcribeVoice,
  voiceInput,
} from "@/server/voice-service";
import { VOICE_MAX_BYTES } from "@/shared/voice";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const json = (value: unknown, status = 200) =>
  NextResponse.json(value, {
    status,
    headers: {
      "Cache-Control": "private, no-store, max-age=0",
      Pragma: "no-cache",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
    },
  });
async function read(req: NextRequest, max: number) {
  const declared = req.headers.get("content-length");
  ensure(
    declared === null || (/^\d+$/.test(declared) && Number(declared) <= max),
    413,
    "输入超过限制。",
  );
  const reader = req.body?.getReader();
  if (!reader) return Buffer.alloc(0);
  const chunks: Uint8Array[] = [];
  let size = 0,
    timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    void reader.cancel().catch(() => {});
  }, 15000);
  const cancel = () => void reader.cancel().catch(() => {});
  req.signal.addEventListener("abort", cancel, { once: true });
  try {
    for (;;) {
      const { done, value } = await reader.read();
      ensure(!timedOut && !req.signal.aborted, 408, "录音上传已中断或超时。");
      if (done) break;
      size += value.byteLength;
      if (size > max) {
        await reader.cancel();
        throw new HttpError(413, "输入超过限制。");
      }
      chunks.push(value);
    }
    return Buffer.concat(chunks);
  } finally {
    clearTimeout(timer);
    req.signal.removeEventListener("abort", cancel);
    reader.releaseLock();
  }
}
const body = async (req: NextRequest) => {
  ensure(
    req.headers.get("content-type")?.split(";")[0] === "application/json",
    415,
    "输入格式不正确。",
  );
  return JSON.parse(
    new TextDecoder("utf-8", { fatal: true }).decode(await read(req, 4096)) ||
      "{}",
  );
};
async function handler(req: NextRequest) {
  try {
    assertInternal();
    const write = req.method === "POST";
    if (write) originCheck(req);
    const identity = {
      token: req.cookies.get(ACCOUNT_COOKIE)?.value,
      account: req.headers.get("x-catletters-account"),
    };
    const p = req.nextUrl.pathname
      .slice("/api/e4/voice/".length)
      .split("/")
      .map(decodeURIComponent);
    if (p.join("/") === "capabilities" && !write)
      return json(await availableVoice(identity));
    if (p.join("/") === "jobs" && write)
      return json(
        await createVoice(identity, voiceInput.parse(await body(req))),
      );
    if (p[0] === "jobs" && p.length >= 2) {
      const id = z.uuid().parse(p[1]);
      if (p.length === 2 && !write) return json(await readVoice(identity, id));
      if (p.length === 3 && write) {
        if (p[2] === "upload") {
          ensure(
            req.headers.get("content-type")?.split(";")[0] ===
              "application/octet-stream",
            415,
            "请上传原始录音数据。",
          );
          const claim = await claimVoiceUpload(identity, id);
          try {
            return json(
              await storeVoiceUpload(
                identity,
                id,
                claim.lease,
                await read(req, Math.min(claim.bytes, VOICE_MAX_BYTES)),
                req.signal,
              ),
            );
          } catch (e) {
            await failVoiceLease(
              identity,
              id,
              claim.lease,
              "UPLOAD_FAILED",
            ).catch(() => {});
            throw e;
          }
        }
        z.strictObject({}).parse(await body(req));
        if (p[2] === "transcribe")
          return json(
            await transcribeVoice(identity, id, undefined, req.signal),
          );
        if (p[2] === "confirm" || p[2] === "cancel")
          return json(await finishVoice(identity, id, p[2]));
      }
    }
    throw new HttpError(404, "没有此接口。");
  } catch (e) {
    const status =
      e instanceof HttpError
        ? e.status
        : e instanceof z.ZodError ||
            e instanceof SyntaxError ||
            e instanceof URIError
          ? 400
          : 503;
    return json(
      {
        error:
          e instanceof HttpError
            ? e.message
            : status === 400
              ? "输入格式不正确。"
              : "语音服务暂不可用，你可以继续打字。",
      },
      status,
    );
  }
}
export const GET = handler;
export const POST = handler;
